/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.myscripts;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import jeeb.lib.util.Import;
import jeeb.lib.util.Log;
import jeeb.lib.util.Record;
import jeeb.lib.util.RecordSet;

/**
 * A format description to read a command file for Heterofor script mode.
 * One line = one simulation to be run, all outputs in one single outputFile
 * which name is in the command file.
 *
 * @author F. de Coligny - November 2012
 */
public class CommandFileReader_CORDEX extends RecordSet {

	/**
	 * One CommandLine per simulation to be processed
	 */
	@Import
	static public class CommandLine extends Record {
		public CommandLine() {
			super();
		}

		public CommandLine(String line) throws Exception {
			super(line);
		}

		// The fields below are in columns separated by tabs
		public String speciesFileName;
		public String inventoryFileName;
		public String soilHorizonsFileName;
		public String meteorologyFileName;
		public String heightGrowthOpt;
		public String outputDendroFile;
		public String outputHydroFile;
		public String isVariableAtmCO2;
		public String atmCO2ConcentrationsFileName;
		public String fixedAtmCO2Value;
	}

	public String commandFileName; // the script reads this file (passed as a parameter)
	public String outputDir;	   // directory for files specific to CORDEX simulations (data and output files)
	public String heteroforDataDir;   // regular directory for Heterofor data

	/**
	 * Default constructor.
	 */
	public CommandFileReader_CORDEX(String commandFileName) throws Exception {
		super();
		this.commandFileName = commandFileName;
		createRecordSet(commandFileName);
		interpret();
	}

	/**
	 * File Interpretation
	 */
	public void interpret() throws Exception {

		for (Iterator i = this.iterator(); i.hasNext();) {
			Object record = i.next();

			if (record instanceof KeyRecord) {
				CommandFileReader_CORDEX.KeyRecord r = (CommandFileReader_CORDEX.KeyRecord) record;

				if (r.hasKey("outputDir")) {
					try {
						outputDir = r.value;
						i.remove(); // only CommandLine instances are kept
					} catch (Exception e) {
						Log.println(
								Log.ERROR,
								"CommandFileReader.interpret ()",
								"Trouble with outputDir (" + r.value + ")",
								e);
						throw e;
					}

				} else
					if (r.hasKey("heteroforDataDir")) {
						try {
							heteroforDataDir = r.value;
							i.remove(); // only CommandLine instances are kept
						} catch (Exception e) {
							Log.println(
									Log.ERROR,
									"CommandFileReader.interpret ()",
									"Trouble with heteroforDataDir (" + r.value + ")",
									e);
							throw e;
						}

				}

			} else if (record instanceof CommandLine) {
				// do nothing, let it in the ArrayList, see
				// getCommandLines ()

			} else {
				throw new Exception("wrong format in " + commandFileName
						+ " near record " + record);
			}
		}

		// Check we have the outputDir and heteroforDataDir (requested). If not, stop
		if (outputDir == null) {
			throw new Exception(commandFileName + ": wrong outputDir: "
					+ outputDir);
		}
		if (heteroforDataDir == null) {
			throw new Exception(commandFileName + ": wrong heteroforDataDir: "
					+ heteroforDataDir);
		}


	}

	/**
	 * A convenient accessor to get the command lines in a list.
	 */
	public List<CommandLine> getCommandLines() {
		return new ArrayList<CommandLine>((Collection) this);
	}

	public String getOutputDirectory() {
		return outputDir;
	}

	public String getHeteroforDataDirectory() {
		return heteroforDataDir;
	}

}
