/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.myscripts;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import jeeb.lib.util.Check;
import jeeb.lib.util.Import;
import jeeb.lib.util.Log;
import jeeb.lib.util.Record;
import jeeb.lib.util.RecordSet;

/**
 * A format description to read a command file for Heterofor script mode.
 * One line = one simulation to be run, all outputs in one single outputFile
 * which name is in the command file.
 *
 * @author F. de Coligny - November 2012
 */
public class CommandFileReader extends RecordSet {

	/**
	 * One CommandLine per simulation to be processed
	 */
	@Import
	static public class CommandLine extends Record {
		public CommandLine() {
			super();
		}

		public CommandLine(String line) throws Exception {
			super(line);
		}

		// The fields below are in columns separated by tabs
		public String inventoryFileName; // relative to the working dir (the dir containing the command file)
		public String samsaraLightFileName; // relative to the working dir (the dir containing the command file)
		//public double sensorHeight; // m //commented by GL on 19/04/13
		public String LADoption; // "MEAN_LAD", "MEAN_SLA", "SLA_MODEL", "QUERGUS_LAD"
		public String Toption; //MEAN_T, QUERGUS_T
		public double LADNeighbourhoodDistance; // m
		public boolean fillGaps; // true, false

	}

	public String commandFileName; // the script reads this file (passed as a
										// parameter)

	public String speciesFileName; // e.g. "heterofor_species.txt", will be written in the same dir than the command file
	public String exportFileName; // e.g. "fic1.out", will be written in the same dir than the command file

	/**
	 * Default constructor.
	 */
	public CommandFileReader(String commandFileName) throws Exception {
		super();
		this.commandFileName = commandFileName;
		createRecordSet(commandFileName);
		interpret();
	}

	/**
	 * File Interpretation
	 */
	public void interpret() throws Exception {

		for (Iterator i = this.iterator(); i.hasNext();) {
			Object record = i.next();

			if (record instanceof KeyRecord) {
				CommandFileReader.KeyRecord r = (CommandFileReader.KeyRecord) record;

				if (r.hasKey("exportFileName")) {
					try {
						exportFileName = r.value;
						i.remove(); // only CommandLine instances are kept
					} catch (Exception e) {
						Log.println(
								Log.ERROR,
								"CommandFileReader.interpret ()",
								"Trouble with exportFileName (" + r.value + ")",
								e);
						throw e;
					}

				} else
					if (r.hasKey("speciesFileName")) {
						try {
							speciesFileName = r.value;
							i.remove(); // only CommandLine instances are kept
						} catch (Exception e) {
							Log.println(
									Log.ERROR,
									"CommandFileReader.interpret ()",
									"Trouble with speciesFileName (" + r.value + ")",
									e);
							throw e;
						}

				}

			} else if (record instanceof CommandLine) {
				// do nothing, let it in the ArrayList, see
				// getCommandLines ()

			} else {
				throw new Exception("wrong format in " + commandFileName
						+ " near record " + record);
			}
		}

		// Check we have the exportFileName (requested). If not, stop
		if (exportFileName == null) {
			throw new Exception(commandFileName + ": wrong exportFileName: "
					+ exportFileName);
		}

	}

	/**
	 * A convenient accessor to get the command lines in a list.
	 */
	public List<CommandLine> getCommandLines() {
		return new ArrayList<CommandLine>((Collection) this);
	}

	public String getExportFileName() {
		return exportFileName;
	}

	public String getSpeciesFileName() {
		return speciesFileName;
	}



}
