# A script to perform optimization of HETEROFOR radiative balance parameters (crown form, ladOption, lad parametrization, turbid medium or porous envelop)


## Function launching Capsis simulations
# Function for optimization
Heterofor.Optimization_func <- function (CapsisDir, reconstructionExportFileName, simulationExportFileName, logFilePath, turbidMediumActivated, crownForm, ladOption, 
                                         extCoef_oak_arg, extCoef_beech_arg, extCoef_carpinus_arg, extCoef_others_arg, 
                                         SLAbottom_oak_arg, SLAbottom_beech_arg, SLAbottom_carpinus_arg, SLAbottom_others_arg, 
                                         SLAtop_oak_arg, SLAtop_beech_arg, SLAtop_carpinus_arg, SLAtop_others_arg, 
                                         UFLB_oak_arg, UFLB_beech_arg, UFLB_carpinus_arg, UFLB_others_arg, 
                                         alpha_oak_arg, alpha_beech_arg, alpha_carpinus_arg, alpha_others_arg, 
                                         beta_oak_arg, beta_beech_arg, beta_carpinus_arg, beta_others_arg, 
                                         MRcoef_oak_Baileux_arg, MRcoef_beech_Baileux_arg, MRcoef_carpinus_Baileux_arg, MRcoef_others_Baileux_arg, 
                                         MRcoef_oak_Chimay_arg, MRcoef_beech_Chimay_arg, MRcoef_carpinus_Chimay_arg, MRcoef_others_Chimay_arg, 
                                         MRcoef_oak_LLN_arg, MRcoef_beech_LLN_arg, MRcoef_carpinus_LLN_arg, MRcoef_others_LLN_arg, 
                                         MRcoef_oak_Virton_arg, MRcoef_beech_Virton_arg, MRcoef_carpinus_Virton_arg, MRcoef_others_Virton_arg,
                                         reconstructionActivated_arg, growthCompetitionAccounted_arg) {
  
  if (.Platform$OS.type == "windows") {
    cmd = paste("capsis -p script heterofor.myscripts.Castanea_MRcoef_10years", CapsisDir, reconstructionExportFileName, simulationExportFileName,
                turbidMediumActivated, crownForm, ladOption,
                extCoef_oak_arg, extCoef_beech_arg, extCoef_carpinus_arg, extCoef_others_arg,
                SLAbottom_oak_arg, SLAbottom_beech_arg, SLAbottom_carpinus_arg, SLAbottom_others_arg,
                SLAtop_oak_arg, SLAtop_beech_arg, SLAtop_carpinus_arg, SLAtop_others_arg,
                UFLB_oak_arg, UFLB_beech_arg, UFLB_carpinus_arg, UFLB_others_arg,
                alpha_oak_arg, alpha_beech_arg, alpha_carpinus_arg, alpha_others_arg,
                beta_oak_arg, beta_beech_arg, beta_carpinus_arg, beta_others_arg,
                MRcoef_oak_Baileux_arg, MRcoef_beech_Baileux_arg, MRcoef_carpinus_Baileux_arg, MRcoef_others_Baileux_arg, 
                MRcoef_oak_Chimay_arg, MRcoef_beech_Chimay_arg, MRcoef_carpinus_Chimay_arg, MRcoef_others_Chimay_arg, 
                MRcoef_oak_LLN_arg, MRcoef_beech_LLN_arg, MRcoef_carpinus_LLN_arg, MRcoef_others_LLN_arg, 
                MRcoef_oak_Virton_arg, MRcoef_beech_Virton_arg, MRcoef_carpinus_Virton_arg, MRcoef_others_Virton_arg,
                reconstructionActivated_arg, growthCompetitionAccounted_arg,
                "2>&1 >", logFilePath,
                sep = " ");
  } else {
    cmd = paste("sh capsis.sh -p script heterofor.myscripts.Castanea_MRcoef_10years", CapsisDir, reconstructionExportFileName, simulationExportFileName,
                turbidMediumActivated, crownForm, ladOption,
                extCoef_oak_arg, extCoef_beech_arg, extCoef_carpinus_arg, extCoef_others_arg,
                SLAbottom_oak_arg, SLAbottom_beech_arg, SLAbottom_carpinus_arg, SLAbottom_others_arg,
                SLAtop_oak_arg, SLAtop_beech_arg, SLAtop_carpinus_arg, SLAtop_others_arg,
                UFLB_oak_arg, UFLB_beech_arg, UFLB_carpinus_arg, UFLB_others_arg,
                alpha_oak_arg, alpha_beech_arg, alpha_carpinus_arg, alpha_others_arg,
                beta_oak_arg, beta_beech_arg, beta_carpinus_arg, beta_others_arg,
                MRcoef_oak_Baileux_arg, MRcoef_beech_Baileux_arg, MRcoef_carpinus_Baileux_arg, MRcoef_others_Baileux_arg, 
                MRcoef_oak_Chimay_arg, MRcoef_beech_Chimay_arg, MRcoef_carpinus_Chimay_arg, MRcoef_others_Chimay_arg, 
                MRcoef_oak_LLN_arg, MRcoef_beech_LLN_arg, MRcoef_carpinus_LLN_arg, MRcoef_others_LLN_arg, 
                MRcoef_oak_Virton_arg, MRcoef_beech_Virton_arg, MRcoef_carpinus_Virton_arg, MRcoef_others_Virton_arg,
                reconstructionActivated_arg, growthCompetitionAccounted_arg,
                "2>&1 >", logFilePath,
                sep = " ");
  }
  
  print(cmd)
  
  if (.Platform$OS.type == "windows") {
    shell(cmd);
  } else{
    system(cmd);
  }
  
  ReconstructionDataFile <- read.table(reconstructionExportFileName, header = TRUE)
  SimulationDataFile <- read.table(simulationExportFileName, header = TRUE)
  
  # RecSim <- cbind(ReconstructionDataFile$plotName, ReconstructionDataFile$year, ReconstructionDataFile$treeId, ReconstructionDataFile$deltaD2H, SimulationDataFile$plotName, SimulationDataFile$year, SimulationDataFile$treeId, SimulationDataFile$deltaD2H)
  # RecSim <- cbind(ReconstructionDataFile$plotName, ReconstructionDataFile$year, ReconstructionDataFile$treeId, ReconstructionDataFile$deltaD2H, SimulationDataFile$plotName, SimulationDataFile$year, SimulationDataFile$treeId, SimulationDataFile$deltaD2H, SimulationDataFile$NppGppRatio) # 03.11.2018
  RecSim <- cbind(ReconstructionDataFile$plotName, ReconstructionDataFile$year, ReconstructionDataFile$treeId, ReconstructionDataFile$deltaD2H, ReconstructionDataFile$DBH, SimulationDataFile$plotName, SimulationDataFile$year, SimulationDataFile$treeId, SimulationDataFile$deltaD2H, SimulationDataFile$DBH, ReconstructionDataFile$species) # 05.02.2019
  
  RecSim_sub <- subset(RecSim, as.numeric(RecSim[,4]) > 0.005 & as.numeric(RecSim[,4]) < 0.7)
  RecSim_sub <- subset(RecSim_sub , !(RecSim_sub[,1] == "Baileux_beech" & RecSim_sub[,11] == "coniferous")) # 05.02.2019
  RecSim_sub <- subset(RecSim_sub , !(RecSim_sub[,1] == "Baileux_mixed" & RecSim_sub[,11] == "carpinus")) # 05.02.2019
  RecSim_sub <- subset(RecSim_sub , !(RecSim_sub[,1] == "Baileux_oak" & RecSim_sub[,11] == "broadleaved")) # 05.02.2019
  RecSim_sub <- subset(RecSim_sub , !(RecSim_sub[,1] == "Chimay_level_II_plot" & RecSim_sub[,11] == "broadleaved")) # 05.02.2019
  RecSim_sub <- subset(RecSim_sub , !(RecSim_sub[,1] == "Virton_level_II_plot" & RecSim_sub[,11] == "carpinus")) # 05.02.2019
  RecSim_sub <- subset(RecSim_sub , !(RecSim_sub[,1] == "Virton_level_II_plot" & RecSim_sub[,11] == "quercus")) # 05.02.2019
  
  return(RecSim_sub)
}

# likelihood <- function(p) {
#   
#       # # Check for bounds
#       # for (i in 1:length(p)){
#       #       if (p[i] <= LB[i] || p[i] >= UB[i]){
#       #             return(.Machine$double.xmax)
#       #       }
#       # }
#   
#   
#       extCoef_oak = p[1]
#       extCoef_beech = p[2]
#       extCoef_carpinus = p[3]
#       extCoef_others = p[4]
#       
#       SLAbottom_oak = 20.0
#       SLAbottom_beech = 30.0
#       # SLAbottom_carpinus = p[3]
#       # SLAbottom_others = p[3]
#       
#       SLAtop_oak = 5.9
#       SLAtop_beech = 9.9
#       # SLAtop_carpinus = p[3]
#       # SLAtop_others = p[3]
#       
#       UFLB_oak = 0.9419424 # value from radiative balance optimization #  p[5]
#       UFLB_beech = 0.8624056 # value from radiative balance optimization #  p[6]
#       UFLB_carpinus = 0.364868 # value from radiative balance optimization #  p[7]
#       UFLB_others = 0.4693958 # value from radiative balance optimization #  p[8]
#       
#       alpha_oak = 0.005
#       alpha_beech = 1.469
#       alpha_carpinus = 15.3816
#       alpha_others = 0.005
#       
#       beta_oak = 1.96
#       beta_beech = 2.0
#       beta_carpinus = 1.3354
#       beta_others = 1.96
# #       
#         MRcoef_oak_Baileux = 10^(p[5])
#         MRcoef_beech_Baileux = 10^(p[6])
#         MRcoef_carpinus_Baileux = 10^(p[7])
#         MRcoef_others_Baileux = 10^(p[4])
# 
#         MRcoef_oak_Chimay = 10^(p[8])
#         MRcoef_beech_Chimay = 10^(p[6]) 
#         MRcoef_carpinus_Chimay = 10^(p[9])
#         MRcoef_others_Chimay = 10^(p[8])
# 
#         MRcoef_oak_LLN = 10^(p[10])
#         MRcoef_beech_LLN = 10^(p[11]) 
#         MRcoef_carpinus_LLN = 10^(p[11])
#         MRcoef_others_LLN = 10^(p[12])
# 
#         MRcoef_oak_Virton = 10^(p[13])
#         MRcoef_beech_Virton = 10^(p[12]) 
#         MRcoef_carpinus_Virton = 10^(p[15])
#         MRcoef_others_Virton = 10^(p[13])
#       
#       measSigma_D2H = 10^(p[18])
# #      measSigma_RadBal = p[30]
#   
#       # NPP
#       RecSim <- Heterofor.Optimization_func(CapsisDir, reconstructionExportFileName, simulationExportFileName, logFilePath, turbidMediumActivated, crownForm, ladOption, 
#                                             extCoef_oak, extCoef_beech, extCoef_carpinus, extCoef_others, 
#                                             SLAbottom_oak, SLAbottom_beech, SLAbottom_carpinus, SLAbottom_others, 
#                                             SLAtop_oak, SLAtop_beech, SLAtop_carpinus, SLAtop_others,
#                                             UFLB_oak, UFLB_beech, UFLB_carpinus,  UFLB_others,
#                                             alpha_oak, alpha_beech, alpha_carpinus, alpha_others, 
#                                             beta_oak, beta_beech, beta_carpinus, beta_others, 
#                                             NppToGppRatio_intercept_oak_Baileux, NppToGppRatio_intercept_beech_Baileux, NppToGppRatio_intercept_carpinus_Baileux, NppToGppRatio_intercept_others_Baileux,
#                                             NppToGppRatio_slope_oak_Baileux, NppToGppRatio_slope_beech_Baileux, NppToGppRatio_slope_carpinus_Baileux, NppToGppRatio_slope_others_Baileux,
#                                             NppToGppRatio_intercept_oak_Chimay, NppToGppRatio_intercept_beech_Chimay, NppToGppRatio_intercept_carpinus_Chimay, NppToGppRatio_intercept_others_Chimay, 
#                                             NppToGppRatio_slope_oak_Chimay, NppToGppRatio_slope_beech_Chimay, NppToGppRatio_slope_carpinus_Chimay, NppToGppRatio_slope_others_Chimay, 
#                                             NppToGppRatio_intercept_oak_LLN, NppToGppRatio_intercept_beech_LLN, NppToGppRatio_intercept_carpinus_LLN, NppToGppRatio_intercept_others_LLN, 
#                                             NppToGppRatio_slope_oak_LLN, NppToGppRatio_slope_beech_LLN, NppToGppRatio_slope_carpinus_LLN, NppToGppRatio_slope_others_LLN, 
#                                             NppToGppRatio_intercept_oak_Virton, NppToGppRatio_intercept_beech_Virton, NppToGppRatio_intercept_carpinus_Virton, NppToGppRatio_intercept_others_Virton,
#                                             NppToGppRatio_slope_oak_Virton, NppToGppRatio_slope_beech_Virton, NppToGppRatio_slope_carpinus_Virton, NppToGppRatio_slope_others_Virton,
#                                             reconstructionActivated, growthCompetitionAccounted)
#       Rec <- as.numeric(RecSim[,4])/((as.numeric(RecSim[,5])/100)^2) #05.02.2019: deltaD2H/D2
#       Sim <- as.numeric(RecSim[,9])/((as.numeric(RecSim[,10])/100)^2) #05.02.2019: deltaD2H/D2
#       
#       # if (min(TreeNppGppRatio) <= 0.2 || max(TreeNppGppRatio) >= 0.8) { # 03.11.2018: Unrealistic values for NppGppRatio => associated with low likelihood value
#       #   
#       #   return(-.Machine$integer.max)
#       #   
#       # } else {
# 
#         # k = 0.5
#         # residuals_D2H <- (Sim - Rec)/(Rec^k)
#       
#       residuals_D2H <- Sim - Rec
#       
#       llValues_D2H <- dnorm(residuals_D2H, sd = measSigma_D2H, log = TRUE) # corresponds to lik 12 in Table B1 of Vrugt EMS2016 p.307
#       
#         return(sum(llValues_D2H))
#       
#       # }
# }


## Main program
s=1
# s = as.numeric(Sys.getenv("SLURM_ARRAY_TASK_ID")) # Job array index
# jobId = as.character(Sys.getenv("SLURM_ARRAY_JOB_ID"))
# taskId = as.character(Sys.getenv("SLURM_ARRAY_TASK_ID"))

## A. Set working environment
# Capsis install directory
if (.Platform$OS.type == "windows"){
  CapsisDir = "C:/DocumentsUCL/Capsis4"
} else {
  homePath = system("echo $HOME", intern = TRUE)
#  CapsisDirCeciHome = "/CECI/home/users/a/n/andref/Capsis4_8may2018_CORRECTED/"
  CapsisDir = paste(homePath, "/Capsis4_5fev2019/", sep = "")
}
setwd(CapsisDir) # Set working directory


## B. Optimization configuration
# Settings (considered as common to all species)
turbidMediumActivated <- "true"
crownFormVector <- c("M")
crownForm <- crownFormVector[s]
ladOption <- 2 #0: mean LAD, 1: mean SLA, 2: SLA model, 3: Quergus LAD
growthCompetitionAccounted <- "false"
# settingString = paste("/",crownForm,"_TM",turbidMediumActivated,"_LAD",as.character(ladOption),"_D2H_AlphaBetaCst_SLAext_CoefExtOpt_UFLBFix_Ratio_Fev2019", sep = "")
# 
if (.Platform$OS.type != "windows") {
  # if (machineAbrev == "mann") { # Manneback (no $LOCALSCRATCH)
  #  localScratchPath = system("echo $GLOBALSCRATCH", intern = TRUE) #!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  # } else {
  localScratchPath = system("echo $LOCALSCRATCH", intern = TRUE)
  # }
  logFileName = paste("logFile_LAD",as.character(ladOption),"_",jobId,"_",taskId,".txt", sep = "")
  logFilePath = paste(localScratchPath,"/",logFileName, sep = "")
} else {
  logFilePath = paste(CapsisDir,"/","logFile_optim.txt", sep = "")
}

# Export filename for Capsis output
if (.Platform$OS.type == "windows") {
  # outputDirPath = paste(CapsisDir, "/src/heterofor/myscripts/CalibRadiationInterception/DREAMzs", settingString, sep = "")
  reconstructionExportFileName = paste("Reconstruction_Castanea_MRcoef_10years.txt", sep = "")
  simulationExportFileName = paste("Simulation_Castanea_MRcoef_10years.txt", sep = "")
} else {
  outputDirPath=paste(localScratchPath, settingString, "_", jobId, "_", taskId, sep = "")
  reconstructionExportFileName = paste(outputDirPath, "/Reconstruction_", crownFormVector[s], ".out", sep = "")
  simulationExportFileName = paste(outputDirPath, "/Simulation_", crownFormVector[s], ".out", sep = "")
}
# dir.create(outputDirPath)


# Set initial guesses to parameter values from speciesFile
# 1-Read speciesFile
speciesFile <- paste("/data/heterofor/heterofor_species_CalibNLMBaileuxMixed19022019_WaterBalance.txt", sep = "")
speciesParameters <- data.frame()
con <- file(paste(CapsisDir, speciesFile, sep = ""), open = "r")
conLine <- scan(con, character(0), nlines = 1, sep = "\t", quiet = TRUE)
while (conLine[1] != "# speciesId"){
  conLine <- scan(con, character(0), nlines = 1, sep = "\t", quiet = TRUE)
}
parameterNames <- conLine

options(stringsAsFactors=FALSE)
for (l in 1:6){ # Read species parameters
  conLine <- scan(con, character(0), nlines = 1, sep = "\t", quiet = TRUE)
  speciesParameters <- rbind(speciesParameters, conLine)
}
names(speciesParameters) <- parameterNames
close(con)
# 2-Set initial guesses
extCoef_oak <- as.double(speciesParameters$extinctionCoefficient[1])
extCoef_beech <- as.double(speciesParameters$extinctionCoefficient[2])
extCoef_carpinus <- as.double(speciesParameters$extinctionCoefficient[3])
extCoef_others <- as.double(speciesParameters$extinctionCoefficient[4])

SLAbottom_oak <- as.double(speciesParameters$SLAbottom[1])
SLAbottom_beech <- as.double(speciesParameters$SLAbottom[2])
SLAbottom_carpinus <- as.double(speciesParameters$SLAbottom[3])
SLAbottom_others <- as.double(speciesParameters$SLAbottom[4])

SLAtop_oak <- as.double(speciesParameters$SLAtop[1])
SLAtop_beech <- as.double(speciesParameters$SLAtop[2])
SLAtop_carpinus <- as.double(speciesParameters$SLAtop[3])
SLAtop_others <- as.double(speciesParameters$SLAtop[4])

UFLB_oak <- as.double(speciesParameters$UFLB[1])
UFLB_beech <- as.double(speciesParameters$UFLB[2])
UFLB_carpinus <- as.double(speciesParameters$UFLB[3])
UFLB_others <- as.double(speciesParameters$UFLB[4])

# oak
strLeafBiom_oak <- speciesParameters$leafBiomassAllometry[1]
indexBracket <- gregexpr("(", strLeafBiom_oak, fixed=TRUE)[[1]][1] #index of character "("
indexComa1 <- gregexpr(";", strLeafBiom_oak, fixed=TRUE)[[1]][1] #index of first ";"
indexComa2 <- gregexpr(";", strLeafBiom_oak, fixed=TRUE)[[1]][2] #index of second ";"
alpha_oak = alpha_oak <- as.double(substr(strLeafBiom_oak, indexBracket+1, indexComa1-1))
beta_oak = beta_oak <- as.double(substr(strLeafBiom_oak, indexComa1+1, indexComa2-1))
# beech
strLeafBiom_beech <- speciesParameters$leafBiomassAllometry[2]
indexBracket <- gregexpr("(", strLeafBiom_beech, fixed=TRUE)[[1]][1] #index of character "("
indexComa1 <- gregexpr(";", strLeafBiom_beech, fixed=TRUE)[[1]][1] #index of first ";"
indexComa2 <- gregexpr(";", strLeafBiom_beech, fixed=TRUE)[[1]][2] #index of second ";"
alpha_beech = alpha_beech <- as.double(substr(strLeafBiom_beech, indexBracket+1, indexComa1-1))
beta_beech = beta_beech <- as.double(substr(strLeafBiom_beech, indexComa1+1, indexComa2-1))
# carpinus
strLeafBiom_carpinus <- speciesParameters$leafBiomassAllometry[3]
indexBracket <- gregexpr("(", strLeafBiom_carpinus, fixed=TRUE)[[1]][1] #index of character "("
indexComa1 <- gregexpr(";", strLeafBiom_carpinus, fixed=TRUE)[[1]][1] #index of first ";"
indexComa2 <- gregexpr(";", strLeafBiom_carpinus, fixed=TRUE)[[1]][2] #index of second ";"
alpha_carpinus = alpha_carpinus <- as.double(substr(strLeafBiom_carpinus, indexBracket+1, indexComa1-1))
beta_carpinus = beta_carpinus <- as.double(substr(strLeafBiom_carpinus, indexComa1+1, indexComa2-1))
# others
strLeafBiom_others <- speciesParameters$leafBiomassAllometry[4]
indexBracket <- gregexpr("(", strLeafBiom_others, fixed=TRUE)[[1]][1] #index of character "("
indexComa1 <- gregexpr(";", strLeafBiom_others, fixed=TRUE)[[1]][1] #index of first ";"
indexComa2 <- gregexpr(";", strLeafBiom_others, fixed=TRUE)[[1]][2] #index of second ";"
alpha_others = alpha_others <- as.double(substr(strLeafBiom_others, indexBracket+1, indexComa1-1))
beta_others = beta_others <- as.double(substr(strLeafBiom_others, indexComa1+1, indexComa2-1))

MRcoef_oak_Baileux <- as.double(speciesParameters$referenceMaintenanceRespiration[1])
MRcoef_beech_Baileux <- as.double(speciesParameters$referenceMaintenanceRespiration[2])
MRcoef_carpinus_Baileux <- as.double(speciesParameters$referenceMaintenanceRespiration[3])
MRcoef_others_Baileux <- as.double(speciesParameters$referenceMaintenanceRespiration[4])

MRcoef_oak_Chimay <- as.double(speciesParameters$referenceMaintenanceRespiration[1])
MRcoef_beech_Chimay <- as.double(speciesParameters$referenceMaintenanceRespiration[2])
MRcoef_carpinus_Chimay <- as.double(speciesParameters$referenceMaintenanceRespiration[3])
MRcoef_others_Chimay <- as.double(speciesParameters$referenceMaintenanceRespiration[4])

MRcoef_oak_LLN <- as.double(speciesParameters$referenceMaintenanceRespiration[1])
MRcoef_beech_LLN <- as.double(speciesParameters$referenceMaintenanceRespiration[2])
MRcoef_carpinus_LLN <- as.double(speciesParameters$referenceMaintenanceRespiration[3])
MRcoef_others_LLN <- as.double(speciesParameters$referenceMaintenanceRespiration[4])

MRcoef_oak_Virton <- as.double(speciesParameters$referenceMaintenanceRespiration[1])
MRcoef_beech_Virton <- as.double(speciesParameters$referenceMaintenanceRespiration[2])
MRcoef_carpinus_Virton <- as.double(speciesParameters$referenceMaintenanceRespiration[3])
MRcoef_others_Virton <- as.double(speciesParameters$referenceMaintenanceRespiration[4])

initGuess <- c(extCoef_oak, extCoef_beech, extCoef_carpinus, extCoef_others, 
               SLAbottom_oak, SLAbottom_beech, SLAbottom_carpinus, SLAbottom_others, 
               SLAtop_oak, SLAtop_beech, SLAtop_carpinus, SLAtop_others, 
               UFLB_oak, UFLB_beech, UFLB_carpinus, UFLB_others, 
               alpha_oak, alpha_beech, alpha_carpinus, alpha_others, 
               beta_oak, beta_beech, beta_carpinus, beta_others, 
               MRcoef_oak_Baileux, MRcoef_beech_Baileux, MRcoef_carpinus_Baileux, MRcoef_others_Baileux, 
               MRcoef_oak_Chimay, MRcoef_beech_Chimay, MRcoef_carpinus_Chimay, MRcoef_others_Chimay, 
               MRcoef_oak_LLN, MRcoef_beech_LLN, MRcoef_carpinus_LLN, MRcoef_others_LLN, 
               MRcoef_oak_Virton, MRcoef_beech_Virton, MRcoef_carpinus_Virton, MRcoef_others_Virton)

# 3-Optimization bounds


# LB <- c(0.30, 0.30, 0.30, 0.30,  # ExtCoef
#         -8.0, -8.0, -8.0,        # MRcoef_Baileux
#         -8.0, -8.0,              # MRcoef_Chimay
#         -8.0, -8.0,              # MRcoef_LLN
#         -8.0, -8.0,              # MRcoef_Virton
#         -10.0)                   # measSigma_D2H
# 
# UB <- c(0.70, 0.70, 0.70, 0.70,  # ExtCoef
#         -1.0, -1.0, -1.0,        # MRcoef_Baileux
#         -1.0, -1.0,              # MRcoef_Chimay
#         -1.0, -1.0,              # MRcoef_LLN
#         -1.0, -1.0,              # MRcoef_Virton
#         10.0)                    # measSigma_D2H
# 
# parNames <- c("extCoef_oak","extCoef_beech","extCoef_carpinus","extCoef_others",
#               "MRcoef_oak_Baileux","MRcoef_beech_Baileux","MRcoef_carpinus_Baileux",
#               "MRcoef_oak_Chimay","MRcoef_carpinus_Chimay",
#               "MRcoef_oak_LLN","MRcoef_beech_LLN",
#               "MRcoef_beech_Virton","MRcoef_others_Virton",
#               "measSigma_D2H")


# 4-Optimization

# First run for computation of reconstruction
reconstructionActivated <- "true"
RecSim_init <- Heterofor.Optimization_func(CapsisDir, reconstructionExportFileName, simulationExportFileName, logFilePath, turbidMediumActivated, crownForm, ladOption,
                                           extCoef_oak, extCoef_beech, extCoef_carpinus, extCoef_others, 
                                           SLAbottom_oak, SLAbottom_beech, SLAbottom_carpinus, SLAbottom_others, 
                                           SLAtop_oak, SLAtop_beech, SLAtop_carpinus, SLAtop_others, 
                                           UFLB_oak, UFLB_beech, UFLB_carpinus, UFLB_others, 
                                           alpha_oak, alpha_beech, alpha_carpinus,alpha_others, 
                                           beta_oak, beta_beech, beta_carpinus, beta_others,
                                           MRcoef_oak_Baileux, MRcoef_beech_Baileux, MRcoef_carpinus_Baileux, MRcoef_others_Baileux, 
                                           MRcoef_oak_Chimay, MRcoef_beech_Chimay, MRcoef_carpinus_Chimay, MRcoef_others_Chimay, 
                                           MRcoef_oak_LLN, MRcoef_beech_LLN, MRcoef_carpinus_LLN, MRcoef_others_LLN, 
                                           MRcoef_oak_Virton, MRcoef_beech_Virton, MRcoef_carpinus_Virton, MRcoef_others_Virton,
                                           reconstructionActivated, growthCompetitionAccounted)
# reconstructionActivated <- "false" # Computation of reconstruction not necessary after first run

# p <- initGuess
#L <- likelihood(p)
# fit <- nlm(SSQ, p, iterlim = 10000, print.level = 2)
#fit <- hydroPSO(fn=SSQ, lower=LB, upper=UB, control=list(npart=20, maxit=200, Xini.type='lhs', reltol=1e-10, normalise=TRUE, REPORT=10, write2disk=TRUE, drty.out=OptimResultsDir))
#fit <- hydroPSO(fn=SSQ, method='spso2011', lower=LB, upper=UB, control=list(npart=25, maxit=650, Xini.type='lhs', Vini.type='lhs2011', reltol=0, boundary.wall='absorbing2011', normalise=TRUE, REPORT=100, write2disk=TRUE, drty.out=outputDirPath))

# prior <- createUniformPrior(lower = LB, upper = UB)
# bayesianSetup <- createBayesianSetup(likelihood, prior, names = parNames)
# settings = list(iterations = 30000, nCR = 3, gamma = NULL, eps = 0, e = 0.05, pCRupdate = TRUE, updateInterval = 10, burnin = 0, thin = 1, adaptation = 0.2, parallel = NULL, Z = NULL, ZupdateFrequency = 10, pSnooker = 0.1, DEpairs = 2, consoleUpdates = 10, startValue = NULL, currentChain = 1, message = TRUE)
# # settings = list(iterations = 30000, nCR = 3, gamma = NULL, eps = 0, e = 0.05, pCRupdate = FALSE, updateInterval = 10, burnin = 0, thin = 1, adaptation = 0.2, parallel = NULL, Z = NULL, ZupdateFrequency = 10, pSnooker = 0.1, DEpairs = 2, consoleUpdates = 10, startValue = NULL, currentChain = 1, message = TRUE)
# out <- runMCMC(bayesianSetup = bayesianSetup, sampler = "DREAMzs", settings = settings)

# 5-Printing and saving optimization results
#plot(out)
#marginalPlot(out)
#correlationPlot(out)
#gelmanDiagnostics(out, plot=T)


# OutputFileName = paste(outputDirPath,"/CalibrationResults.RData", sep = "")
# save(out, file = OutputFileName)


# # Copy results and remove tmp files on local scratch
# if (.Platform$OS.type != "windows") {
#   finalOutputDirPath = paste(CapsisDir, "src/heterofor/myscripts/CalibRadiationInterception/Clusters/DREAMzs", sep = "")
#   copyCmd = paste("cp -a ", outputDirPath, " ", finalOutputDirPath, sep = "")
#   system(copyCmd)
#   # finalOutputDirPathCeciHome = paste(CapsisDirCeciHome, "src/heterofor/myscripts/CalibRadiationInterception/Clusters/DREAMzs", sep = "")
#   # copyCmd = paste("cp -a ", outputDirPath, " ", finalOutputDirPathCeciHome, sep = "")
#   # system(copyCmd)
#   unlink(outputDirPath, recursive=TRUE)
# }





