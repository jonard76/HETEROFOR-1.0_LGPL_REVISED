/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.extension.ioformat;

import heterofor.model.HetModel;
import heterofor.model.HetScene;
import heterofor.model.HetTree;

import java.util.Date;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

import jeeb.lib.util.Import;
import jeeb.lib.util.Log;
import jeeb.lib.util.Record;
import jeeb.lib.util.Translator;
import capsis.kernel.GModel;
import capsis.kernel.GScene;
import capsis.kernel.Project;
import capsis.kernel.Step;
import capsis.util.GTreeIdComparator;
import capsis.util.StandRecordSet;

/**
 * HetExport exports an Heterofor scene to a file.
 *
 * @author F. de Coligny - November 2013
 */
public class HetExport extends StandRecordSet {

	static {
		Translator.addBundle("heterofor.extension.ioformat.ExportLabels");
	}

	// Extension properties
	// nb-13.08.2018
	//static public String NAME = Translator.swap("HetExport");
	//static public String AUTHOR = "F. de Coligny, M. Jonard";
	//static public String VERSION = "1.1";
	//static public String DESCRIPTION = Translator.swap("HetExport.description");

	// A tree line in the file
	@Import
	static public class TreeLine extends Record {

		public TreeLine() {
			super();
		}

		public TreeLine(String line) throws Exception {
			super(line);
		}

		// public String getSeparator () {return ";";} // to change default "\t"
		// separator
		public int date; // unique in the scene
		public int id; // unique in the scene
		public double x;
		public double y;
		public double z;
		public double dbh;
		public double height;
		public String speciesName;

		public double hlce; // height at the largest crown extension (m)
		public double hcb; // height of the crown base (m)
		public double rnorth; // crown radius in the North direction (m)
		public double reast; // crown radius in the East direction (m)
		public double rsouth; // crown radius in the South direction (m)
		public double rwest; // crown radius in the West direction (m)
		public String crownForm; // Ec, Ed, Bc, Bd, M
		public double leafLitterAmount; // kg
		public int LADoption; // see HetInitialParameters
		public int Toption; // see HetInitialParameters
		public boolean virtual;
		public double mean2CrownRadius; // quadratic mean crown radius (cm)

		public double leafBiomass; // kgC
		public double branchBiomass; // kgC
		public double stemBiomass; // kgC
		public double rootBiomass; // kgC = belowGroundBiomass
		public double fineRootBiomass; // kgC

		public double leafArea; // m2

		public double sunlitLeafArea; // m2 // fc+mj-13.9.2017
		public double shadedLeafArea; // m2 // fc+mj-13.9.2017

		public double crownVolume; // m3
		public double crownVolumeUp; //fa-06.12.2018
		public double crownVolumeDown; //fa-06.132.2018
		public double crownLAD; // m2/m3
		public double LADup; //fa-06.12.2018
		public double LADdown; //fa-06.12.2018
		public double SLAup; //fa-06.12.2018
		public double SLAdown; //fa-06.12.2018
		public double crownLength; // m
		public double crownProjection; // m2
		public double uflb; //fa-06.12.2018

		// Light
		public double crownDirectEnergy;
		public double crownDiffuseEnergy;
		public double crownPotentialEnergy;
		public double crownEnergy;

		// Growth variables
		public double interceptedParRadiation;

		public double interceptedDirectParRadiation; // fc+mj-13.9.2017
		public double interceptedDiffuseParRadiation; // fc+mj-13.9.2017

		public double grossPrimaryProduction;
		public double stemLivingFraction;
		public double maintenanceRespiration;
		public double leafRetranslocation;
		public double fineRootRetranslocation;
		public double netPrimaryProduction;
		public double newLeafBiomassProduction;
		public double newFineRootBiomassProduction;
		public double totalStructuralBiomassToAllocate;
		public double branchLitterFall;
		public double rootLitterFall;
		public double fruitLitterFall; //fa+mj-05.12.2017
		public double deltaAboveGroundStructuralBiomass;
		public double deltaDbh_cm; // fa-02.11.2018
		public double deltaHeight; // fa-02.11.2018
		public double deltaG; //fa-02.11.2018
		public double deltaDbh2Height; // fa-02.11.2018
		public double residual;
		public double stemAllocationCoefficient;
		public double rootAllocationCoefficient;
		public double branchAllocationCoefficient;

		// PAR Use Efficiency // fc+mj added 25.3.2016
		public double lightCompetitionIndex;
		public double parUseEfficiency;

		// fc+mj+fa-14.11.2017
		public double yearlyTranspiration;
		public double yearlyPotentialTranspiration;

	}

	/**
	 * Constructor
	 */
	public HetExport() {
		super();
		// Do not write the standard header lines in the output file
		setHeaderEnabled(false);
	}

	/**
	 * Extension dynamic compatibility mechanism. This matchWith method checks
	 * if the extension can deal (i.e. is compatible) with the referent.
	 */
	static public boolean matchWith(Object referent) {
		try {
			if (!(referent instanceof HetModel)) {
				return false;
			}

		} catch (Exception e) {
			Log.println(Log.ERROR, "HetExport.matchWith ()", "Error in matchWith () (returned false)", e);
			return false;
		}

		return true;
	}

	@Override
	public String getName() {
		return Translator.swap("HetExport.name");
	}

	@Override
	public String getAuthor() {
		return "F. de Coligny, M. Jonard";
	}

	@Override
	public String getDescription() {
		return Translator.swap("HetExport.description");
	}

	@Override
	public String getVersion() {
		return "1.1";
	}

	/**
	 * Export: turns the given Scene into a collection of records In script
	 * mode, save (fileName) must be called after.
	 */
	@Override
	public void createRecordSet(GScene s) throws Exception {
		HetScene scene = (HetScene) s;
		super.createRecordSet(scene); // deals with RecordSet's source

		// 1. Custom headers
		add(new CommentRecord("Heterofor scene export (HetExport) at " + new Date()));
		add(new EmptyRecord());

		// Tree line header
		add(new CommentRecord("Trees"));
		add(new CommentRecord(
				"date\tid\tx\ty\tz\tdbh\theight\tspeciesName\thlce\thcb\trnorth\treast\trsouth\trwest\tcrownForm\tleafLitterAmount\tLADoption\t"
						+ "Toption\tvirtual\tmean2CrownRadius\tleafBiomass\tbranchBiomass\tstemBiomass\trootBiomass\tfineRootBiomass\t"
						+ "tleafArea\tsunlitLeafArea\tshadedLeafArea\tcrownVolume\tcrownVolumeUp\tcrownVolumeDown\tcrownLAD\tcrownLADup\tcrownLADdown\tcrownSLAup\tcrownSLAdown\tcrownLength\tcrownProjection\tUFLB\t"
						+ "crownDirectEnergy\tcrownDiffuseEnergy\tcrownPotentialEnergy\tcrownEnergy\t"
						+ "interceptedParRadiation\tinterceptedDirectParRadiation\tinterceptedDiffuseParRadiation\t"
						+ "grossPrimaryProduction\t"
						+ "stemLivingFraction\tmaintenanceRespiration\tleafRetranslocation\tfineRootRetranslocation\tnetPrimaryProduction\tnewLeafBiomassProduction\t"
						+ "newFineRootBiomassProduction\ttotalStructuralBiomassToAllocate\tbranchLitterFall\trootLitterFall\tfruitLitterFall\tdeltaAboveGroundStructuralBiomass\tdeltaDbh_cm\tdeltaHeight\tdeltaG\tdeltaDbh2Height\tresidual\t"
						+ "stemAllocationCoefficient\trootAllocationCoefficient\tbranchAllocationCoefficient\tlightCompetitionIndex\tparUseEfficiency\tyearlyTranspiration\tyearlyPotentialTranspiration"));

		// For each step in the scenario from the root, write all trees
		Step step = scene.getStep();
		Project project = step.getProject();
		for (Step st : project.getStepsFromRoot(step)) {

			// add (new EmptyRecord ());
			writeLines((HetScene) st.getScene());

		}

	}

	private void writeLines(HetScene scene) {

		// Sort the trees on their ids
		Set sortedTrees = new TreeSet(new GTreeIdComparator());
		sortedTrees.addAll(scene.getTrees());

		for (Iterator i = sortedTrees.iterator(); i.hasNext();) {
			HetTree t = (HetTree) i.next();

			TreeLine r = new TreeLine();

			r.date = scene.getDate();
			r.id = t.getId();
			r.x = t.getX();
			r.y = t.getY();
			r.z = t.getZ();
			r.dbh = t.getDbh();
			r.height = t.getHeight();
			r.speciesName = t.getSpecies().getName();

			r.hlce = t.getHlce();
			r.hcb = t.getHcb();
			r.rnorth = t.getRnorth();
			r.reast = t.getReast();
			r.rsouth = t.getRsouth();
			r.rwest = t.getRwest();
			r.crownForm = t.getCrownForm();
			r.leafLitterAmount = t.getLeafLitterAmount_kgOM();
			r.LADoption = t.getLADoption();
			r.Toption = t.getToption();
			r.virtual = t.isVirtual();
			r.mean2CrownRadius = t.getMean2CrownRadius();

			r.leafBiomass = t.getLeafBiomass_kgC();
			r.branchBiomass = t.getBranchBiomass_kgC();
			r.stemBiomass = t.getStemBiomass_kgC();
			r.rootBiomass = t.getRootBiomass_kgC();
			r.fineRootBiomass = t.getFineRootBiomass_kgC();

			r.leafArea = t.getLeafArea();
			r.sunlitLeafArea = t.getSunlitLeafArea();
			r.shadedLeafArea = t.getShadedLeafArea();

			r.crownVolume = t.getCrownVolume();
			r.crownVolumeUp = t.getCrownVolumeUp(); // fa-06.12.2018
			r.crownVolumeDown = t.getCrownVolumeDown(); // fa-06.12.2018
			r.crownLAD = t.getCrownLAD();
			r.LADup = t.getLADup(); // fa-06.12.2018
			r.LADdown = t.getLADdown(); // fa-06.12.2018
			r.SLAup = t.getSLAup(); // fa-06.12.2018
			r.SLAdown = t.getSLAdown(); // fa-06.12.2018
			r.crownLength = t.getCrownLength();
			r.crownProjection = t.getCrownProjection();
			r.uflb = t.getUflb(); // fa-06.12.2018

			r.crownDirectEnergy = t.getLightResult().getCrownDirectEnergy();
			r.crownDiffuseEnergy = t.getLightResult().getCrownDiffuseEnergy();
			r.crownPotentialEnergy = t.getLightResult().getCrownPotentialEnergy();
			r.crownEnergy = t.getLightResult().getCrownEnergy();

			r.interceptedParRadiation = t.getInterceptedParRadiation();
			r.interceptedDirectParRadiation = t.getInterceptedDirectParRadiation();
			r.interceptedDiffuseParRadiation = t.getInterceptedDiffuseParRadiation();

			r.grossPrimaryProduction = t.getGrossPrimaryProduction_kgC();

			r.stemLivingFraction = -1; // LATER
			// r.stemLivingFraction = t.getStemLivingFraction ();

			r.maintenanceRespiration = t.getMaintenanceRespiration_kgC();
			r.leafRetranslocation = t.getLeafRetranslocation_kgC();
			r.fineRootRetranslocation = t.getFineRootRetranslocation_kgC();
			r.netPrimaryProduction = t.getNetPrimaryProduction_kgC();
			r.newLeafBiomassProduction = t.getLeafBiomassProduction_kgC();
			r.newFineRootBiomassProduction = t.getFineRootBiomassProduction_kgC();
			r.totalStructuralBiomassToAllocate = t.getTotalStructuralBiomassToAllocate_kgC();
			r.branchLitterFall = t.getBranchLitterFall_kgC();
			r.rootLitterFall = t.getRootLitterFall_kgC();
			r.fruitLitterFall = t.getFruitLitterFall_kgC(); //mj+fa-05.12.2017
			r.deltaAboveGroundStructuralBiomass = t.getDeltaAboveGroundStructuralBiomass_kgC();
			r.deltaDbh_cm = t.getDeltaDbh_cm(); // fa-02.11.2018
			r.deltaHeight = t.getDeltaHeight(); // fa-02.11.2018
			r.deltaG = t.getDeltaG(); // fa-02.11.2018
			r.deltaDbh2Height = t.getDeltaDbh2Height(); // fa-02.11.2018
			r.residual = t.getResidual();
			r.stemAllocationCoefficient = t.getStemAllocationCoefficient();
			r.rootAllocationCoefficient = t.getRootAllocationCoefficient();
			r.branchAllocationCoefficient = t.getBranchAllocationCoefficient();
			r.lightCompetitionIndex = t.getLightCompetitionIndex();
			r.parUseEfficiency = t.getParUseEfficiency();

			r.yearlyTranspiration = t.getYearlyTranspiration();
			r.yearlyPotentialTranspiration = t.getYearlyPotentialTranspiration();


			add(r);
		}

	}

	/**
	 * Importation is not implemented here
	 */
	@Override
	public GScene load(GModel m) throws Exception {
		return null;
	}

}