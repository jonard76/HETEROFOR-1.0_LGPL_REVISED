/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.extension.ioformat;

import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import capsis.defaulttype.Tree;
import capsis.kernel.GModel;
import capsis.kernel.GScene;
import capsis.kernel.Project;
import capsis.kernel.Step;
import capsis.util.StandRecordSet;
import heterofor.model.HetElementState;
import heterofor.model.HetInitialParameters;
import heterofor.model.HetModel;
import heterofor.model.HetScene;
import heterofor.model.HetTree;
import heterofor.model.soil.HetHorizon;
import heterofor.model.soil.HetSoil;
import heterofor.model.soil.HetSoilInterface;
import heterofor.model.soilchemistry.HetChemicalElement;
import heterofor.model.soilchemistry.HetMineral;
import heterofor.model.treechemistry.HetLitterCompartment;
import heterofor.model.treechemistry.HetTreeCompartment;
import heterofor.model.treechemistry.HetTreeElement;
import jeeb.lib.util.AdditionMap;
import jeeb.lib.util.Log;
import jeeb.lib.util.Translator;

/**
 * HetStandNutrientStockAndFluxExport exports nutrient stocks and fluxes at the
 * stand scale.
 *
 * @author F. de Coligny, M. Jonard - December 2016
 */
public class HetStandNutrientStockAndFluxExport extends StandRecordSet {

	static {
		Translator.addBundle("heterofor.extension.ioformat.ExportLabels");
	}

	// Extension properties
	// nb-13.08.2018
	//static public String NAME = Translator.swap("HetStandNutrientStockAndFluxExport");
	//static public String AUTHOR = "F. de Coligny, M. Jonard";
	//static public String VERSION = "1.0";
	//static public String DESCRIPTION = Translator.swap("HetStandNutrientStockAndFluxExport.description");

	public final static String TAB = "\t";

	private HetInitialParameters ip;

	private boolean wroteHeader;

	private AdditionMap prevYear_teTotalStock_map;

	/**
	 * Constructor
	 */
	public HetStandNutrientStockAndFluxExport() {
		super();
		// Do not write the standard header lines in the output file
		setHeaderEnabled(false);
	}

	/**
	 * Extension dynamic compatibility mechanism. This matchWith method checks
	 * if the extension can deal (i.e. is compatible) with the referent.
	 */
	static public boolean matchWith(Object referent) {
		try {
//			return referent instanceof HetModel; //mj+fa-19.11.2019: commented
			
			//mj+fa-19.11.2019
			if (!(referent instanceof HetModel)) {
				return false;
			}
			
			// fc+mj+fa-19.11.2019 Compatible only if HetSoil (not with a HetDiscreteSoil)
			HetModel model = (HetModel) referent;
			Step root = (Step) model.getProject ().getRoot ();
			HetSoilInterface soil = ((HetScene) root.getScene ()).getSoil ();
			return !soil.isDiscreteSoil();
//			return soil instanceof HetSoil;

		} catch (Exception e) {
			Log.println(Log.ERROR, "HetStandNutrientStockAndFluxExport.matchWith ()",
					"Error in matchWith () (returned false)", e);
			return false;
		}

	}

	@Override
	public String getName() {
		return Translator.swap("HetStandNutrientStockAndFluxExport.name");
	}

	@Override
	public String getAuthor() {
		return "F. de Coligny, M. Jonard";
	}

	@Override
	public String getDescription() {
		return Translator.swap("HetStandNutrientStockAndFluxExport.description");
	}

	@Override
	public String getVersion() {
		return "1.0";
	}

	/**
	 * Export: turns the given Scene into a collection of records. In script
	 * mode, save (fileName) must be called after.
	 */
	@Override
	public void createRecordSet(GScene s) throws Exception {
		HetScene scene = (HetScene) s;
		super.createRecordSet(scene); // deals with RecordSet's source

		// For each step in the scenario from the root, write a section
		Step step = scene.getStep();
		Project project = step.getProject();

		HetModel model = (HetModel) project.getModel ();
		ip = model.getSettings();

		for (Step stp : project.getStepsFromRoot(step)) {

			if (!wroteHeader)
				writeHeader(stp);

			writeLines((HetScene) stp.getScene());

		}

	}

	private void writeHeader(Step step) throws Exception {

		if (wroteHeader)
			return;

		// 1. Custom headers
		add(new CommentRecord("Heterofor Stand Nutrient Stock and Flux Export (HetStandNutrientStockAndFluxExport) at "
				+ new Date()));
		add(new EmptyRecord());

		StringBuffer h = new StringBuffer();
		h.append("date" + TAB + "type");

		for (String eName : HetTreeElement.elementNames) {
			h.append(TAB + eName);
		}

		add(new CommentRecord(h.toString()));

		wroteHeader = true;

	}

	private void writeLines(HetScene scene) {

		treeLines(scene);
		soilLines (scene);

	}

	private void soilLines(HetScene scene) {

		double area_ha = scene.getArea() / 10000d;

		// Soil
		HetSoilInterface soil = scene.getSoil ();

		HetElementState nutrientDeposition = soil.getNutrientDeposition();

		AdditionMap exchangeableStock_map = new AdditionMap ();

		// fc-13.11.2019			
		for (HetHorizon h : soil.getPedonSpecimen().getHorizons()) {
//		for (HetHorizon h : soil.getHorizons()) {

			Map<String, Double> cationStock = h.concentrationToStock(ip, scene,
					h.getExchangeableCationConcentrations()); // Kg

			Map<String, Double> anionStock = h.concentrationToStock(ip, scene,
					h.getExchangeableAnionConcentrations()); // Kg

			Map<String, Double> exchStock = new HashMap<> (cationStock);
			exchStock.putAll(anionStock);

			for (String exchName : exchStock.keySet ()) {

				double value = exchStock.get(exchName);

				HetChemicalElement elt = ip.getChemicalElement(exchName);
				String eName = elt.treeElement; // maybe "-"

				if (!eName.equals ("-")) {
					exchangeableStock_map.addValue(eName, value / area_ha);
				}

			}

		}

		writeLine(scene, "nutrientDeposition(kg/ha/year)", nutrientDeposition);
		writeLine(scene, "exchangeableStock(kg/ha)", exchangeableStock_map);

		// weathering: "alteration"
		weatheringFluxCalculation (scene, soil);
	}

	private void weatheringFluxCalculation (HetScene scene, HetSoilInterface soil) {

		double area_ha = scene.getArea() / 10000d;
		double area_m2 = scene.getArea();

		AdditionMap teTotalStock_map = new AdditionMap ();

		// fc-13.11.2019		
		for (HetHorizon h : soil.getPedonSpecimen().getHorizons()) {
//		for (HetHorizon h : soil.getHorizons()) {

			AdditionMap teStock_map = new AdditionMap ();

			for (String mineralName : h.getMineralConcentrations ().keySet()) {

				HetMineral m = h.getMineralConcentrations ().get(mineralName);
				Set<String> ceNames = HetMineral.getChemicalElementNames (mineralName);

				for (String ceName : ceNames) {

					HetChemicalElement ce = ip.getChemicalElement(ceName);
					String teName = ce.treeElement;

					double moleNumber = HetMineral.getMoleNumber(mineralName, ceName);
					double mineralConcentration = m.concentration;
					double bulkDensity = h.bulkDensity; // kg/m3
					double thickness = h.thickness; // m
					double coarseFraction = h.additionalCoarseFraction; // m3/m3 [0,1]
					double atomicMass = ce.atomicMass; // g

					double teStock = mineralConcentration * bulkDensity * thickness * area_m2 * (1 - coarseFraction)
							* moleNumber * atomicMass / 1000d / area_ha; // Kg/ha

					teStock_map.addValue(teName, teStock);
				}

			}
			teTotalStock_map = AdditionMap.sum (teTotalStock_map, teStock_map);
		}


		writeLine(scene, "mineralElementStock(kg/ha)", teTotalStock_map);

		if (prevYear_teTotalStock_map == null) // first year
			writeLine(scene, "weatheringFlux(kg/ha/year)", new HetElementState ()); // all zero
		else {
			 AdditionMap weatheringFlux_Map = AdditionMap.difference(prevYear_teTotalStock_map, teTotalStock_map);
			 writeLine(scene, "weatheringFlux(kg/ha/year)", weatheringFlux_Map);
		}

		prevYear_teTotalStock_map = teTotalStock_map; // for next year
	}

	private void treeLines(HetScene scene) {

		// Key is eName
		AdditionMap aboveGroundTreeStock_map = new AdditionMap();
		AdditionMap belowGroundTreeStock_map = new AdditionMap();
		AdditionMap currentDemand_map = new AdditionMap();
		AdditionMap deficientDemand_map = new AdditionMap();
		AdditionMap optimalDemand_map = new AdditionMap();
		AdditionMap potentialUptake_map = new AdditionMap();
		AdditionMap actualUptake_map = new AdditionMap();
		AdditionMap currentRetranslocation_map = new AdditionMap();
		AdditionMap currentRequirement_map = new AdditionMap();
		AdditionMap aboveGroundLitterProduction_map = new AdditionMap();
		AdditionMap belowGroundLitterProduction_map = new AdditionMap();

		AdditionMap nutrientRemoval_map = new AdditionMap();

		double area_ha = scene.getArea() / 10000d;

		// Alive trees
		for (Iterator i = scene.getTrees().iterator(); i.hasNext();) {
			HetTree t = (HetTree) i.next();

			// Tree > treeCompartments > elements
			for (HetTreeCompartment comp : t.getTreeCompartments()) {
				String compartmentName = comp.name;

				for (String eName : HetTreeElement.elementNames) {

					String key = eName;

					if (comp.isAboveGround()) {

						try {
							double eStock = comp.getNutrientContent(eName) / area_ha; // kg/ha
							aboveGroundTreeStock_map.addValue(key, eStock);
						} catch (Exception e) {
						} // if exception, nothing added

					} else {

						try {
							double eStock = comp.getNutrientContent(eName) / area_ha; // kg/ha
							belowGroundTreeStock_map.addValue(key, eStock);
						} catch (Exception e) {
						} // if exception, nothing added

					}

				}

			}

			// Tree > litterCompartments > elements
			for (HetLitterCompartment comp : t.getLitterCompartments()) {
				String compartmentName = comp.name;

				for (String eName : HetTreeElement.elementNames) {

					String key = eName;

					if (comp.isAboveGround()) {

						try {
							double aboveGroundLitterProduction = comp.getNutrientFlux(eName) / area_ha;
							aboveGroundLitterProduction_map.addValue(key, aboveGroundLitterProduction);
						} catch (Exception e) {
						} // if exception, nothing added

					} else {

						try {
							double belowGroundLitterProduction = comp.getNutrientFlux(eName) / area_ha;
							belowGroundLitterProduction_map.addValue(key, belowGroundLitterProduction);
						} catch (Exception e) {
						} // if exception, nothing added

					}

				}

			}

			// Tree > elements
			for (String eName : HetTreeElement.elementNames) {

				String key = eName;

				try {
					double retranslocation = t.getRetranslocation().getValue(eName) / 1000d / area_ha;// kg/ha
					currentRetranslocation_map.addValue(key, retranslocation);
				} catch (Exception e) {
				} // if exception, nothing added

				try {
					double demand = t.getDemand().getValue(eName) / 1000d / area_ha; // kg/ha
					currentDemand_map.addValue(key, demand);
				} catch (Exception e) {
				} // if exception, nothing added

				try {
					double deficientDemand = t.getDeficientDemand().getValue(eName) / 1000d / area_ha; // kg/ha
					deficientDemand_map.addValue(key, deficientDemand);
				} catch (Exception e) {
				} // if exception, nothing added

				try {
					double optimalDemand = t.getOptimalDemand().getValue(eName) / 1000d / area_ha; // kg/ha
					optimalDemand_map.addValue(key, optimalDemand);
				} catch (Exception e) {
				} // if exception, nothing added

				try {
					double potentialUptake = t.getPotentialUptake().getValue(eName) / 1000d / area_ha; // kg/ha
					potentialUptake_map.addValue(key, potentialUptake);
				} catch (Exception e) {
				} // if exception, nothing added

				try {
					double actualUptake = t.getActualUptake().getValue(eName) / 1000d / area_ha; // kg/ha
					actualUptake_map.addValue(key, actualUptake);
				} catch (Exception e) {
				} // if exception, nothing added




			}

			// fc+mj-9.12.2016
			potentialUptake_map.overwriteValue("N", scene.getNAvailable_kg() / area_ha);

		}

		// Cut trees (if any)
		Collection<Tree> cutTrees = scene.getTrees ("cut");
		for (Iterator i = cutTrees.iterator(); i.hasNext();) {
			HetTree t = (HetTree) i.next();

			// Tree > treeCompartments > elements
			for (HetTreeCompartment comp : t.getTreeCompartments()) {
				String compartmentName = comp.name;

				for (String eName : HetTreeElement.elementNames) {

					String key = eName;

					if (comp.isAboveGround()) {

						if (comp.diameter >= ip.cuttingDiameter) {

							try {
								double nutrientRemoval = comp.getNutrientContent(eName) / area_ha; // kg/ha
								nutrientRemoval_map.addValue(key, nutrientRemoval);
							} catch (Exception e) {
							} // if exception, nothing added

						}

					}

				}

			}

		}

		currentRequirement_map = AdditionMap.sum(currentDemand_map, currentRetranslocation_map);

		writeLine(scene, "aboveGroundTreeStock(kg/ha)", aboveGroundTreeStock_map);
		writeLine(scene, "belowGroundTreeStock(kg/ha)", belowGroundTreeStock_map);
		writeLine(scene, "currentDemand(kg/ha/year)", currentDemand_map);
		writeLine(scene, "deficientDemand(kg/ha/year)", deficientDemand_map);
		writeLine(scene, "optimalDemand(kg/ha/year)", optimalDemand_map);
		writeLine(scene, "potentialUptake(kg/ha/year)", potentialUptake_map);
		writeLine(scene, "actualUptake(kg/ha/year)", actualUptake_map);
		writeLine(scene, "currentRetranslocation(kg/ha/year)", currentRetranslocation_map);
		writeLine(scene, "currentRequirement(kg/ha/year)", currentRequirement_map);
		writeLine(scene, "aboveGroundLitterProduction(kg/ha/year)", aboveGroundLitterProduction_map);
		writeLine(scene, "belowGroundLitterProduction(kg/ha/year)", belowGroundLitterProduction_map);
		writeLine(scene, "nutrientRemoval(harvesting)(kg/ha/year)", nutrientRemoval_map);

	}

	/**
	 * Writes a line, source is an AdditionMap
	 */
	private void writeLine(HetScene scene, String type, AdditionMap map) {

		int date = scene.getDate();

		StringBuffer line = new StringBuffer();

		line.append("" + date);
		line.append(TAB);
		line.append(type);

		for (String eName : HetTreeElement.elementNames) {

			// AdditionMap.getValue () never returns null
			double value = map.getValue(eName); // 0 if not found

			line.append(TAB);
			line.append("" + value);

		}

		add(new FreeRecord(line.toString()));

	}

	/**
	 * Writes a line, source is a HetElementState
	 */
	private void writeLine(HetScene scene, String type, HetElementState eState) {

		int date = scene.getDate();

		StringBuffer line = new StringBuffer();

		line.append("" + date);
		line.append(TAB);
		line.append(type);

		for (String eName : HetTreeElement.elementNames) {

			// HetElementState.getValue () may return null
			Double value = eState.getValue(eName); // may be null
			if (value == null)
				value = 0d;

			line.append(TAB);
			line.append("" + value);

		}

		add(new FreeRecord(line.toString()));

	}

	/**
	 * Importation is not implemented here
	 */
	@Override
	public GScene load(GModel m) throws Exception {
		return null;
	}

}