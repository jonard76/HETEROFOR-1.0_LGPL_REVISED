/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.extension.ioformat;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import capsis.kernel.GModel;
import capsis.kernel.GScene;
import capsis.kernel.Project;
import capsis.kernel.Step;
import capsis.util.StandRecordSet;
import heterofor.model.HetModel;
import heterofor.model.HetScene;
import heterofor.model.soil.HetHorizon;
import heterofor.model.soil.HetSoilInterface;
import heterofor.model.waterbalance.HetWaterBalance;
import heterofor.model.waterbalance.HetWaterBalanceIntegrator;
import heterofor.model.waterbalance.pedon.Pedon;
import jeeb.lib.util.Import;
import jeeb.lib.util.Log;
import jeeb.lib.util.Record;
import jeeb.lib.util.Translator;

/**
 * Exports water balance at a daily time step
 *
 * @author F. de Coligny, F Andr� - November 2019
 */
public class HetPedonWaterBalanceDailyExport extends StandRecordSet {

	static {
		Translator.addBundle("heterofor.extension.ioformat.ExportLabels");
	}

	// Extension properties
	// nb-13.08.2018
	//static public String NAME = Translator.swap("HetPedonWaterBalanceDailyExport");
	//static public String AUTHOR = "F. de Coligny, F. Andr�;
	//static public String VERSION = "1.0";
	//static public String DESCRIPTION = Translator.swap("HetPedonWaterBalanceDailyExport.description");

//	private LinkedHashMap<String, HetWaterBalance> wbMapDaily;

	/**
	 * Represents a line in the export file.
	 */
	@Import
	static public class Line extends Record {

		public Line() {
			super();
		}

		public Line(String line) throws Exception {
			super(line);
		}

		public int pedonId; // fc+fa-21.11.2019
		
		public int year;
		public int month;
		public int day;

		public double rainfall; // mm
		public double stemflow; // mm
		public double throughfall; // mm
		public double interception; // mm
		public double transpiration; // mm

		// fc+mj-13.9.2017
		public double standLevel_transpiration; // mm
		public double treeLevel_transpiration; // mm
		public double groundVegetationTranspiration; // mm

		public double barkEvaporation; // mm // fc+mj+lw-19.10.2016
		public double foliageEvaporation; // mm // fc+mj+lw-19.10.2016
		public double vegetationEvaporation; // mm
		public double soilEvaporation; // mm
		public double deepDrainage; // mm

		public double relativeExtractableWater; // mm/mm
		public double forestFloorRelativeExtractableWater; // mm/mm
		public String horizonWaterContents; // separated by tabs, m3/m3
		public double waterContentStockVariation; // TODO: unit
		public double waterBalance; // TODO: unit
	}

	/**
	 * The separator used in generated .csv file
	 */
	static private final String TAB = "\t";

	/**
	 * Constructor
	 */
	public HetPedonWaterBalanceDailyExport() {

		super();

		// Do not write the standard header lines in the output file
		setHeaderEnabled(false);
	}

	/**
	 * Extension dynamic compatibility mechanism. This matchWith method checks
	 * if the extension can deal (i.e. is compatible) with the referent.
	 */
	static public boolean matchWith(Object referent) {

		try { // fa-22.11.2019
//			return (referent instanceof HetModel); // fa-22.11.2019: commented
		
			// fa-22.11.2019
			if (!(referent instanceof HetModel)) {
				return false;
			}
		
			// fa-22.11.2019 Compatible only if HetSoil (not with a HetDiscreteSoil)
			HetModel model = (HetModel) referent;
			Step root = (Step) model.getProject ().getRoot ();
			HetSoilInterface soil = ((HetScene) root.getScene ()).getSoil ();
			return soil.isDiscreteSoil();
//			return soil instanceof HetSoil;
			
		} catch (Exception e) {
			Log.println(Log.ERROR, "HetPedonWaterBalanceDailyExport.matchWith ()",
					"Error in matchWith () (returned false)", e);
			return false;
		}
	}

	@Override
	public String getName() {
		return Translator.swap("HetPedonWaterBalanceDailyExport.name");
	}

	@Override
	public String getAuthor() {
		return "F. de Coligny, F. Andr�";
	}

	@Override
	public String getDescription() {
		return Translator.swap("HetPedonWaterBalanceDailyExport.description");
	}

	@Override
	public String getVersion() {
		return "1.1";
	}

	/**
	 * Export: create a list of records. In script mode, save (fileName) must be
	 * called after.
	 */
	@Override
	public void createRecordSet(GScene s) throws Exception {

		HetScene scene = (HetScene) s;
		super.createRecordSet(scene); // deals with RecordSet's source

		// fc-13.11.2019		
		Set<Integer> horizonIdsSet = scene.getSoil().getPedonSpecimen().getHorizonMap().keySet(); // fa-19.11.2019: OK, valid for any pedon (horizonId list is the same for any pedon)
//		Set<Integer> horizonIdsSet = scene.getSoil().getHorizonMap().keySet();
		
		// Sort horizon ids on ascending order
		Set<Integer> sortedHorizonIds = new TreeSet<>(horizonIdsSet);

		// 1. Custom headers
		add(new CommentRecord("Heterofor Water Balance Daily Export (HetPedonWaterBalanceDailyExport) at " + new Date()));
		add(new EmptyRecord());

		// Tree line header
		add(new CommentRecord("Water Balance lines"));
//		String columnNames =  "year" + TAB + "month" + TAB + "day" + TAB + "rainfall (mm)" + TAB + "stemflow (mm)" + TAB + "throughfall (mm)" + TAB
		String columnNames =  "pedonId" + TAB + "year" + TAB + "month" + TAB + "day" + TAB + "rainfall (mm)" + TAB + "stemflow (mm)" + TAB + "throughfall (mm)" + TAB // fa-22.11.2019
				+ "interception (mm)"
				+ TAB + "transpiration (mm)" + TAB + "standLevel_transpiration (mm)" + TAB + "treeLevel_transpiration (mm)" + TAB + "groundVegetationTranspiration (mm)"
				+ TAB + "barkEvaporation (mm)" + TAB
				+ "foliageEvaporation (mm)" + TAB + "vegetationEvaporation (mm)" + TAB + "soilEvaporation (mm)" + TAB
				+ "deepDrainage (mm)" + TAB + "relativeExtractableWater (mm.mm-1)" + TAB
				+ "forestFloorRelativeExtractableWater (mm.mm-1)";
		for (int horizonId : sortedHorizonIds) {
			
			// fc-13.11.2019			
			columnNames += TAB + "horizonWaterContent (m3.m-3) for horizon " + horizonId + " - " 
						+ scene.getSoil().getPedonSpecimen().getHorizon(horizonId).name; // fa-19.11.2019: OK, valid for any pedon (horizon names are the same for any pedon)
//			columnNames += TAB + "horizonWaterContent (m3.m-3) for horizon " + horizonId + " - " + scene.getSoil().getHorizon(horizonId).name;
		
		}
		columnNames += TAB + "waterContentStockVariation (TODO: unit)" + TAB + "waterBalance (TODO: unit)";
		add(new CommentRecord(columnNames));

		Step step = scene.getStep();
		Project project = step.getProject();

		// Map with key: pedonId_horizonId, value: water content at previous day (at hour=23h of previous day)
		HashMap<String, Double> pedonId_horizonId_PreviousWaterContentMap = new HashMap<>();

		// Create full waterbalance map containing all entries until the current scene's date
		LinkedHashMap<String, HetWaterBalance> fullWBMap = new LinkedHashMap<>();

		// Create dateStepMap with key: scene's date, value: the step having this date. nb-13.09.2017
		HashMap<Integer, Step> dateStepMap = new HashMap<Integer, Step>();

		// fc+fa-21.11.2019 Introducing pedon level
		Map<Integer, LinkedHashMap<String, HetWaterBalance>> pedonWaterBalanceMap = new LinkedHashMap<> ();
		
		for (Step st : project.getStepsFromRoot(step)) {
			
			// fa-02.12.2019: skip 'star scene' (result of intervention, with dead or thinned trees removed)
			if (st.getScene().isInterventionResult())
				continue;

			dateStepMap.put(st.getScene().getDate(), st);

			HetScene sc = (HetScene) st.getScene();

			// fc+fa-21.11.2019 Introducing pedon level
			for (int pedonId : sc.getSoil ().getPedonMap().keySet ()) {
				Pedon pedon = sc.getSoil ().getPedonMap().get(pedonId);
				
				// fa-25.11.2019: remainingPedon (id = 0) with area equals to zero is not processed in HetWaterBalanceCalculator() => not waterBalanceMap
				if (pedon.getPedonId() == 0 && pedon.getPedonArea() == 0)
					continue;
				
				// Create an entry for this pedonId if needed
				if (pedonWaterBalanceMap.get(pedonId) == null)
					pedonWaterBalanceMap.put(pedonId, new LinkedHashMap<String, HetWaterBalance> ());
				
				if (sc.isInitialScene()) {
	
					// fc-13.11.2019			
					for (HetHorizon horizon : pedon.getHorizons())					
						pedonId_horizonId_PreviousWaterContentMap.put(pedon.getPedonId ()+"_"+horizon.id, horizon.meanWaterContent); 
				
				}
	
				// No waterBalance map for root step
				
				// fc-19.11.2019 Works only for an HetSoil, not for HetDiscreteSoil)
				// fa-19.11.2019: now OK in any case (averageWaterBalanceMap for HetDiscreteSoil)
				
				LinkedHashMap<String, HetWaterBalance> pedonMap = pedonWaterBalanceMap.get(pedonId);
				
				if (pedon.getWaterBalanceMap () != null && !pedon.getWaterBalanceMap ().isEmpty())
					pedonMap.putAll(pedon.getWaterBalanceMap ());
				
//				if (sc.getWaterBalanceMap () != null && !sc.getWaterBalanceMap ().isEmpty()) {
//					fullWBMap.putAll(sc.getWaterBalanceMap ());
//				}
			
			}
		}

		// Create wbMapDaily: daily waterbalance map. For example, wbMapDaily
		// map has 3x365 entries if fullWBMap map contains entries over three
		// years. So wbMapDaily map has one entry per day.
		// wbMapDaily map :
		// 		key: the year+month+day string (e.g.: 2002_5_21_)
		// 		value: the waterbalance object containing physical variables
		//			   summed and averaged over the day of the year
		for (int pedonId : pedonWaterBalanceMap.keySet ()) {
			LinkedHashMap<String, HetWaterBalance> pedonMap = pedonWaterBalanceMap.get(pedonId);
			
			HetWaterBalanceIntegrator wbi = new HetWaterBalanceIntegrator(pedonMap, HetWaterBalanceIntegrator.DAY_LEVEL);
	
			LinkedHashMap<String, HetWaterBalance> wbMapDaily = wbi.integrate();
	
			writeLines(pedonId, wbMapDaily, dateStepMap, pedonId_horizonId_PreviousWaterContentMap);
		}
		
	}

	/**
	 * Writes the water balance for all days of simulation.
	 */
	private void writeLines(int pedonId, LinkedHashMap<String, HetWaterBalance> wbMapDaily, HashMap<Integer, Step> dateStepMap, HashMap<String, Double> pedonId_horizonId_PreviousWaterContentMap) {

		// nb-13.09.2017. Note: wbMapDaily contains daily water balance data for all days of simulation
		for (Iterator<String> i = wbMapDaily.keySet().iterator(); i.hasNext();) {

			String key = i.next();
			HetWaterBalance wb = wbMapDaily.get(key);

			Line line = new Line();

			line.pedonId = pedonId;

			line.year = wb.year;
			line.month = wb.month;
			line.day = wb.day;

			line.rainfall = wb.rainfall;
			line.stemflow = wb.stemflow;
			line.throughfall = wb.throughfall;
			line.interception = wb.interception;
			line.transpiration = wb.transpiration;

			// fc+mj-13.9.2017
			line.standLevel_transpiration = wb.standLevel_transpiration;
			line.treeLevel_transpiration = wb.treeLevel_transpiration;
			line.groundVegetationTranspiration = wb.groundVegetationTranspiration;

			line.barkEvaporation = wb.barkEvaporation;
			line.foliageEvaporation = wb.foliageEvaporation;
			line.vegetationEvaporation = wb.vegetationEvaporation;
			line.soilEvaporation = wb.soilEvaporation;
			line.deepDrainage = wb.deepDrainage;

			line.relativeExtractableWater = wb.relativeExtractableWater;
			line.forestFloorRelativeExtractableWater = wb.forestFloorRelativeExtractableWater;

			// Last columns contains one value per horizon, separated by tabs
			// (horizons number may vary)
			// Sort horizon ids on ascending order
			Set<Integer> sortedHIds = new TreeSet<>(wb.horizonWaterContent.keySet());

			StringBuffer b = new StringBuffer();
			for (Iterator<Integer> j = sortedHIds.iterator(); j.hasNext();) {

				int hId = j.next();
				double v = wb.horizonWaterContent.get(hId);

				b.append(v);

				if (j.hasNext())
					b.append(TAB);
			}

			line.horizonWaterContents = b.toString();

			// Calculate water balance. nb-13.09.2017
			double waterContentVariation = 0.0;

			HetScene scene = (HetScene) dateStepMap.get(wb.year).getScene();

			for (int horizonId : sortedHIds) {

				// fc-13.11.2019	
				HetHorizon horizon = scene.getSoil().getPedonMap().get(pedonId).getHorizon(horizonId); // fc+fa-21.11.2019
//				HetHorizon horizon = scene.getSoil().getPedonSpecimen().getHorizon(horizonId); // fa-19.11.2019: OK, valid for any pedon (horizon thickness and additionalCoarseFraction are the same for any pedon)
//				HetHorizon horizon = scene.getSoil().getHorizon(horizonId);
				
				// fc-19.11.2019 Works only for an HetSoil, not for HetDiscreteSoil)
				// fa-19.11.2019: now OK in any case (averageWaterBalanceMap for HetDiscreteSoil)
				
				Map<String, HetWaterBalance> pedonHourlyWaterBalance = scene.getSoil().getPedonMap().get(pedonId).getWaterBalanceMap(); // fa-22.11.2019
//				Map<String, HetWaterBalance> hourlyWaterBalance = wbMapDaily; // fc+fa-21.11.2019 pedon level
//				Map<String, HetWaterBalance> hourlyWaterBalance = scene.getWaterBalanceMap ();
//				LinkedHashMap<String, HetWaterBalance> hourlyWaterBalance = scene.waterBalanceMap;

				// waterContent is the value of water content at hour=23h of current day
//				System.out.println("HetPedonWaterBalanceDailyExport: key = " + wb.year + "_" + wb.month + "_" + wb.day + "_23");
//				double waterContent = hourlyWaterBalance.get(wb.year + "_" + wb.month + "_" + wb.day + "_23").horizonWaterContent.get(horizonId);
//				double waterContent = pedonHourlyWaterBalance.get(wb.year + "_" + wb.month + "_" + wb.day + "_23").horizonWaterContent.get(horizonId); // fa-22.11.2019 // fa-25.11.2019: commented
				// fa-25.11.2019
				double waterContent;
				if (!scene.getSoil().isDiscreteSoil())
					waterContent = pedonHourlyWaterBalance.get(wb.year + "_" + wb.month + "_" + wb.day + "_23").horizonWaterContent.get(horizonId);
				else // in detailed water balance mode, waterBalanceMaps are now integrated at the daily level to save memory
					waterContent = pedonHourlyWaterBalance.get(wb.year + "_" + wb.month + "_" + wb.day + "_").horizonWaterContent.get(horizonId);
				
				double previousWaterContent = pedonId_horizonId_PreviousWaterContentMap.get(pedonId+"_"+horizonId);

				waterContentVariation += (waterContent-previousWaterContent)*horizon.thickness*(1.0-horizon.additionalCoarseFraction)*1000.0;

				// Updates the previous water content for next hour. nb-13.09.2017
				pedonId_horizonId_PreviousWaterContentMap.put(pedonId+"_"+horizonId, waterContent);
			}
			line.waterContentStockVariation = waterContentVariation;

//			line.waterBalance = line.rainfall - (line.transpiration + line.vegetationEvaporation
//					+ line.soilEvaporation + line.deepDrainage + line.waterContentStockVariation);
			line.waterBalance = line.rainfall - (line.transpiration + line.interception
					+ line.soilEvaporation + line.deepDrainage + line.waterContentStockVariation); // mj+fa-26.09.2017

			add(line);
		}

	}

	/**
	 * Importation is not implemented here
	 */
	@Override
	public GScene load(GModel m) throws Exception {
		return null;
	}

}
