/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.extension.ioformat;

import heterofor.model.HetModel;
import heterofor.model.HetScene;
import heterofor.model.soil.HetHorizon;
import heterofor.model.waterbalance.HetWaterBalance;
import heterofor.model.waterbalance.HetWaterBalanceIntegrator;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import jeeb.lib.util.Import;
import jeeb.lib.util.Record;
import jeeb.lib.util.Translator;
import capsis.kernel.GModel;
import capsis.kernel.GScene;
import capsis.kernel.Project;
import capsis.kernel.Step;
import capsis.util.StandRecordSet;

/**
 * Exports water balance at an yearly time step
 *
 * @author N. Beudez, F. de Coligny, M. Jonard - March 2017
 */
public class HetWaterBalanceYearlyExport extends StandRecordSet {

	static {
		Translator.addBundle("heterofor.extension.ioformat.ExportLabels");
	}

	// Extension properties
	// nb-13.08.2018
	//static public String NAME = Translator.swap("HetWaterBalanceYearlyExport");
	//static public String AUTHOR = "N. Beudez, F. de Coligny, M. Jonard";
	//static public String VERSION = "1.0";
	//static public String DESCRIPTION = Translator.swap("HetWaterBalanceYearlyExport.description");

	private LinkedHashMap<String, HetWaterBalance> wbMapYearly;

	/**
	 * Represents a line in the export file.
	 */
	@Import
	static public class Line extends Record {

		public Line() {
			super();
		}

		public Line(String line) throws Exception {
			super(line);
		}

		public int year;

		public double rainfall; // mm
		public double stemflow; // mm
		public double throughfall; // mm
		public double interception; // mm
		public double transpiration; // mm

		// fc+mj-13.9.2017
		public double standLevel_transpiration; // mm
		public double treeLevel_transpiration; // mm
		public double groundVegetationTranspiration; // mm

		public double barkEvaporation; // mm // fc+mj+lw-19.10.2016
		public double foliageEvaporation; // mm // fc+mj+lw-19.10.2016
		public double vegetationEvaporation; // mm
		public double soilEvaporation; // mm
		public double deepDrainage; // mm

		public double relativeExtractableWater; // mm/mm
		public double forestFloorRelativeExtractableWater; // mm/mm
		public String horizonWaterContents; // separated by tabs, m3/m3

		public double grossPrimaryProduction_gC_m2; // TODO: unit
		public double netPrimaryProduction_gC_m2; // TODO: unit
		public double maintenanceRespiration_gC_m2; // TODO: unit

		public double waterContentStockVariation; // TODO: unit
		public double waterBalance; // TODO: unit
	}

	/**
	 * The separator used in generated .csv file
	 */
	static private final String TAB = "\t";

	/**
	 * Constructor
	 */
	public HetWaterBalanceYearlyExport() {

		super();

		// Do not write the standard header lines in the output file
		setHeaderEnabled(false);
	}

	/**
	 * Extension dynamic compatibility mechanism. This matchWith method checks
	 * if the extension can deal (i.e. is compatible) with the referent.
	 */
	static public boolean matchWith(Object referent) {

		return (referent instanceof HetModel);
	}

	@Override
	public String getName() {
		return Translator.swap("HetWaterBalanceYearlyExport.name");
	}

	@Override
	public String getAuthor() {
		return "N. Beudez, F. de Coligny, M. Jonard";
	}

	@Override
	public String getDescription() {
		return Translator.swap("HetWaterBalanceYearlyExport.description");
	}

	@Override
	public String getVersion() {
		return "1.0";
	}

	/**
	 * Export: create a list of records. In script mode, save (fileName) must be
	 * called after.
	 */
	@Override
	public void createRecordSet(GScene s) throws Exception {

		HetScene scene = (HetScene) s;
		super.createRecordSet(scene); // deals with RecordSet's source

		// fc-13.11.2019		
		Set<Integer> horizonIdsSet = scene.getSoil().getPedonSpecimen().getHorizonMap().keySet(); // fa-19.11.2019: OK, valid for any pedon (horizonId list is the same for any pedon)
//		Set<Integer> horizonIdsSet = scene.getSoil().getHorizonMap().keySet();
		
		// Sort horizon ids on ascending order
		Set<Integer> sortedHorizonIds = new TreeSet<>(horizonIdsSet);

		// 1. Custom headers
		add(new CommentRecord("Heterofor Water Balance Yearly Export (HetWaterBalanceYearlyExport) at " + new Date()));
		add(new EmptyRecord());

		// Tree line header
		add(new CommentRecord("Water Balance lines"));
		String columnNames = "year" + TAB + "rainfall (mm)" + TAB + "stemflow (mm)" + TAB + "throughfall (mm)" + TAB
				+ "interception (mm)" + TAB + "transpiration (mm)" + TAB + "standLevel_transpiration (mm)" + TAB
				+ "treeLevel_transpiration (mm)" + TAB + "groundVegetationTranspiration (mm)" + TAB
				+ "barkEvaporation (mm)" + TAB + "foliageEvaporation (mm)" + TAB
				+ "vegetationEvaporation (mm)" + TAB + "soilEvaporation (mm)" + TAB + "deepDrainage (mm)" + TAB
				+ "relativeExtractableWater (mm.mm-1)" + TAB + "forestFloorRelativeExtractableWater (mm.mm-1)";
		for (int horizonId : sortedHorizonIds) {
			
			// fc-13.11.2019			
			columnNames += TAB + "horizonWaterContent (m3.m-3) for horizon " + horizonId + " - "
					+ scene.getSoil().getPedonSpecimen().getHorizon(horizonId).name; // fa-19.11.2019: OK, valid for any pedon (horizon names are the same for any pedon)
//			columnNames += TAB + "horizonWaterContent (m3.m-3) for horizon " + horizonId + " - "
//					+ scene.getSoil().getHorizon(horizonId).name;
		}
		columnNames += TAB + "grossPrimaryProduction_gC_m2 (TODO: unit)" + TAB + "netPrimaryProduction_gC_m2 (TODO: unit)"
						+ TAB + "maintenanceRespiration_gC_m2 (TODO: unit)" + TAB + "waterContentStockVariation (TODO: unit)"
						+ TAB + "waterBalance (TODO: unit)";
		add(new CommentRecord(columnNames));

		Step step = scene.getStep();
		Project project = step.getProject();

		// Create full waterbalance map containing all entries until the current scene's date.
		LinkedHashMap<String, HetWaterBalance> fullWBMap = new LinkedHashMap<>();

		// Create dateStepMap with key: scene's date, value: the step having this date. nb-13.09.2017
		HashMap<Integer, Step> dateStepMap = new HashMap<Integer, Step>();

		// fa-21.11.2019
		int initYear = 0;
		
		for (Step st : project.getStepsFromRoot(step)) {
			
			// fa-17.12.2019: skip 'star scene' (result of intervention, with dead or thinned trees removed)
			if (st.getScene().isInterventionResult())
				continue;

			dateStepMap.put(st.getScene().getDate(), st);

			HetScene sc = (HetScene) st.getScene();
			
			// fa-21.11.2019
			if (sc.isInitialScene())
				initYear = sc.getDate();

			// no waterbalance map for root step
			
			// fc-19.11.2019 Works only for an HetSoil, not for HetDiscreteSoil)
			// fa-19.11.2019: now OK in any case (averageWaterBalanceMap for HetDiscreteSoil)
			if (sc.getWaterBalanceMap () != null && !sc.getWaterBalanceMap ().isEmpty()) {
				fullWBMap.putAll(sc.getWaterBalanceMap ());
			}
//			if (sc.waterBalanceMap != null && !sc.waterBalanceMap.isEmpty()) {
//				fullWBMap.putAll(sc.waterBalanceMap);
//			}
		}

		// Create wbMapYearly: yearly waterbalance map. For example, wbMapYearly
		// map has three entries if fullWBMap map contains entries over three
		// years. So wbMapYearly map has one entry per year.
		// wbMapYearly map :
		// key: the year string (e.g.: 2002_)
		// value: the waterbalance object containing physical variables
		// summed and averaged over the year
		HetWaterBalanceIntegrator wbi = new HetWaterBalanceIntegrator(fullWBMap, HetWaterBalanceIntegrator.YEAR_LEVEL);
		wbMapYearly = wbi.integrate();

//		writeLines(dateStepMap);
		writeLines(dateStepMap, initYear); // fa-21.11.2019
	}

//	private void writeLines(HashMap<Integer, Step> dateStepMap) {
	private void writeLines(HashMap<Integer, Step> dateStepMap, int initYear) { // fa-21.11.2019
		
		// fa-25.11.2019
		Map<Integer, Double> previousSceneHorizonsLastWaterContentMap = new HashMap<Integer, Double>();

		for (Iterator<String> i = wbMapYearly.keySet().iterator(); i.hasNext();) {

			String key = i.next();
			HetWaterBalance wb = wbMapYearly.get(key);

			Line line = new Line();

			line.year = wb.year;

			line.rainfall = wb.rainfall;
			line.stemflow = wb.stemflow;
			line.throughfall = wb.throughfall;
			line.interception = wb.interception;
			line.transpiration = wb.transpiration;

			// fc+mj-13.9.2017
			line.standLevel_transpiration = wb.standLevel_transpiration;
			line.treeLevel_transpiration = wb.treeLevel_transpiration;
			line.groundVegetationTranspiration = wb.groundVegetationTranspiration;

			line.barkEvaporation = wb.barkEvaporation;
			line.foliageEvaporation = wb.foliageEvaporation;

			line.vegetationEvaporation = wb.vegetationEvaporation;
			line.soilEvaporation = wb.soilEvaporation;
			line.deepDrainage = wb.deepDrainage;

			line.relativeExtractableWater = wb.relativeExtractableWater;
			line.forestFloorRelativeExtractableWater = wb.forestFloorRelativeExtractableWater;

			// Last columns contains one value per horizon, separated by tabs
			// (horizons number may vary)
			// Sort horizon ids on ascending order
			Set<Integer> sortedHIds = new TreeSet<>(wb.horizonWaterContent.keySet());

			StringBuffer b = new StringBuffer();
			for (Iterator<Integer> j = sortedHIds.iterator(); j.hasNext();) {

				int hId = j.next();
				double v = wb.horizonWaterContent.get(hId);

				b.append(v);

				if (j.hasNext())
					b.append(TAB);
			}

			line.horizonWaterContents = b.toString();

			Step step = dateStepMap.get(wb.year);
			HetScene scene = (HetScene) step.getScene();

			line.grossPrimaryProduction_gC_m2 = scene.getGrossPrimaryProduction_gC_m2();
			line.netPrimaryProduction_gC_m2 = scene.getNetPrimaryProduction_gC_m2();
			line.maintenanceRespiration_gC_m2 = scene.getMaintenanceRespiration_gC_m2();

			// Calculate water balance. nb-12.09.2017
			double waterContentVariation = 0.0;

			// fa-25.11.2019
			// OK to use getPedonSpecimen() as properties associated with these horizons used here (thickness, additional coarse fraction) are the same for all pedons
			Map<Integer, HetHorizon> sceneHorizonsMap = scene.getSoil().getPedonSpecimen().getHorizonMap();
			HashMap<String, HetWaterBalance> sceneWaterBalanceMap = scene.getWaterBalanceMap();
			Map<Integer, Double> sceneHorizonsLastWaterContentMap = new HashMap<Integer, Double>();
			if (!scene.getSoil().isDiscreteSoil())
				sceneHorizonsLastWaterContentMap = sceneWaterBalanceMap.get(wb.year + "_12_31_23").horizonWaterContent;
			else // in detailed water balance mode, waterBalanceMaps are now integrated at the daily level to save memory
				sceneHorizonsLastWaterContentMap = sceneWaterBalanceMap.get(wb.year + "_12_31_").horizonWaterContent;
			
			double previousSceneLastWaterContent = 0d; 

			for (int horizonId : sortedHIds) {
				
				double sceneLastWaterContent = sceneHorizonsLastWaterContentMap.get(horizonId);
				
				if (wb.year == initYear + 1) // no water balance processed on initial scene => no simulated horizon water content available
					previousSceneLastWaterContent = sceneHorizonsMap.get(horizonId).meanWaterContent; // OK to take it from 'scene', same for all scenes
				else
					previousSceneLastWaterContent = previousSceneHorizonsLastWaterContentMap.get(horizonId);

				waterContentVariation += (sceneLastWaterContent - previousSceneLastWaterContent)
						* sceneHorizonsMap.get(horizonId).thickness * (1.0 - sceneHorizonsMap.get(horizonId).additionalCoarseFraction) * 1000.0;
//				waterContentVariation += (horizonOfScene.lastWaterContent - horizonOfPreviousScene.lastWaterContent)
//						* horizonOfScene.thickness * (1.0 - horizonOfScene.additionalCoarseFraction) * 1000.0;
			}
			line.waterContentStockVariation = waterContentVariation;

//			line.waterBalance = line.rainfall
//					- (line.transpiration + line.vegetationEvaporation + line.soilEvaporation + line.deepDrainage + line.waterContentStockVariation);
			line.waterBalance = line.rainfall
					- (line.transpiration + line.interception + line.soilEvaporation + line.deepDrainage + line.waterContentStockVariation); // mj+fa-26.09.2017

			add(line);
			
			previousSceneHorizonsLastWaterContentMap = sceneHorizonsLastWaterContentMap;
		}

	}

	/**
	 * Importation is not implemented here
	 */
	@Override
	public GScene load(GModel m) throws Exception {
		return null;
	}

}
