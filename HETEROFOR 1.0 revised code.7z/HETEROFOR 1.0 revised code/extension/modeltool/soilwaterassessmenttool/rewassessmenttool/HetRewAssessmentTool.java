/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.extension.modeltool.soilwaterassessmenttool.rewassessmenttool;

import heterofor.extension.modeltool.soilwaterassessmenttool.HetSoilWaterAssessmentManager;
import heterofor.extension.modeltool.soilwaterassessmenttool.HetSoilWaterAssessmentTool;
import heterofor.model.HetModel;
import heterofor.model.HetScene;
import heterofor.model.meteorology.HetMeteorology;
import heterofor.model.waterbalance.HetWaterBalance;
import heterofor.model.waterbalance.HetWaterBalanceCalculator;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import jeeb.lib.util.Log;
import jeeb.lib.util.MessageDialog;
import jeeb.lib.util.StatusDispatcher;
import jeeb.lib.util.Translator;
import jeeb.lib.util.task.Task;
import jeeb.lib.util.task.TaskManager;

import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import capsis.kernel.GModel;
import capsis.kernel.Step;
import capsis.util.Calendar;

/**
 * A tool to compare hourly or daily simulated and observed relative extractable water (REW) values in
 * a soil composed of several horizons.
 * It is a subclass of {@link HetSoilWaterAssessmentTool} which allows to generate a part of the graphical
 * user interface and retrieve water content values in an observations file.
 *
 * @author N. Beudez - October 2017
 */
public class HetRewAssessmentTool extends HetSoilWaterAssessmentTool {

	static {
		Translator.addBundle("heterofor.extension.modeltool.soilwaterassessmenttool.HetSoilWaterAssessmentTool");
	}

	// nb-13.08.2018
	//public static final String NAME = "HetRewAssessmentTool";
	//public static final String VERSION = "1.0";
	//public static final String AUTHOR = "N. Beudez, M. Jonard";
	//public static final String DESCRIPTION = "HetRewAssessmentTool.description";

	// Map containing simulated water content values.
	// key: "year_month_day_hour" (case of hourly observations) or "year_month_day" (case of daily observations)
	// value: map with key: horizon's id and value: simulated water content (an hourly value in the case of
	// hourly observations or an averaged value in the the case of daily observations)
	public Map<String, Map<Integer, Double>> simulatedWaterContentMap;

	/**
	 * Default constructor.
	 */
	public HetRewAssessmentTool() {

		super();
	}

	@Override
	public void init(GModel model, Step step) {

		super.init(model, step, "HetRewAssessmentTool");
		simulatedWaterContentMap = new HashMap<String, Map<Integer, Double>>();
	}

	/**
	 * Extension dynamic compatibility mechanism. This matchwith() method checks
	 * if the extension can deal (i.e. is compatible) with the referent.
	 */
	static public boolean matchWith(Object referent) {

		return referent instanceof HetModel;
	}

	@Override
	public String getName() {
		return Translator.swap("HetRewAssessmentTool.name");
	}

	@Override
	public String getAuthor() {
		return "N. Beudez, M. Jonard";
	}

	@Override
	public String getDescription() {
		return Translator.swap("HetRewAssessmentTool.description");
	}

	@Override
	public String getVersion() {
		return "1.0";
	}

	/**
	 * Action on the draw curves button: retrieves observed water content values, checks their validity and
	 * compatibility with simulated dates, retrieves corresponding simulated water content values and
	 * creates a viewer aimed at displaying the curves of observed and simulated relative extractable water
	 * (REW) values over time.
	 *
	 * @throws Exception
	 */
	@Override
	protected void drawCurvesButtonAction() throws Exception {

		// Creates a task
		Task<Object, Void> task = new Task<Object, Void>(Translator.swap("HetRewAssessmentTool.comparisonOfObservedAndSimulatedREWValues")) {

			@Override
			protected void doFirstInEDT() {

				// Deletes existing message in the left part of the status panel
				StatusDispatcher.print("");
			}

			@Override
			protected Object doInWorker() throws InterruptedException {

				try {
					// Writes in the right part of the status panel
					StatusDispatcher.print(Translator.swap("HetSoilWaterAssessmentTool.graphCreationInProgress"));

					// Creates an empty data set aimed at containing 2 series :
					// - a series of observed relative extractable water (REW) values
					// - a series of simulated relative extractable water (REW) values
					XYSeriesCollection dataSet = new XYSeriesCollection();

					// Prepares observed and simulated REW values
					prepareData(dataSet);

					// Creates the viewer without displaying it (see doInEDTafterWorker() method)
					HetRewAssessmentViewer viewer = createViewer(dataSet);

					return viewer;

				} catch (Exception e) {

					Log.println(Log.ERROR, "HetRewAssessmentTool.drawCurvesButtonAction()",
							"Problem occurs when preparing observed/simulated relative extractable water (REW) values for drawing", e);
					MessageDialog.print(this, e.getMessage());

					return null;
				}
			}

			@Override
			protected void doInEDTafterWorker() {

				try {

					HetRewAssessmentViewer viewer = (HetRewAssessmentViewer) get();

					if (viewer != null) {

						// Displays the viewer
						displayViewer(viewer);

						// Writes in the left part of the status panel
						// TODO: to be improved. Indeed this message sometimes appears before the viewer is displayed.
						StatusDispatcher.print(Translator.swap("HetSoilWaterAssessmentTool.graphCreationTerminated"));
					} else {

						// Writes in the left part of the status panel
						StatusDispatcher.print(Translator.swap("HetSoilWaterAssessmentTool.graphCreationAborted"));
					}

				} catch (InterruptedException | ExecutionException e) {

					Log.println(Log.ERROR, "HetRewAssessmentTool.drawCurvesButtonAction()",
							"Problem occurs when drawing observed/simulated data curves", e);
					MessageDialog.print(this, e.getMessage());
				}
			}
		};

		// Allows to see a moving bar in the progress bar instead of a percentage that would
		// stay to the 0 value until task terminated
		task.setIndeterminate();

		// Executes the created task
		TaskManager.getInstance().add(task);
	}

	/**
	 * Retrieves observed water content values, do some checks and fills in the given empty data set with
	 * observed and simulated relative extractable water (REW) values calculated from observed and simulated
	 * water content values.
	 *
	 * @param dataSet The empty data set aimed at containing: a series of observed relative extractable
	 * water (REW) values and a series of simulated relative extractable water (REW) values.
	 * @throws Exception
	 */
	private void prepareData(XYSeriesCollection dataSet) throws Exception {

		// Retrieves observed water content values and do some checks
		super.drawCurvesButtonAction();

		// Retrieves simulated water content values
//		retrieveSimulatedWaterContentValues(manager.areHourlyData()); // fa-25.11.2019: commented
		// fa-25.11.2019
		HetScene initScene = (HetScene) model.getProject().getRoot().getScene();
		if (!initScene.getSoil().isDiscreteSoil()) // Default water balance mode => hourly of daily data can be loaded
			retrieveSimulatedWaterContentValues(manager.areHourlyData());
		else { // Detailed water balance mode, water balance maps are now aggregated at the daily time step to save memory
			if (manager.areHourlyData())
				throw new Exception("Error: incompatibility between hourly water content observations in file\n\n" + manager.getObservationsFileName()
						+ "\n\nand simulated values integrated at the daily time step in detailed water balance mode.\n\nAborted.");
			else
				retrieveSimulatedWaterContentValues(manager.areHourlyData());
		}

		// Fills in dataSet with observed and simulated relative extractable water (REW) values
		XYSeries observedREWSeries = new XYSeries(Translator.swap("HetRewAssessmentTool.observedRelativeExtractableWater"));
		XYSeries simulatedREWSeries = new XYSeries(Translator.swap("HetRewAssessmentTool.simulatedRelativeExtractableWater"));

		dataSet.addSeries(observedREWSeries);
		dataSet.addSeries(simulatedREWSeries);

		fillInSeriesOfObservedAndSimulatedREWValues(observedREWSeries, simulatedREWSeries);
	}

	/**
	 * Creates the viewer allowing to print the observed and simulated relative extractable water (REW) values. This
	 * method does not print this viewer: see the {@link #display(HetRewAssessmentViewer)} method.
	 *
	 * @param dataSet The set containing series of observed and simulated relative extractable water (REW) values
	 */
	private HetRewAssessmentViewer createViewer(XYSeriesCollection dataSet) {

		HetRewAssessmentViewer viewer = new HetRewAssessmentViewer(dataSet, this);
		return viewer;
	}

	/**
	 * Retrieves the simulated water content values at dates and for horizons of the observations file.
	 * All the dates that are strictly lower than the simulation begin date or strictly greater
	 * than the last simulated date of the current step (see {@link HetSoilWaterAssessmentTool.step}) are
	 * ignored. Retrieved simulated water content values are stored in the {@link simulatedWaterContentMap}
	 * map.
	 *
	 * @param hourlyData True if observed water content are hourly, false if they are daily
	 * @throws Exception
	 */
	public void retrieveSimulatedWaterContentValues(boolean hourlyData) throws Exception {

		if (hourlyData) {
			retrieveSimulatedWaterContentValuesForHourlyObservations();
		} else {
			retrieveSimulatedWaterContentValuesForDailyObservations();
		}
	}

	/**
	 * Stores in the {@link simulatedWaterContentMap} map the hourly values of water content simulated for the
	 * hourly dates and horizons of the {@link observedWaterContentMap} map.
	 * All the dates of {@link observedWaterContentMap} map that are lower than the simulation begin date or
	 * greater than the last simulated date of current step (see {@link HetSoilWaterAssessmentTool.step}) are
	 * ignored.
	 *
	 * @throws Exception
	 */
	private void retrieveSimulatedWaterContentValuesForHourlyObservations() throws Exception {

		// Needed each time the user clicks on the "draw curves" button without
		// having closed the tool: he makes several comparisons in the same tool's instance.
		simulatedWaterContentMap.clear();

		Map<String, Map<Integer, Double>> observedWaterContentMap = manager.getObservedWaterContentMap();

		// Map with key: year, value: corresponding scene
		Map<Integer, HetScene> yearSceneMap = new HashMap<Integer, HetScene>();

		for (Step st : model.getProject().getStepsFromRoot(step)) {

			HetScene scene = (HetScene) st.getScene();
			int year = scene.getDate();
			yearSceneMap.put(year, scene);
		}

		for (String date : observedWaterContentMap.keySet()) {

			// date is "year_month_day_hour" string
			String[] yearMonthDayHourTab = date.split(HetMeteorology.SEP);
			int year = Integer.valueOf(yearMonthDayHourTab[0]);

			HetScene scene = yearSceneMap.get(year);

			// Consider only years of simulation
			if (scene != null) {

				Map<Integer, Double> horizonIdObservedWaterContentMap = observedWaterContentMap.get(date);

				for (int horizonId : horizonIdObservedWaterContentMap.keySet()) {

					HetWaterBalance waterBalance; // fa-25.11.2019
					if (!scene.getSoil().isDiscreteSoil())
						waterBalance = scene.getWaterBalanceMap ().get(date);
					else // in detailed water balance mode, dates are generated by HetWaterBalanceIntegrator when aggregating water balance map at daily time step to save memory
						waterBalance = scene.getWaterBalanceMap ().get(date + "_");
//					HetWaterBalance waterBalance = scene.waterBalanceMap.get(date);

					// waterBalance is null for initial scene (no calculation is made)
					if (waterBalance != null) {

						Map<Integer, Double> horizonIdSimulatedWaterContentMap = waterBalance.horizonWaterContent;

						// The checking that the list of horizon's ids in observation file is included in the
						// list of horizon's ids of the soil simulated by Heterofor has already been done: see the
						// HetSoilWaterAssessmentManager.checkObservedHorizonIdListCompatibility() method.
						// Thus the following simulatedWaterContent variable should not be null. But a checking is
						// still done in the case a water content were not calculated by Heterofor, what would be an
						// error in the process of Heterofor calculations if it occurred.

						if (horizonIdSimulatedWaterContentMap.get(horizonId) == null) {
							String errorMessage = "Error: no water content calculated by Heterofor for horizon with id " +
													horizonId + " at time " + date + ".\n\nAborted.";
							throw new Exception(errorMessage);
						}

						double simulatedWaterContent = horizonIdSimulatedWaterContentMap.get(horizonId);

						// Fills in simulatedWaterContentMap map
						if (!simulatedWaterContentMap.containsKey(date)) {
							Map<Integer, Double> horizonIdSimulatedWaterContentMap2 = new HashMap<Integer, Double>();
							horizonIdSimulatedWaterContentMap2.put(horizonId, simulatedWaterContent);
							simulatedWaterContentMap.put(date, horizonIdSimulatedWaterContentMap2);
						} else {
							simulatedWaterContentMap.get(date).put(horizonId, simulatedWaterContent);
						}
					}
				}
			}
		}
	}

	/**
	 * Stores in the {@link simulatedWaterContentMap} map the daily values of water content
	 * obtained by averaging the hourly values of water content simulated for the daily dates
	 * and horizons of the {@link observedWaterContentMap} map.
	 * All the dates of {@link observedWaterContentMap} map that are lower than the simulation begin date or
	 * greater than the last simulated date of current step (see {@link HetSoilWaterAssessmentTool.step}) are
	 * ignored.
	 *
	 * @throws Exception
	 */
	private void retrieveSimulatedWaterContentValuesForDailyObservations() throws Exception {

		// Needed each time the user clicks on the "draw curves" button without
		// having closed the tool: he makes several comparisons in the same tool's instance.
		simulatedWaterContentMap.clear();

		// Map with key: year, value: corresponding scene
		Map<Integer, HetScene> yearSceneMap = new HashMap<Integer, HetScene>();

		for (Step st : model.getProject().getStepsFromRoot(step)) {

			HetScene scene = (HetScene) st.getScene();
			int year = scene.getDate();
			yearSceneMap.put(year, scene);
		}

		for (String date : manager.getObservedWaterContentMap().keySet()) {

			// date is "year_month_day" string
			String[] yearMonthDayTab = date.split(HetMeteorology.SEP);
			int year = Integer.valueOf(yearMonthDayTab[0]);

			HetScene scene = yearSceneMap.get(year);

			// Consider only years of simulation
			if (scene != null) {

				Map<Integer, Double> horizonIdObservedWaterContentMap = manager.getObservedWaterContentMap().get(date);

				for (int horizonId : horizonIdObservedWaterContentMap.keySet()) {

					double dailyAverageSimulatedWaterContent = 0.0;
					
					HetWaterBalance waterBalance; // fa-25.11.2019
					if (!scene.getSoil().isDiscreteSoil()) { // default water balance mode

						// Loop on all the hours of the current day (date is "year_month_day" string)
						for (int hour=0 ; hour<24 ; ++hour) {

							// fc-19.11.2019 Works only for an HetSoil, not for HetDiscreteSoil)
							// fa-25.11.2019: Now also OK for HetDiscreteSoil
							waterBalance = scene.getWaterBalanceMap ().get(date + HetMeteorology.SEP + hour);
//							HetWaterBalance waterBalance = scene.waterBalanceMap.get(date + HetMeteorology.SEP + hour);

							// waterBalance is null for initial scene (no calculation is made)
							if (waterBalance != null) {

								Map<Integer, Double> horizonIdSimulatedWaterContentMap = waterBalance.horizonWaterContent;

								// The checking that the list of horizon's ids in observation file is included in the
								// list of horizon's ids of the soil simulated by Heterofor has already been done: see the
								// HetSoilWaterAssessmentManager.checkObservedHorizonIdListCompatibility() method.
								// Thus the following simulatedWaterContent variable should not be null. But a checking is
								// still done in the case a water content were not calculated by Heterofor, what would be an
								// error in the process of Heterofor calculations if it occurred.

								if (horizonIdSimulatedWaterContentMap.get(horizonId) == null) {
									String errorMessage = "Error: no water content calculated by Heterofor for horizon with id " +
															horizonId + " at time " + date + ".\n\nAborted.";
									throw new Exception(errorMessage);
								}

								double simulatedWaterContent = horizonIdSimulatedWaterContentMap.get(horizonId);
								dailyAverageSimulatedWaterContent += simulatedWaterContent;
							}
						}

						dailyAverageSimulatedWaterContent /= 24;
						
					} else { // fa-25.11.2019: in detailed water balance mode, water balance maps are already aggregated at the daily time step to save memory
						waterBalance = scene.getWaterBalanceMap().get(date + HetMeteorology.SEP ); // in detailed water balance mode, dates are generated by HetWaterBalanceIntegrator
						
						// waterBalance is null for initial scene (no calculation is made)
						if (waterBalance != null) {
							Map<Integer, Double> horizonIdSimulatedWaterContentMap = waterBalance.horizonWaterContent;
							
							if (horizonIdSimulatedWaterContentMap.get(horizonId) == null) {
								String errorMessage = "Error: no water content calculated by Heterofor for horizon with id " +
															horizonId + " at time " + date + ".\n\nAborted.";
								throw new Exception(errorMessage);
							}
						
							dailyAverageSimulatedWaterContent = horizonIdSimulatedWaterContentMap.get(horizonId);
						}
					}

					// Fills in simulatedWaterContentMap map
					if (!simulatedWaterContentMap.containsKey(date)) {
						Map<Integer, Double> horizonIdSimulatedWaterContentMap2 = new HashMap<Integer, Double>();
						horizonIdSimulatedWaterContentMap2.put(horizonId, dailyAverageSimulatedWaterContent);
						simulatedWaterContentMap.put(date, horizonIdSimulatedWaterContentMap2);
					} else {
						simulatedWaterContentMap.get(date).put(horizonId, dailyAverageSimulatedWaterContent);
					}
				}
			}
		}
	}

	/**
	 * Fills in the initially empty series passed as parameters with hourly or daily observed and simulated values
	 * of relative extractable water (REW).
	 *
	 * @param observedREWSeries The initially empty series aimed at containing observed relative extractable water (REW) values.
	 * @param simulatedREWSeries The initially empty series aimed at containing simulated relative extractable water (REW) values.
	 */
	public void fillInSeriesOfObservedAndSimulatedREWValues(XYSeries observedREWSeries, XYSeries simulatedREWSeries) {

		// Map with key: year, value: the corresponding scene
		Map<Integer, HetScene> yearSceneMap = new HashMap<Integer, HetScene>();

		for (Step st : model.getProject().getStepsFromRoot(step)) {

			HetScene scene = (HetScene) st.getScene();

			//fa-21.06.2019: skip to avoid duplicates ('star scene'))
			if (scene.isInterventionResult())
				continue;

			int year = scene.getDate();
			yearSceneMap.put(year, scene);
		}

		if (manager.areHourlyData()) {

			// Case 1: the observations file contains hourly water content values

			for (Step st : model.getProject().getStepsFromRoot(step)) {

				HetScene scene = (HetScene) st.getScene();
				int cptHour = 0;

				//fa-21.06.2019: skip to avoid duplicates ('star scene'))
				if (scene.isInterventionResult())
					continue;

				// fc-19.11.2019 Works only for an HetSoil, not for HetDiscreteSoil)
				for (String date : scene.getWaterBalanceMap ().keySet()) {
//				for (String date : scene.waterBalanceMap.keySet()) {

					// date is "year_month_day_hour" string
					String[] yearMonthDayHourTab = date.split(HetMeteorology.SEP);
					int year = Integer.valueOf(yearMonthDayHourTab[0]);

					double time;

					if (Calendar.isLeap(year)) {
						time = year + cptHour/(24*366.0);
					} else {
						time = year + cptHour/(24*365.0);
					}

					if (manager.getObservedWaterContentMap().keySet().contains(date)) {

						// fc-13.11.2019			
						double observedRelativeExtractableWater = HetWaterBalanceCalculator.calculateRelativeExtractableWater(manager.getObservedWaterContentMap().get(date),
								scene.getSoil().getPedonSpecimen().getHorizons(), scene.getArea()); // fa-19.11.2019: OK to use getPedonSpecimen(), horizon characteristics used here (id, volume, wiltingPointWaterContent, additionalCoarseFraction, fieldCapacityWaterContent) are the same for all pedons
																									// scene.getArea() OK as this tool applies at the scene spatial scale => average over all pedons for detailed water balance

						double simulatedRelativeExtractableWater = HetWaterBalanceCalculator.calculateRelativeExtractableWater(simulatedWaterContentMap.get(date),
								scene.getSoil().getPedonSpecimen().getHorizons(), scene.getArea()); // fa-19.11.2019: OK to use getPedonSpecimen(), horizon characteristics used here (id, volume, wiltingPointWaterContent, additionalCoarseFraction, fieldCapacityWaterContent) are the same for all pedons
																									// scene.getArea() OK as this tool applies at the scene spatial scale => average over all pedons for detailed water balance
						
//						double observedRelativeExtractableWater = HetWaterBalanceCalculator.calculateRelativeExtractableWater(manager.getObservedWaterContentMap().get(date),
//								scene.getSoil().getHorizons(), scene.getArea());
//
//						double simulatedRelativeExtractableWater = HetWaterBalanceCalculator.calculateRelativeExtractableWater(simulatedWaterContentMap.get(date),
//								scene.getSoil().getHorizons(), scene.getArea());

						observedREWSeries.add(time, observedRelativeExtractableWater);
						simulatedREWSeries.add(time, simulatedRelativeExtractableWater);
					} else {
						observedREWSeries.add(time, null);
						simulatedREWSeries.add(time, null);
					}

					++cptHour;
				}
			}

		} else {

			// Case 2: the observations file contains daily water content values

			for (Step st : model.getProject().getStepsFromRoot(step)) {

				HetScene scene = (HetScene) st.getScene();
				int cptDay = 1;

				//fa-21.06.2019: skip to avoid duplicates ('star scene'))
				if (scene.isInterventionResult())
					continue;

				// fc-19.11.2019 Works only for an HetSoil, not for HetDiscreteSoil)
				// fa-25.11.2019: Now also OK for HetDiscreteSoil
				for (String date : scene.getWaterBalanceMap ().keySet()) {
//				for (String date : scene.waterBalanceMap.keySet()) {

					String[] yearMonthDayHourTab = date.split(HetMeteorology.SEP);
					int year = Integer.valueOf(yearMonthDayHourTab[0]);
					int month = Integer.valueOf(yearMonthDayHourTab[1]);
					int day = Integer.valueOf(yearMonthDayHourTab[2]);
					
					if (!scene.getSoil().isDiscreteSoil()) { // fa-25.11.2019: default water balance mode, date is "year_month_day_hour" string
						
						int hour = Integer.valueOf(yearMonthDayHourTab[3]);

						if (hour != 0) continue;	
					}
					
					double time;

					if (Calendar.isLeap(year)) {
						time = year+cptDay/366.0;
					} else {
						time = year+cptDay/365.0;
					}

					String dailyDate = "" + year + HetMeteorology.SEP + month + HetMeteorology.SEP + day;

					if (manager.getObservedWaterContentMap().keySet().contains(dailyDate)) {
						
						// fc-13.11.2019
						double observedRelativeExtractableWater = HetWaterBalanceCalculator.calculateRelativeExtractableWater(manager.getObservedWaterContentMap().get(dailyDate),
								scene.getSoil().getPedonSpecimen().getHorizons(), scene.getArea()); // fa-19.11.2019: OK to use getPedonSpecimen(), horizon characteristics used here (id, volume, wiltingPointWaterContent, additionalCoarseFraction, fieldCapacityWaterContent) are the same for all pedons
																									// scene.getArea() OK as this tool applies at the scene spatial scale => average over all pedons for detailed water balance

						double simulatedRelativeExtractableWater = HetWaterBalanceCalculator.calculateRelativeExtractableWater(simulatedWaterContentMap.get(dailyDate),
								scene.getSoil().getPedonSpecimen().getHorizons(), scene.getArea()); // fa-19.11.2019: OK to use getPedonSpecimen(), horizon characteristics used here (id, volume, wiltingPointWaterContent, additionalCoarseFraction, fieldCapacityWaterContent) are the same for all pedons
																									// scene.getArea() OK as this tool applies at the scene spatial scale => average over all pedons for detailed water balance

//						double observedRelativeExtractableWater = HetWaterBalanceCalculator.calculateRelativeExtractableWater(manager.getObservedWaterContentMap().get(dailyDate),
//								scene.getSoil().getHorizons(), scene.getArea());
//
//						double simulatedRelativeExtractableWater = HetWaterBalanceCalculator.calculateRelativeExtractableWater(simulatedWaterContentMap.get(dailyDate),
//								scene.getSoil().getHorizons(), scene.getArea());

						observedREWSeries.add(time, observedRelativeExtractableWater);
						simulatedREWSeries.add(time, simulatedRelativeExtractableWater);
					} else {
						observedREWSeries.add(time, null);
						simulatedREWSeries.add(time, null);
					}

					++cptDay;
				}
			}

		}
	}
	
	// fa-21.06.2019: for water balance calibration script
	public void setStep(Step step) {
		super.step = step;
	}

	// fa-21.06.2019: for water balance calibration script
	public void setModel(GModel model) {
		super.model = model;
	}

	// fa-21.06.2019: for water balance calibration script
	public void setManager(HetSoilWaterAssessmentManager  manager) {
		super.manager = manager;
	}
	

}
