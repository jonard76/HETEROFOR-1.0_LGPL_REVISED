/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.extension.modeltool.soilwaterassessmenttool;

import heterofor.model.HetScene;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import jeeb.lib.util.ColumnPanel;
import jeeb.lib.util.LinePanel;
import jeeb.lib.util.Log;
import jeeb.lib.util.MessageDialog;
import jeeb.lib.util.PathManager;
import jeeb.lib.util.Settings;
import jeeb.lib.util.Translator;
import capsis.extension.DialogModelTool;
import capsis.kernel.GModel;
import capsis.kernel.Step;

/**
 * An abstract class for tools aimed at comparing observed and simulated soil water data (e.g. water content values
 * or data calculated from water content values like relative extractable water). This class allows to generate
 * a graphical user interface, select a file containing observed water content values and create a soil water
 * assessment manager which loads these data and then check their compatibility with the simulated dates
 * and the list of the soil's horizons.
 *
 * @author N. Beudez - October 2017
 */
public abstract class HetSoilWaterAssessmentTool extends DialogModelTool implements ActionListener, DocumentListener {

	static {
		Translator.addBundle("heterofor.extension.modeltool.soilwaterassessmenttool.HetSoilWaterAssessmentTool");
	}

	protected GModel model;
	protected Step step;
	private String toolName;
	protected HetSoilWaterAssessmentManager manager;

	// Graph part
	protected JTextField observationFileNameTextField;
	private JButton browseButton;
	protected JButton drawCurvesButton;
	protected JScrollPane viewerScrollPane;
	private JButton closeButton;

	/**
	 * Constructor.
	 */
	public HetSoilWaterAssessmentTool() {

		super();
	}

	/**
	 * Initializes the tool.
	 *
	 * @param model The model
	 * @param step The current step
	 * @param toolName The tool's name
	 */
	public void init(GModel model, Step step, String toolName) {

		try {

			this.model = model;
			this.step = step;
			this.toolName = toolName;

			// If the user launches the assessment tool (water content assessment or relative extractable
			// water assessment) on the initial step: impossible to go further because no water content
			// should be calculated in initial scene.

			HetScene scene = (HetScene) step.getScene();

			if (scene.isInitialScene()) {

				// fc-19.11.2019 Works only for an HetSoil, not for HetDiscreteSoil)
				// fa-25.11.2019: Now also OK for HetDiscreteSoil
				if (scene.getWaterBalanceMap () == null || scene.getWaterBalanceMap ().isEmpty()) {
//				if (scene.waterBalanceMap == null || scene.waterBalanceMap.isEmpty()) {

					int dateOfInitialScene = scene.getDate();

					String errorMessage = "Impossible to launch the assessment tool: no water content value "
							+ "is simulated in year " + dateOfInitialScene + " (initial scene)." + "\n\nAborted.";

					throw new Exception(errorMessage);
				}
			}

			// Creation of the user interface
			createUI();

			this.setTitle(getName() + " - " + step.getCaption());
			this.setModalityType(Dialog.ModalityType.MODELESS); // Equivalent to setModal(false) which is obsolete
			this.setSize(1000, 700);

			this.setVisible(true);

		} catch (Exception e) {
			Log.println(Log.ERROR, "HetSoilWaterAssessmentTool.init()", "Problem during initialization", e);
			MessageDialog.print(this, e.getMessage());
		}
	}

	/**
	 * Creates the user interface.
	 *
	 * @param toolName The tool's name
	 */
	private void createUI() {

		// Top panel with 4 pixels at the beginning of the column and 4 pixels between its components
		ColumnPanel topColumnPanel = new ColumnPanel(4, 4);

		LinePanel l1 = new LinePanel();
		l1.add(new JLabel(Translator.swap("HetSoilWaterAssessmentTool.observationFileName") + " : "));
		observationFileNameTextField = new JTextField();
		observationFileNameTextField.setText(Settings.getProperty("heterofor." + toolName + ".observationFileName", ""));
		observationFileNameTextField.getDocument().addDocumentListener(this);
		l1.add(observationFileNameTextField);
		browseButton = new JButton(Translator.swap("Shared.browse"));
		browseButton.addActionListener(this);
		l1.add(browseButton);
		l1.addStrut0();
		topColumnPanel.add(l1);

		LinePanel l2 = new LinePanel();
		drawCurvesButton = new JButton(Translator.swap("HetSoilWaterAssessmentTool.drawCurves"));
		manageDrawCurvesButtonVisibility();
		drawCurvesButton.addActionListener(this);
		l2.add(drawCurvesButton);
		topColumnPanel.add(l2);
		topColumnPanel.addStrut0();

		// Scroll pane aimed at containing the viewer: HetRewAssessmentViewer or
		// HetWaterContentAssessmentViewer.
		viewerScrollPane = new JScrollPane();
		LinePanel viewerLinePanel = new LinePanel();
		viewerScrollPane.getViewport().setView(viewerLinePanel);

		// Control panel
		JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		closeButton = new JButton(Translator.swap("Shared.close"));
		closeButton.addActionListener(this);
		controlPanel.add(closeButton);

		// Adds the panels and the scroll pane to the container
		Container cont = this.getContentPane();
		cont.setLayout(new BorderLayout(0, 8));
		cont.add(topColumnPanel, BorderLayout.NORTH);
		cont.add(viewerScrollPane, BorderLayout.CENTER);
		cont.add(controlPanel, BorderLayout.SOUTH);
	}

	/**
	 * Enables or disables the draw curves button.
	 */
	private void manageDrawCurvesButtonVisibility() {

		if (observationFileNameTextField.getText().isEmpty()) {
			drawCurvesButton.setEnabled(false);
		} else {
			drawCurvesButton.setEnabled(true);
		}
	}

	/**
	 * Action on the browse button: chooses a file containing observed water content values.
	 */
	private void browseButtonAction() {

		String observationFileName = getExternalFileName();

		if (observationFileName == null) {
			return; // user cancelled, see getExternalFileName() method
		}

		observationFileNameTextField.setText(observationFileName);
	}

	/**
	 * Action on the draw curves button: creates a soil water assessment manager, loads
	 * observed water content values and do checks.
	 *
	 * @throws Exception
	 */
	protected void drawCurvesButtonAction() throws Exception {

		String observationFileName = observationFileNameTextField.getText();

		// Creates the soil water assesment manager
		manager = new HetSoilWaterAssessmentManager(observationFileName, step, model);

		// Loads observed water content values (for all observed horizons)
		manager.loadObservedWaterContentValues();

		// Checks if observed dates are compatible with the simulated dates
		manager.checkObservedDatesCompatibility();

		// Checks if the horizons in the observations file are simulated
		manager.checkObservedHorizonIdListCompatibility();

	}

	/**
	 * Creates a file chooser in order to select a file containing observed water content values.
	 *
	 * @return The full file name of the selected observations file or null if the user cancelled
	 */
	private String getExternalFileName() {

		JFileChooser chooser = new JFileChooser(Settings.getProperty("heterofor." + toolName + ".observationFileName",
				PathManager.getDir("data/heterofor")));

		int returnVal = chooser.showOpenDialog(this);

		if (returnVal == JFileChooser.APPROVE_OPTION) {
			String fileName = chooser.getSelectedFile().toString();
			Settings.setProperty("heterofor." + toolName + ".observationFileName", fileName);
			return fileName;
		} else {
			// if JFileChooser.CANCEL_OPTION (user cancelled) or JFileChooser.ERROR_OPTION
			return null;
		}
	}

	/**
	 * Displays the viewer of observed and simulated water content values in a scroll pane.
	 *
	 * @param viewer The viewer which prints the observed and simulated water content values
	 */
	protected void displayViewer(Component viewer) {

		// Adds viewer at the end of the viewerLinePanel (after the last existing viewer)
		LinePanel viewerLinePanel = (LinePanel) viewerScrollPane.getViewport().getView();
		viewerLinePanel.add(viewer);
		viewerScrollPane.getViewport().setView(viewerLinePanel);
	}

	/**
	 * From ActionListener interface.
	 */
	@Override
	public void actionPerformed(ActionEvent evt) {

		if (evt.getSource().equals(browseButton)) {
			browseButtonAction();
		}

		if (evt.getSource().equals(drawCurvesButton)) {
			try {
				drawCurvesButtonAction();
			} catch (Exception e) {
				Log.println(Log.ERROR, "HetSoilWaterAssessmentTool.actionPerformed()",
						"Problem occurs when trying to draw observed/simulated data curves", e);
				MessageDialog.print(this, e.getMessage());
			}
		}

		if (evt.getSource().equals(closeButton)) {
			dispose();
		}
	}

	/**
	 * From DocumentListener interface.
	 */
	@Override
	public void insertUpdate(DocumentEvent evt) {

		manageDrawCurvesButtonVisibility();
	}

	/**
	 * From DocumentListener interface.
	 */
	@Override
	public void removeUpdate(DocumentEvent evt) {

		manageDrawCurvesButtonVisibility();
	}

	/**
	 * From DocumentListener interface.
	 * Nothing to do because this event is never generated by a JTextField.
	 */
	@Override
	public void changedUpdate(DocumentEvent evt) {

	}

	/**
	 * Returns the name of the file containing observed water content values.
	 *
	 * @return The name of the file containing observed water content values
	 */
	public String getObservationFileName() {

		return observationFileNameTextField.getText();
	}
}
