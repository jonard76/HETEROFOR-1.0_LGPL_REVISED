/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.extension.modeltool.soilwaterassessmenttool.watercontentassessmenttool;

import heterofor.extension.modeltool.soilwaterassessmenttool.HetSoilWaterAssessmentTool;
import heterofor.model.HetModel;
import heterofor.model.HetScene;
import heterofor.model.meteorology.HetMeteorology;

import java.util.Map;
import java.util.concurrent.ExecutionException;

import jeeb.lib.util.Log;
import jeeb.lib.util.MessageDialog;
import jeeb.lib.util.StatusDispatcher;
import jeeb.lib.util.Translator;
import jeeb.lib.util.task.Task;
import jeeb.lib.util.task.TaskManager;

import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import capsis.kernel.GModel;
import capsis.kernel.Step;
import capsis.util.Calendar;

/**
 * A tool to compare hourly or daily simulated and observed water content values in a soil composed
 * of several horizons. Comparisons are made for each horizon.
 * It is a subclass of {@link HetSoilWaterAssessmentTool} which allows to generate a part of the graphical
 * user interface and retrieve water content values in an observations file.
 *
 * @author N. Beudez - October 2017
 */
public class HetWaterContentAssessmentTool extends HetSoilWaterAssessmentTool {

	static {
		Translator.addBundle("heterofor.extension.modeltool.soilwaterassessmenttool.HetSoilWaterAssessmentTool");
	}

	// nb-13.08.2018
	//public static final String NAME = "HetWaterContentAssessmentTool";
	//public static final String VERSION = "1.0";
	//public static final String AUTHOR = "N. Beudez, M. Jonard";
	//public static final String DESCRIPTION = "HetWaterContentAssessmentTool.description";

	/**
	 * Default constructor.
	 */
	public HetWaterContentAssessmentTool() {

		super();
	}

	@Override
	public void init(GModel model, Step step) {

		super.init(model, step, "HetWaterContentAssessmentTool");
	}

	/**
	 * Extension dynamic compatibility mechanism. This matchwith() method checks
	 * if the extension can deal (i.e. is compatible) with the referent.
	 */
	static public boolean matchWith(Object referent) {

		return referent instanceof HetModel;
	}

	@Override
	public String getName() {
		return Translator.swap("HetWaterContentAssessmentTool.name");
	}

	@Override
	public String getAuthor() {
		return "N. Beudez, M. Jonard";
	}

	@Override
	public String getDescription() {
		return Translator.swap("HetWaterContentAssessmentTool.description");
	}

	@Override
	public String getVersion() {
		return "1.0";
	}

	/**
	 * Action on the draw curves button: retrieves observed water content values, checks their validity and
	 * compatibility with simulated dates and creates a viewer aimed at displaying the curves of observed
	 * and simulated water content values over time.
	 */
	@Override
	protected void drawCurvesButtonAction() {

		// Creates a task
		Task<Object, Void> task = new Task<Object, Void>(Translator.swap("HetWaterContentAssessmentTool.comparisonOfObservedAndSimulatedWaterContentValues")) {

			@Override
			protected void doFirstInEDT() {

				// Deletes existing message in the left part of the status panel
				StatusDispatcher.print("");
			}

			@Override
			protected Object doInWorker() {

				try {
					// Writes in the right part of the status panel
					StatusDispatcher.print(Translator.swap("HetSoilWaterAssessmentTool.graphCreationInProgress"));

					// Creates an empty data set aimed at containing 2 series for each soil's horizon:
					// - a series of observed water content values
					// - a series of simulated water content values
					XYSeriesCollection dataSet = new XYSeriesCollection();

					// Prepares observed and simulated water content values
					prepareData(dataSet);

					// Creates the viewer without displaying it (see doInEDTafterWorker() method)
					HetWaterContentAssessmentViewer viewer = createViewer(dataSet);

					return viewer;

				} catch (Exception e) {

					Log.println(Log.ERROR, "HetWaterContentAssessmentTool.drawCurvesButtonAction()",
							"Problem occurs when preparing observed/simulated water content values for drawing", e);
					MessageDialog.print(this, e.getMessage());

					return null;
				}
			}

			@Override
			protected void doInEDTafterWorker() {

				try {

					HetWaterContentAssessmentViewer viewer = (HetWaterContentAssessmentViewer) get();

					if (viewer != null) {

						// Displays the viewer
						displayViewer(viewer);

						// Writes in the left part of the status panel
						// TODO: to be improved. Indeed this message sometimes appears before the viewer is displayed.
						StatusDispatcher.print(Translator.swap("HetSoilWaterAssessmentTool.graphCreationTerminated"));
					} else {

						// Writes in the left part of the status panel
						StatusDispatcher.print(Translator.swap("HetSoilWaterAssessmentTool.graphCreationAborted"));
					}

				} catch (InterruptedException | ExecutionException e) {

					Log.println(Log.ERROR, "HetWaterContentAssessmentTool.drawCurvesButtonAction()",
							"Problem occurs when drawing observed/simulated data curves", e);
					MessageDialog.print(this, e.getMessage());
				}
			}
		};

		// Allows to see a moving bar in the progress bar instead of a percentage that would
		// stay to the 0 value until task terminated
		task.setIndeterminate();

		// Executes the created task
		TaskManager.getInstance().add(task);
	}

	/**
	 * Retrieves observed water content values, do some checks and fill in the given empty data set with,
	 * for each soil horizon, observed water content values and corresponding simulated water content values.
	 *
	 * @param dataSet The empty data set aimed at containing for each soil horizon: a series of observed
	 * water content values and a series of simulated water content values.
	 * @throws Exception
	 */
	private void prepareData(XYSeriesCollection dataSet) throws Exception {

		// Retrieves observed water content values and do some checks
		super.drawCurvesButtonAction();
		
		// fa-25.11.2019: // Detailed water balance mode, water balance maps are now aggregated at the daily time step to save memory
		HetScene initScene = (HetScene) model.getProject().getRoot().getScene();
		if (initScene.getSoil().isDiscreteSoil() && manager.areHourlyData())
			throw new Exception("Error: incompatibility between hourly water content observations in file\n\n" + manager.getObservationsFileName()
			+ "\n\nand simulated values integrated at the daily time step in detailed water balance mode.\n\nAborted.");		

		// Fills in dataSet with observed and simulated water content values
		for (int horizonId : manager.getObservedHorizonIdList()) {

			XYSeries observedWaterContentSeries = new XYSeries(Translator.swap("HetWaterContentAssessmentTool.observedWaterContentForHorizon")
														+ " " + horizonId);
			XYSeries simulatedWaterContentSeries = new XYSeries(Translator.swap("HetWaterContentAssessmentTool.simulatedWaterContentForHorizon")
														+ " " + horizonId);

			dataSet.addSeries(observedWaterContentSeries);
			dataSet.addSeries(simulatedWaterContentSeries);

			// Fill in the series of observed and simulated water content values
			fillInSeriesOfObservedAndSimulatedWaterContentValues(observedWaterContentSeries,
					simulatedWaterContentSeries, horizonId);
		}
	}

	/**
	 * Creates the viewer allowing to print the observed and simulated water content values. This
	 * method does not print this viewer: see the {@link #display(HetWaterContentAssessmentViewer)} method.
	 *
	 * @param dataSet The set containing series of observed and simulated water content values
	 */
	private HetWaterContentAssessmentViewer createViewer(XYSeriesCollection dataSet) {

		HetWaterContentAssessmentViewer viewer = new HetWaterContentAssessmentViewer(dataSet, manager.getObservedHorizonIdList(), this);
		return viewer;
	}

	/**
	 * Fills in the initially empty series passed as parameters with hourly or
	 * daily observed and simulated values of water content for the horizon with
	 * id the given horizonId.
	 *
	 * @param observedWaterContentSeries The initially empty series aimed at containing observed water content values
	 * @param simulatedWaterContentSeries The initially empty series aimed at containing simulated water content values
	 * @param horizonId The id of the horizon for which observed and simulated water content series are filled in
	 */
	public void fillInSeriesOfObservedAndSimulatedWaterContentValues(XYSeries observedWaterContentSeries,
			XYSeries simulatedWaterContentSeries, int horizonId) {

		Map<String, Map<Integer, Double>> observedWaterContentMap = manager.getObservedWaterContentMap();

		if (manager.areHourlyData()) {

			// Case 1: the observations file contains hourly water content values

			for (Step st : model.getProject().getStepsFromRoot(step)) {

				HetScene scene = (HetScene) st.getScene();
				int cptHour = 0;

				//fa-26.06.2019: skip to avoid duplicates ('star scene'))
				if (scene.isInterventionResult())
					continue;

				// fc-19.11.2019 Works only for an HetSoil, not for HetDiscreteSoil)
				// fa-25.11.2019: Now also OK for HetDiscreteSoil
				for (String date : scene.getWaterBalanceMap ().keySet()) {
//				for (String date : scene.waterBalanceMap.keySet()) {

					// date is "year_month_day_hour" string
					String[] yearMonthDayHourTab = date.split(HetMeteorology.SEP);
					int year = Integer.valueOf(yearMonthDayHourTab[0]);

					double time;

					if (Calendar.isLeap(year)) {
						time = year+cptHour/(24*366.0);
					} else {
						time = year+cptHour/(24*365.0);
					}

					// Hourly simulated water content value

					double simulatedWaterContent = scene.getWaterBalanceMap ().get(date).horizonWaterContent.get(horizonId);
//					double simulatedWaterContent = scene.waterBalanceMap.get(date).horizonWaterContent.get(horizonId);

					simulatedWaterContentSeries.add(time, simulatedWaterContent);

					// Hourly observed water content values are not necessary complete:
					// values for some dates and/or for some horizons are missing
					if ((observedWaterContentMap.keySet().contains(date))
							&& (observedWaterContentMap.get(date).get(horizonId) != null)) {
						double observedWaterContent = observedWaterContentMap.get(date).get(horizonId);
						observedWaterContentSeries.add(time, observedWaterContent);
					} else {
						observedWaterContentSeries.add(time, null);
					}

					++cptHour;
				}
			}

		} else {

			// Case 2: the observations file contains daily water content values

			for (Step st : model.getProject().getStepsFromRoot(step)) {

				HetScene scene = (HetScene) st.getScene();

				//fa-26.06.2019: skip to avoid duplicates ('star scene'))
				if (scene.isInterventionResult())
					continue;

				int cptDay = 1;
				double dailyAverageSimulatedWaterContent = 0.0;

				// fc-19.11.2019 Works only for an HetSoil, not for HetDiscreteSoil)
				// fa-25.11.2019: Now also OK for HetDiscreteSoil
				for (String date : scene.getWaterBalanceMap ().keySet()) {
//				for (String date : scene.waterBalanceMap.keySet()) {
					
					String[] yearMonthDayHourTab = date.split(HetMeteorology.SEP);
					int year = Integer.valueOf(yearMonthDayHourTab[0]);
					int month = Integer.valueOf(yearMonthDayHourTab[1]);
					int day = Integer.valueOf(yearMonthDayHourTab[2]);

					if (!scene.getSoil().isDiscreteSoil()) { // default water balance mode
						int hour = Integer.valueOf(yearMonthDayHourTab[3]);

						double simulatedWaterContent = scene.getWaterBalanceMap ().get(date).horizonWaterContent.get(horizonId);
//						double simulatedWaterContent = scene.waterBalanceMap.get(date).horizonWaterContent.get(horizonId);
			
						dailyAverageSimulatedWaterContent += simulatedWaterContent;

						// In the "year_month_day_hour" string, hour begins at value 0 and ends at value 23
						if (hour < 23) {
							continue;
						}

						// hour is equal to 23

						// Daily simulated water content value
						dailyAverageSimulatedWaterContent /= 24;
					} else // fa-25.11.2019: detailed water balance mode, water balance maps are already aggregated at the daily time step to save memory
						dailyAverageSimulatedWaterContent = scene.getWaterBalanceMap ().get(date).horizonWaterContent.get(horizonId); // dates are generated by HetWaterBalanceIntegrator ()
					
					double time;

					if (Calendar.isLeap(year)) {
						time = year+cptDay/366.0;
					} else {
						time = year+cptDay/365.0;
					}

					String dailyDate = "" + year + HetMeteorology.SEP + month + HetMeteorology.SEP + day;

					simulatedWaterContentSeries.add(time, dailyAverageSimulatedWaterContent);

					// Daily observed water content values are not necessary complete:
					// values for some dates and/or for some horizons are missing.
					if ((observedWaterContentMap.keySet().contains(dailyDate))
							&& (observedWaterContentMap.get(dailyDate).get(horizonId) != null)) {
						double observedWaterContent = observedWaterContentMap.get(dailyDate).get(horizonId);
						observedWaterContentSeries.add(time, observedWaterContent);
					} else {
						observedWaterContentSeries.add(time, null);
					}

					++cptDay;
				}
			}

		}

	}

}
