/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.extension.modeltool.predictionassessmenttool;

import heterofor.model.HetInitialParameters;
import heterofor.model.HetScene;
import heterofor.model.HetTree;
import jeeb.lib.util.Translator;

import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public abstract class XYPlot extends PredVsObsIncrement {

	/**
	 * Constructor. SpeciesCode: if -1, ignored, else the graph concerns only
	 * the trees of this species.
	 */
	public XYPlot(PredictionAssessmentTool pat, String title, HetScene initScene, HetScene refScene, HetScene obsScene, String xLabel, String yLabel) {
		super(pat, title, initScene, refScene, obsScene, xLabel, yLabel, false); // logMode
																			// =
																			// false
	}

	/**
	 * Create the data set to be plot, called by superclass. This method is
	 * responsible for creating a dataSet with at least one dataSeries and
	 * setting min and maxValues;
	 */
	protected XYDataset createDataSet(HetScene initScene, HetScene refScene, HetScene obsScene) {
		HetInitialParameters ip = (HetInitialParameters) initScene.getStep().getProject().getModel().getSettings();

		String speciesName = Translator.swap("XYDataset.allSpecies");
		if (getSpeciesCode() >= 0) {
			speciesName = ip.speciesMap.get(getSpeciesCode()).niceName;
		}
		XYSeriesCollection dataSet = new XYSeriesCollection();

		XYSeries refSeries = new XYSeries("Predictions");
		XYSeries obsSeries = new XYSeries("Observations");

		dataSet.addSeries(refSeries);
		dataSet.addSeries(obsSeries);

		int period = refScene.getDate() - initScene.getDate();

		// Enrich chart title
		title = title + "\n" + ip.plotName + " " + initScene.getDate() + "-" + refScene.getDate() + " " + speciesName;

		minValue = Double.MAX_VALUE;
		maxValue = -Double.MAX_VALUE;

		for (Object o : initScene.getTrees()) {

			HetTree initTree = (HetTree) o;
			if (initTree.isVirtual())
				continue;

			int treeId = initTree.getId();

			HetTree refTree = (HetTree) refScene.getTree(treeId);
			HetTree obsTree = (HetTree) obsScene.getTree(treeId);

			if (refTree == null || obsTree == null)
				continue;

			// fc+mj-10.5.2016
			if (!pat.getInnerZone().contains(initTree.getX(), initTree.getY()))
				continue;

			if (getSpeciesCode() < 0 || getSpeciesCode() == initTree.getSpecies().getValue()) {
				// we keep the tree
			} else {
				continue;
			}

			double x = getXValue(initTree);

			double gInit = getYValue(initTree);
			double gRef = getYValue(refTree);
			double gObs = getYValue(obsTree);

			double yRef = (gRef - gInit) / period;
			double yObs = (gObs - gInit) / period;

			// minValue = Math.min(minValue, x);
			// minValue = Math.min(minValue, yRef);
			// maxValue = Math.max(maxValue, x);
			// maxValue = Math.max(maxValue, y);

			// if (y < 0 || y > 3) {
			// System.out.println("Trouble: treeId: " + treeId + " iniV: " +
			// initV + " refV: " + refV + " obsV: "
			// + obsV + " period: " + period);
			// }

			refSeries.add(x, yRef);
			obsSeries.add(x, yObs);
		}

		// System.out.println("XYPlot minValue: " + minValue + " maxValue: " +
		// maxValue);

		return dataSet;
	}

	abstract protected double getXValue(HetTree tree);

	abstract protected double getYValue(HetTree tree);

	abstract protected int getSpeciesCode();

	// protected double getValue(HetTree tree) {
	// return logMode ? Math.log10(tree.getGirth()) : tree.getGirth();
	// }

}
