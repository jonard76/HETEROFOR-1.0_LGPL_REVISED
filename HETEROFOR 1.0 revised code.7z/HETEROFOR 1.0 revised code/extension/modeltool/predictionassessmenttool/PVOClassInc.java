/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.extension.modeltool.predictionassessmenttool;

import heterofor.model.HetInitialParameters;
import heterofor.model.HetScene;
import heterofor.model.HetSpecies;
import heterofor.model.HetTree;

import java.awt.Color;
import java.awt.Window;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jeeb.lib.util.Classifier;
import jeeb.lib.util.ClassifierCriterion;
import jeeb.lib.util.Log;
import jeeb.lib.util.MessageDialog;
import jeeb.lib.util.Translator;
import jeeb.lib.util.csvfileviewer.CsvFileViewer;

import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import capsis.defaulttype.Tree;
import capsis.gui.MainFrame;

/**
 * This class allows to create a data set containing simulated and observed increases values averaged over girth classes
 * of initial trees. These average values are obtained from a tree characteristic (for example girth or height or basal
 * area...) that must be set in a method that overrides the {@link #getValue(HetTree)} method.
 * The data set contains an average simulated (resp. observed) value per (species, girth class) pair: it is the mean of
 * the increases of the considered characteristic (for example girth or height or basal area...) of the trees which
 * belong to the given girth class for the given species.
 * The contents of the data set is also stored in the {{@link #dataSetMap}} map which is used to display the results
 * in a floating table (see {@link PVOClassIncTableBuilder} class).
 *
 * @author N. Beudez - November 2017
 */
public abstract class PVOClassInc extends PredVsObsIncrement {

	/**
	 * The width of the girth class (unit: cm) used by the classifier.
	 */
	private final double girthClassWidth = 20.0;

	/**
	 * The classifier that builds the girth classes.
	 */
	private Classifier classifier;

	/**
	 * Map with key: species id, value: species.
	 */
	private Map<Integer, HetSpecies> speciesMap;

	/**
	 * Map aimed at being used for printing results in a floating table.
	 * Key: species id.
	 * Value: map with key: girth class id, value: the corresponding PVIOClassIncStore object.
	 */
	Map<Integer, Map<Integer, PVOClassIncStore>> dataSetMap;

	/**
	 * The name of the title used in the floating table for the column containing the means of the observed increases values
	 * per species and per girth class.
	 */
	private String titleOfObservedMeanColumn;

	/**
	 * The name of the title used in the floating table for the column containing the means of the simulated increases values
	 * per species and per girth class.
	 */
	private String titleOfSimulatedMeanColumn;

	/**
	 * The name of the title used in the floating table for the column containing the standard errors on the observed increases
	 * values per species and per girth class.
	 */
	private String titleOfObservedStandardErrorColumn;

	/**
	 * The name of the title used in the floating table for the column containing the standard errors on the simulated increases
	 * values per species and per girth class.
	 */
	private String titleOfSimulatedStandardErrorColumn;

	/**
	 * Constructor. The logMode parameter is forced to false in the body of the constructor because log10 mode
	 * is not needed for the moment.
	 *
	 * @param tool The reference to the prediction assessment tool.
	 * @param chartTitle The title of the chart.
	 * @param initScene The initial simulated scene.
	 * @param refScene The current simulated scene.
	 * @param obsScene The observed scene.
	 * @param logMode True for using a decimal logarithmic (log10) scale in chart, false otherwise.
	 * @param titleOfObservedMeanColumn The title used in the floating table for the column containing the means of the
	 * observed increases values per species and per girth class.
	 * @param titleOfSimulatedMeanColumn The title used in the floating table for the column containing the means of the
	 * simulated increases values per species and per girth class.
	 * @param titleOfObservedStandardErrorColumn The title used in the floating table for the column containing the standard
	 * errors on the observed increases values per species and per girth class.
	 * @param titleOfSimulatedStandardErrorColumn The title used in the floating table for the column containing the standard
	 * errors on the simulated increases values per species and per girth class.
	 */
	public PVOClassInc(PredictionAssessmentTool tool, String chartTitle, HetScene initScene, HetScene refScene,
			HetScene obsScene, boolean logMode, String titleOfObservedMeanColumn, String titleOfSimulatedMeanColumn,
			String titleOfObservedStandardErrorColumn, String titleOfSimulatedStandardErrorColumn) {

		// The logMode is forced to false.
		super(tool, chartTitle, initScene, refScene, obsScene, Translator.swap("PVOI.predictions"), Translator.swap("PVOI.measurements"), false);

		this.titleOfObservedMeanColumn = titleOfObservedMeanColumn;
		this.titleOfSimulatedMeanColumn = titleOfSimulatedMeanColumn;
		this.titleOfObservedStandardErrorColumn = titleOfObservedStandardErrorColumn;
		this.titleOfSimulatedStandardErrorColumn = titleOfSimulatedStandardErrorColumn;
	}

	/**
	 * Creates the data set to be plotted and the corresponding {@link #dataSetMap} to be used in floating table building. Sets also
	 * the values of {@link PredVsObsIncrement#minValue} and {@link PredVsObsIncrement#maxValue}.
	 *
	 * @param initScene The initial simulated scene.
	 * @param refScene The current simulated scene.
	 * @param obsScene The observed scene.
	 */
	protected XYDataset createDataSet(HetScene initScene, HetScene refScene, HetScene obsScene) {

		// Gets the speciesMap from the initial parameters.
		HetInitialParameters ip = (HetInitialParameters) initScene.getStep().getProject().getModel().getSettings();
		speciesMap = ip.speciesMap;

		// Creates an empty data set.
		XYSeriesCollection dataSet = new XYSeriesCollection();

		// Creates map with key: species id; value: corresponding series.
		Map<Integer, XYSeries> seriesMap = new HashMap<Integer, XYSeries>();

		// Initializes the minimum and maximum values of the data set.
		minValue = Double.MAX_VALUE;
		maxValue = -Double.MAX_VALUE;

		// Sorts the list of the species ids. The speciesMap map is such as: key=species id, value=species.
		List<Integer> speciesIdList = new ArrayList<Integer>(speciesMap.keySet());
		Collections.sort(speciesIdList);

		// Initializes the dataSetMap.
		dataSetMap = new HashMap<Integer, Map<Integer, PVOClassIncStore>>();

		for (int speciesId : speciesIdList) {

			HetSpecies species = ip.speciesMap.get(speciesId);
			XYSeries series = new XYSeries(species.niceName);
			seriesColors.add(species.color);
			dataSet.addSeries(series);
			seriesMap.put(speciesId, series);
			dataSetMap.put(speciesId, new HashMap<Integer, PVOClassIncStore>());
		}

		// Increase's time interval.
		int period = refScene.getDate()-initScene.getDate();

		// Enriches chart title.
		String logLabel = logMode ? "Log10 " : "";
		title = logLabel + title + "\n" + ip.plotName + " " + initScene.getDate() + "-" + refScene.getDate();

		// Creates girth classes.
		ClassifierCriterion criterion = new ClassifierCriterion() {

			@Override
			public double getValue(Object o) {

				// Girth classes.
				return ((HetTree) o).getGirth();
			}
		};

		// The girth classes are made with trees of initial scene that still exist in observed scene. Indeed some
		// trees can born or die between initial date and observed date. In initial scene, simulated and observed
		// trees are the same.

		List<HetTree> selectedInitTreeList = new ArrayList<HetTree>();

		for (Tree initTree : initScene.getTrees()) {

			int initTreeId = initTree.getId();
			HetTree obsTree = (HetTree) obsScene.getTree(initTreeId);

			if (obsTree != null) {
				selectedInitTreeList.add((HetTree) initTree);
			}
		}

		classifier = null;

		try {
			classifier = new Classifier(selectedInitTreeList, criterion, 0.0, girthClassWidth);
		} catch (Exception e) {
			Log.println(Log.ERROR, "PVOClassInc.createDataSet()", "Problem when creating the classifier", e);
			MessageDialog.print(this, e.getMessage());
		}

		// The trees are kept in an array of lists. Each component of the array is a list and corresponds to a (girth) class.
		// Then the classifier.getObjects() method can be used (see below).
		classifier.setKeepObjects(true);

		// Runs the classification process.
		int rc = classifier.execute();

		// The number of calculated girth classes.
		int numberOfClasses = classifier.getN();

		// Each component of the array corresponds to a girth class and contains the list of the initial
		// trees that belong to the girth class.
		List[] classifiedSelectedTreesTab = classifier.getObjects();

		// Fills in the dataSetMap.
		for (int speciesId : speciesIdList) {

			for (int i=0 ; i<numberOfClasses ; ++i) {

				Map<Integer, PVOClassIncStore> girthClassIdStoreMap = dataSetMap.get(speciesId);
				girthClassIdStoreMap.put(i, new PVOClassIncStore());
			}
		}

		// Loop on the girth classes.
		for (int i=0 ; i<numberOfClasses ; ++i) {

			// Loop on the trees composing the i-th class. They may have different species.
			for (Object tree : classifiedSelectedTreesTab[i]) {

				HetTree initTree = (HetTree) tree;

				if (initTree.isVirtual()) {
					continue;
				}

				int treeId = initTree.getId();

				HetTree refTree = (HetTree) refScene.getTree(treeId);
				HetTree obsTree = (HetTree) obsScene.getTree(treeId);

				if ((refTree == null) || (obsTree == null)) {
					continue;
				}

				if (!pat.getInnerZone().contains(initTree.getX(), initTree.getY())) {
					continue;
				}

				int speciesId = initTree.getSpecies().getId();

				// Gets initial value, simulated value and observed value. Value is for example girth or
				// height or basal area...
				double initValue = getValue(initTree);
				double refValue = getValue(refTree);
				double obsValue = getValue(obsTree);

				// Calculates simulated and observed increases.
				double simulatedIncrease = (refValue-initValue)/period;
				double observedIncrease = (obsValue-initValue)/period;

				// Stores calculations.
				PVOClassIncStore store = dataSetMap.get(speciesId).get(i);
				store.getSimulatedValuesList().add(simulatedIncrease);
				store.getObservedValuesList().add(observedIncrease);
			}
		}

		// Calculates observed and simulated means and standard errors. Means are needed for chart and
		// standard errors are needed for floating table. The calculation of standard error calls the
		// calculation of mean.
		for (int speciesId : speciesIdList) {

			// Gets map with key: girth class id, value: the corresponding PVOClassIncStore object
			Map<Integer, PVOClassIncStore> girthClassIdStoreMap = dataSetMap.get(speciesId);

			for (int i=0 ; i<numberOfClasses ; ++i) {

				// Calculates for the species with id speciesId and the i-th girth class:
				//	- the number of simulated and observed increases;
				//	- the mean of the simulated increases;
				//	- the mean of the observed increases;
				//	- the standard error of the simulated increases;
				//	- the standard error of the observed increases.
				// The results of these calculations are stored in the PVOClassIncStore object corresponding
				// to the species with id speciesId and the i-th girth class.

				PVOClassIncStore store = girthClassIdStoreMap.get(i);
				try {
					store.calculate();
				} catch (Exception e) {
					Log.println(Log.ERROR, "PVOClassInc.createDataSet()", "Problem when calculating means and standard errors "
							+ "for species with id: " + speciesId + " and girth class with id: " + i, e);
					MessageDialog.print(this, e.getMessage());
				}
			}
		}

		// Fills in series to be used for chart. A series corresponds to a species.
		for (int speciesId : speciesIdList) {

			// Gets map with key: girth class id, value: the corresponding PVOClassIncStore object
			Map<Integer, PVOClassIncStore> girthClassIdStoreMap = dataSetMap.get(speciesId);

			for (int i=0 ; i<numberOfClasses ; ++i) {

				PVOClassIncStore store = girthClassIdStoreMap.get(i);

				int numberOfTrees = -1;
				try {
					numberOfTrees = store.getNumberOfElements();
				} catch (Exception e) {
					Log.println(Log.ERROR, "PVOClassInc.createDataSet()", "Problem when filling in series\nfor species " +
							"with id: " + speciesId + " and girth class with id: " + i, e);
					MessageDialog.print(this, e.getMessage());
				}

				// Nothing to do if the number of trees is equal to 0.

				if (numberOfTrees > 0) {

					double averageSimulatedIncreases = store.getMeanOfSimulatedValues();
					double averageObservedIncreases = store.getMeanOfObservedValues();

					XYSeries series = seriesMap.get(speciesId);
					series.add(averageSimulatedIncreases, averageObservedIncreases);

					minValue = Math.min(minValue, averageSimulatedIncreases);
					minValue = Math.min(minValue, averageObservedIncreases);
					maxValue = Math.max(maxValue, averageSimulatedIncreases);
					maxValue = Math.max(maxValue, averageObservedIncreases);
				}
			}
		}

		return dataSet;
	}

	/**
	 * Returns the value of the characteristic (girth, height, basal area,...) of the given tree to be considered for
	 * calculating the average values per girth class stored in the data set.
	 * This method has to be overridden.
	 *
	 * @param tree The tree from which the value is extracted (girth, height, basal area,...)
	 * @return The value to be considered for calculating average values per girth class
	 */
	abstract protected double getValue(HetTree tree);

	@Override
	protected void openCsvViewer() {

		PVOClassIncTableBuilder builder = null;

		try {
			builder = new PVOClassIncTableBuilder(dataSetMap, classifier, speciesMap, titleOfObservedMeanColumn,
					titleOfSimulatedMeanColumn, titleOfObservedStandardErrorColumn, titleOfSimulatedStandardErrorColumn);
		} catch (Exception e) {
			Log.println(Log.ERROR, "PVOClassInc.openCsvViewer()", "Problem when creating the floating table builder", e);
			MessageDialog.print(this, e.getMessage());
		}

		Window window = MainFrame.getInstance();
		String name = title;
		String tableContent = builder.getTableInAString();
		String separator = "\t";

		try {
			new CsvFileViewer(window, name, tableContent, separator, Color.BLUE);
		} catch (Exception e) {
			Log.println(Log.ERROR, "PVOClassInc.openCsvViewer()", "Problem when creating the floating table viewer", e);
			MessageDialog.print(this, e.getMessage());
		}
	}
}
