/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */
package heterofor.extension.modeltool.predictionassessmenttool;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.StandardChartTheme;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

import capsis.extension.datarenderer.drcurves.DRTableBuilder;
import capsis.gui.MainFrame;
import heterofor.model.HetInitialParameters;
import heterofor.model.HetScene;
import heterofor.model.HetTree;
import jeeb.lib.util.Log;
import jeeb.lib.util.Translator;
import jeeb.lib.util.csvfileviewer.CsvFileViewer;

/**
 * An histogram showing predicted and observed values per species.
 *
 * @author F. de Coligny - April 2015
 */
abstract public class HistoSpecies extends JPanel implements ActionListener {

	private PredictionAssessmentTool pat;
	private String title;
	private String yAxisName;
	private HetScene initScene;
	private HetScene refScene;
	private HetScene obsScene;

	private List<Integer> treeIds;
	private List<String> speciesNames;
	private Map<String, Color> speciesColors;

	private JMenuItem openInTable; // fc-30.10.2015
	private CategoryDataset memoDataset;

	/**
	 * Creates a new demo instance.
	 *
	 * @param title
	 *            the frame title.
	 */
	public HistoSpecies(PredictionAssessmentTool pat, String title, String yAxisName, HetScene initScene, HetScene refScene, HetScene obsScene) {

		super();

		this.pat = pat;
		this.title = title;
		this.yAxisName = yAxisName;
		this.initScene = initScene;
		this.refScene = refScene;
		this.obsScene = obsScene;

		setLayout(new BorderLayout());

		createTreeIds();

		final CategoryDataset dataset = createDataset();

		memoDataset = dataset; // for csvViewer

		final JFreeChart chart = createChart(dataset);

		// Theme customization fc+mj-30.10.2015
		Plot plot = chart.getPlot();
		chart.setBackgroundPaint(Color.WHITE);
		plot.setBackgroundPaint(Color.WHITE);

		final ChartPanel chartPanel = new ChartPanel(chart);
		// chartPanel.setPreferredSize(new Dimension(500, 270));

		// Complete popupmenu fc-30.10.2015
		JPopupMenu m = chartPanel.getPopupMenu();
		m.addSeparator();
		openInTable = new JMenuItem(Translator.swap("DataRenderer.openInTable"));
		openInTable.setEnabled(true);
		openInTable.addActionListener(this);
		m.add(openInTable);

		add(chartPanel, BorderLayout.CENTER);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource().equals(openInTable)) {
			// ... CsvFileViewer
			openCsvViewer();

		}
	}

	/**
	 * Open CsvViewer.
	 */
	private void openCsvViewer() {

		try {

			DRTableBuilder builder = new DRTableBuilder(memoDataset);

			Window window = MainFrame.getInstance();
			String name = title;
			String tableContent = builder.getTableInAString();
			String separator = "\t";

			new CsvFileViewer(window, name, tableContent, separator, Color.BLUE);

		} catch (Exception e) {
			Log.println(Log.WARNING, "HistoSpecies.openCsvViewer()", "Could not open CsvFileViewer", e);
		}

	}

	abstract protected double getYValue(HetTree tree);

	/**
	 * Get the trees not virtual, present in init, ref and obs scenes, keep
	 * their ids. Keep also the species names.
	 */
	private void createTreeIds() {
		treeIds = new ArrayList<Integer>();
		speciesNames = new ArrayList<String>();
		speciesColors = new HashMap<String, Color>();

		for (Object o : initScene.getTrees()) {

			HetTree initTree = (HetTree) o;
			if (initTree.isVirtual())
				continue;

			int treeId = initTree.getId();

			HetTree refTree = (HetTree) refScene.getTree(treeId);
			HetTree obsTree = (HetTree) obsScene.getTree(treeId);

			if (refTree == null || obsTree == null)
				continue;

			// fc+mj-10.5.2016
			if (!pat.getInnerZone().contains(initTree.getX(), initTree.getY()))
				continue;

			treeIds.add(treeId);

			String spName = initTree.getSpecies().niceName;
			if (!speciesNames.contains(spName)) {
				speciesNames.add(spName);
				speciesColors.put(spName, initTree.getSpecies().color);
			}
		}
	}

	/**
	 * Returns a dataset.
	 */
	private CategoryDataset createDataset() {

		// row keys...
		final String predSeries = Translator.swap("Predictions");
		final String obsSeries = Translator.swap("Observations");

		int period = refScene.getDate() - initScene.getDate();

		// Create the dataset...
		final DefaultCategoryDataset dataset = new DefaultCategoryDataset();

		for (String spName : speciesNames) {

			// column keys...
			final String category = spName;

			double initSum = 0;
			double refSum = 0;
			double obsSum = 0;
			int nTrees = 0;

			for (int treeId : treeIds) {

				HetTree initTree = (HetTree) initScene.getTree(treeId);

				if (!initTree.getSpecies().niceName.equals(spName))
					continue;

				HetTree refTree = (HetTree) refScene.getTree(treeId);
				HetTree obsTree = (HetTree) obsScene.getTree(treeId);

				initSum += getYValue(initTree);
				refSum += getYValue(refTree);
				obsSum += getYValue(obsTree);
				nTrees++;

			}
			double initMean = initSum / nTrees;
			double refMean = refSum / nTrees;
			double obsMean = obsSum / nTrees;

			double predV = (refMean - initMean) / period;
			dataset.addValue(predV, predSeries, category);

			double obsV = (obsMean - initMean) / period;
			dataset.addValue(obsV, obsSeries, category);

		}

		return dataset;

	}

	// // column keys...
	// final String category1 = "Category 1";
	// final String category2 = "Category 2";
	// final String category3 = "Category 3";
	// final String category4 = "Category 4";
	// final String category5 = "Category 5";
	//
	// // create the dataset...
	// final DefaultCategoryDataset dataset = new DefaultCategoryDataset();
	//
	// dataset.addValue(1.0, series1, category1);
	// dataset.addValue(4.0, series1, category2);
	// dataset.addValue(3.0, series1, category3);
	// dataset.addValue(5.0, series1, category4);
	// dataset.addValue(5.0, series1, category5);
	//
	// dataset.addValue(5.0, series2, category1);
	// dataset.addValue(7.0, series2, category2);
	// dataset.addValue(6.0, series2, category3);
	// dataset.addValue(8.0, series2, category4);
	// dataset.addValue(4.0, series2, category5);
	//
	// dataset.addValue(4.0, series3, category1);
	// dataset.addValue(3.0, series3, category2);
	// dataset.addValue(2.0, series3, category3);
	// dataset.addValue(3.0, series3, category4);
	// dataset.addValue(6.0, series3, category5);

	/**
	 * Creates a sample chart.
	 *
	 * @param dataset
	 *            the dataset.
	 *
	 * @return The chart.
	 */
	private JFreeChart createChart(final CategoryDataset dataset) {

		// Use a simple theme fc+mj-30.10.2015
		StandardChartTheme theme = (StandardChartTheme) StandardChartTheme.createLegacyTheme();
		ChartFactory.setChartTheme(theme);

		// create the chart...
		final JFreeChart chart = ChartFactory.createBarChart("", // title: see
																	// below
				Translator.swap("Species"), // domain axis label
				yAxisName, // range axis label
				dataset, // data
				PlotOrientation.VERTICAL, // orientation
				true, // include legend
				true, // tooltips?
				false // URLs?
		);

		// Enrich title
		HetInitialParameters ip = (HetInitialParameters) initScene.getStep().getProject().getModel().getSettings();
		title = title + "\n" + ip.plotName;

		// Change title size (set it a little smaller), see HistogramPanel
		chart.setTitle(
				new org.jfree.chart.title.TextTitle(title, new java.awt.Font("SansSerif", java.awt.Font.ITALIC, 14)));

		// NOW DO SOME OPTIONAL CUSTOMISATION OF THE CHART...

		// set the background color for the chart...
		chart.setBackgroundPaint(null);

		// get a reference to the plot for further customisation...
		final CategoryPlot plot = chart.getCategoryPlot();
		// plot.setBackgroundPaint(Color.lightGray);
		// plot.setDomainGridlinePaint(Color.white);
		// plot.setRangeGridlinePaint(Color.white);

		// set the range axis to display integers only...
		final NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
		// rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
		// // fc-4.5.2015 more ticks

		// disable bar outlines...
		final BarRenderer renderer = (BarRenderer) plot.getRenderer();
		renderer.setDrawBarOutline(true);

		// Removes the bar shadows fc+mj-30.10.2015
		renderer.setShadowVisible(false);

		// set up gradient paints for series...
		// final GradientPaint gp0 = new GradientPaint(0.0f, 0.0f, Color.blue,
		// 0.0f, 0.0f, Color.RED);
		// final GradientPaint gp1 = new GradientPaint(0.0f, 0.0f, Color.green,
		// 0.0f, 0.0f, Color.BLUE);
		renderer.setSeriesPaint(0, Color.RED);
		renderer.setSeriesPaint(1, Color.BLUE);

		final CategoryAxis domainAxis = plot.getDomainAxis();
		domainAxis.setCategoryLabelPositions(CategoryLabelPositions.createUpRotationLabelPositions(Math.PI / 6.0));
		// OPTIONAL CUSTOMISATION COMPLETED.

		return chart;

	}

	// ****************************************************************************
	// * JFREECHART DEVELOPER GUIDE *
	// * The JFreeChart Developer Guide, written by David Gilbert, is available
	// *
	// * to purchase from Object Refinery Limited: *
	// * *
	// * http://www.object-refinery.com/jfreechart/guide.html *
	// * *
	// * Sales are used to provide funding for the JFreeChart project - please *
	// * support us so that we can continue developing free software. *
	// ****************************************************************************

	/**
	 * Starting point for the demonstration application.
	 *
	 * @param args
	 *            ignored.
	 */
	// public static void main(final String[] args) {
	//
	// final HistoSpecies demo = new HistoSpecies("Bar Chart Demo");
	// demo.pack();
	// RefineryUtilities.centerFrameOnScreen(demo);
	// demo.setVisible(true);
	//
	// }

}