/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */
package heterofor.extension.modeltool.paruseefficiencyestimationtool;

import heterofor.extension.ioformat.HetExport;
import heterofor.model.HetEvolutionParameters;
import heterofor.model.HetInitialParameters;
import heterofor.model.HetModel;
import heterofor.model.HetScene;
import heterofor.model.HetSpecies;
import heterofor.model.HetTree;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;

import jeeb.lib.util.Alert;
import jeeb.lib.util.Check;
import jeeb.lib.util.ColumnPanel;
import jeeb.lib.util.LinePanel;
import jeeb.lib.util.Log;
import jeeb.lib.util.MessageDialog;
import jeeb.lib.util.PathManager;
import jeeb.lib.util.Question;
import jeeb.lib.util.SetMap;
import jeeb.lib.util.Settings;
import jeeb.lib.util.StatusDispatcher;
import jeeb.lib.util.StatusListener;
import jeeb.lib.util.Translator;
import jeeb.lib.util.csvfileviewer.CsvFileViewer;

import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import capsis.app.C4Script;
import capsis.commongui.util.Helper;
import capsis.defaulttype.Tree;
import capsis.extension.DialogModelTool;
import capsis.gui.MainFrame;
import capsis.kernel.GModel;
import capsis.kernel.Project;
import capsis.kernel.Step;

/**
 * A tool to estimate tree PAR Use Efficiency from two successive inventories.
 *
 * @author M. Jonard - March 2016
 */
public class PUEEstimationTool extends DialogModelTool implements ActionListener, StatusListener {

	static {
		Translator.addBundle("heterofor.extension.modeltool.paruseefficiencyestimationtool.PUEEstimationTool");
	}

	// nb-13.08.2018
	//static public final String NAME = Translator.swap("PUEEstimationTool");
	//static public final String DESCRIPTION = Translator.swap("PUEEstimationTool.description");
	//static public final String AUTHOR = "M. Jonard, F. de Coligny";
	//static public final String VERSION = "1.0";

	private static final int INITIAL_WIDTH = 700;
	private static final int INITIAL_HEIGHT = 600;

	private Step refStep;
	private Project refProject;
	private HetScene refScene;
	private HetModel model;

	private HetScene obsScene;

	private int date1;
	private int date2;

	private JTextField observationFileName;
	private JButton browse;
	private boolean observationIsLoaded;

	private JTextField trueThinningFileName;
	private JButton browse2;
	private boolean thinningIsLoaded;

	private JButton launchEstimation;

	private JScrollPane scroll;

	private LinePanel controlPanel;
	private JLabel status; // fc-4.5.2015

	// After an estimation, this step may be exported
	private Step estimationFinalStep;
	private JButton export;

	private JButton close; // after confirmation
	private JButton help;

	/**
	 * Constructor.
	 */
	public PUEEstimationTool() {
		super();
	}

	/**
	 * Inits the tool on the given Step.
	 */
	@Override
	public void init(GModel m, Step s) {

		try {

			refStep = s;
			refProject = s.getProject();
			model = (HetModel) refProject.getModel();
			refScene = (HetScene) refStep.getScene();
			date1 = refScene.getDate();

			setTitle(getName () + " - " + refStep.getCaption());

			// fc+fa-31.7.2017
			StatusDispatcher.addListener (this);

			createUI();

			printMessage(Translator.swap("PUEEstimationTool.pleaseLoadAnObservationFile") + "...");

			setSize(INITIAL_WIDTH, INITIAL_HEIGHT);
			setModal(false);
			setVisible(true);

		} catch (Exception e) {
			Log.println(Log.ERROR, "PUEEstimationTool.c ()", "Exception in init ()", e);
		}
	}

	/**
	 * Extension dynamic compatibility mechanism. This matchwith method checks
	 * if the extension can deal (i.e. is compatible) with the referent.
	 */
	static public boolean matchWith(Object referent) {
		return referent instanceof HetModel;
	}

	@Override
	public String getName() {
		return Translator.swap("PUEEstimationTool.name");
	}

	@Override
	public String getAuthor() {
		return "M. Jonard, F. de Coligny";
	}

	@Override
	public String getDescription() {
		return Translator.swap("PUEEstimationTool.description");
	}

	@Override
	public String getVersion() {
		return "1.0";
	}

	/**
	 * Action on browse, returns a file name or null if user cancelled.
	 */
	private String getExternalFileName() {
		JFileChooser chooser = new JFileChooser(Settings.getProperty("heterofor.PUEEstimationTool.path",
				PathManager.getDir("data")));

		int returnVal = chooser.showOpenDialog(this);

		if (returnVal == JFileChooser.APPROVE_OPTION) {
			String fileName = chooser.getSelectedFile().toString();
			Settings.setProperty("heterofor.PUEEstimationTool.path", fileName);
			return fileName;
		}

		return null; // user cancelled
	}

	private void printMessage(final String message) {
		final JLabel st = status;
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				st.setText(message);
				st.revalidate();
				st.repaint();
			}
		});
	}

	/**
	 * Export results in a file
	 */
	public void exportAction() {

		JFileChooser chooser = new JFileChooser(Settings.getProperty("PUEEstimationTool.exportFileName",
				PathManager.getDir("tmp")));

		int returnVal = chooser.showSaveDialog(this);

		String exportFileName = null;

		if (returnVal == JFileChooser.APPROVE_OPTION) {
			exportFileName = chooser.getSelectedFile().toString();
			Settings.setProperty("PUEEstimationTool.exportFileName", exportFileName);
		} else {
			return; // user aborted
		}

		try {
			// Run the export
			HetExport e = new HetExport();
			HetModel m = (HetModel) estimationFinalStep.getProject().getModel();

			e.initExport(m, estimationFinalStep);
			e.save(exportFileName);

			new CsvFileViewer(this, exportFileName);

		} catch (Exception e) {
			Alert.print(Translator.swap("PUEEstimationTool.errorDuringExportSeeLog"), e);
		}

	}

	/**
	 * Load the observation file.
	 */
	public void browseAction() {

		if (observationIsLoaded) {
			boolean yep = Question.ask(this, Translator.swap("PUEEstimationTool.confirm"),
					Translator.swap("PUEEstimationTool.doYouWantToLoadANewObservationFile") + " ?");
			if (!yep)
				return;
		}

		String obsFileName = getExternalFileName();
		if (obsFileName == null)
			return; // user cancelled

		observationFileName.setText(obsFileName);

		Settings.setProperty("PUEEstimationTool.observationFileName", obsFileName);

	}

	/**
	 * Load the trueThinningFile.
	 */
	public void browse2Action() {

		if (thinningIsLoaded) {
			boolean yep = Question.ask(this, Translator.swap("PUEEstimationTool.confirm"),
					Translator.swap("PUEEstimationTool.doYouWantToLoadANewTrueThinningFile") + " ?");
			if (!yep)
				return;
		}

		String thinningFileName = getExternalFileName();
		if (thinningFileName == null)
			return; // user cancelled

		trueThinningFileName.setText(thinningFileName);

		Settings.setProperty("PUEEstimationTool.trueThinningFileName", thinningFileName);

	}

	/**
	 * Launch the PUE estimation
	 */
	public void launchEstimationAction() {

		String obsFileName = observationFileName.getText().trim();
		if (!Check.isFile(obsFileName)) {
			MessageDialog.print(this, Translator.swap("PUEEstimationTool.wrongObservationFile"));
			return;
		}

		String thinningFileName = trueThinningFileName.getText().trim();

		if (thinningFileName.length() > 0 && !Check.isFile(thinningFileName)) {
			MessageDialog.print(this, Translator.swap("PUEEstimationTool.wrongTrueThinningFile"));
			return;
		}

		if (observationIsLoaded || thinningIsLoaded) {
			boolean yep = Question.ask(this, Translator.swap("PUEEstimationTool.confirm"),
					Translator.swap("PUEEstimationTool.doYouWantToRelaunchThePUEestimation") + " ?");
			if (!yep)
				return;
		}

		launchEstimationTask(obsFileName, thinningFileName);

	}

	private void launchEstimationTask(final String obsFileName, final String thinningFileName) {

		// printMessage(Translator.swap("PUEEstimationTool.loadingObservationFile")
		// + "...");

		class ChartWorker extends SwingWorker<Object, Object> {
			@Override
			public Object doInBackground() {

				// While in doInBackground(), complete the report.
				// If trouble, Log it, show it in dialog and return null
				// If ok, return the chartLine

				StringBuffer report = new StringBuffer("PAR use efficency estimation tool...\n");

				try {

					// Stage 1: load observation file and calculate date2
					report.append("stage1: loading observation file: " + obsFileName + "...\n");
					printMessage("stage1: loading observation file: " + obsFileName + "...");

					C4Script s1 = createObsProject(obsFileName);
					obsScene = (HetScene) s1.getRoot().getScene();
					s1.closeProject();

					date2 = obsScene.getDate();
					observationIsLoaded = true;

					report.append("stage1: observation date: " + date2 + "\n");

					// Check dates
					if (date2 <= date1) {
						report.append("stage1: ERROR: observation date must be greater than root step date: " + date1
								+ "\n");
						throw new Exception(report.toString());
					}

					// Stage 2: Launch a growth in pue mode
					report.append("stage2: reloading original inventory file...\n");
					printMessage("stage2: reloading original inventory file...");

					C4Script s2 = createPueProject();

					report.append("stage2: running evolution in inverse mode...\n");
					printMessage("stage2: running evolution in inverse mode...");

					HetEvolutionParameters ep = new HetEvolutionParameters(obsScene, thinningFileName);
					Step finalStep = s2.evolve(ep);
					report.append("stage2: reached year: " + finalStep.getScene().getDate() + "\n");

					// To enable optional export
					estimationFinalStep = finalStep;
					export.setEnabled(true); // export is now possible

					report.append("stage2: ready for evaluation\n");
					printMessage("stage2: ready for evaluation");

					// Stage 3: build charts
					LinePanel chartLine = printCharts(s2, finalStep, report);

					// TRACE print the report in terminal
					System.out.println(report.toString());

					return chartLine; // Ok

				} catch (Exception e) {
					Log.println(Log.ERROR, "PUEEstimationTool.browseAction ()",
							"Trouble in PAR use efficiency estimation tool" + "\n" + e.getMessage(), e);
					MessageDialog.print(this, Translator.swap("PUEEstimationTool.TroubleInParUseEfficiencyToolSeeLog")
							+ "\n" + e.getMessage(), e);
					printMessage("");
					return null; // Error
				}
			}

			@Override
			protected void done() {
				try {
					// If error, return
					if (get() == null) {
						printMessage("");
						return;
					}

					LinePanel chartLine = (LinePanel) get();

					scroll.getViewport().setView(chartLine);

					scroll.revalidate();
					scroll.repaint();

					printMessage("");

				} catch (Exception e) {
					Log.println(Log.ERROR, "PUEEstimationTool.launchChartTask ()",
							"Could not estimate Par Use Efficiency", e);
					printMessage(Translator.swap("PUEEstimationTool.anErrorOccurred"));
				}
			}
		}

		new ChartWorker().execute();

	}

	private static class Point {
		public double pue; // par use efficiency
		public double lci; // light competition index
		public int n; // incremented on addValue ()

		public Point() {
		}

		public void addCouple(double pue, double lci) {
			this.pue += pue;
			this.lci += lci;
			n++;
		}

		public void performMean() {
			pue /= n;
			lci /= n;
		}
	}

	private static class DataMap extends HashMap<Integer, Point> {

		// Species -> list of treeIds
		private SetMap<HetSpecies, Integer> speciesMap;

		public DataMap() {
			super();
			speciesMap = new SetMap<>();
		}

		/**
		 * For the given treeId, store its species in the speciesMap and store
		 * the given 2 values in the DataMap.
		 */
		public void addValue(HetSpecies species, int treeId, double pue, double lci) {

			speciesMap.addObject(species, treeId);

			Point p = get(treeId);
			if (p == null) {
				p = new Point();
				this.put(treeId, p);
			}

			p.addCouple(pue, lci);
		}

		public void performMeans() {
			for (Point p : values()) {
				p.performMean();
			}
		}

		public Set<HetSpecies> getSpecies() {
			return speciesMap.keySet();
		}

		public Set<Integer> getTreeIds(HetSpecies species) {
			return speciesMap.getObjects(species);
		}

	}

	/**
	 * Creates a line with various charts inside.
	 */
	private LinePanel printCharts(C4Script script, Step finalStep, StringBuffer report) {

		report.append("stage3: extracting data...\n");

		LinePanel chartLine = new LinePanel();

		// PUE vs lightCompetitionIndex
		// Get the data, performs means
		Vector<Step> steps = script.getProject().getStepsFromRoot(finalStep);

		DataMap map = new DataMap();

		for (Step step : steps) { // each step
			HetScene scene = (HetScene) step.getScene();

			for (Tree tree : scene.getTrees()) { // each tree
				HetTree t = (HetTree) tree;
				if (t.isVirtual())
					continue;

				map.addValue(t.getSpecies(), t.getId(), t.getParUseEfficiency(), t.getLightCompetitionIndex());
			}
		}

		map.performMeans();

		// Create the dataSet
		XYSeriesCollection dataSet = new XYSeriesCollection();

		// Map<String, XYSeries> seriesMap = new HashMap<>();
		List<Color> seriesColors = new ArrayList<>(); // keep insertion order

		for (HetSpecies species : map.getSpecies()) {

			XYSeries series = new XYSeries(species.getName());
			dataSet.addSeries(series);

			// seriesMap.put(species.getName (), series);

			seriesColors.add(species.color);

			for (int treeId : map.getTreeIds(species)) {
				Point p = map.get(treeId);

				series.add(p.lci, p.pue);
			}
		}

		// Create the chart
		String title = Translator.swap("PUEEstimationTool.pueVsLightCompetitionIndex");
		String xLabel = Translator.swap("PUEEstimationTool.lightCompetitionIndex");
		String yLabel = Translator.swap("PUEEstimationTool.parUseEfficiency");
		chartLine.add(new XvsYChart(title, dataSet, seriesColors, xLabel, yLabel));

		report.append("stage3: chart construction is over\n");

		return chartLine;
	}

	private C4Script createPueProject() throws Exception {
		// Create a new script for the PUE growth stage
		// to avoid any interferences with the simulated project
		C4Script s = new C4Script("heterofor");

		// Find the species and samsara file names used in the simulation
		HetInitialParameters ip0 = model.getSettings();


		// fc+mj-12.9.2017 Better copy of HetInitialParameters

		// Make a copy of ip
		HetInitialParameters ip1 = new HetInitialParameters(ip0);

//		String refInventoryFileName = ip0.inventoryFileName;
//		String refSpeciesFileName = ip0.speciesFileName;
//		String refSamsaraLightFileName = ip0.samsaraLightFileName;
//
//		HetInitialParameters ip1 = new HetInitialParameters(refSpeciesFileName, refInventoryFileName,
//				refSamsaraLightFileName);
//
//		// Copy all the information the user may have changed at init time on
//		// the HetInitialDialog
//
//		ip1.soilChemistryFileName = ip0.soilChemistryFileName;
//		ip1.soilHorizonsFileName = ip0.soilHorizonsFileName; // fc-8.12.2016 was missing
//		ip1.radiationCalculationTimeStep = ip0.radiationCalculationTimeStep; // This
//																				// was
//																				// formerly
//																				// forgotten
//		ip1.constantNppToGppRatio = ip0.constantNppToGppRatio;
//		ip1.competitionAccountedForCrownGrowth = ip0.competitionAccountedForCrownGrowth;
//		ip1.heightGrowthOption = ip0.heightGrowthOption;
//
//		// fc-3.5.2017 was missing
//		ip1.castaneaPhotosynthesisActivated = ip0.castaneaPhotosynthesisActivated;
//
//		// fc+mj+fa-31.7.2017 trying to init as close as possible as the original project
//		ip1.meteorologyFileName = ip0.meteorologyFileName; // fc-5.9.2017 was missing
//		ip1.meteorology = ip0.meteorology;
//		ip1.castaneaFileName = ip0.castaneaFileName;
//		ip1.mortalityActivated = ip0.mortalityActivated;
//		ip1.generalNutrientLimitation = ip0.generalNutrientLimitation;
//		ip1.nLimitation = ip0.nLimitation;
//		ip1.phenologyActivated = ip0.phenologyActivated;
//		ip1.mineralHorizonsTemperatureCalculationActivated = ip0.mineralHorizonsTemperatureCalculationActivated;
//		ip1.fineResolutionRadiativeBalanceActivated = ip0.fineResolutionRadiativeBalanceActivated;
//		ip1.heightGrowthOption = ip0.heightGrowthOption;

		s.init(ip1);

		return s;

	}

	private C4Script createObsProject(String obsFileName) throws Exception {
		// Load the file in a script / new project
		// to avoid any interferences with the simulated project
		C4Script s = new C4Script("heterofor");

		// Find the species and samsara file names used in the simulation
		HetInitialParameters ip0 = model.getSettings();

		// fc+mj-12.9.2017 Better copy of HetInitialParameters

		// 1. Make a copy of ip
		HetInitialParameters ip1 = new HetInitialParameters(ip0);

		// 2. Change inventory file
		ip1.inventoryFileName = obsFileName;


//		String refSpeciesFileName = ip0.speciesFileName;
//		String refSamsaraLightFileName = ip0.samsaraLightFileName;
//
//		HetInitialParameters ip1 = new HetInitialParameters(refSpeciesFileName, obsFileName, refSamsaraLightFileName);
//
//		// Copy all the information the user may have changed at init time on
//		// the HetInitialDialog
//		ip1.soilChemistryFileName = ip0.soilChemistryFileName;
//		ip1.soilHorizonsFileName = ip0.soilHorizonsFileName; // fc-8.12.2016 was missing
//		ip1.radiationCalculationTimeStep = ip0.radiationCalculationTimeStep; // This
//																				// was
//																				// formerly
//																				// forgotten
//		ip1.constantNppToGppRatio = ip0.constantNppToGppRatio;
//		ip1.competitionAccountedForCrownGrowth = ip0.competitionAccountedForCrownGrowth;
//		ip1.heightGrowthOption = ip0.heightGrowthOption;
//
//		// fc-9.5.2017 was missing
//		ip1.castaneaPhotosynthesisActivated = ip0.castaneaPhotosynthesisActivated;
//
//		// fc+mj+fa-31.7.2017 trying to init as close as possible as the original project
//		ip1.meteorologyFileName = ip0.meteorologyFileName;
//		ip1.meteorology = ip0.meteorology;
//		ip1.castaneaFileName = ip0.castaneaFileName;
//		ip1.mortalityActivated = ip0.mortalityActivated;
//		ip1.generalNutrientLimitation = ip0.generalNutrientLimitation;
//		ip1.nLimitation = ip0.nLimitation;
//		ip1.phenologyActivated = ip0.phenologyActivated;
//		ip1.mineralHorizonsTemperatureCalculationActivated = ip0.mineralHorizonsTemperatureCalculationActivated;
//		ip1.fineResolutionRadiativeBalanceActivated = ip0.fineResolutionRadiativeBalanceActivated;
//		ip1.heightGrowthOption = ip0.heightGrowthOption;

		s.init(ip1);

		return s;
	}

	@Override
	public void actionPerformed(ActionEvent evt) {
		if (evt.getSource().equals(close)) {
			escapePressed();

		} else if (evt.getSource().equals(export)) {
			exportAction();

		} else if (evt.getSource().equals(browse)) {
			browseAction();

		} else if (evt.getSource().equals(browse2)) {
			browse2Action();

		} else if (evt.getSource().equals(launchEstimation)) {
			launchEstimationAction();

		} else if (evt.getSource().equals(help)) {
			Helper.helpFor(this);
		}

	}

	/**
	 * Called on Escape. Redefinition of method in AmapDialog : ask for user
	 * confirmation.
	 */
	protected void escapePressed() {
		if (Question.ask(MainFrame.getInstance(), Translator.swap("PUEEstimationTool.confirm"),
				Translator.swap("PUEEstimationTool.confirmClose"))) {
			StatusDispatcher.removeListener(this);
			dispose();
		}
	}

	/**
	 * User interface definition
	 */
	private void createUI() {

		//
		ColumnPanel top = new ColumnPanel(Translator.swap("PUEEstimationTool.observationFiles"));

		LinePanel l1 = new LinePanel();
		l1.add(new JLabel(Translator.swap("PUEEstimationTool.observationFileName") + " : "));
		observationFileName = new JTextField();
		observationFileName.setText(Settings.getProperty("PUEEstimationTool.observationFileName", ""));
		l1.add(observationFileName);
		browse = new JButton(Translator.swap("Shared.browse"));
		browse.addActionListener(this);
		l1.add(browse);
		l1.addStrut0();
		top.add(l1);

		LinePanel l2 = new LinePanel();
		l2.add(new JLabel(Translator.swap("PUEEstimationTool.trueThinningFileName") + " : "));
		trueThinningFileName = new JTextField();
		trueThinningFileName.setText(Settings.getProperty("PUEEstimationTool.trueThinningFileName", ""));
		l2.add(trueThinningFileName);
		browse2 = new JButton(Translator.swap("Shared.browse"));
		browse2.addActionListener(this);
		l2.add(browse2);
		l2.addStrut0();
		top.add(l2);

		LinePanel l3 = new LinePanel();
		launchEstimation = new JButton(Translator.swap("PUEEstimationTool.launchEstimation"));
		launchEstimation.addActionListener(this);
		l3.addGlue();
		l3.add(launchEstimation);
		l3.addStrut0();
		top.add(l3);

		scroll = new JScrollPane();
		getContentPane().add(scroll, BorderLayout.CENTER);

		// Control panel at the bottom: Close / Help
		controlPanel = new LinePanel();
		controlPanel.addStrut0();

		// fc-4.5.2015 add a status to talk to user
		status = new JLabel();
		controlPanel.add(status);
		controlPanel.addGlue();

		export = new JButton(Translator.swap("PUEEstimationTool.export"));
		export.addActionListener(this);
		export.setEnabled(false);
		controlPanel.add(export);

		close = new JButton(Translator.swap("Shared.close"));
		close.addActionListener(this);
		help = new JButton(Translator.swap("Shared.help"));
		help.addActionListener(this);
		controlPanel.add(close);
		controlPanel.add(help);
		controlPanel.addStrut0();

		setDefaultButton(close);

		// // layout parts
		// JSplitPane mainPanel = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
		// mainPanel.setLeftComponent(part1);
		// mainPanel.setRightComponent(part2);
		// mainPanel.setOneTouchExpandable(true);
		// mainPanel.setDividerLocation(INITIAL_WIDTH / 2);

		getContentPane().add(top, BorderLayout.NORTH);
		getContentPane().add(controlPanel, BorderLayout.SOUTH);
	}

	// fc+fa-31.7.2017 link to the StatusDispatcher
	@Override
	public void print(String msg) {
		printMessage(msg);

	}

}
