package heterofor.extension.modeltool.virtualunderstoreygeneration;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;

import capsis.app.C4Script;
import capsis.commongui.util.Helper;
import capsis.defaulttype.Tree;
import capsis.defaulttype.plotofcells.SquareCell;
import capsis.extension.DialogModelTool;
import capsis.kernel.GModel;
import capsis.kernel.Project;
import capsis.kernel.Step;
import capsis.lib.regeneration.RGCohort;
import capsis.lib.regeneration.RGCohortSizeClass;
import capsis.lib.regeneration.RGSpecies;
import heterofor.model.HetCell;
import heterofor.model.HetEvolutionParameters;
import heterofor.model.HetInitialParameters;
import heterofor.model.HetInventoryLoader;
import heterofor.model.HetInventoryLoader.CohortRecord;
import heterofor.model.HetModel;
import heterofor.model.HetPlot;
import heterofor.model.HetScene;
import jeeb.lib.util.Check;
import jeeb.lib.util.ColumnPanel;
import jeeb.lib.util.LinePanel;
import jeeb.lib.util.Log;
import jeeb.lib.util.MemoPanel;
import jeeb.lib.util.MessageDialog;
import jeeb.lib.util.PathManager;
import jeeb.lib.util.Record;
import jeeb.lib.util.SetMap;
import jeeb.lib.util.Settings;
import jeeb.lib.util.StatusDispatcher;
import jeeb.lib.util.StatusListener;
import jeeb.lib.util.Translator;

/**
 * A tool to make grow the understorey found in an inventory file for a while
 * and export another inventory file with the higher understorey.
 * 
 * @author F. de Coligny, M. Jonard, F. André, B. Ryelandt - May 2019
 */
public class VirtualUnderstoreyGeneration extends DialogModelTool implements ActionListener, StatusListener {

	static {
		Translator.addBundle("heterofor.extension.modeltool.virtualunderstoreygeneration.VirtualUnderstoreyGeneration");
	}

	private static final int INITIAL_WIDTH = 700;
	private static final int INITIAL_HEIGHT = 600;

	private Step refStep;
	private Project refProject;
	private HetModel refModel;
	private HetInitialParameters refIp;
	private HetScene refScene;

	private JTextField originalInventoryFile;

	private JRadioButton untilNumberOfYears;
	private JTextField numberOfYears;
	private JRadioButton untilFirstRecruitment;
	private ButtonGroup group1;

	private JTextField outputInventoryFile;
	private JButton browse;

	private JCheckBox keepTmpProjectAtTheEnd;

	private LinePanel controlPanel;
	private JButton run;
	private JButton cancel;
	private JButton help;

	private JLabel status;

	/**
	 * Constructor.
	 */
	public VirtualUnderstoreyGeneration() {
		super();
	}

	@Override
	public void init(GModel model, Step step) {

		refStep = step;
		refProject = step.getProject();
		refModel = (HetModel) refProject.getModel();
		refIp = refModel.getSettings();
		refScene = (HetScene) refStep.getScene();

		setTitle(getName() + " - " + refStep.getCaption());

		StatusDispatcher.addListener(this);

		createUI();

		printMessage(Translator.swap("VirtualUnderstoreyGeneration.ready") + "...");

		setSize(INITIAL_WIDTH, INITIAL_HEIGHT);
		setModal(false);
		setVisible(true);

	}

	/**
	 * Extension dynamic compatibility mechanism. This matchwith method checks
	 * if the extension can deal (i.e. is compatible) with the referent.
	 */
	static public boolean matchWith(Object referent) {
		return referent instanceof HetModel;
	}

	@Override
	public String getName() {
		return Translator.swap("VirtualUnderstoreyGeneration.name");
	}

	@Override
	public String getAuthor() {
		return "F. de Coligny, M. Jonard, F. André, B. Ryelandt";
	}

	@Override
	public String getDescription() {
		return Translator.swap("VirtualUnderstoreyGeneration.description");
	}

	@Override
	public String getVersion() {
		return "1.0";
	}

	private void browseAction() {
		JFileChooser chooser = new JFileChooser(
				Settings.getProperty("heterofor.VirtualUnderstoreyGeneration.path", PathManager.getDir("data")));

		int returnVal = chooser.showSaveDialog(this);

		if (returnVal == JFileChooser.APPROVE_OPTION) {
			String fileName = chooser.getSelectedFile().toString();
			Settings.setProperty("heterofor.VirtualUnderstoreyGeneration.path", fileName);
			outputInventoryFile.setText(fileName);
		}

	}

	private void runAction() {

		// Check user entries

		boolean _untilNumberOfYears = false;
		int _numberOfYears = 0;

		if (untilNumberOfYears.isSelected()) {

			if (!Check.isDouble(numberOfYears.getText().trim())) {
				MessageDialog.print(this,
						Translator.swap("VirtualUnderstoreyGeneration.numberOfYearsShouldBeAPositiveInteger"));
				return;
			}

			_numberOfYears = Check.intValue(numberOfYears.getText().trim());
			if (_numberOfYears <= 0) {
				MessageDialog.print(this,
						Translator.swap("VirtualUnderstoreyGeneration.numberOfYearsShouldBeAPositiveInteger"));
				return;
			}

			_untilNumberOfYears = true;

		} else {

			_untilNumberOfYears = false;

		}

		String _outputInventoryFile = outputInventoryFile.getText().trim();

		// fc+mj+fa-28.5.2019
		try {
			new File(_outputInventoryFile).createNewFile();

		} catch (Exception e) {
			MessageDialog.print(this,
					Translator.swap("VirtualUnderstoreyGeneration.wrongOutputInventoryFilePleaseCorrectIt"));
			return;
		}

		launchUnderstoreyGenerationTask(_untilNumberOfYears, _numberOfYears, _outputInventoryFile);

	}

	/**
	 * Launch an auxiliary simulation to make the understorey grow.
	 */
	public void launchUnderstoreyGenerationTask(boolean _untilNumberOfYears, int _numberOfYears,
			String _outputInventoryFile) {

		class AuxWorker extends SwingWorker {
			@Override
			public Object doInBackground() {

				// While in doInBackground(), complete the report.
				// If trouble, Log it, show it in dialog and return null
				// If ok, return the chartLine
				// StringBuffer report = new StringBuffer("...\n");

				int n = 50;
				if (_untilNumberOfYears)
					n = _numberOfYears;

				boolean stopIfRecruitment = !_untilNumberOfYears;

				try {
					C4Script auxScript = new C4Script("heterofor");

					HetInitialParameters auxIp = new HetInitialParameters(refIp);

					// fc+mj+fa-28.55.2019 We need mortality
					// Disable adults mortality to check recruitmentOccurred
					// auxIp.mortalityActivated = false;

					auxScript.init(auxIp);

					Step step = auxScript.getRoot();
					HetScene rootScene = (HetScene) auxScript.getRoot().getScene();

					Set<Integer> rootTreeIds = new HashSet<>(rootScene.getTreeIds());
					// int nTreesAtRootStep = rootScene.getTrees().size();

					// No more light calculation for adult trees from this point
					auxIp.virtualUnderstoreyGeneration = true;

					// Run a simulation year by year
					boolean recruitmentStoppedSimulation = false;

					int i = 0;
					for (i = 0; i < n; i++) {

						HetEvolutionParameters ep = new HetEvolutionParameters(1); // 1
																					// year
						printMessage("Evolution step: " + (i + 1) + " / " + n + "...");

						step = auxScript.evolve(step, ep);

						// if (stopIfRecruitment) {

						// fc-28.6.2019 newScene is not under root !
						// HetScene newScene = (HetScene)
						// auxScript.getRoot().getScene();
						HetScene newScene = (HetScene) step.getScene();

						boolean recruitmentOccurred = checkIfRecruitmentOccurred(rootTreeIds, newScene);

						// int nTreesAtNewStep = newScene.getTrees().size();
						// boolean recruitmentOccurred = (nTreesAtNewStep !=
						// nTreesAtRootStep);

						if (recruitmentOccurred) {
							recruitmentStoppedSimulation = true;
							break;
						}
						// }

					}

					String s = recruitmentStoppedSimulation
							? " " + Translator.swap("VirtualUnderstoreyGeneration.recruitmentStoppedSimulation")
							: "";
					printMessage(Translator.swap("VirtualUnderstoreyGeneration.endOfSimulation") + " #years: " + i + s);

					// Get the original inventory file loader
					HetInventoryLoader l = ((HetModel) auxScript.getModel()).getInventoryLoader();

					// Change cohort records in the loader
					// 1. remove the original cohort records
					for (Iterator it = l.iterator(); it.hasNext();) {

						Record r = (Record) it.next();
						if (r instanceof CohortRecord)
							it.remove();

					}

					// 2. add the cohort records made from the simulation last
					// step cohorts
					HetScene lastScene = (HetScene) step.getScene();

					// fc+mj-28.6.2019 if recruitment stopped simulation,
					// consider the previous scene (the last one without
					// recruitment)
					if (recruitmentStoppedSimulation)
						lastScene = (HetScene) ((Step) lastScene.getStep().getFather()).getScene();

					// fc-22.5.2019 NOTE: here, I'm not sure the way I should
					// read the 'cohorts' and their 'sizeClasses' in the cells
					// of the scene and what kind of CohortRecords I should
					// add in the loader before the save () statement below

					// TODO: create the HetInventoryLoader.CohortRecord
					// instances and add them in the loader

					// Add comment records
					l.addFreeRecord("");
					l.addFreeRecord("# The cohorts below were generated by the VirtualUnderstoreyRegeneration tool on "
							+ new Date());
					l.addFreeRecord("");
					l.addFreeRecord("# Cohorts");
					l.addFreeRecord("# cellRow	cellCol	speciesId	year	heightMoy_m	diamMoy_cm	number");

					HetPlot plot = lastScene.getPlot();
					for (SquareCell sc : plot.getCells()) {
						HetCell cell = (HetCell) sc;
						SetMap<RGSpecies, RGCohort> cohortSetMap = cell.getCohorts();

						if (cohortSetMap == null || cohortSetMap.isEmpty())
							continue;

						Collection<RGCohort> allCohorts = cohortSetMap.allValues();

						for (RGCohort co : allCohorts) {

							HetInventoryLoader.CohortRecord record = new HetInventoryLoader.CohortRecord();

							record.i = cell.getIGrid();
							record.j = cell.getJGrid();
							record.speciesId = co.getSpecies().getValue();
							record.year = co.getYear();

							record.classes = new ArrayList<>();

							boolean foundAKlass = false;
							for (RGCohortSizeClass klass : co.getSizeClasses()) {

								foundAKlass = true;

								StringBuffer b = new StringBuffer();

								b.append("[");
								b.append("" + klass.getHeightAvg());
								b.append(",");
								b.append("" + klass.getDiameterAvg());
								b.append(",");
								b.append("" + klass.getNumber());
								b.append("]");

								record.classes.add("" + b);

							}

							if (foundAKlass)
								l.addRecord(record);

						}

					}

					// Export output inventory file
					l.setHeaderEnabled(false);
					l.save(_outputInventoryFile);

					// Close project if user did not ask to keep it
					if (!keepTmpProjectAtTheEnd.isSelected())
						auxScript.closeProject();

					return "Ok";

				} catch (Exception e) {
					Log.println(Log.ERROR, "VirtualUnderstoreyGeneration.browseAction ()",
							"Trouble in virtual understorey generation tool" + "\n" + e.getMessage(), e);
					MessageDialog.print(this,
							Translator.swap("VirtualUnderstoreyGeneration.TroubleInVirtualUnderstoreyGenerationSeeLog")
									+ "\n" + e.getMessage(),
							e);
					printMessage("");
					return null; // Error
				}
			}

			@Override
			protected void done() {
				try {

					// If error, return
					if (get() == null) {
						printMessage("");
						return;
					}

					// Else continue...

					// fc-24.6.2019 run was ok, change the buttons to let user
					// close
					run.setEnabled(false);
					cancel.setText(Translator.swap("Shared.close"));

				} catch (Exception e) {
					Log.println(Log.ERROR, "VirtualUnderstoreyGeneration.done ()",
							"Trouble in virtual understorey generation tool", e);
					printMessage(Translator.swap("VirtualUnderstoreyGeneration.anErrorOccurred"));
				}
			}
		}

		new AuxWorker().execute();

	}

	private boolean checkIfRecruitmentOccurred(Set<Integer> rootTreeIds, HetScene newScene) {

		for (Tree t : newScene.getTrees()) {
			if (!rootTreeIds.contains(t.getId()))
				// found a tree which was not in root scene : recruited
				return true;
		}
		return false;
	}

	@Override
	public void actionPerformed(ActionEvent evt) {
		if (evt.getSource().equals(cancel)) {
			dispose();

		} else if (evt.getSource().equals(run)) {
			runAction();

		} else if (evt.getSource().equals(browse)) {
			browseAction();

		} else if (evt.getSource().equals(help)) {
			Helper.helpFor(this);
		}

	}

	/**
	 * User interface definition
	 */
	private void createUI() {

		// Top part
		ColumnPanel top = new ColumnPanel();

		LinePanel l1 = new LinePanel();
		l1.add(new JLabel(Translator.swap("VirtualUnderstoreyGeneration.originalInventoryFile") + " : "));
		originalInventoryFile = new JTextField();
		originalInventoryFile.setText(refIp.inventoryFileName);
		originalInventoryFile.setEditable(false);
		l1.add(originalInventoryFile);
		l1.addStrut0();
		top.add(l1);

		// private JRadioButton untilNumberOfYears;
		// private JTextField numberOfYears;
		// private JRadioButton untilFirstRecruitment;
		// private ButtonGroup group1;
		//
		// private JTextField outputInventoryFile;
		// private JButton browse;

		LinePanel l1a = new LinePanel();
		l1a.add(new JLabel(Translator.swap("VirtualUnderstoreyGeneration.stopCriterionForUnderstoreyGrowth")));
		l1a.addGlue();
		top.add(l1a);

		LinePanel l2 = new LinePanel();
		untilNumberOfYears = new JRadioButton(
				Translator.swap("VirtualUnderstoreyGeneration.untilNumberOfYears") + " : ");
		l2.add(untilNumberOfYears);
		numberOfYears = new JTextField();
		numberOfYears.setText("" + Settings.getProperty("VirtualUnderstoreyGeneration.numberOfYears", 20));
		l2.add(numberOfYears);
		l2.addStrut0();
		top.add(l2);

		LinePanel l3 = new LinePanel();
		untilFirstRecruitment = new JRadioButton(Translator.swap("VirtualUnderstoreyGeneration.untilFirstRecruitment"));
		l3.add(untilFirstRecruitment);
		l3.addGlue();
		top.add(l3);

		group1 = new ButtonGroup();
		group1.add(untilNumberOfYears);
		group1.add(untilFirstRecruitment);

		untilNumberOfYears.setSelected(true);

		LinePanel l4 = new LinePanel();
		l4.add(new JLabel(Translator.swap("VirtualUnderstoreyGeneration.outputInventoryFile") + " : "));
		outputInventoryFile = new JTextField();
		outputInventoryFile.setText("");
		l4.add(outputInventoryFile);
		browse = new JButton(Translator.swap("Shared.browse"));
		browse.addActionListener(this);
		l4.add(browse);
		l4.addStrut0();
		top.add(l4);

		LinePanel l5 = new LinePanel();
		keepTmpProjectAtTheEnd = new JCheckBox(Translator.swap("VirtualUnderstoreyGeneration.keepTmpProjectAtTheEnd"));
		keepTmpProjectAtTheEnd
				.setSelected(Settings.getProperty("VirtualUnderstoreyGeneration.keepTmpProjectAtTheEnd", false));
		l5.add(keepTmpProjectAtTheEnd);
		l5.addGlue();
		top.add(l5);

		LinePanel l6 = new LinePanel();
		MemoPanel memo = new MemoPanel(Translator.swap("VirtualUnderstoreyGeneration.explanation"));
		memo.setRows(6);
		l6.add(memo);
		l6.addStrut0();
		top.add(l6);
		
		top.addStrut0();

		// Bottom part
		ColumnPanel bottom = new ColumnPanel();

		// fc-4.5.2015 add a status to talk to user
		LinePanel l9 = new LinePanel();
		status = new JLabel();
		l9.add(status);
		l9.addStrut0();
		bottom.add(l9);

		// Control panel at the bottom: Close / Help
		controlPanel = new LinePanel();
		controlPanel.addGlue();

		run = new JButton(Translator.swap("VirtualUnderstoreyGeneration.run"));
		run.addActionListener(this);
		controlPanel.add(run);

		cancel = new JButton(Translator.swap("Shared.cancel"));
		cancel.addActionListener(this);
		controlPanel.add(cancel);

		help = new JButton(Translator.swap("Shared.help"));
		help.addActionListener(this);
		controlPanel.add(help);

		controlPanel.addStrut0();
		bottom.add(controlPanel);

		bottom.addStrut0();

		setDefaultButton(run);

		getContentPane().add(top, BorderLayout.NORTH);
		getContentPane().add(bottom, BorderLayout.SOUTH);

	}

	// fc+fa-31.7.2017 link to the StatusDispatcher
	@Override
	public void print(String msg) {
		printMessage(msg);

	}

	private void printMessage(final String message) {
		final JLabel st = status;
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				st.setText(message);
				st.revalidate();
				st.repaint();
			}
		});
	}

}
