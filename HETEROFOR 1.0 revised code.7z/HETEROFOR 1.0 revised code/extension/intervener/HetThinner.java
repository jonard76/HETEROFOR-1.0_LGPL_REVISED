/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.extension.intervener;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import capsis.defaulttype.Tree;
import capsis.defaulttype.TreeList;
import capsis.kernel.GModel;
import capsis.kernel.GScene;
import capsis.kernel.Step;
import capsis.kernel.extensiontype.Intervener;
import capsis.util.group.GroupableIntervener;
import capsis.util.group.GroupableType;
import heterofor.model.HetModel;
import jeeb.lib.util.Automatable;
import jeeb.lib.util.Log;
import jeeb.lib.util.Translator;
import jeeb.lib.util.annotation.Ignore;
import jeeb.lib.util.autoui.SimpleAutoDialog;
import jeeb.lib.util.autoui.annotations.AutoUI;
import jeeb.lib.util.autoui.annotations.Editor;


/**	HetThinner is an example of thinning tool for Heterofor.
 *
 * 	@author M. Jonard, F. Herman - January 2012
 */
@AutoUI(title="HeteroforThinner", translation="HetThinner")
public class HetThinner implements Intervener, GroupableIntervener, Automatable {

	static {
		Translator.addBundle ("heterofor.extension.intervener.HetThinner");
	}

	// nb-13.08.2018
	//public static final String NAME = "HetThinner";
	//public static final String VERSION = "1.0";
	//public static final String AUTHOR =  "M. Jonard, F. Herman";
	//public static final String DESCRIPTION = "HetThinner.description";

	// nb-30.08.2018
	//static public String SUBTYPE = "SelectiveThinner";

	@Ignore
	private boolean constructionCompleted = false;  // if cancel in interactive mode, false
	@Ignore
	private GScene scene;  // Reference scene: will be altered by apply ()
	@Ignore
	private GModel model;
	@Ignore
	protected Collection<Tree> concernedTrees;

	@Editor
	protected double selectionDbh = 20;  // cm, cut no trees above this dbh



	/**
	 * Default constructor.
	 */
	public HetThinner () {}


	/**
	 * Script constructor.
	 */
	public HetThinner (List<Integer> treeIdsToBeCut) {

		// fc-31.8.2018 Removed this line, no effect, the selectionDbh is set with the autoUI
//		this.selectionDbh = selectionDbh;

		constructionCompleted = true;

	}


	/** Init the thinner on a given scene.
	 */
	@Override
	public void init(GModel model, Step s, GScene scene, Collection c) {
		this.scene = scene;	// this is referentScene.getInterventionBase ();
		this.model = model;

		if (c == null) {
			concernedTrees = (Collection<Tree>) ((TreeList) scene).getTrees ();  // all trees
		} else {
			concernedTrees = c;  // restrict to the given collection
		}

		constructionCompleted = true;
	}


	/**	Open a dialog to tune the thinner.
	 */
	@Override
	public boolean initGUI() throws Exception {
		// Interactive start
		SimpleAutoDialog dlg = new SimpleAutoDialog (this, false);  // false: no extra buttons
		dlg.setVisible(true);

		constructionCompleted = false;
		if (dlg.isValidDialog ()) {
			// Valid -> ok was hit and all checks were ok
			constructionCompleted = true;
		}
		dlg.dispose ();
		return constructionCompleted;

	}


	/**	Extension dynamic compatibility mechanism.
	 *	This matchwith method checks if the extension can deal (i.e. is compatible) with the referent.
	 */
	static public boolean matchWith (Object referent) {
		try {
			if (!(referent instanceof HetModel)) {return false;}

		} catch (Exception e) {
			Log.println (Log.ERROR, "HetThinner.matchWith ()",
					"Error in matchWith () (returned false)", e);
			return false;
		}

		return true;
	}

	@Override
	public String getName() {
		return Translator.swap("HetThinner.name");
	}

	@Override
	public String getAuthor() {
		return "M. Jonard, F. Herman";
	}

	@Override
	public String getDescription() {
		return Translator.swap("HetThinner.description");
	}

	@Override
	public String getVersion() {
		return "1.0";
	}

	@Override
	public String getSubType() {
		return Translator.swap("HetThinner.subType");
	}

	/**	GroupableIntervener interface. This intervener acts on trees,
	 *	tree groups can be processed.
	 */
	public GroupableType getGrouperType () {return TreeList.GROUP_ALIVE_TREE;}


	/**	These checks are done at the beginning of apply ().
	 * 	They are run in interactive AND script mode.
	 */
	public boolean isReadyToApply () {

		if (!constructionCompleted) {
			// If cancel on dialog in interactive mode -> constructionCompleted = false
			Log.println (Log.ERROR, "HetThinner.isReadyToApply ()",
					"constructionCompleted is false. HetThinner is not appliable.");
			return false;
		}

		if (selectionDbh <= 0) {
			Log.println (Log.ERROR, "HetThinner.isReadyToApply ()",
					"Wrong selectionDbh: "+selectionDbh+". HetThinner is not appliable.");
			return false;
		}

		return true;
	}


	/**	Makes the action: thinning.
	 */
	public Object apply () throws Exception {
		// Check if apply is possible
		if (!isReadyToApply ()) {
			throw new Exception ("HetThinner.apply () - Wrong input parameters, see Log");
		}

		scene.setInterventionResult (true);

		// iterate and cut
		for (Iterator i = concernedTrees.iterator (); i.hasNext ();) {
			Tree t = (Tree) i.next ();

			// do we cut this tree ?
			if (t.getDbh () <= selectionDbh) {  // yes
				// remove the tree
				i.remove ();
				((TreeList) scene).removeTree (t);
				// remember this tree has been cut
				((TreeList) scene).storeStatus (t, "cut");

			}

		}

		return scene;
	}


	/**	Intervener
	 */
	@Override
	public void activate() {
		// not used

	}

}

