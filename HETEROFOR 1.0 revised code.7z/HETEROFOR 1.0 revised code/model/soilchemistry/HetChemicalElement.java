/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.soilchemistry;

import java.io.Serializable;

import jeeb.lib.util.Record;

/**
 * A soil chemical element in the heterofor model.
 *
 * @author M. Jonard - October 2015
 */
public class HetChemicalElement extends Record implements Serializable {

	public String name;
	public int charge; // positive or negative
	public double atomicMass; // g
	public double diffusionCoefficient; // m2/s
	public String treeElement; // fc+mj-12.5.2016, see HetTreeElement

	/**
	 * Constructor for record recognition.
	 */
	public HetChemicalElement() {
		super();
	}

	/**
	 * Constructor for record recognition.
	 */
	public HetChemicalElement(String line) throws Exception {
		super(line);
	}

	/**
	 * Constructor
	 */
	public HetChemicalElement(String name, int charge, double atomicMass) {
		this.name = name;
		this.charge = charge;
		this.atomicMass = atomicMass;
	}

	@Override
	public String toString() {
		return "HetChemicalElement [name: " + name + ", charge: " + charge
				+ ", atomicMass: " + atomicMass + ", diffusionCoefficient: "
						+ diffusionCoefficient + ", treeElement: "
								+ treeElement + "]";
	}

}
