/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.treechemistry.treefunction;

import heterofor.model.treechemistry.HetTreeCompartment;


/**
 * A concentration function for an element in a tree compartment.
 *
 * @author M. Jonard - March 2016
 */
public class HetTreeDefaultFunction extends HetTreeFunction {

	/**
	 * Constructor.
	 */
	public HetTreeDefaultFunction(String str) throws Exception { // e.g.
																// defaultFunction
		if (!str.startsWith("defaultFunction")) {
			throw new Exception("HetTreeNormalFunction error, string should start with \"defaultFunction\": " + str);
		}

	}

	/**
	 * Returns a concentration value for the given compartment.
	 */
	@Override
	public double getValue(HetTreeCompartment compartment) {
		return 0;
	}


	public String toString () {
		return "defaultFunction";
	}

}
