/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.treechemistry;

import heterofor.model.treechemistry.treefunction.HetTreeFunction;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jeeb.lib.util.Log;

/**
 * HetTreeChemistryDistribution Knows about regional tree chemistry
 * distributions.
 *
 * @author M. Jonard - February 2016
 */
public class HetTreeChemistryDistribution implements Serializable {

	private List<String> speciesNames;
	private List<String> compartmentTypes;
	private List<String> compartmentNames;
	private List<String> elementNames;

	private List<String> keys; // keep insertion order
	private Map<String, HetTreeFunction> map; // HashMap for fast searching

	/**
	 * Construction
	 */
	public HetTreeChemistryDistribution(List<String> speciesNames, List<String> compartmentTypes,
			List<String> compartmentNames, List<String> elementNames) {

		this.speciesNames = speciesNames;
		this.compartmentTypes = compartmentTypes;
		this.compartmentNames = compartmentNames;
		this.elementNames = elementNames;

		keys = new ArrayList<>();
		map = new HashMap<>();
	}

	/**
	 * Main function to add information from the species file. Note:
	 * speciesName, compartmentType, compartmentName and elementName may contain
	 * "ALL".
	 */
	public void add(String speciesName, String compartmentType, String compartmentName, String elementName,
			String encodedDistributionFunction) throws Exception {

		HetTreeFunction distributionFunction = HetTreeFunction.getFunction(encodedDistributionFunction);

		if (speciesName == null || compartmentType == null || compartmentName == null || elementName == null
				|| distributionFunction == null)
			throw new Exception("HetTreeChemistryDistribution could not add a distributionFunction, speciesName: "
					+ speciesName + " compartmentType: " + compartmentType + " compartmentName: " + compartmentName
					+ " elementName: " + elementName + " distributionFunction: " + distributionFunction);

		if (speciesName.equals("ALL"))
			// for all species
			for (String sName : speciesNames) {
				addSpeciesName(sName, compartmentType, compartmentName, elementName, distributionFunction);
			}
		else
			addSpeciesName(speciesName, compartmentType, compartmentName, elementName, distributionFunction);
	}

	/**
	 * sName cannot be ALL
	 */
	private void addSpeciesName(String sName, String compartmentType, String compartmentName, String elementName,
			HetTreeFunction distributionFunction) {

		if (compartmentType.equals("ALL"))
			for (String cType : compartmentTypes) {
				addCompartmentType(sName, cType, compartmentName, elementName, distributionFunction);
			}
		else
			addCompartmentType(sName, compartmentType, compartmentName, elementName, distributionFunction);
	}

	/**
	 * sName and cType cannot be ALL
	 */
	private void addCompartmentType(String sName, String cType, String compartmentName, String elementName,
			HetTreeFunction distributionFunction) {

		if (compartmentName.equals("ALL"))
			// Restrict to the compartment names matching the given cType
			for (String cName : HetTreeCompartment.getNames(cType)) {
				addCompartmentName(sName, cType, cName, elementName, distributionFunction);
			}
		else
			addCompartmentName(sName, cType, compartmentName, elementName, distributionFunction);

	}

	/**
	 * sName, cType and cName cannot be ALL
	 */
	private void addCompartmentName(String sName, String cType, String cName, String elementName,
			HetTreeFunction distributionFunction) {

		if (elementName.equals("ALL"))
			for (String eName : elementNames) {
				addElementName(sName, cType, cName, eName, distributionFunction);
			}
		else
			addElementName(sName, cType, cName, elementName, distributionFunction);

	}

	/**
	 * sName, cType, cName and eName cannot be ALL
	 */
	private void addElementName(String sName, String cType, String cName, String eName, HetTreeFunction distributionFunction) {

		String key = sName + '.' + cType + '.' + cName + '.' + eName;
		if (!map.containsKey(key))
			keys.add(key);
		map.put(key, distributionFunction);

	}

	public double getConcentration(String speciesName, HetTreeCompartment compartment, String elementName) {

		// Get the function for this compartment
		String key = speciesName + '.' + compartment.getType() + '.' + compartment.name + '.' + elementName;
		HetTreeFunction f = map.get(key);

		if (f == null)
			Log.println(Log.ERROR, "HetTreeChemistryDistribution.getConcentration ()",
					"Could not find a function for key: " + key);

		// Return the value for this compartment
		return f.getValue(compartment);
	}

	@Override
	public String toString() {
		StringBuffer b = new StringBuffer("TreeChemistryDistributions (" + keys.size() + " entries)...\n");
		for (String key : keys) {
			b.append(key);
			b.append(" -> ");
			b.append(map.get(key));
			b.append("\n");
		}
		return b.toString();
	}

}
