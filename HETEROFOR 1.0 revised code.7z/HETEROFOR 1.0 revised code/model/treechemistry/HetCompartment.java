/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.treechemistry;

import heterofor.model.HetElementState;

/**
 * HetCompartment is a tree compartment or a litter compartment in the tree
 *
 * @author M. Jonard - December2016
 */
public interface HetCompartment {

	public String getName(); // LEAVES_UPPER_CURRENT,... MYCORRHIZAE

	public double getBiomass(); // kgC

	public HetElementState getConcentrations(); // Nutrient name ->
												// concentration (mg/g)

	/**
	 * True if the compartment is above ground.
	 */
	public boolean isAboveGround ();

}
