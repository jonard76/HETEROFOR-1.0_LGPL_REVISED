/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model;

import heterofor.model.treechemistry.HetTreeElement;

import java.io.Serializable;
import java.text.NumberFormat;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import jeeb.lib.util.DefaultNumberFormat;

/**
 * Amount or concentration of each element for a given tree. Can be used for
 * requirement, retranslocation, demand, supply.
 *
 * @author M. Jonard - March 2016
 */
public class HetElementState implements Serializable {

	private static NumberFormat nf = DefaultNumberFormat.getInstance(2);

	// One entry per element in HetTreeElement
	public Map<String, Double> values; // Nutrient name -> amount (g)

	/**
	 * Construction.
	 */
	public HetElementState() {
		this.values = new HashMap<>();
	}

	/**
	 * Builds and returns a copy of this object.
	 */
	public HetElementState getCopy() {
		HetElementState copy = new HetElementState();
		for (String eName : values.keySet()) {
			Double v = getValue(eName);
			copy.setValue(eName, v);
		}
		return copy;
	}

	public boolean contains(String eName) {
		return values.keySet().contains(eName);
	}

	public Set<String> getKeys() {
		return new HashSet<>(values.keySet());
	}

	/**
	 * Adds a value for the given elementName.
	 */
	public void addValue(String eName, double value) {
		Double a = values.get(eName);

		double prevValue = 0;
		if (a != null)
			prevValue = a;

		values.put(eName, prevValue + value);
	}

	/**
	 * Sets a value for the given element name.
	 */
	public void setValue(String elementName, double value) {
		values.put(elementName, value);
	}

	/**
	 * Returns the value (concentration or amount) for the given element name,
	 * or null if the element is not in the map.
	 */
	public Double getValue(String eName) {
		return values.get(eName);
	}

	public String getFormattedHeader(String separator, String prefix, String suffix) {
		StringBuffer b = new StringBuffer();
		boolean first = true;
		for (String eName : HetTreeElement.elementNames) {

			if (first)
				first = false;
			else
				b.append(separator);

			if (prefix != null)
				b.append(prefix);

			b.append(eName);

			if (suffix != null)
				b.append(suffix);

		}
		return b.toString();

	}

	public String getFormattedValues(String separator) {
		StringBuffer b = new StringBuffer();
		boolean first = true;
		for (String eName : HetTreeElement.elementNames) {
			Double v = getValue(eName);

			if (first)
				first = false;
			else
				b.append(separator);

			if (v == null)
				b.append("NA");
			else
				b.append(nf.format(v));
		}
		return b.toString();
	}

//	 /**
//	 * Returns this compartments value for each element name in a formatted
//	 * String. e.g. possible outputs: "C N P S Ca Mg K Na Al Mn Fe Cl
//	 * Si" OR "475.16 4.21 0.09 0.14 1.49 0.21 1.06 0 0 0.44 0 0 0"
//	 *
//	 * @param separatorBetweenElements
//	 *            : to be used between each element information
//	 * @param includingElementNames
//	 *            : if true, each element name is written
//	 * @param eNamePrefix
//	 *            : if includingElementName and not null, added before eName
//	 * @param eNameSuffix
//	 *            : if includingElementName and not null, added after eName
//	 * @param includingValues
//	 *            : if true, each value is written
//	 * @param separatorBetweenElementNameAndValue
//	 *            : if both element name and value are written, this separator
//	 *            is written between them
//	 * @param replaceNullAndNaNByZero
//	 *            : if true, null and NaN values are replaced by zeroes
//	 * @return
//	 */
	// public String getFormatedString(String separatorBetweenElements, boolean
	// includingElementNames, String eNamePrefix,
	// String eNameSuffix, boolean includingValues, String
	// separatorBetweenElementNameAndValue,
	// boolean replaceNullAndNaNByZero) {
	//
	// StringBuffer b = new StringBuffer();
	// boolean first = true;
	// for (String eName : HetTreeElement.elementNames) {
	//
	// if (first)
	// first = false;
	// else
	// b.append(separatorBetweenElements);
	//
	// if (includingElementNames) {
	// if (eNamePrefix != null)
	// b.append(eNamePrefix);
	// b.append(eName);
	// if (eNameSuffix != null)
	// b.append(eNameSuffix);
	// }
	//
	// if (includingElementNames && includingValues)
	// b.append(separatorBetweenElementNameAndValue);
	//
	// if (includingValues) {
	//
	// Double v = values.get(eName);
	//
	// if (v == null) {
	// b.append(replaceNullAndNaNByZero ? 0 : "null");
	// } else if (v.isNaN()) {
	// b.append(replaceNullAndNaNByZero ? 0 : "NaN");
	// } else {
	// b.append(nf.format(v));
	// }
	// }
	//
	// }
	// return b.toString();
	//
	// }

	public String toString() {
		NumberFormat nf = DefaultNumberFormat.getInstance(2);
		StringBuffer b = new StringBuffer("ElementState ");
		for (String eName : HetTreeElement.elementNames) {
			Double v = getValue(eName);
			if (v == null) {
				b.append(" " + eName + ": null");
			} else if (v.isNaN()) {
				b.append(" " + eName + ": NaN");
			} else if (v.isInfinite()) {
				b.append(" " + eName + ": Infinite");
			} else { // normal double value
				b.append(" " + eName + ": " + nf.format(v));
			}
		}
		return b.toString();
	}

}
