/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.phenology;

import heterofor.model.meteorology.HetMeteoLine;
import heterofor.model.meteorology.HetMeteorology;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;

import capsis.util.Calendar;
import capsis.util.Fit2018Date;

/**
 * The superclass of the phenology models. It usually contains methods to calculate
 * the phenological dates depending on a phenological model.
 *
 * @author N. Beudez - May 2017
 */
public abstract class HetPhenologyModel implements Serializable {

	protected final static String THERMAL_TIME = "thermalTime";
	protected final static String UNI_FORC = "uniForc";
	protected final static String SEQUENTIAL = "sequential";
	protected final static String UNI_CHILL = "uniChill";

	// Key: year_month_day string, value: true if frost day, false otherwise.
	private LinkedHashMap<String, Boolean> dateFrostDayMap;

	// Key: phenological date, value: budburst rate
	private LinkedHashMap<HetPhenologyDate, Double> budburstRateMap;

	/**
	 * Instanciates a phenological model with the given phenology line.
	 * @param phenologyLine The full phenology line including the name of the phenology model followed by the list of phenology parameters
	 * @return An instance of a particular HetPhenologyModel
	 * @throws Exception
	 */
	public static HetPhenologyModel getModel(String phenologyLine) throws Exception {

		if (phenologyLine.startsWith(THERMAL_TIME + "(")) {
			return new HetThermalTimeModel(phenologyLine);
		}

		if (phenologyLine.startsWith(UNI_FORC + "(")) {
			return new HetUniForcModel(phenologyLine);
		}

		if (phenologyLine.startsWith(SEQUENTIAL + "(")) {
			return new HetSequentialModel(phenologyLine);
		}

		if (phenologyLine.startsWith(UNI_CHILL  +"(")) {
			return new HetUniChillModel(phenologyLine);
		}

		throw new Exception("HetPhenologyModel.getModel(String): could not get a model for: " + phenologyLine);
	}

	/**
	 * Returns a string tokenizer containing the list of the given parameters phenology.
	 * @param phenologyLine The full phenology parameter line including the name of the phenology model foolwed by the list of phenology parameters
	 * @param phenologyModelName The name of the phenology model
	 * @return A string tokenizer containing the list of parameters phenology.
	 */
	protected StringTokenizer parsePhenologyParameterLines(String phenologyLine, String phenologyModelName) {

		String s = phenologyLine.replace(phenologyModelName+"(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, ";");

		return st;
	}

	/**
	 * Sets some phenological dates in the given phenology depending on the phenological model used. This method is called when processing
	 * the phenology for the initial scene because there are no meteorological data for the previous year of the initial scene. That is
	 * why t2b_averageTreeBudburstDateDOY is given instead of been calculated.
	 * Abstract method to be redefined in all subclasses.
	 * @param phenology The phenology which phenological dates are updated
	 * @param year The year
	 * @param t2b_averageTreeBudburstDateDOY The day of year (doy) of the leaf budburst date of the average tree
	 */
	protected abstract void completeInitialisation(HetPhenology phenology, int year, int t2b_averageTreeBudburstDateDOY);

	/**
	 * Sets some phenological dates and states in the given newPhenology depending on the phenological model used and the phenological dates
	 * and states of the given sourcePhenology. This method is called when processing the phenology for the scenes after the initial scene.
	 * Abstract method to be redefined in all subclasses.
	 * @param newPhenology The phenology which phenological dates and states are updated
	 * @param sourcePhenology The phenology of previous year whose dates and states are used to update dates and states of the new phenology
	 * @param year The year
	 */
	protected abstract void completeInitialisation(HetPhenology newPhenology, HetPhenology sourcePhenology, int year);

	/**
	 * Calculates the phenology states and dates for the given year. Abstract method to be redefined in all subclasses.
	 * @param phenology The phenology
	 * @param year The year number
	 * @param dateDailyAverageAirTemperatureMap The map with key: year_month_day string, value: the average air temperature of the day
	 * @param dateDailyAverageWindSpeedMap The map with key: year_month_day string, value: the average wind speed of the day
	 * @param meteoLinesOfYear The ordered meteorological lines of the year (one line per hour)
	 * @param latitudeInRadians The latitude of the plot expressed in radians
	 * @throws Exception
	 */
	protected abstract void run(HetPhenology phenology, int year, LinkedHashMap<String, Double> dateDailyAverageAirTemperatureMap,
			LinkedHashMap<String, Double> dateDailyAverageWindSpeedMap, List<HetMeteoLine> meteoLinesOfYear,
			double latitudeInRadians) throws Exception;

	/**
	 * Calculates the minimal day length in the year: it is obtained for DOY=355 (December 21th)
	 * @param latitudeInRadians The latitude of the plot expressed in radians
	 */
	protected double calculateMinimalDayLength(double latitudeInRadians) {

		return calculateDayLength(latitudeInRadians, 355);
	}

	/**
	 * Calculates t2a_standBudburstStartingDate. It is calculated by adding t2a_budburstShift days (t2a_budburstShift <= 0)
	 * to t2b_averageTreeBudburstDate, so that t2a_standBudburstStartingDate appears abs(t2a_budburstShift) days before t2b_averageTreeBudburstDate.
	 *
	 * @throws Exception
	 */
	protected void calculate_t2a_standBudburstStartingDate(HetPhenology phenology, int year, int month, int day,
			int t2a_budburstShift, String modelName) throws Exception {

		if (phenology.getT2a_standBudburstStartingDate().isSet())
			return; // done

		if (!phenology.getT2b_averageTreeBudburstDate().isSet())
			return; // not yet

		HetPhenologyDate today = HetPhenologyDate.getPhenologyDate(year, month, day);

		HetPhenologyDate t2b_averageTreeBudburstDate = phenology.getT2b_averageTreeBudburstDate();
		Fit2018Date t2bDate = Fit2018Date.getInstance(t2b_averageTreeBudburstDate.getYear(), t2b_averageTreeBudburstDate.getDoy());
		Fit2018Date t2aDate = t2bDate.addDays(t2a_budburstShift); // t2a_budburstShift <= 0
		HetPhenologyDate t2a_standBudburstStartingDate = new HetPhenologyDate(t2aDate.getYear(), (int) t2aDate.getDayOfYear());
		phenology.getT2a_standBudburstStartingDate().setValue(t2a_standBudburstStartingDate);

		if (((Calendar.isLeap(year) && today.getDoy() == 366) || (!Calendar.isLeap(year) && today.getDoy() == 365))
				&& !phenology.getT2a_standBudburstStartingDate().isSet()) {

			throw new Exception("HetPhenologyModel.calculate_t2a_standBudburstStartingDate() year: " + year
					+ ". Error in " + modelName + " model: t2a_standBudburstStartingDate should have been reached before the end of year.");
		}

	}

	/**
	 * Calculates t2b_averageTreeBudburstDate. Stores also the budburst rates to be used in the calculation of t2c_completeLeafDevelopmentDate.
	 *
	 * @throws Exception
	 */
	protected void calculate_t2b_averageTreeBudburstDate(HetPhenology phenology, int year, int month, int day, double dailyAirTemperature,
			double t1_forcingThreshold, String modelName) throws Exception {

		if (phenology.getT2b_averageTreeBudburstDate().isSet())
			return; // done

		if (!phenology.getT1_forcingStartingDate().isSet())
			return; // not yet

		HetPhenologyDate today = HetPhenologyDate.getPhenologyDate(year, month, day);

		// Useful: for thermalTime and uniForc models, t1_forcingStartingDate is set at initialization instead of being calculated.
		boolean t1_forcingStartingDateWasReached = today.isGreaterOrEqualThan(phenology.getT1_forcingStartingDate());
		if (!t1_forcingStartingDateWasReached)
			return; // not yet

		// Calculates new t1_forcingState value.
		double t1_forcingState = phenology.getT1_forcingState();
		t1_forcingState += calculate_t1_forcingRate(dailyAirTemperature);
		phenology.setT1_forcingState(t1_forcingState);

		if (phenology.getT1_forcingState() >= t1_forcingThreshold) {
			phenology.getT2b_averageTreeBudburstDate().setValue(today);
		}

		// Stores in budburstRateMap the budburst rates for t1_forcingStartingDate <= t <= t2b_averageTreeBudburstDate to be used
		// in the calculation of t2c_completeLeafDevelopmentDate.
		if (budburstRateMap == null) {
			budburstRateMap = new LinkedHashMap<HetPhenologyDate, Double>();
		}
 		double t2a_budburstRate = calculate_t2a_budburstRate(dailyAirTemperature);
		budburstRateMap.put(today, t2a_budburstRate);

		if (((Calendar.isLeap(year) && today.getDoy() == 366) || (!Calendar.isLeap(year) && today.getDoy() == 365))
				&& !phenology.getT2b_averageTreeBudburstDate().isSet()) {

			throw new Exception("HetPhenologyModel.calculate_t2b_averageTreeBudburstDate() year: " + year
					+ ". Error in " + modelName + " model: t2b_averageTreeBudburstDate should have been reached before the end of year."
					+ "t1_forcingState: " + phenology.getT1_forcingState() + "t1_forcingThreshold: " + t1_forcingThreshold);
		}
	}

	/**
	 * Calculates t2c_completeLeafDevelopmentDate. Calculates also the ladProp and greenProp coefficients for days
	 * greater than or equal to t2a_standBudburstStartingDate and smaller than or equal to t2c_completeLeafDevelopmentDate.
	 *
	 * @throws Exception
	 */
	protected void calculate_t2c_completeLeafDevelopmentDate(HetPhenology phenology, int year, int month, int day,
			double dailyAirTemperature, double t2a_budburstThreshold, String modelName) throws Exception {

		if (phenology.getT2c_completeLeafDevelopmentDate().isSet())
			return; // done

		if (!phenology.getT2b_averageTreeBudburstDate().isSet())
			return; // not yet

		HetPhenologyDate today = HetPhenologyDate.getPhenologyDate(year, month, day);

		// Security: when this line is reached, t2b_averageTreeBudburstDate was always reached because is never set at
		// initialization (always calculated).
		boolean t2b_averageTreeBudburstDateWasReached = today.isGreaterOrEqualThan(phenology.getT2b_averageTreeBudburstDate());
		if (!t2b_averageTreeBudburstDateWasReached)
			return; // not yet

		double ladProp;
		double greenProp;

		// At t = t2b_averageTreeBudburstDate: gets the budburst rates stored in budburstRateMap for
		// t2a_standBudburstStartingDate <= t <= t2b_averageTreeBudburstDate. The budburst rates have been stored in budburstRateMap
		// for t1_forcingStartingDate <= t <= t2b_averageTreeBudburstDate.
		if (today.isEqualTo(phenology.getT2b_averageTreeBudburstDate())) {

			double t2a_budburstState = 0.0;

			// Dates in the map are ordered (insertion order) because its type is LinkedHashMap.
			for (HetPhenologyDate date : budburstRateMap.keySet()) {

				if (date.isGreaterOrEqualThan(phenology.getT2a_standBudburstStartingDate())) {

					double rate = budburstRateMap.get(date);
					t2a_budburstState += rate;

					// Calculates ladProp.
					if (date.isEqualTo(phenology.getT2a_standBudburstStartingDate())) {
						ladProp = 0.0;
					} else { // t2a_standBudburstStartingDate < t <= t2b_averageTreeBudburstDate
						ladProp = t2a_budburstState/t2a_budburstThreshold;
					}

					// All new leaves are green.
					greenProp = ladProp;

					// Saves the ladProp and greenProp values.
					phenology.getDoyLadPropMap().put(date.getDoy(), ladProp);
					phenology.getDoyGreenPropMap().put(date.getDoy(), greenProp);
				}
			}

			phenology.setT2a_budburstState(t2a_budburstState);

		} else { // t > t2b_averageTreeBudburstDate

			// Calculates new t2a_budburstState value.
			double t2a_budburstState = phenology.getT2a_budburstState();
			t2a_budburstState += calculate_t2a_budburstRate(dailyAirTemperature);

			phenology.setT2a_budburstState(t2a_budburstState);

			ladProp = t2a_budburstState/t2a_budburstThreshold;

			if (phenology.getT2a_budburstState() >= t2a_budburstThreshold) {
				phenology.getT2c_completeLeafDevelopmentDate().setValue(today);
				ladProp = 1.0; // ladProp is forced to 1.0 instead of t2a_budburstState/t2a_budburstThreshold >= 1
			}

			// All new leaves are green.
			greenProp = ladProp;

			// Saves the ladProp and greenProp values.
			phenology.getDoyLadPropMap().put(today.getDoy(), ladProp);
			phenology.getDoyGreenPropMap().put(today.getDoy(), greenProp);
		}

		if (((Calendar.isLeap(year) && today.getDoy() == 366) || (!Calendar.isLeap(year) && today.getDoy() == 365))
				&& !phenology.getT2c_completeLeafDevelopmentDate().isSet()) {

			throw new Exception("HetPhenologyModel.calculate_t2c_completeLeafDevelopmentDate() year: " + year
					+ ". Error in " + modelName + " model: t2c_completeLeafDevelopmentDate should have been reached before the end of year."
					+ "t2a_budburstState: " + phenology.getT2a_budburstState() + "t2a_budburstThreshold: "
					+ t2a_budburstThreshold);
		}
	}

	/**
	 * Calculates t3_ageingStartingDate.
	 */
	protected void calculate_t3_ageingStartingDate(HetPhenology phenology, int year, int month, int day,
			double dailyAirTemperature, String simpleClassName, String modelName) throws Exception {

		if (!phenology.getT3_ageingStartingDate().isSet()) {

			throw new Exception("HetPhenologyModel.calculate_t3_ageingStartingDate() year: " + year
					+ ". Error in " + modelName + " model: t3_ageingStartingDate should have been set in "
					+ simpleClassName + ".completeInitialisation(HetPhenology phenology, int year, int t2b_averageTreeBudburstDateDOY) or "
					+ simpleClassName + ".completeInitialisation(HetPhenology newPhenology, HetPhenology sourcePhenology, int year), "
					+ "t3_ageingStartingDate: " + phenology.getT3_ageingStartingDate());
		}
	}

	/**
	 * Calculates t4a_yellowingStartingDate.
	 *
	 * @throws Exception
	 */
	protected void calculate_t4a_yellowingStartingDate(HetPhenology phenology, int year, int month, int day,
			double dailyAirTemperature, double t3_criticalAgeingTemperature, double t3_ageingThreshold, String modelName) throws Exception {

		if (phenology.getT4a_yellowingStartingDate().isSet())
			return; // done

		HetPhenologyDate today = HetPhenologyDate.getPhenologyDate(year, month, day);

		// Useful: t3_ageingStartingDate is set at initialization instead of being calculated.
		boolean t3_ageingStartingDateWasReached = today.isGreaterOrEqualThan(phenology.getT3_ageingStartingDate());
		if (!t3_ageingStartingDateWasReached)
			return; // not yet

		// Calculates new t3_ageingState value.
		double t3_ageingState = phenology.getT3_ageingState();
		t3_ageingState += calculate_t3_ageingRate(dailyAirTemperature, t3_criticalAgeingTemperature);
		phenology.setT3_ageingState(t3_ageingState);

		if (phenology.getT3_ageingState() >= t3_ageingThreshold) {
			phenology.getT4a_yellowingStartingDate().setValue(today);
		}

		if (((Calendar.isLeap(year) && today.getDoy() == 366) || (!Calendar.isLeap(year) && today.getDoy() == 365))
				&& !phenology.getT4a_yellowingStartingDate().isSet()) {

			throw new Exception("HetPhenologyModel.calculate_t4a_yellowingStartingDate() year: " + year
					+ ". Error in " + modelName + " model: t4a_yellowingStartingDate should have been reached before the end of year."
					+ "t3_ageingState: " + phenology.getT3_ageingState() + "t3_ageingThreshold: " + t3_ageingThreshold);
		}
	}

	/**
	 * Calculates t4b_yellowingEndingDate. It uses the calculation of the greenProp coefficients for days greater than or equal to
	 * t4a_yellowingStartingDate and smaller than or equal to t4b_yellowingEndingDate.
	 *
	 * @throws Exception
	 */
	protected void calculate_t4b_yellowingEndingDate(HetPhenology phenology, int year, int month, int day,
			double latitudeInRadians, double dayLengthMin, double t4a_leafYellowingParameter, double t4a_yellowingThreshold, String modelName) throws Exception {

		if (phenology.getT4b_yellowingEndingDate().isSet())
			return; // done

		if (!phenology.getT4a_yellowingStartingDate().isSet())
			return; // not yet

		HetPhenologyDate today = HetPhenologyDate.getPhenologyDate(year, month, day);

		// Security: when this line is reached, t4a_yellowingStartingDate was always reached because is never set
		// at initialization (always calculated).
		boolean t4a_yellowingStartingDateWasReached = today.isGreaterOrEqualThan(phenology.getT4a_yellowingStartingDate());
		if (!t4a_yellowingStartingDateWasReached)
			return; // not yet

		double greenProp;

		if (today.isEqualTo(phenology.getT4a_yellowingStartingDate())) {
			greenProp = 1.0;
		} else { // today > t4a_yellowingStartingDate

			double greenProportionPrev = phenology.getDoyGreenPropMap().get(today.getDoy()-1);
			double dayLengthT4a_yellowingStartingDay = calculateDayLength(latitudeInRadians, phenology.getT4a_yellowingStartingDate().getDoy());

			greenProp = calculateGreenProportion(today, greenProportionPrev, latitudeInRadians, dayLengthMin,
					dayLengthT4a_yellowingStartingDay, t4a_leafYellowingParameter);
		}

		if (greenProp <= t4a_yellowingThreshold) {
			phenology.getT4b_yellowingEndingDate().setValue(today);
			greenProp = 0.0; // greenProp is forced to 0.0 instead of been calculated by the calculateGreenProportion() method (greenProp must be in [0,1]).
		}

		// Saves the greenProp value.
		phenology.getDoyGreenPropMap().put(today.getDoy(), greenProp);

		if ( ( (Calendar.isLeap(year) && today.getDoy() == 366) || (!Calendar.isLeap(year) && today.getDoy() == 365) )
				&& !phenology.getT4b_yellowingEndingDate().isSet() ) {

			throw new Exception("HetPhenologyModel.calculate_t4b_yellowingEndingDate() year: " + year
					+ ". Error in " + modelName + " model: t4b_yellowingEndingDate should have been reached before the end of year."
					+ "greenProp: " + greenProp + " t4a_yellowingThreshold: " + t4a_yellowingThreshold);
		}
	}

	/**
	 * Calculates t5a_fallingStartingDate.
	 *
	 * @throws Exception
	 */
	protected void calculate_t5a_fallingStartingDate(HetPhenology phenology, int year, int month, int day, String modelName) throws Exception {

		if (phenology.getT5a_fallingStartingDate().isSet())
			return; // done

		// The calculation of t5a_fallingStartingDate can not begin if t4a_yellowingStartingDate is not set.
		// The calculation of t5a_fallingStartingDate begins before t4b_yellowingEndingDate is reached.
		if (!phenology.getT4a_yellowingStartingDate().isSet())
			return; // not yet

		HetPhenologyDate today = HetPhenologyDate.getPhenologyDate(year, month, day);

		// Security: when this line is reached, t4a_yellowingStartingDate was always reached because is never set
		// at initialization (always calculated).
		boolean t4a_yellowingStartingDateWasReached = today.isGreaterOrEqualThan(phenology.getT4a_yellowingStartingDate());
		if (!t4a_yellowingStartingDateWasReached)
			return; // not yet

		// t5a_fallingStartingDate is reached when more than 40% of the leaves are yellow (it means less than 60% of
		// the leaves are green). nb-02.10.2018
		double greenProp = phenology.getGreenProportion(today.getDoy());

		if (greenProp <= 0.6) {
			phenology.getT5a_fallingStartingDate().setValue(today);
		}

		if ( ( (Calendar.isLeap(year) && today.getDoy() == 366) || (!Calendar.isLeap(year) && today.getDoy() == 365) )
				&& !phenology.getT5a_fallingStartingDate().isSet() ) {

			throw new Exception("HetPhenologyModel.calculate_t5a_fallingStartingDate() year: " + year
					+ ". Error in " + modelName + " model: t5a_fallingStartingDate should have been reached before the end of year."
					+ "greenProp: " + greenProp);
		}
	}

	/**
	 * Calculates the t5b_fallingEndingDate. It uses the calculation of the ladProp coefficients for days greater than or equal to
	 * t5a_fallingStartingDate and smaller than or equal to t5b_fallingEndingDate.
	 *
	 * @throws Exception
	 */
	protected void calculate_t5b_fallingEndingDate(HetPhenology phenology, int year, int month, int day,
			double dailyAverageWindSpeed, List<HetMeteoLine> meteoLinesOfYear,
			double t5a_frostFallingAmplifier, double t5a_fallingRate, String modelName) throws Exception {

		if (phenology.getT5b_fallingEndingDate().isSet())
			return; // done

		if (!phenology.getT5a_fallingStartingDate().isSet())
			return; // not yet

		HetPhenologyDate today = HetPhenologyDate.getPhenologyDate(year, month, day);

		// Security: when this line is reached, t5a_fallingStartingDate was always reached because is never set
		// at initialization (always calculated).
		boolean t5a_fallingStartingDateWasReached = today.isGreaterOrEqualThan(phenology.getT5a_fallingStartingDate());
		if (!t5a_fallingStartingDateWasReached)
			return; // not yet

		// Stores the frostDay status of all days from t5a_fallingStartingDate to the end of year in the dateFrostDayMap map.
		// The dateFrostDayMap map :
		//		key: year_month_day string,
		//		value: true if frost day, false otherwise.
		if (today.isEqualTo(phenology.getT5a_fallingStartingDate())) {
			dateFrostDayMap = HetMeteorology.identifyFrostDays(month, day, meteoLinesOfYear);
		}

		double ladProp;

		if (today.isEqualTo(phenology.getT5a_fallingStartingDate())) {
			ladProp = 1.0;
		} else { // t > t5a_fallingStartingDate
			double ladPropPrev = phenology.getDoyLadPropMap().get(today.getDoy()-1);
			double frostFallingAmplifier;

			boolean frostDay = dateFrostDayMap.get(year + HetMeteorology.SEP + month + HetMeteorology.SEP + day);

			if (frostDay) {
				frostFallingAmplifier = t5a_frostFallingAmplifier;
			} else {
				frostFallingAmplifier = 1.0;
			}

			ladProp = ladPropPrev-frostFallingAmplifier*dailyAverageWindSpeed*t5a_fallingRate;

			// Entry in doyGreenPropMap exists when t5a_fallingStartingDtae <= t <= t4b_yellowingEndingDate, because doyGreenPropMap
			// contains entries for t4a_yellowingStartuingDate <= t <= t4b_yellowingEndingDate.
			if (phenology.getDoyGreenPropMap().get(today.getDoy()) != null) {

				// ladProp must be >= greenProp.
				double greenProp = phenology.getDoyGreenPropMap().get(today.getDoy());
				if (ladProp < greenProp) {
					ladProp = greenProp;
				}
			}

			if (ladProp <= 0.0) {
				phenology.getT5b_fallingEndingDate().setValue(today);
				ladProp = 0.0; // ladProp is in [0,1].
			}

		}

		// Saves the ladProp value.
		phenology.getDoyLadPropMap().put(today.getDoy(), ladProp);

		if ( (Calendar.isLeap(year) && today.getDoy() == 366) || (!Calendar.isLeap(year) && today.getDoy() == 365) ) {

			if (phenology.getDoyLadPropMap().get(today.getDoy()) < 0.4) { // ladProp < 0.1
                phenology.getT5b_fallingEndingDate().setValue(today);
                phenology.getDoyLadPropMap().put(today.getDoy(), 0.0); // ladProp is in [0,1].
            } else { // ladProp >= 0.1
            	throw new Exception("HetPhenologyModel.calculate_t5b_fallingEndingDate() year: " + year
    					+ ". Error in " + modelName + " model: t5b_fallingEndingDate should have been reached before the end of year."
    					+ "ladProp: " + ladProp);
            }

		}
	}

	/**
	 * Calculates t1_forcingStateNext (for the following year) and sends an exception if budburst date of the average tree
	 * for the following year is reached before the end of year.
	 */
	protected void calculate_t2b_averageTreeBudburstDateNext(HetPhenology phenology, int year, int month, int day,
			double dailyAirTemperature, double t1_forcingThreshold, String modelName) throws Exception {

		if (!phenology.getT1_forcingStartingDateNext().isSet())
			return; // not yet

		HetPhenologyDate today = HetPhenologyDate.getPhenologyDate(year, month, day);

		// Useful: for thermalTime and uniForc models, t1_forcingStartingDateNext is set at initialization instead of being calculated.
		boolean t1_forcingStartingDateNextWasReached = today.isGreaterOrEqualThan(phenology.getT1_forcingStartingDateNext());
		if (!t1_forcingStartingDateNextWasReached)
			return; // not yet

		double t1_forcingStateNext = phenology.getT1_forcingStateNext();
		t1_forcingStateNext += calculate_t1_forcingRate(dailyAirTemperature);
		phenology.setT1_forcingStateNext(t1_forcingStateNext);

		if (phenology.getT1_forcingStateNext() >= t1_forcingThreshold) {

			throw new Exception("HetPhenologyModel.calculate_t2b_averageTreeBudburstDateNext() year: " + year
					+ ". Error in " + modelName + " model: t2b_averageTreeBudburstDateNext (budburst date of the average tree for the next year)"
					+ " has been reached before the end of year.");
		}

	}

	/**
	 * Finishes to calculate the ladProp and greenProp coefficients.
	 *
	 * @param phenology The reference to the phenology
	 * @param datesOfYear The list of ordered dates of a year. Each date is a string with the year_month_day format.
	 */
	protected void completeGreenProportionAndLadProportionCalculations(HetPhenology phenology, Set<String> datesOfYear) {

		for (String date : datesOfYear) {

			// date is a year_month_day string
			String[] yearMonthDayTab = date.split(HetMeteorology.SEP);

			int year = Integer.valueOf(yearMonthDayTab[0]);
			int month = Integer.valueOf(yearMonthDayTab[1]);
			int day = Integer.valueOf(yearMonthDayTab[2]);

			int todayDOY = HetPhenologyDate.getPhenologyDate(year, month, day).getDoy();

			completeGreenProportionCalculation(phenology, todayDOY);
			completeLadProportionCalculation(phenology, todayDOY);
		}
	}

	/**
	 * Calculates and returns the day length of the given day of year.
	 *
	 * @param latitude
	 *            The latitude of the site expressed in radian
	 * @param dayOfYear
	 *            The day of the year
	 * @return The day length
	 */
	private double calculateDayLength(double latitudeInRadian, int dayOfYear) {

		// solar declination: Teh 2006, eq. 2.2 p.25
		double solarDeclination = (-23.45*Math.PI/180.0)*Math.cos(2.0*Math.PI*(dayOfYear+10)/365.0);

		// day length: Teh 2006, eq. 2.13 p.31
		double quotient = Math.sin(solarDeclination)*Math.sin(latitudeInRadian)/(Math.cos(solarDeclination)*Math.cos(latitudeInRadian));
		double dayLength = (24.0/Math.PI)*Math.acos(-quotient);

		return dayLength;
	}

	/**
	 * Calculates and returns t1_forcingRate.
	 */
	protected abstract double calculate_t1_forcingRate(double dailyAverageTemperature);

	/**
	 * Calculates and returns t2a_budburstRate.
	 */
	private double calculate_t2a_budburstRate(double dailyAverageTemperature) {

		if (dailyAverageTemperature > 0)
			return dailyAverageTemperature;
		else
			return 0.0;
	}

	/**
	 * Calculates and returns t3_ageingRate.
	 */
	private double calculate_t3_ageingRate(double dailyAverageTemperature, double t3_criticalAgeingTemperature) {

		double t3_ageingRate;
		if (dailyAverageTemperature < t3_criticalAgeingTemperature)
			t3_ageingRate = t3_criticalAgeingTemperature - dailyAverageTemperature;
		else
			t3_ageingRate = 0.0;

		return t3_ageingRate;
	}

	/**
	 * Calculates and returns the proportion of green leaves for the given date.
	 *
	 * @param date
	 *            The (year, day of year) date
	 * @param greenProportionPrev
	 *            The proportion of green leaves compared to the level of maximum development of the previous day
	 * @param latitude
	 *            The latitude of the site expressed in radian
	 * @return
	 */
	private double calculateGreenProportion(HetPhenologyDate date, double greenProportionPrev, double latitude,
			double dayLengthMin, double dayLengthT4_yellowingStartingDay, double t4_leafYellowingParameter) {

		double dayLength = calculateDayLength(latitude, date.getDoy());

		double quotient = (dayLength-dayLengthMin)/(dayLengthT4_yellowingStartingDay-dayLengthMin);
		double greenProportion = greenProportionPrev*Math.pow(quotient, t4_leafYellowingParameter);

		return greenProportion;
	}

	/**
	 * Calculates the greenProp coefficients for:
	 * - days strictly smaller than t2a_standBudburstStartingDate,
	 * - and days strictly greater than t2c_completeLeafDevelopmentDate and strictly smaller than t4a_yellowingStartingDate,
	 * - and days strictly greater than t4b_yellowingEndingDate.
	 *
	 * The greenProp coefficients for days greater than or equal to t2a_standBudburstStartingDate and smaller than or equal to t2c_completeLeafDevelopmentDate are
	 * calculated in {@link heterofor.model.phenology.HetPhenologyModel#calculate_t2c_completeLeafDevelopmentDate(HetPhenology, int, int, int, double, double, String)}.
	 *
	 * The greenProp coefficients for days greater than or equal to t4a_yellowingStartingDate and smaller than or equal to t4b_yellowingEndingDate are
	 * calculated in {@link heterofor.model.phenology.HetPhenologyModel#calculate_t4b_yellowingEndingDate(HetPhenology, int, int, int, double, double, double, double, String)}.
	 */
	private void completeGreenProportionCalculation(HetPhenology phenology, int doy) {

		if (doy < phenology.getT2a_standBudburstStartingDate().getDoy()) {
			double greenProp = 0.0;
			phenology.getDoyGreenPropMap().put(doy, greenProp);
		}

		// If t2a_standBudburstStartingDateDOY <= doy <= t2c_completeLeafDevelopmentDateDOY: already done in calculate_t2c_completeLeafDevelopmentDate().

		if (doy > phenology.getT2c_completeLeafDevelopmentDate().getDoy() && doy < phenology.getT4a_yellowingStartingDate().getDoy()) {
			double greenProp = 1.0;
			phenology.getDoyGreenPropMap().put(doy, greenProp);
		}

		// If t4a_yellowingStartingDateDOY <= doy <= t4b_yellowingEndingDateDOY: already done in calculate_t4b_yellowingEndingDate().

		if (doy > phenology.getT4b_yellowingEndingDate().getDoy()) {
			double greenProp = 0.0;
			phenology.getDoyGreenPropMap().put(doy, greenProp);
		}
	}

	/**
	 * Calculates the ladProp coefficients for:
	 * - days strictly smaller than t2a_standBudburstStartingDate,
	 * - and days strictly greater than t2c_completeLeafDevelopmentDate and strictly smaller than t5a_fallingStartingDate,
	 * - and days strictly greater than t5b_fallingEndingDate.
	 *
	 * The ladProp coefficients for days greater than or equal to t2a_standBudburstStartingDate and smaller than or equal to t2c_completeLeafDevelopmentDate are
	 * calculated in {@link heterofor.model.phenology.HetPhenologyModel#calculate_t2c_completeLeafDevelopmentDate(HetPhenology, int, int, int, double, double, String)}.
	 *
	 * The ladProp coefficients for days greater than or equal to t5a_fallingStartingDate and smaller than or equal to t5b_fallingEndingDate are
	 * calculated in {@link heterofor.model.phenology.HetPhenologyModel#calculate_t5b_fallingEndingDate(HetPhenology, int, int, int, double, List, double, double, String)}.
	 */
	private void completeLadProportionCalculation(HetPhenology phenology, int doy) {

		if (doy < phenology.getT2a_standBudburstStartingDate().getDoy()) {
			double ladProp = 0.0;
			phenology.getDoyLadPropMap().put(doy, ladProp);
		}

		// If t2a_standBudburstStartingDateDOY <= doy <= t2c_completeLeafDevelopmentDateDOY: already done in calculate_t2c_completeLeafDevelopmentDate().

		if (doy > phenology.getT2c_completeLeafDevelopmentDate().getDoy() && doy < phenology.getT5a_fallingStartingDate().getDoy()) {
			double ladProp = 1.0;
			phenology.getDoyLadPropMap().put(doy, ladProp);
		}

		// If t5a_fallingStartingDateDOY <= doy <= t5b_fallingEndingDateDOY: already done in calculate_t5b_fallingEndingDate().

		if (doy > phenology.getT5b_fallingEndingDate().getDoy()) {
			double ladProp = 0.0;
			phenology.getDoyLadPropMap().put(doy, ladProp);
		}
	}

}
