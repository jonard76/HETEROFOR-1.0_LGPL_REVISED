/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.phenology;

import heterofor.model.HetReporter;
import heterofor.model.meteorology.HetMeteoLine;
import heterofor.model.meteorology.HetMeteorology;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.StringTokenizer;

/**
 * Class containing the parameters of the phenological uniChill model and methods to calculate phenological dates
 * using this model.
 *
 * @author N. Beudez - May 2017
 */
public class HetUniChillModel extends HetPhenologyModel {

	// Parameters of the model
	private int t0_chillingStartingDateDOY;
	private double t0_chillingA;
	private double t0_chillingB;
	private double t0_chillingC;
	private double t0_chillingThreshold;
	private double t1_forcingB;
	private double t1_forcingC;
	private double t1_forcingThreshold;
	private int t2a_budburstShift;
	private double t2a_budburstThreshold;
	private int t3_ageingStartingDateDOY;
	private double t3_criticalAgeingTemperature;
	private double t3_ageingThreshold;
	private double t4a_leafYellowingParameter;
	private double t4a_yellowingThreshold;
	private double t5a_fallingRate;
	private double t5a_frostFallingAmplifier;

	/**
	 * Constructor: parses a String containing the phenology parameters line (phenology model name + list of parameters), e.g.
	 * uniChill(305;0.37418;-6.47872;-7.90865;132.817;0.23495;13.17058;9.717;-2;200.0;213;20.0;230.0;0.4;0.01;0.022126;4.0)
	 * @param phenologyParametersLine The full phenology parameter line including the name of the phenology model and the list of phenology parameters
	 * @throws Exception
	 */
	public HetUniChillModel(String phenologyParametersLine) throws Exception {

		try {
			HetReporter.printInStandardOutput("HetUniChillModel instance\n");

			StringTokenizer st = parsePhenologyParameterLines(phenologyParametersLine, UNI_CHILL);

			t0_chillingStartingDateDOY = Integer.parseInt(st.nextToken().trim());
			t0_chillingA = Double.parseDouble(st.nextToken().trim());
			t0_chillingB = Double.parseDouble(st.nextToken().trim());
			t0_chillingC = Double.parseDouble(st.nextToken().trim());
			t0_chillingThreshold = Double.parseDouble(st.nextToken().trim());
			t1_forcingB = Double.parseDouble(st.nextToken().trim());
			t1_forcingC = Double.parseDouble(st.nextToken().trim());
			t1_forcingThreshold = Double.parseDouble(st.nextToken().trim());
			t2a_budburstShift = Integer.parseInt(st.nextToken().trim());
			if (t2a_budburstShift > 0) {
				throw new Exception("HetUniChillModel.HetUniChillModel(String): t2a_budburstShift must be a negative or zero integer.");
			}
			t2a_budburstThreshold = Double.parseDouble(st.nextToken().trim());
			t3_ageingStartingDateDOY = Integer.parseInt(st.nextToken().trim());
			t3_criticalAgeingTemperature = Double.parseDouble(st.nextToken().trim());
			t3_ageingThreshold = Double.parseDouble(st.nextToken().trim());
			t4a_leafYellowingParameter = Double.parseDouble(st.nextToken().trim());
			t4a_yellowingThreshold = Double.parseDouble(st.nextToken().trim());
			t5a_fallingRate = Double.parseDouble(st.nextToken().trim());;
			t5a_frostFallingAmplifier = Double.parseDouble(st.nextToken().trim());;

			HetReporter.printInStandardOutput("t0_chillingStartingDateDOY: " + t0_chillingStartingDateDOY);
			HetReporter.printInStandardOutput("t0_chillingA: " + t0_chillingA);
			HetReporter.printInStandardOutput("t0_chillingB: " + t0_chillingB);
			HetReporter.printInStandardOutput("t0_chillingC: " + t0_chillingC);
			HetReporter.printInStandardOutput("t0_chillingThreshold: " + t0_chillingThreshold);
			HetReporter.printInStandardOutput("t1_forcingB: " + t1_forcingB);
			HetReporter.printInStandardOutput("t1_forcingC: " + t1_forcingC);
			HetReporter.printInStandardOutput("t1_forcingThreshold: " + t1_forcingThreshold);
			HetReporter.printInStandardOutput("t2a_budburstShift: " + t2a_budburstShift);
			HetReporter.printInStandardOutput("t2a_budburstThreshold: " + t2a_budburstThreshold);
			HetReporter.printInStandardOutput("t3_ageingStartingDateDOY: " + t3_ageingStartingDateDOY);
			HetReporter.printInStandardOutput("t3_criticalAgeingTemperature: " + t3_criticalAgeingTemperature);
			HetReporter.printInStandardOutput("t3_ageingThreshold: " + t3_ageingThreshold);
			HetReporter.printInStandardOutput("t4a_leafYellowingParameter: " + t4a_leafYellowingParameter);
			HetReporter.printInStandardOutput("t4a_yellowingThreshold: " + t4a_yellowingThreshold);
			HetReporter.printInStandardOutput("t5a_fallingRate: " + t5a_fallingRate);
			HetReporter.printInStandardOutput("t5a_frostFallingAmplifier: " + t5a_frostFallingAmplifier);
			HetReporter.printInStandardOutput("");

		} catch (Exception e) {
			throw new Exception("HetUniChillModel.HetUniChillModel(String): could not parse this string: " + phenologyParametersLine, e);
		}

	}

	@Override
	public void completeInitialisation(HetPhenology phenology, int year, int t2b_averageTreeBudburstDateDOY) {

		HetReporter.printInStandardOutput("dans HetUniChillModel.completeInitialisation(HetPhenology phenology, int year, int t2b_averageTreeBudburstDateDOY)");

		int previousYear = year-1;

		// t0_chillingStartingDate
		phenology.getT0_chillingStartingDate().setValue(previousYear, t0_chillingStartingDateDOY);

		// t1_forcingStartingDate is not set: t2b_averageTreeBudburstDate is set below.

		// t2a_standBudburstStartingDate is not set: it will be calculated in run().

		// t2b_averageTreeBudburstDate is the one calculated by Samsaralight because there are no meteo data for the previous year.
		phenology.getT2b_averageTreeBudburstDate().setValue(year, t2b_averageTreeBudburstDateDOY);

		// t2c_completeLeafDevelopmentDate is not set: it will be calculated in run().

		// t3_ageingStartingDate
		phenology.getT3_ageingStartingDate().setValue(year, t3_ageingStartingDateDOY);

		// t4a_yellowingStartingDate is not set: it will be calculated in run().

		// t4b_yellowingEndingDate is not set: it will be calculated in run().

		// t5a_fallingStartingDate is not set: it will be calculated in run().

		// t5b_fallingEndingDate is not set: it will be calculated in run().

		// t0_chillingStartingDateNext
		phenology.getT0_chillingStartingDateNext().setValue(year, t0_chillingStartingDateDOY);

		// t1_forcingStartingDateNext is not set: it will be calculated in run().
	}

	@Override
	public void completeInitialisation(HetPhenology newPhenology, HetPhenology sourcePhenology, int year) {

		HetReporter.printInStandardOutput("dans HetUniChillModel.completeInitialisation(HetPhenology newPhenology, HetPhenology sourcePhenology, int year)");

		// t0_chillingStartingDate
		newPhenology.getT0_chillingStartingDate().setValue(sourcePhenology.getT0_chillingStartingDateNext());

		// t0_chillingState
		newPhenology.setT0_chillingState(sourcePhenology.getT0_chillingStateNext());

		// t1_forcingStartingDate
		newPhenology.getT1_forcingStartingDate().setValue(sourcePhenology.getT1_forcingStartingDateNext());

		// t1_forcingState
		newPhenology.setT1_forcingState(sourcePhenology.getT1_forcingStateNext());

		// t2a_standBudburstStartingDate is not set: it will be calculated in run().

		// t2b_averageTreeBudburstDate is not set: it will be calculated in run().

		// t2a_budburstState is already set to 0.0 in HetPhenology.init().

		// t2c_completeLeafDevelopmentDate is not set: it will be calculated in run().

		// t3_ageingStartingDate
		newPhenology.getT3_ageingStartingDate().setValue(year, t3_ageingStartingDateDOY);

		// t3_ageingState is already set to 0.0 in HetPhenology.init().

		// t4a_yellowingStartingDate is not set: it will be calculated in run().

		// t4b_yellowingEndingDate is not set: it will be calculated in run().

		// t5a_fallingStartingDate is not set: it will be calculated in run().

		// t5b_fallingEndingDate is not set: it will be calculated in run().

		// t0_chillingStartingDateNext
		newPhenology.getT0_chillingStartingDateNext().setValue(year, t0_chillingStartingDateDOY);

		// t0_chillingStateNext is already set to 0.0 in HetPhenology.init().

		// t1_forcingStartingDateNext is not set: it will be calculated in run().

		// t1_forcingStateNext is already set to 0.0 in HetPhenology.init().
	}

	/**
	 * Calculates the phenology states and dates for the given year.
	 */
	@Override
	public void run(HetPhenology phenology, int year, LinkedHashMap<String, Double> dateDailyAverageAirTemperatureMap,
			LinkedHashMap<String, Double> dateDailyAverageWindSpeedMap, List<HetMeteoLine> meteoLinesOfYear,
			double latitudeInRadians) throws Exception {

		HetReporter.printInStandardOutput("dans HetUniChillModel.run()");

		double dayLengthMin = calculateMinimalDayLength(latitudeInRadians);

		for (String date : dateDailyAverageAirTemperatureMap.keySet()) {

			// date is a year_month_day string
			String [] yearMonthDayTab = date.split( HetMeteorology.SEP );

			// year is already known
			int month = Integer.valueOf(yearMonthDayTab[1]);
			int day = Integer.valueOf(yearMonthDayTab[2]);

			double dailyAirTemperature = dateDailyAverageAirTemperatureMap.get(date);
			double dailyAverageWindSpeed = dateDailyAverageWindSpeedMap.get(date);

			calculate_t0_chillingStartingDate(phenology, year, month, day, dailyAirTemperature);
			calculate_t1_forcingStartingDate(phenology, year, month, day, dailyAirTemperature);
			// t2a_standBudburstStartingDate is calculated when t2b_averageTreeBudburstDate is reached so that
			// calculate_t2a_standBudburstStartingDate() is called after calculate_t2b_averageTreeBudburstDate().
			calculate_t2b_averageTreeBudburstDate(phenology, year, month, day, dailyAirTemperature, t1_forcingThreshold, UNI_CHILL);
			calculate_t2a_standBudburstStartingDate(phenology, year, month, day, t2a_budburstShift, UNI_CHILL);
			calculate_t2c_completeLeafDevelopmentDate(phenology, year, month, day, dailyAirTemperature, t2a_budburstThreshold, UNI_CHILL);
			calculate_t3_ageingStartingDate(phenology, year, month, day, dailyAirTemperature, this.getClass().getSimpleName(), UNI_CHILL);
			calculate_t4a_yellowingStartingDate(phenology, year, month, day, dailyAirTemperature, t3_criticalAgeingTemperature, t3_ageingThreshold, UNI_CHILL);
			calculate_t4b_yellowingEndingDate(phenology, year, month, day, latitudeInRadians, dayLengthMin, t4a_leafYellowingParameter, t4a_yellowingThreshold, UNI_CHILL);
			calculate_t5a_fallingStartingDate(phenology, year, month, day, UNI_CHILL);
			calculate_t5b_fallingEndingDate(phenology, year, month, day, dailyAverageWindSpeed, meteoLinesOfYear, t5a_frostFallingAmplifier, t5a_fallingRate, UNI_CHILL);

			calculate_t0_chillingStartingDateNext(phenology, year, month, day, dailyAirTemperature);
			calculate_t1_forcingStartingDateNext(phenology, year, month, day, dailyAirTemperature);
			calculate_t2b_averageTreeBudburstDateNext(phenology, year, month, day, dailyAirTemperature, t1_forcingThreshold, UNI_CHILL);
		}

		completeGreenProportionAndLadProportionCalculations(phenology, dateDailyAverageWindSpeedMap.keySet());

	}

	/**
	 * Calculates the t0_chillingStartingDate.
	 */
	private void calculate_t0_chillingStartingDate(HetPhenology phenology, int year, int month, int day, double dailyAirTemperature) throws Exception {

		if (!phenology.getT0_chillingStartingDate().isSet()) {

			throw new Exception("HetUniChillModel.calculate_t0_chillingStartingDate() year: " + year
					+ ". Error: t0_chillingStartingDate should have been set in "
					+ "HetUniChillModel.completeInitialisation(int year, HetPhenology phenology, int t2b_averageTreeBudburstDateDOY) or "
					+ "HetUniChillModel.completeInitialisation(int year, HetPhenology phenology), "
					+ "t0_chillingStartingDate: " + phenology.getT0_chillingStartingDate());
		}
	}

	/**
	 * Calculates the t1_forcingStartingDate.
	 */
	private void calculate_t1_forcingStartingDate(HetPhenology phenology, int year, int month, int day, double dailyAirTemperature) {

		if (phenology.getT1_forcingStartingDate().isSet())
			return; // done

		if (phenology.getT2b_averageTreeBudburstDate().isSet())
			return; // usefull for the case of the initial phenology, t1_forcingStartingDate is not needed

		HetPhenologyDate today = HetPhenologyDate.getPhenologyDate(year, month, day);

		// Useful: t0_chillingStartingDate is set at initialization instead of being calculated.
		boolean t0_chillingStartingDateWasReached = today.isGreaterOrEqualThan(phenology.getT0_chillingStartingDate());
		if (!t0_chillingStartingDateWasReached)
			return; // not yet

		// Calculates new t0_chillingState value.
		double t0_chillingState = phenology.getT0_chillingState();
		t0_chillingState += calculate_t0_chillingRate(dailyAirTemperature);
		phenology.setT0_chillingState(t0_chillingState);

		if (phenology.getT0_chillingState() >= t0_chillingThreshold) {
			phenology.getT1_forcingStartingDate().setValue(today);
		}
	}

	/**
	 * Calculates the t0_chillingStartingDateNext (for the following year).
	 */
	private void calculate_t0_chillingStartingDateNext(HetPhenology phenology, int year, int month, int day, double dailyAirTemperature) throws Exception {

		if (!phenology.getT0_chillingStartingDateNext().isSet()) {

			throw new Exception("HetUniChillModel.calculate_t0_chillingStartingDateNext() year: " + year
					+ ". Error: t0_chillingStartingDateNext should have been set in "
					+ "HetUniChillModel.completeInitialisation(int year, HetPhenology phenology, int t2b_averageTreeBudburstDateDOY) or "
					+ "HetUniChillModel.completeInitialisation(int year, HetPhenology phenology), "
					+ "t0_chillingStartingDateNext: " + phenology.getT0_chillingStartingDateNext());
		}
	}

	/**
	 * Calculates the t1_forcingStartingDateNext (for the following year).
	 */
	private void calculate_t1_forcingStartingDateNext(HetPhenology phenology, int year, int month, int day, double dailyAirTemperature) {

		if (phenology.getT1_forcingStartingDateNext().isSet())
			return; // done

		HetPhenologyDate today = HetPhenologyDate.getPhenologyDate(year, month, day);

		// Useful: t0_chillingStartingDateNext is set at initialization instead of being calculated.
		boolean t0_chillingStartingDateNextWasReached = today.isGreaterOrEqualThan(phenology.getT0_chillingStartingDateNext());
		if (!t0_chillingStartingDateNextWasReached)
			return; // not yet

		// Calculates new t0_chillingStateNext value.
		double t0_chillingStateNext = phenology.getT0_chillingStateNext();
		t0_chillingStateNext += calculate_t0_chillingRate(dailyAirTemperature);
		phenology.setT0_chillingStateNext(t0_chillingStateNext);

		if (phenology.getT0_chillingStateNext() >= t0_chillingThreshold) {
			phenology.getT1_forcingStartingDateNext().setValue(today);
		}
	}

	/**
	 * Calculates and returns t0_chillingRate.
	 */
	private double calculate_t0_chillingRate(double dailyAverageTemperature) {

		if (dailyAverageTemperature >= -5.0 && dailyAverageTemperature <= 10.0) {
			double coeff = t0_chillingA*Math.pow(dailyAverageTemperature-t0_chillingC, 2.0)+t0_chillingB*(dailyAverageTemperature-t0_chillingC);
			return 1.0/(1.0+Math.exp(coeff));
		} else {
			return 0.0;
		}
	}

	@Override
	protected double calculate_t1_forcingRate(double dailyAverageTemperature) {

		if (dailyAverageTemperature > 0.0) {
			double coeff = t1_forcingB*(dailyAverageTemperature-t1_forcingC);
			return 1.0/(1.0+Math.exp(coeff));
		} else {
			return 0.0;
		}
	}

}
