/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */
package heterofor.model.fineresolutionradiativebalance;

import java.io.Serializable;

/**
 * A key day in Heterofor fine resolution radiative balance mode, e.g. 2
 * specific days in the leaf development period, characterized by a leaf
 * development coefficient (ladProportion).
 *
 * @author F. André, F. de Coligny - April 2017
 */
public class HetKeyDoy implements Serializable {

	public int doy; // day of year [1, 366]
	public String name; // for tag creation...

	// fc+fa-18.5.2017 REMOVED ladProportion, replaced by a doy in SLBeam and a
	// SLLadProportionManager for SLModel.processLighting ()
	// fa-19.06.2017: SLLadProportionManager refactored to SLFoliageStateManager,
	// managing both ladProportion and greenProportion

	// key: speciesCode, value: ladProportion [0, 1] for this species
	// private Map<Integer, Double> ladProportionMap;

	/**
	 * Constructor.
	 */
	public HetKeyDoy(int doy, String name) {
		this.doy = doy;
		this.name = name;
		// this.ladProportionMap = new HashMap<> ();
	}

	// /**
	// * Adds a ladProportion for the given species at this doy.
	// */
	// public void addLadProportion (int speciesCode, double ladProportion) {
	// ladProportionMap.put(speciesCode, ladProportion);
	// }
	//
	// public Map<Integer, Double> getLadProportionMap() {
	// return ladProportionMap;
	// }

}
