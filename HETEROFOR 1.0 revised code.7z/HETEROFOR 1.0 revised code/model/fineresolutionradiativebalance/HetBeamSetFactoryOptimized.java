/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.fineresolutionradiativebalance;

import heterofor.model.HetReporter;
import heterofor.model.meteorology.HetMeteorology;
import heterofor.model.vegetationperiod.HetPhase;
import heterofor.model.vegetationperiod.HetVegetationPeriod;

import java.io.Serializable;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import jeeb.lib.util.AmapTools;
import jeeb.lib.util.ListMap;
import jeeb.lib.util.Log;
import capsis.lib.samsaralight.SLBeam;
import capsis.lib.samsaralight.SLBeamSet;
import capsis.lib.samsaralight.SLBeamSetFactory;
import capsis.lib.samsaralight.SLSettings;
import capsis.lib.samsaralight.tag.SLTag;
import capsis.lib.samsaralight.tag.SLTagOptimized;

/**
 * A factory to build beamSets in Heterofor in fineResolutionRadiativeBalance
 * mode. BeamSets are rebuilt before each processLighting () in HetModel,
 * relying on the heterofor meteorology file.
 *
 * @author F. André, F. de Coligny - August 2017
 */
public class HetBeamSetFactoryOptimized  implements Serializable {

	private static GregorianCalendar calendar;

	private int startYear;
	private int endYear;
	private int completeDevelopmentPhaseStartDoy;
	private int completeDevelopmentPhaseEndDoy;
	private HetMeteorology meteo;
	private SLSettings slSettings;

	private HetAverageRadiation averageRadiation;

	private SLBeamSet beamSet;

	/**
	 * Constructor
	 */
	public HetBeamSetFactoryOptimized(int startYear, int endYear, HetVegetationPeriod vegetationPeriod,
			HetMeteorology meteo, SLSettings slSettings) throws Exception {
		this.startYear = startYear;
		this.endYear = endYear;

		this.completeDevelopmentPhaseStartDoy = vegetationPeriod.completeDevelopmentPhase.startDoy;
		this.completeDevelopmentPhaseEndDoy = vegetationPeriod.completeDevelopmentPhase.endDoy;
		// this.keyDoys = vegetationPeriod.keyDoys;

		this.meteo = meteo;
		this.slSettings = slSettings;

		beamSet = new SLBeamSet();

		averageRadiation = new HetAverageRadiation(startYear, endYear, meteo);

		for (HetPhase phase : vegetationPeriod.getPhases()) {

			if (phase.isCompleteDevelopmentPhase()) {

				// Add beams for the complete development phase
				addBeamsForPeriod(beamSet, completeDevelopmentPhaseStartDoy, completeDevelopmentPhaseEndDoy);

			} else {

				for (HetKeyDoy keyDoy : phase.getKeyDoys()) {
					addBeamsForKeyDoy(beamSet, keyDoy);
				}

			}
		}

	}

	public HetAverageRadiation getAverageRadiation() {
		return averageRadiation;
	}

	/**
	 * Returns the month of the given doy, in [0,11], January is 0.
	 */
	public static int getMonth(int year, int doy) {
		if (calendar == null)
			calendar = new GregorianCalendar();

		calendar.set(GregorianCalendar.YEAR, year);
		calendar.set(GregorianCalendar.DAY_OF_YEAR, doy);

		return calendar.get(Calendar.MONTH); // month in [0,11]
	}

	// Ok
	public static void main(String[] args) {
		System.out.println("Month of 15: " + getMonth(2000, 15));
		System.out.println("Month of 35: " + getMonth(2000, 35));
		System.out.println("Month of 59: " + getMonth(2000, 59));
		System.out.println("Month of 60: " + getMonth(2000, 60));
		System.out.println("Month of 61: " + getMonth(2000, 61));
	}

	// ------------------------- beams for a given key doy

	/**
	 * Creates diffuse and direct beams for the given key doy.
	 */
	public void addBeamsForKeyDoy(SLBeamSet beamSet, HetKeyDoy keyDoy) {

		HetReporter.printInStandardOutput("addBeamsForKeyDoy(SLBeamSet beamSet, HetKeyDoy keyDoy)...");

		double latitude_rad = Math.toRadians(slSettings.getPlotLatitude_deg());
		double longitude_rad = Math.toRadians(slSettings.getPlotLongitude_deg());
		double heightAngleMin_rad = Math.toRadians(slSettings.getHeightAngleMin());
		double slope_rad = Math.toRadians(slSettings.getPlotSlope_deg());
		double northToXAngle_cw_rad = Math.toRadians(slSettings.getNorthToXAngle_cw_deg());
		double southAzimut_ccw_rad = Math.PI + northToXAngle_cw_rad; // azimut
																		// of
																		// south
																		// counterclockwise
																		// from
																		// x
																		// axis
		double bottomAzimut_rad = Math
				.toRadians(-slSettings.getPlotAspect_deg() + slSettings.getNorthToXAngle_cw_deg()); // azimut
																									// of
																									// the
																									// vector
		// orthogonal to

		double diffuseAngleStep_rad = Math.toRadians(slSettings.getDiffuseAngleStep());

		int GMT = slSettings.getGMT();

		if (southAzimut_ccw_rad > 2 * Math.PI)
			southAzimut_ccw_rad -= 2 * Math.PI; // GL 27/06/2012

		boolean SOC = slSettings.isSoc();

		double[] declination_rad = new double[12];
		for (int i = 0; i < SLBeamSetFactory.DECLINATION_DEG.length; i++)
			declination_rad[i] = Math.toRadians(SLBeamSetFactory.DECLINATION_DEG[i]);

		// For each direction of diffuse ray, we will have 24 rays with their
		// hour tag
		// So we need 24 sums of energies over the period
		double[] diffuseEnergies = new double[24];

		// For each month, we will have 24 rays with their hour tag
		// Note: hour fractions not yet implemented
		double[] directEnergies = new double[24];

		// Get the 24 radiation lines for the key doy
		List<HetAverageRadiationLine> doyLines = averageRadiation.getLines(keyDoy.doy);

		HetReporter.printInStandardOutput("doyLines: " + AmapTools.toString(doyLines));

		for (HetAverageRadiationLine r : doyLines) {

			int doy = r.doy;
			int hour = r.hour;

			// Sum diffuse energy
			diffuseEnergies[hour] = r.globalRadiation_MJm2 * r.diffuseToGlobalRatio;

			// Sum hourly direct energy
			directEnergies[hour] = r.globalRadiation_MJm2 * (1 - r.diffuseToGlobalRatio);

		}

		HetReporter.printInStandardOutput("diffuseEnergies: " + AmapTools.toString(diffuseEnergies));
		HetReporter.printInStandardOutput("directEnergies: " + AmapTools.toString(directEnergies));

		// Common for keyDoy and leavedPeriod

		double diffuseIncidentEnergy = 1; // fc+fa-3.8.2017

		HetBeamSetFactoryOptimized.classicDiffuseRaysCreation(keyDoy, keyDoy.name, SOC, diffuseIncidentEnergy,
				diffuseEnergies, diffuseAngleStep_rad, heightAngleMin_rad, slope_rad, bottomAzimut_rad, beamSet);

		// Specific for keyDoy
		HetBeamSetFactoryOptimized.keyDoyDirectHourRaysCreation(keyDoy, keyDoy.name, startYear, latitude_rad,
				longitude_rad, declination_rad, directEnergies, heightAngleMin_rad, slope_rad, southAzimut_ccw_rad,
				bottomAzimut_rad, GMT, beamSet);

	}

	// -------------------------- beams for leaved period

	/**
	 * Creates diffuse and direct beams for the leaved period.
	 */
	public void addBeamsForPeriod(SLBeamSet beamSet, int leavedPeriodStartDoy, int leavedPeriodEndDoy) {

		double latitude_rad = Math.toRadians(slSettings.getPlotLatitude_deg());
		double longitude_rad = Math.toRadians(slSettings.getPlotLongitude_deg());
		double heightAngleMin_rad = Math.toRadians(slSettings.getHeightAngleMin());
		double slope_rad = Math.toRadians(slSettings.getPlotSlope_deg());
		double northToXAngle_cw_rad = Math.toRadians(slSettings.getNorthToXAngle_cw_deg());
		double southAzimut_ccw_rad = Math.PI + northToXAngle_cw_rad; // azimut
																		// of
																		// south
																		// counterclockwise
																		// from
																		// x
																		// axis
		double bottomAzimut_rad = Math
				.toRadians(-slSettings.getPlotAspect_deg() + slSettings.getNorthToXAngle_cw_deg()); // azimut
																									// of
																									// the
																									// vector
		// orthogonal to

		double diffuseAngleStep_rad = Math.toRadians(slSettings.getDiffuseAngleStep());

		int GMT = slSettings.getGMT();

		if (southAzimut_ccw_rad > 2 * Math.PI)
			southAzimut_ccw_rad -= 2 * Math.PI; // GL 27/06/2012

		boolean SOC = slSettings.isSoc();

		double[] declination_rad = new double[12];
		for (int i = 0; i < SLBeamSetFactory.DECLINATION_DEG.length; i++)
			declination_rad[i] = Math.toRadians(SLBeamSetFactory.DECLINATION_DEG[i]);

		// For each direction of diffuse ray, we will have 24 rays with their
		// hour tag
		// So we need 24 sums of energies over the period
		double[] diffuseEnergies = new double[24];

		// For each month, we will have 24 rays with their hour tag
		// Note: hour fractions not yet implemented
		double[][] directEnergies = new double[12][24];
		// first index is
		// the month, second
		// index is the hour

		// Dispatch radiation lines per month in a listMap
		ListMap<Integer, HetAverageRadiationLine> radiationsPerMonth = averageRadiation.getRadiationsPerMonth();

		int doyMonthFirstDay = 0;

		for (int m = 0; m < 12; m++) { // the key used in the listMap
										// corresponds exactly to the month
										// index

			// m+1 because in the ListMap they are encoded with the true month
			// number
			List<HetAverageRadiationLine> oneMonth = (List) radiationsPerMonth.getObjects(m + 1);

			for (HetAverageRadiationLine r : oneMonth) {

				int doy = r.doy;
				int hour = r.hour;
				// int doy = doyMonthFirstDay + r.day;

				if (doy >= leavedPeriodStartDoy && doy <= leavedPeriodEndDoy) {

					// Sum diffuse energy
					diffuseEnergies[hour] += r.globalRadiation_MJm2 * r.diffuseToGlobalRatio;

					// Sum hourly direct energy
					directEnergies[m][hour] += r.globalRadiation_MJm2 * (1 - r.diffuseToGlobalRatio);

				}
			}
			doyMonthFirstDay += SLBeamSetFactory.NBMONTHDAYS[m];

		}

		int[] meanDoy = SLBeamSetFactory.meanDoyPerMonth(leavedPeriodStartDoy, leavedPeriodEndDoy);

		// Common for keyDoy and leavedPeriod

		double diffuseIncidentEnergy = 1; // fc+fa-3.8.2017

		HetBeamSetFactoryOptimized.classicDiffuseRaysCreation(null, "LEAVED_PERIOD", SOC, diffuseIncidentEnergy,
				diffuseEnergies, diffuseAngleStep_rad, heightAngleMin_rad, slope_rad, bottomAzimut_rad, beamSet);

		// Specific for leavedPeriod
		HetBeamSetFactoryOptimized.periodDirectHourRaysCreation("LEAVED_PERIOD", latitude_rad, longitude_rad,
				declination_rad, directEnergies, heightAngleMin_rad, slope_rad, southAzimut_ccw_rad, bottomAzimut_rad,
				meanDoy, GMT, beamSet);

	}

	/**
	 * Direct rays are created along one solar path for one single day, ray
	 * energy is proportional to sin(heightAngle)
	 */
	public static void keyDoyDirectHourRaysCreation(HetKeyDoy keyDoy, String tagPrefix, int startYear,
			double latitude_rad, double longitude_rad, double[] declination_rad, double[] directEnergies,
			double angleMin_rad, double slope_rad, double southAzimut_rad, double bottomAzimut_rad, int GMT,
			SLBeamSet bs) {
		double heightAngle_rad;
		double azimut_rad;
		// double energy;
		double horizontalDirect = 0;
		double slopeDirect = 0;
		int count = 0;
		double lostEnergy = 0; // radiations recorded during the night

		int m = getMonth(startYear, keyDoy.doy); // [0, 11]

		lostEnergy = 0;
		for (int h = 0; h < 24; h++) { // for each hour

			double directEnergy = directEnergies[h];
			if (directEnergy > 0) {

				// compute hour angle with Teh (2006, p27-29) equations
				// or see http://pvcdrom.pveducation.org/SUNLIGHT/SOLART.HTM
				// nearest standard meridian from the site
				double stdLongitude = ((int) (longitude_rad / (Math.PI / 12))) * (Math.PI / 12); // eq.
																									// 2.5.

				// equation of timee q 2.6 Teh (2006, p27-29)
				// double B = 2 * Math.PI * (meanDoy[m] - 81) / 364;
				// //eq.2.6 Teh (2006, p27-29)
				// double eot = 9.87 * Math.sin(2 * B) - 7.53 * Math.cos(B)
				// - 1.5 * Math.sin(B);

				// equation of time, wikipedia
				double B = 2 * Math.PI * keyDoy.doy / 365.242; // wikipedia
				double eot = -7.657 * Math.sin(B) + 9.862 * Math.sin(2 * B + 3.599); // minutes,
																						// wikipedia

				// 0.5 if the time measure corresponds to the measurement
				// start
				double localClockTime = h + 0.5;
				double daylightSavingTime = 0; // TODO
				double LocalClockTimeOnGreenwichMeridian = localClockTime - GMT - daylightSavingTime;
				double longitudeCorrection = (longitude_rad - stdLongitude) / Math.PI * 12;
				// this will only work in Western Europe!
				double localSolarTime = LocalClockTimeOnGreenwichMeridian + eot / 60 - longitudeCorrection; // hour
				double hourAngle = Math.PI / 12 * (localSolarTime - 12); // hour

				heightAngle_rad = Math.asin(Math.sin(latitude_rad) * Math.sin(declination_rad[m])
						+ Math.cos(latitude_rad) * Math.cos(declination_rad[m]) * Math.cos(hourAngle));
				azimut_rad = SLBeamSetFactory.sunAzimut(latitude_rad, declination_rad[m], hourAngle, heightAngle_rad,
						southAzimut_rad);

				if (heightAngle_rad > angleMin_rad) {
					horizontalDirect += directEnergy;
				} else {
					lostEnergy += directEnergy;
				}

				// in MJ/m2 on a plane perpendicular to the ray
				// hourSinHeightAng is very close to Math.sin (heightAngle)
				// so all rays
				// have about the same amount of energy on the plane
				// perpendicular to the ray.
				double perpendicularEnergyRay = directEnergy / Math.sin(heightAngle_rad);

				// a ray is created only if it reaches the soil with an
				// angle > angleMin
				// the cosinus of the angle between the vector orthogonal to
				// slope and the ray must be heigher than sin(angleMin)
				// this cosinus is given by scalar
				double scalar = Math.cos(slope_rad) * Math.sin(heightAngle_rad) + Math.sin(slope_rad)
						* Math.cos(heightAngle_rad) * Math.cos(azimut_rad - bottomAzimut_rad);

				if ((heightAngle_rad > 0) && (scalar > Math.sin(angleMin_rad))) {

					SLBeam b = new SLBeam(azimut_rad, heightAngle_rad, perpendicularEnergyRay, true);

					if (keyDoy != null)
						b.setDoy(keyDoy.doy);
					// b.setLadProportion(keyDoy.getLadProportionMap()); //
					// REMOVED

					b.setTag(new SLTag(tagPrefix + "_" + h));
					bs.addBeam(b);

					count++;

					slopeDirect += scalar * perpendicularEnergyRay;

					HetReporter.printInLog("SamsaraLight", (m + 1) + ";" + h + ";" + localSolarTime + ";" + Math.toDegrees(hourAngle) + ";"
												+ heightAngle_rad + ";" + azimut_rad + ";" + perpendicularEnergyRay + ";"
												+ (scalar * perpendicularEnergyRay) + ";" + false);

				} else if ((heightAngle_rad > 0) && (scalar <= Math.sin(angleMin_rad))) {

					HetReporter.printInLog("SamsaraLight", (m + 1) + ";" + h + ";" + localSolarTime + ";" + Math.toDegrees(hourAngle) + ";"
												+ heightAngle_rad + ";" + azimut_rad + ";" + perpendicularEnergyRay + ";"
												+ (scalar * perpendicularEnergyRay) + ";" + true);
				}

				// horizontal/slope direct/diffuse vars are set only for the
				// leaved period
				// this method is dedicated to keyDoys -> commented 2 lines
				// below
				// bs.setHorizontalDirect(horizontalDirect);
				// bs.setSlopeDirect(slopeDirect);
				// fa-9.8.2017: moved below
			}
		}
		// fc+fa-4.8.2017 for leaved period AND keyDoys
		bs.setHorizontalDirect(bs.getHorizontalDirect() + horizontalDirect);
		bs.setSlopeDirect(bs.getSlopeDirect() + slopeDirect);

		// }

		HetReporter.printInStandardOutput("HetBeamSetFactoryOptimized, keyDoyDirectHourRaysCreation() tagPrefix: " + tagPrefix
				+ " created: " + count + " DIRECT beams, horizontalDirect: " + horizontalDirect + ", slopeDirect: "
				+ slopeDirect);

	} // end-of-directHourRaysCreationForOneDay ()

	/**
	 * Diffuse beams are created with a classical sky hemisphere divided by
	 * meridians and parallels Standard Overcast Sky and Uniform Overcast Sky
	 * are possible. diffuseEnergies contains 24 sums of diffuse energy values
	 * for the period.
	 */
	public static void classicDiffuseRaysCreation(HetKeyDoy keyDoy, String tagPrefix, boolean SOC,
			double diffuseIncidentEnergy, double[] diffuseEnergies, double diffuseAngleStep_rad, double angleMin_rad,
			double slope_rad, double bottomAzimut_rad, SLBeamSet bs) {

		// when this method is called for the leaved period, parameter keyDoy ==
		// null

		int count = 0;
		double horizontalDiffuse = 0; //fa-20.12.2017: converted from float to double to avoid rounding error side effects
		double slopeDiffuse = 0; //fa-20.12.2017: converted from float to double to avoid rounding error side effects
		double lostSlopeDiffuse = 0; // fa-31.05.2017,  fa-20.12.2017: converted from float to double to avoid rounding error side effects
		double heightAngle_rad = diffuseAngleStep_rad / 2;
		while (heightAngle_rad < Math.PI / 2) {
			double azimut = diffuseAngleStep_rad / 2; // If azimut starts from
			// 0, there can be round problems with transformation of angleStep
			// from degrees to radians and the last azimut can be very close to
			// 360 (one extra azimut)
			while (azimut < 2 * Math.PI) { // azimut is with anticlockwise

				// fc+fa-3.8.2017 1 beam per day / one for the complete leaf
				// development period only (optimized version)
				// for (int h = 0; h < 24; h++) {

				// (trigonometric) rotation from X axis
				double energy = SLBeamSetFactory.classicDiffuseEnergy(SOC, heightAngle_rad, diffuseAngleStep_rad,
						diffuseIncidentEnergy);

				if (energy <= 0)
					continue; // next

				// A beam is created only if it reaches the soil with an
				// angle >
				// angleMin the cosinus of the angle between the vector
				// orthogonal to slope and the beam must be higher than
				// sin(angleMin) this cosinus is given by scalar
				double scalar = Math.cos(slope_rad) * Math.sin(heightAngle_rad) + Math.sin(slope_rad)
						* Math.cos(heightAngle_rad) * Math.cos(azimut - bottomAzimut_rad);

				for (int h = 0; h < 24; h++) {
					// The HorizontalDiffuse reference is calculated for
					// heightAngles > angleMin
					if (heightAngle_rad > angleMin_rad)
						horizontalDiffuse += diffuseEnergies[h] * energy * Math.sin(heightAngle_rad);

					// SlopeDiffuse
					if (scalar > Math.sin(angleMin_rad))
						slopeDiffuse += diffuseEnergies[h] * scalar * energy;
					else
						lostSlopeDiffuse += diffuseEnergies[h] * scalar * energy;
				}

				// Beam creation
				if (scalar > Math.sin(angleMin_rad)) {
					SLBeam b = new SLBeam(azimut, heightAngle_rad, energy, false); // false:
																					// diffuse

					if (keyDoy != null)
						b.setDoy(keyDoy.doy);
					// b.setLadProportion(keyDoy.getLadProportionMap()); //
					// REMOVED



					// fc+fa-3.8.2017 Optimized mode results in a deferred
					// tagResult expansion process, will rely on these
					// diffuseEnergies per hour
					b.setTag(new SLTagOptimized(tagPrefix, diffuseEnergies));
					// b.setTag(new SLTag(tagPrefix));

					// b.setTag(new SLTag(tagPrefix + "_" + h));
					bs.addBeam(b);
					count++;
				}

				azimut += diffuseAngleStep_rad;
			}
			heightAngle_rad += diffuseAngleStep_rad;


//				// The HorizontalDiffuse reference is calculated for
//				// heightAngles > angleMin
//				if (heightAngle_rad > angleMin_rad) {
//					for (int h = 0; h < 24; h++) {
//						horizontalDiffuse += diffuseEnergies[h] * energy * Math.sin(heightAngle_rad);
//					}
//				}
//
//
//				if (scalar > Math.sin(angleMin_rad)) {
//					SLBeam b = new SLBeam(azimut, heightAngle_rad, energy, false); // false:
//																					// diffuse
//
//					if (keyDoy != null)
//						b.setDoy(keyDoy.doy);
//					// b.setLadProportion(keyDoy.getLadProportionMap()); //
//					// REMOVED
//
//
//
//					// fc+fa-3.8.2017 Optimized mode results in a deferred
//					// tagResult expansion process, will rely on these
//					// diffuseEnergies per hour
//					b.setTag(new SLTagOptimized(tagPrefix, diffuseEnergies));
//					// b.setTag(new SLTag(tagPrefix));
//
//					// b.setTag(new SLTag(tagPrefix + "_" + h));
//					bs.addBeam(b);
//
//					// fa-08.01.2018
//					for (int h = 0; h < 24; h++) {
//						slopeDiffuse += diffuseEnergies[h] * scalar * energy;
//					}
//					count++;
//				}
//
//				// fa-31.05.2017, 08.01.2018
//				else {
//					for (int h = 0; h < 24; h++) {
//						lostSlopeDiffuse += diffuseEnergies[h] * scalar * energy;
//					}
//				}
//
//				azimut += diffuseAngleStep_rad;
//			}
//			heightAngle_rad += diffuseAngleStep_rad;
		}

		// horizontal/slope direct/diffuse vars are set only for the leaved
		// period
		// this method is called for leaved period and for keyDoys
		// -> run 2 lines below only if leaved period
		// fc+fa-4.8.2017 see below
//		if (keyDoy == null) {
//			bs.setHorizontalDiffuse(horizontalDiffuse);
//			bs.setSlopeDiffuse(slopeDiffuse);
//
//			// fa-31.05.2017
//			System.out.println("lostSlopeDiffuse= " + lostSlopeDiffuse);
//		}

		// fc+fa-4.8.2017 for leaved period AND keyDoys
		bs.setHorizontalDiffuse(bs.getHorizontalDiffuse() + horizontalDiffuse);
		bs.setSlopeDiffuse(bs.getSlopeDiffuse() + slopeDiffuse);


		HetReporter.printInStandardOutput("HetBeamSetFactoryOptimized, classicDiffuseRaysCreation() tagPrefix: " + tagPrefix
				+ " created: " + count + " DIFFUSE beams, horizontalDiffuse: " + horizontalDiffuse + ", slopeDiffuse: "
				+ slopeDiffuse + ", lostSlopeDiffuse: " + lostSlopeDiffuse);
	} // end-of-classicDiffuseRaysCreation ()

	/**
	 * Direct rays are created along one solar path per month During a day, ray
	 * energy is proportional to sin(heightAngle)
	 */
	public static void periodDirectHourRaysCreation(String tagPrefix, double latitude_rad, double longitude_rad,
			double[] declination_rad, double[][] directEnergies, double angleMin_rad, double slope_rad,
			double southAzimut_rad, double bottomAzimut_rad, int[] meanDoy, int GMT, SLBeamSet bs) {
		double heightAngle_rad;
		double azimut_rad;
		// double energy;
		double horizontalDirect = 0;
		double slopeDirect = 0;
		double lostSlopeDirect = 0; // fa-31.05.2017
		int count = 0;
		double lostEnergy = 0; // radiations recorded during the night

		for (int m = 0; m < 12; m++) { // for each month

			lostEnergy = 0;
			for (int h = 0; h < 24; h++) { // for each hour

				double directEnergy = directEnergies[m][h];
				if (directEnergy > 0) {

					// compute hour angle with Teh (2006, p27-29) equations
					// or see http://pvcdrom.pveducation.org/SUNLIGHT/SOLART.HTM
					// nearest standard meridian from the site
					double stdLongitude = ((int) (longitude_rad / (Math.PI / 12))) * (Math.PI / 12); // eq.
																										// 2.5.

					// equation of timee q 2.6 Teh (2006, p27-29)
					// double B = 2 * Math.PI * (meanDoy[m] - 81) / 364;
					// //eq.2.6 Teh (2006, p27-29)
					// double eot = 9.87 * Math.sin(2 * B) - 7.53 * Math.cos(B)
					// - 1.5 * Math.sin(B);

					// equation of time, wikipedia
					double B = 2 * Math.PI * meanDoy[m] / 365.242; // wikipedia
					double eot = -7.657 * Math.sin(B) + 9.862 * Math.sin(2 * B + 3.599); // minutes,
																							// wikipedia

					// 0.5 if the time measure corresponds to the measurement
					// start
					double localClockTime = h + 0.5;
					double daylightSavingTime = 0; // TODO
					double LocalClockTimeOnGreenwichMeridian = localClockTime - GMT - daylightSavingTime;
					double longitudeCorrection = (longitude_rad - stdLongitude) / Math.PI * 12;
					// this will only work in Western Europe!
					double localSolarTime = LocalClockTimeOnGreenwichMeridian + eot / 60 - longitudeCorrection; // hour
					double hourAngle = Math.PI / 12 * (localSolarTime - 12); // hour

					heightAngle_rad = Math.asin(Math.sin(latitude_rad) * Math.sin(declination_rad[m])
							+ Math.cos(latitude_rad) * Math.cos(declination_rad[m]) * Math.cos(hourAngle));
					azimut_rad = SLBeamSetFactory.sunAzimut(latitude_rad, declination_rad[m], hourAngle,
							heightAngle_rad, southAzimut_rad);

					if (heightAngle_rad > angleMin_rad) {
						horizontalDirect += directEnergy;
					} else {
						lostEnergy += directEnergy;
					}

					// in MJ/m2 on a plane perpendicular to the ray
					// hourSinHeightAng is very close to Math.sin (heightAngle)
					// so all rays
					// have about the same amount of energy on the plane
					// perpendicular to the ray.
					double perpendicularEnergyRay = directEnergy / Math.sin(heightAngle_rad);

					// a ray is created only if it reaches the soil with an
					// angle > angleMin
					// the cosinus of the angle between the vector orthogonal to
					// slope and the ray must be heigher than sin(angleMin)
					// this cosinus is given by scalar
					double scalar = Math.cos(slope_rad) * Math.sin(heightAngle_rad) + Math.sin(slope_rad)
							* Math.cos(heightAngle_rad) * Math.cos(azimut_rad - bottomAzimut_rad);

					if ((heightAngle_rad > 0) && (scalar > Math.sin(angleMin_rad))) {

						SLBeam b = new SLBeam(azimut_rad, heightAngle_rad, perpendicularEnergyRay, true);

						// fc+fa-16.5.2017 period: no keyDoy, no ladProportion

						b.setTag(new SLTag(tagPrefix + "_" + h));
						bs.addBeam(b);

						count++;

						slopeDirect += scalar * perpendicularEnergyRay;

						HetReporter.printInLog("SamsaraLight", (m + 1) + ";" + h + ";" + localSolarTime + ";" + Math.toDegrees(hourAngle) + ";"
											+ heightAngle_rad + ";" + azimut_rad + ";" + perpendicularEnergyRay + ";"
											+ (scalar * perpendicularEnergyRay) + ";" + false);

					} else if ((heightAngle_rad > 0) && (scalar <= Math.sin(angleMin_rad))) {

						HetReporter.printInLog("SamsaraLight", (m + 1) + ";" + h + ";" + localSolarTime + ";" + Math.toDegrees(hourAngle) + ";"
											+ heightAngle_rad + ";" + azimut_rad + ";" + perpendicularEnergyRay + ";"
											+ (scalar * perpendicularEnergyRay) + ";" + true);

						// fa-31.05.2017
						lostSlopeDirect += scalar * perpendicularEnergyRay;
					}

					// horizontal/slope direct/diffuse vars are set only for the
					// leaved period
					// this method is called for leaved period only
					// -> run 2 lines below
//					bs.setHorizontalDirect(horizontalDirect);
//					bs.setSlopeDirect(slopeDirect);
					//fa-9.8.2017: moved below
				}
			}

		}
		// fc+fa-4.8.2017 for leaved period AND keyDoys
		bs.setHorizontalDirect(bs.getHorizontalDirect() + horizontalDirect);
		bs.setSlopeDirect(bs.getSlopeDirect() + slopeDirect);

		HetReporter.printInStandardOutput("HetBeamSetFactoryOptimized, periodDirectHourRaysCreation() tagPrefix: " + tagPrefix
				+ " created: " + count + " DIRECT beams, horizontalDirect: " + horizontalDirect + ", slopeDirect: "
				+ slopeDirect);

		// fa-31.05.2017
		HetReporter.printInStandardOutput("lostSlopeDirect= " + lostSlopeDirect);

	} // end-of-directHourRaysCreationForSeveralMonths ()

	public SLBeamSet getBeamSet() {
		return beamSet;
	}

}
