/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.model.waterbalance;

import java.io.Serializable;
import java.util.StringTokenizer;

/**
 * Tree transpiration for a given hour.
 * 
 * @author F. ANDRE - September 2019
 */
public class HetHourlyTreeTranspiration implements Serializable {

	public int treeId;
	public int year;
	public int month;
	public int day;
	public int hour;

	public double treeTranspiration; // l
	public double treePotentialTranspiration; // l

	/**
	 * Constructor
	 */
	public HetHourlyTreeTranspiration(int treeId, int year, int month, int day, int hour, double treeTranspiration, double potentialTreeTranspiration) {
		super();
		this.treeId = treeId;
		this.year = year;
		this.month = month;
		this.day = day;
		this.hour = hour;
		this.treeTranspiration = treeTranspiration;
		this.treePotentialTranspiration = potentialTreeTranspiration;
	}


	/**
	 * Returns a full copy of the HetWaterBalance object
	 */
	public HetHourlyTreeTranspiration getCopy() {

		HetHourlyTreeTranspiration copiedHourlyTreeTranspiration = null;

		copiedHourlyTreeTranspiration = new HetHourlyTreeTranspiration(this.treeId, this.year, this.month, this.day, this.hour,
				this.treeTranspiration, this.treePotentialTranspiration);

		return copiedHourlyTreeTranspiration;
	}

	// Tools to work with the key used in the maps containing HourlyTreeTranspiration
	// objects
	static public int[] decomposeKey(String treeId_year_month_day_hour) throws Exception {
		try {
			int[] res = new int[5];
			StringTokenizer st = new StringTokenizer(treeId_year_month_day_hour, "_");

			for (int i = 0; i < 5; i++) {
				String token = st.nextToken();
				res[i] = Integer.parseInt(token);
			}
			return res;
		} catch (Exception e) {
			throw new Exception("HetWaterBalance, could not decopomse this key, should be treeId_year_month_day_hour: "
					+ treeId_year_month_day_hour);
		}

	}

	// Tools to work with the key used in the maps containing HourlyTreeTranspiration
	// objects
	public String getKey() {
		return "" + treeId + "_" + year + "_" + month + "_" + day + "_" + hour;
	}

	/**
	 * Returns a string representation of the object.
	 */
	public String toString() {

		StringBuffer b = new StringBuffer(getKey());

		b.append(" treeTranspiration: " + treeTranspiration);
		b.append(" potentialTreeTranspiration: " + treePotentialTranspiration);

		return b.toString();
	}

}
