package heterofor.model.waterbalance.pedon;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import heterofor.model.HetScene;
import heterofor.model.HetTree;

/**
 * A list of soil horizons in a soil for use with a list of TreePedons, this one
 * is for the semaining surface of the stand.
 * 
 * @author F. de Coligny - November 2019
 */
public class RemainingPedon extends Pedon {

	/**
	 * Constructor
	 */
	public RemainingPedon() {
		super();
	}

	/**
	 * Copy constructor, see getCopy ()
	 */
	protected RemainingPedon(RemainingPedon original) {
		super(original);
	}

	public RemainingPedon getPedonCopy() {
		return new RemainingPedon(this);
	}

	/**
	 * Convention: pedon id is -1 for a StandPedon, 0 for a RemainingPedon and
	 * treeId for a TreePedon.
	 */
	public int getPedonId() {
		return 0;
	}

	/**
	 * Returns a list of trees matching this pedon: all the scene's trees for a
	 * StandPedon, the single tree with same id matching a TreePedon and an
	 * empty list for a RemainingPedon.
	 */
	public Collection<HetTree> getTrees(HetScene scene) {
		List<HetTree> list = new ArrayList<>();
		// We return an empty list (RemainingPedon matches no tree)
		return list;

	}

}
