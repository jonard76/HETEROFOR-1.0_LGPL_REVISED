package heterofor.model.waterbalance.pedon;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import heterofor.model.HetScene;
import heterofor.model.HetSpecies;
import heterofor.model.HetTree;
import heterofor.model.soil.HetHorizon;
import heterofor.model.soil.HetSoilInterface;
import heterofor.model.waterbalance.HetWaterBalance;
import jeeb.lib.util.ListMap;

/**
 * A list of soil horizons in a soil
 * 
 * @author F. de Coligny - November 2019
 */
abstract public class Pedon {

	protected double pedonArea; // m2

	private Map<Integer, HetHorizon> horizons;

	private int maxHorizonId;
	
	private LinkedHashMap<String, HetWaterBalance> waterBalanceMap; // fa-15.11.2015: moved from HetScene
	
	// fa-20.11.2019: MOVED from HetSoil
	/**
	 * Key: key is year_month_day_hour string, value: thermal diffusivity of
	 * soil profile (weighted average of horizon thermal diffusivities).
	 */
	public Map<String, Double> timeAverageThermalDiffusivityMap; 

	/**
	 * Constructor
	 */
	protected Pedon() {

		horizons = new LinkedHashMap<>(); // keep insertion order
		waterBalanceMap = new LinkedHashMap<>(); // Linked: keep insertion	// fa-15.11.2019: moved from HetScene
	
	}

	/**
	 * Copy constructor
	 */
	protected Pedon(Pedon original) {
		this();

		// fc+mj+fa-19.11.2019
		// At this time, we copy the pedonArea, it will be updated later
		this.pedonArea = original.pedonArea;
		
		// Copy horizons
		for (HetHorizon h : original.horizons.values()) {
			this.addHorizon(new HetHorizon(h));
		}

	}

	// /**
	// * Called at pedon construction time (and each year to reinit).
	// */
	// abstract public void updatePedon (HetScene scene);

	/**
	 * Convention: pedon id is -1 for a StandPedon, 0 for a RemainingPedon and
	 * treeId for a TreePedon.
	 */
	abstract public int getPedonId();

	public double getPedonArea() {
		return pedonArea;
	}

	public void setPedonArea(double pedonArea) {
		this.pedonArea = pedonArea;
	}

	public void addHorizon(HetHorizon h) {
		horizons.put(h.id, h);
		setMaxHorizonId(Math.max(h.id, getMaxHorizonId()));
	}

	public List<HetHorizon> getHorizons() {
		return new ArrayList<HetHorizon>(horizons.values());
	}

	public Map<Integer, HetHorizon> getHorizonMap() {
		return new HashMap<>(horizons);
	}

	public HetHorizon getHorizon(int id) {
		return horizons.get(id);
	}

	public boolean isLowestHorizon(int hId) {
		return hId == maxHorizonId;
	}

	public int getMaxHorizonId() {
		return maxHorizonId;
	}

	public void setMaxHorizonId(int id) {
		maxHorizonId = id;
	}

	abstract public Pedon getPedonCopy();
	
	// fa-20.11.2019: MOVED from HetSoil
	public Map<String, Double> getTimeAverageThermalDiffusivityMap() {
		
		if (timeAverageThermalDiffusivityMap == null)
			timeAverageThermalDiffusivityMap = new HashMap<>();
		
		return timeAverageThermalDiffusivityMap;
	}

	/**
	 * Returns a list of trees matching this pedon: all the scene's trees for a
	 * StandPedon, the single tree with same id matching a TreePedon and an
	 * empty list for a RemainingPedon.
	 */
	abstract public Collection<HetTree> getTrees(HetScene scene);

	
	// fc-15.11.2019 MOVED from HetSoil
	public Map<Integer, Double> getLastWaterContent() {
		Map<Integer, Double> lwc = new HashMap<>();

		for (int hId : this.getHorizonMap().keySet()) {
			HetHorizon h = this.getHorizonMap().get(hId);
			lwc.put(hId, h.lastWaterContent);
		}
		return lwc;
	}

	
	/**
	 * A utility method to get all the horizons in all the pedons of the given
	 * soil. The id of the ListMap is the pedonId, the matching list is the list
	 * of all horizons in this pedon. To get the union of all the horizons of
	 * the ListMap (i.e. for all pedons), use lm.allValues ().
	 */
	static public ListMap<Integer, HetHorizon> getAllHorizonsInSoil(HetSoilInterface soil) {

		ListMap<Integer, HetHorizon> lm = new ListMap<>();

		for (Pedon p : soil.getPedons()) {
			lm.addObjects(p.getPedonId(), p.getHorizons());
		}

		return lm;

	}
	
	
	/**
	 * Returns a WatarBalanceMAp which is an average of the wbmaps of the given pedons.
	 */
	static public LinkedHashMap<String, HetWaterBalance> averageWaterBalanceMaps (List<Pedon> pedons) {
		
		LinkedHashMap<String, HetWaterBalance> avgMap = new LinkedHashMap<> ();
		
		// fa-25.11.2019
		Pedon pedonSpecimen = pedons.get(0);
		if (pedonSpecimen.getPedonId() == 0 && pedonSpecimen.getPedonArea() == 0) // remaining pedon with area equal to zero => no waterBalanceMap as was not processed in HetWaterBalanceCalculator.run()
			pedonSpecimen = pedons.get(1);
		
		// Loop and calc the avg
//		for (String key : pedons.get(0).getWaterBalanceMap().keySet()) { // year-month-day-hour lines
		for (String key : pedonSpecimen.getWaterBalanceMap().keySet()) { // year-month-day-hour lines // fa-25.11.2019
			
//			int year = pedons.get(0).getWaterBalanceMap().get(key).year;
//			int month = pedons.get(0).getWaterBalanceMap().get(key).month;
//			int day = pedons.get(0).getWaterBalanceMap().get(key).day;
//			int hour = pedons.get(0).getWaterBalanceMap().get(key).hour;
			// fa-25.11.2019
			int year = pedonSpecimen.getWaterBalanceMap().get(key).year;
			int month = pedonSpecimen.getWaterBalanceMap().get(key).month;
			int day = pedonSpecimen.getWaterBalanceMap().get(key).day;
			int hour = pedonSpecimen.getWaterBalanceMap().get(key).hour;
			
			double sumArea = 0d;
			Map<Integer, Double> sumNewHorizonsWaterContent = new HashMap<>();
			Map<Integer, Double> avgNewHorizonsWaterContent = new HashMap<>();
			double sumRainfall = 0d; 
			double sumStemflow = 0d;
			double sumThroughfall = 0d;
			double sumInterception = 0d;
			double sumTranspiration = 0d;
			double sumStandLevel_transpiration = 0d;
			double sumTreeLevel_transpiration = 0d;
			double sumGroundVegetationTranspiration = 0d;
			double sumBarkEvaporation = 0d;
			double sumFoliageEvaporation = 0d;
			double sumVegetationEvaporation = 0d;
			double sumSoilEvaporation = 0d;
			double sumDeepDrainage = 0d;
			double sumRelativeExtractableWater = 0d;
			double sumForestFloorRelativeExtractableWater = 0d;
			double sumTreeLevel_potentialTranspiration = 0d;
			
			for (Pedon pedon : pedons) {
				
				if (pedon.getPedonId() == 0 && pedon.getPedonArea() == 0) // fa-25.11.2019: skip processing of remainingPedon with area equals to zero
					continue;

				sumArea += pedon.getPedonArea();
				
				for (int hId : pedon.getWaterBalanceMap().get(key).horizonWaterContent.keySet()) {
					addInMap(sumNewHorizonsWaterContent, hId, pedon.getWaterBalanceMap().get(key).horizonWaterContent.get(hId) * pedon.getPedonArea());
				}
				
				sumRainfall += pedon.getWaterBalanceMap().get(key).rainfall * pedon.getPedonArea();
				sumStemflow += pedon.getWaterBalanceMap().get(key).stemflow * pedon.getPedonArea();
				sumThroughfall += pedon.getWaterBalanceMap().get(key).throughfall * pedon.getPedonArea();
				sumInterception += pedon.getWaterBalanceMap().get(key).interception * pedon.getPedonArea();
				sumTranspiration += pedon.getWaterBalanceMap().get(key).transpiration * pedon.getPedonArea();
				sumStandLevel_transpiration += pedon.getWaterBalanceMap().get(key).standLevel_transpiration * pedon.getPedonArea();
				sumTreeLevel_transpiration += pedon.getWaterBalanceMap().get(key).treeLevel_transpiration * pedon.getPedonArea();
				sumGroundVegetationTranspiration += pedon.getWaterBalanceMap().get(key).groundVegetationTranspiration * pedon.getPedonArea();
				sumBarkEvaporation += pedon.getWaterBalanceMap().get(key).barkEvaporation * pedon.getPedonArea();
				sumFoliageEvaporation += pedon.getWaterBalanceMap().get(key).foliageEvaporation * pedon.getPedonArea();
				sumVegetationEvaporation += pedon.getWaterBalanceMap().get(key).vegetationEvaporation * pedon.getPedonArea();
				sumSoilEvaporation += pedon.getWaterBalanceMap().get(key).soilEvaporation * pedon.getPedonArea();
				sumDeepDrainage += pedon.getWaterBalanceMap().get(key).deepDrainage * pedon.getPedonArea();
				sumRelativeExtractableWater += pedon.getWaterBalanceMap().get(key).relativeExtractableWater * pedon.getPedonArea(); // OK as maximumExtractableWaterContent are the same among pedons for a given horizon
				sumForestFloorRelativeExtractableWater += pedon.getWaterBalanceMap().get(key).forestFloorRelativeExtractableWater * pedon.getPedonArea(); // OK as maximumExtractableWaterContent are the same among pedons for a given horizon
				sumTreeLevel_potentialTranspiration += pedon.getWaterBalanceMap().get(key).treeLevel_potentialTranspiration * pedon.getPedonArea();
			}
			
			for (int hId : sumNewHorizonsWaterContent.keySet()) {
				avgNewHorizonsWaterContent.put(hId, sumNewHorizonsWaterContent.get(hId) / sumArea);
			}
			double avgRainfall = sumRainfall / sumArea; 
			double avgStemflow = sumStemflow / sumArea; 
			double avgThroughfall = sumThroughfall / sumArea; 
			double avgInterception = sumInterception / sumArea;
			double avgTranspiration = sumTranspiration / sumArea;
			double avgStandLevel_transpiration = sumStandLevel_transpiration / sumArea;
			double avgTreeLevel_transpiration = sumTreeLevel_transpiration / sumArea;
			double avgGroundVegetationTranspiration = sumGroundVegetationTranspiration / sumArea;
			double avgBarkEvaporation = sumBarkEvaporation / sumArea;
			double avgFoliageEvaporation = sumFoliageEvaporation / sumArea;
			double avgVegetationEvaporation = sumVegetationEvaporation / sumArea;
			double avgSoilEvaporation = sumSoilEvaporation / sumArea;
			double avgDeepDrainage = sumDeepDrainage / sumArea;
			double avgRelativeExtractableWater = sumRelativeExtractableWater / sumArea;
			double avgForestFloorRelativeExtractableWater = sumForestFloorRelativeExtractableWater / sumArea;
			double avgTreeLevel_potentialTranspiration = sumTreeLevel_potentialTranspiration / sumArea;
			
			HetWaterBalance avgWb = new HetWaterBalance(year, month, day, hour,
					avgNewHorizonsWaterContent, avgRainfall, avgStemflow, avgThroughfall, avgInterception, avgTranspiration,
					avgStandLevel_transpiration, avgTreeLevel_transpiration, avgGroundVegetationTranspiration, avgBarkEvaporation,
					avgFoliageEvaporation, avgVegetationEvaporation, avgSoilEvaporation, avgDeepDrainage, avgRelativeExtractableWater,
					avgForestFloorRelativeExtractableWater,	avgTreeLevel_potentialTranspiration);
			avgMap.put(key, avgWb);
		}
		
		return avgMap;
	}
		
	private static void addInMap(Map<Integer, Double> map, int hId, double value) {
		double sum = 0;
		Double v = map.get(hId);
		if (v != null)
			sum = v;
		sum += value;
		map.put(hId, sum);
	}
	
	
	public LinkedHashMap<String, HetWaterBalance> getWaterBalanceMap () {
		return waterBalanceMap;
	}
	
	public void setWaterBalanceMap (LinkedHashMap<String, HetWaterBalance> map) {
		this.waterBalanceMap = map;
	}
}
