package heterofor.model.waterbalance;

import java.util.HashMap;
import java.util.Map;

/**
 * A way to temporarily store transpiration values. Calculated in
 * waterBalanceCalculator before newTrees creation, need to be used during
 * treeGrowth and finally stored in newTrees.
 * 
 * @author F. de Coligny - November 2017
 */
public class HetYearlyTranspirationMemory {

	// Key is treeId
	private Map<Integer, Double> yearlyTranspiration;
	private Map<Integer, Double> yearlyPotentialTranspiration;

	/**
	 * Constructor
	 */
	public HetYearlyTranspirationMemory() {
		yearlyTranspiration = new HashMap<>();
		yearlyPotentialTranspiration = new HashMap<>();
	}

	public void storeYearlyTranspiration (int treeId, double v) {
		yearlyTranspiration.put (treeId, v);
	}

	public void storeYearlyPotentialTranspiration (int treeId, double v) {
		yearlyPotentialTranspiration.put (treeId, v);
	}
	
	public double getYearlyTranspiration(int treeId) {
		Double v = yearlyTranspiration.get(treeId);
		return v != null ? v : 0;
	}

	public double getYearlyPotentialTranspiration(int treeId) {
		Double v = yearlyPotentialTranspiration.get(treeId);
		return v != null ? v : 0;
	}

}
