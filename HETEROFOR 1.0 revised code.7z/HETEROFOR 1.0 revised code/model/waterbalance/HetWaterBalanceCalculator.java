/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.waterbalance;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import capsis.defaulttype.Tree;
import capsis.defaulttype.plotofcells.RoundMask;
import capsis.defaulttype.plotofcells.SquareCell;
import capsis.kernel.Step;
import capsis.lib.samsaralight.SLFoliageStateManager;
import capsis.lib.samsaralight.SLModel;
import capsis.lib.samsaralight.SLTargetLightResult;
import heterofor.model.HetCell;
import heterofor.model.HetInitialParameters;
import heterofor.model.HetMethodProvider;
import heterofor.model.HetModel;
import heterofor.model.HetPlot;
import heterofor.model.HetReporter;
import heterofor.model.HetScene;
import heterofor.model.HetSpecies;
import heterofor.model.HetTree;
import heterofor.model.meteorology.HetMeteoLine;
import heterofor.model.meteorology.HetMeteorology;
import heterofor.model.soil.HetHorizon;
import heterofor.model.soil.HetSoilInterface;
import heterofor.model.vegetationperiod.HetAbsorptionCoefficientEvaluator;
import heterofor.model.waterbalance.pedon.Pedon;
import jeeb.lib.util.AdditionMap;

/**
 * Calculates the water balance.
 *
 * @author M. Jonard, L. de Wergifosse, F. de Coligny - October 2016
 */
public class HetWaterBalanceCalculator {

	private HetInitialParameters ip;
	private HetScene refScene;
	private HetScene newScene;
	private HetModel model;
	private HetSoilHeatFluxCalculator soilHeatFluxCalculator;
	private SLModel slModel;

	// fc+mj+fa-14.11.2017
	// Store tree level values in order to use them during tree growth, finally
	// report them in newTree later in process
	private HetYearlyTranspirationMemory yearlyTranspirationMemory;

	/**
	 * Constructor
	 */
	public HetWaterBalanceCalculator(HetInitialParameters ip, HetScene refScene, HetScene newScene, HetModel model,
			HetSoilHeatFluxCalculator soilHeatFluxCalculator) {

		this.ip = ip;
		this.refScene = refScene;
		this.newScene = newScene;
		this.model = model;
		this.soilHeatFluxCalculator = soilHeatFluxCalculator;
		this.slModel = ip.samsaFileLoader.getSLModel();

		yearlyTranspirationMemory = new HetYearlyTranspirationMemory();

	}

	public void run() throws Exception {

		// fc-15.11.2019 MOVED, was in updateWaterBalance (), better here now
		// fc+mj+lw-18.10.2016
		// MJ/m2/year, for vegetation period only
		double slIncidentGlobalRadiation = slModel.calculateIncidentRadiation(true, SLModel.GLOBAL_RADIATION);
		newScene.setStandIncidentGlobalRadiation(slIncidentGlobalRadiation);// fc-et-al-20.1.2017

		double slIncidentDirectRadiation = slModel.calculateIncidentRadiation(true, SLModel.DIRECT_RADIATION);
		newScene.setStandIncidentDirectRadiation(slIncidentDirectRadiation);// fc+fa-31.7.2017

		double slIncidentDiffuseRadiation = slModel.calculateIncidentRadiation(true, SLModel.DIFFUSE_RADIATION);
		newScene.setStandIncidentDiffuseRadiation(slIncidentDiffuseRadiation);// fc+fa-31.7.2017
		
		// fa-15.11.2019: moved here from updateWaterBalance ()
		HetMethodProvider mp = (HetMethodProvider) model.getMethodProvider();
		double hDom = mp.getHdom(refScene, refScene.getTrees());
		
		// fa-15.11.2019: moved here from updateWaterBalance ()
		// Calculates the temperature at the interface between the organic layer
		// and the mineral layer
		int year = newScene.getDate();
		double organicLayerThickness = newScene.getSoil().getOrganicLayerThickness();
		int dayWindowWidth = 24; // Size of the time window for moving average
								 // accounting for intra-day temperature
								 // variations (24 hours)
		int yearWindowWidth = 15; // Size of the time window to account for
								  // intra-year temperature variations (15
								  // days preceding the current date)
		HetReporter.printInStandardOutput("HeatTransfertInput: Meteo = " + ip.meteorology + ", Year = " + year
				+ ", Window = " + dayWindowWidth + ", OrganicThickness = " + organicLayerThickness);
		// Calculate average air temperature for over a 15 day period preceding
		// each day of the current year
		LinkedHashMap<String, Double> dateAverageAirTemperatureOverPrecedingPeriodMap = HetMeteorology
				.calculateAverageAirTemperatureOverPrecedingPeriod(ip.meteorology, year, yearWindowWidth);
		newScene.getSoil().calculateSoilInterfaceTemperature(ip.meteorology, year, dayWindowWidth,
				organicLayerThickness, dateAverageAirTemperatureOverPrecedingPeriodMap);
		
//		newScene.hourlyTreeTranspirationMap = Collections.synchronizedMap(new LinkedHashMap<>()); // fa-02.12.2019: moved from below and synchronized (thread-safe)
		newScene.hourlyTreeTranspirationMap = new ConcurrentHashMap <String, HetHourlyTreeTranspiration>(); // fa-02.12.2019: moved from below and concurrent map (thread-safe)

		// fa-18.11.2019: parallel processing
		Collection rPedon = new ArrayList(refScene.getSoil().getPedons());
		rPedon.parallelStream().forEach((o) -> {
			Pedon refPedon = (Pedon) o;
			
//		for (Pedon refPedon : refScene.getSoil().getPedons()) { // sequential processing
			
			Pedon newPedon = newScene.getSoil().getPedonMap().get(refPedon.getPedonId()); //fa-15.11.2019

			try {
				
				// fa-25.11.2019: skip processing of remainingPedon with zero area
				if (refPedon.getPedonArea() == 0)
					if (refPedon.getPedonId() == 0) { // remainingPedon
						return; // skip iteration (parallel mode)
//						continue; // skip iteration (sequential mode)
					} else {
						throw new Exception("HetWaterBalanceCalculator.run () error: found pedon with area equals to zero, pedon Id is : " + refPedon.getPedonId() + ".\n\nAborted.");
					}	
				
				updateWaterBalance(ip, refScene, refPedon, newScene, newPedon, soilHeatFluxCalculator,
						slIncidentGlobalRadiation, hDom, organicLayerThickness);
				
				//fa-25.11.2019: aggregate to daily time step in order to save memory
				if (newScene.getSoil().isDiscreteSoil()) {
					LinkedHashMap<String, HetWaterBalance> dailyWaterBalanceMap = hourly2DailyWaterBalanceMap(newPedon);
					newPedon.setWaterBalanceMap(dailyWaterBalanceMap);
				}
				
			} catch (Exception e) {
				// fc+fa-21.11.2019 parallelStream accepts RuntimeExceptions
				throw new RuntimeException (e);
			}

//		} // end of sequential processing
		}); // fa-18.11.2019: end of parallel processing

		// for (Tree tree : refScene.getTrees()) {
		//
		// HetTree t = (HetTree) tree;
		//
		// double yt = t.getYearlyTranspiration();
		// double ypt = t.getYearlyPotentialTranspiration();
		//
		// System.out.println(refScene.getDate() + " treeId: " + t.getId() +
		// " --> yt: " + yt + " ypt: " + ypt);
		// System.exit(1);
		// }

		// System.out.println("TOTOT");
		// System.exit(1);
	}

	/**
	 * Calculates the stand water balance and updates the soil water content in
	 * the horizons. Returns a map: for each tree, its yearly transpiration
	 * value.
	 */
	private void updateWaterBalance(HetInitialParameters ip, HetScene refScene, Pedon refPedon, HetScene newScene,
			Pedon newPedon, HetSoilHeatFluxCalculator soilHeatFluxCalculator, double slIncidentGlobalRadiation, double hDom,
			double organicLayerThickness) throws Exception {

		// System.out.println("HetModel updateWaterBalance()...");

		Map<Integer, Double> prevHorizonsWaterContent = refPedon.getLastWaterContent();
		// Map<Integer, Double> prevHorizonsWaterContent =
		// refScene.getSoil().getLastWaterContent();

		// This process needs the optional soil horizons to be provided at
		// simulation start time
		if (!refScene.isSoilHorizonsAvailable()) {
			HetReporter.printInStandardOutput("HetModel updateWaterBalance() returned (1)");
			HetReporter.printInLog("HetModel updateWaterBalance() !refScene.isSoilHorizonsAvailable() ***");
			// return null;
		}

		// Also needs the meteorology file loaded
		if (ip.meteorology == null) {
			HetReporter.printInStandardOutput("HetModel updateWaterBalance() returned (2)");
			HetReporter.printInLog("HetModel updateWaterBalance() ip.meteorology == null ***");
			// return null;
		}

		// Prepare
		Map<HetSpecies, Double> leaflessBarkStorageCapacity_sp = new HashMap<>(); // l/sp
		Map<HetSpecies, Double> leavedBarkStorageCapacity_sp = new HashMap<>(); // l/sp
		Map<HetSpecies, Double> leaflessStemflowProportion_sp = new HashMap<>(); // l/l
																					// [0,1]
																					// MJ
																					// +
																					// FA
																					// +
																					// LW
																					// 05/10/2016
		Map<HetSpecies, Double> leavedStemflowProportion_sp = new HashMap<>(); // l/l
																				// [0,1]
																				// MJ
																				// +
																				// FA
																				// +
																				// LW
																				// 05/10/2016
		// Map<HetSpecies, Double> leafAreaMap_sp = new HashMap<>(); // m2
		// //mj+fa-04.12.2017: moved to HetSpecies
		Map<HetSpecies, Double> barkArea_sp = new HashMap<>(); // m2
		Set<HetSpecies> speciesList = new HashSet<>();
		double leaflessStemflowProportion_stand = 0;
		double leavedStemflowProportion_stand = 0;
		double leaflessThroughfallProportion_stand = 0;
		double leavedThroughfallProportion_stand = 0;

		double crownAbsorbedRadiation = 0;
		double leafAbsorbedRadiation = 0;
		double branchAbsorbedRadiation = 0;

		double trunkAbsorbedRadiation = 0;
		double trunkAbsorbedRadiation_direct = 0;
		double trunkAbsorbedRadiation_diffuse = 0;

		double barkAbsorbedRadiation_m2bark = 0;

		double leafArea_stand = 0;
		double sapwoodArea_stand = 0; // fc+mj-13.9.2017
		double crownProjectionSum_stand = 0; // mj+fa-20.09.2017

		// Equivalent area... to be completed
		double leafAbsorbedRadiationProportion = 0; // [0, 1]
		double barkAbsorbedRadiationProportion = 0; // [0, 1]

		double stemBarkArea_stand = 0;
		double branchBarkArea_stand = 0;

		// fa-29.09.2017
		double meanBasicCanopyStomatalConductance_stand = 0;

		// Sum leaf areas per species / stemflowProportion_sp / calc
		// barkStorageCapacity_sp
		
		double maxFoliageStorageCapacity_stand = 0; // fa-15.11.2019: moved from below

		// fc-15.11.2019 CANDIDATE new for ()...
		for (Iterator i = refPedon.getTrees(refScene).iterator(); i.hasNext();) {
			// for (Iterator i = refScene.getTrees().iterator(); i.hasNext();) {

			HetTree t = (HetTree) i.next();
			HetSpecies sp = t.getSpecies();

			speciesList.add(sp); // set: no duplicates

			// Sum leaf areas
			// addInMap(leafAreaMap_sp, sp, t.getLeafArea());
			// //mj+fa-04.12.2017: moved to HetModel

			// leaflessBarkStorageCapacity_sp
			double barkStorageCapacity_tree = sp.leaflessStemflowFunction.result(t.getGirth(),
					sp.leaflessRainfallThreshold);
			barkStorageCapacity_tree = Math.max(0, barkStorageCapacity_tree);// MJ
																				// +
																				// FA
																				// +
																				// LW
																				// 05/10/2016
			addInMap(leaflessBarkStorageCapacity_sp, sp, barkStorageCapacity_tree);

			// leavedBarkStorageCapacity_sp // fc+mj+lw=17.10.2016
			barkStorageCapacity_tree = sp.leavedStemflowFunction.result(t.getGirth(), sp.leavedRainfallThreshold);
			barkStorageCapacity_tree = Math.max(0, barkStorageCapacity_tree);// MJ
																				// +
																				// FA
																				// +
																				// LW
																				// 05/10/2016
			addInMap(leavedBarkStorageCapacity_sp, sp, barkStorageCapacity_tree);

			// leaflessSpeciesStemflowProportion_sp MJ + FA + LW 05/10/2016
			double stemflowProportion_tree = sp.leaflessStemflowFunction.result(t.getGirth(), 1)
					/ newPedon.getPedonArea();
			// double stemflowProportion_tree =
			// sp.leaflessStemflowFunction.result(t.getGirth(), 1) /
			// newScene.getArea();
			stemflowProportion_tree = Math.max(0, stemflowProportion_tree);
			addInMap(leaflessStemflowProportion_sp, sp, stemflowProportion_tree);

			// leavedSpeciesStemflowProportion_sp MJ + FA + LW 05/10/2016 //
			// fc+mj+lw=17.10.2016
			stemflowProportion_tree = sp.leavedStemflowFunction.result(t.getGirth(), 1) / newPedon.getPedonArea();
			// stemflowProportion_tree =
			// sp.leavedStemflowFunction.result(t.getGirth(), 1) /
			// newScene.getArea();
			stemflowProportion_tree = Math.max(0, stemflowProportion_tree);
			addInMap(leavedStemflowProportion_sp, sp, stemflowProportion_tree);

			// leaflessStemflowProportion_stand
			double v = sp.leaflessStemflowFunction.result(t.getGirth(), 1);
			if (v > 0)
				leaflessStemflowProportion_stand += v / newPedon.getPedonArea();
			// leaflessStemflowProportion_stand += v / newScene.getArea();

			// leavedStemflowProportion_stand // fc+mj+lw=17.10.2016
			v = sp.leavedStemflowFunction.result(t.getGirth(), 1);
			if (v > 0)
				leavedStemflowProportion_stand += v / newPedon.getPedonArea();
			// leavedStemflowProportion_stand += v / newScene.getArea();

			// albedo: Teh 2006
			crownAbsorbedRadiation += t.getLightResult().getCrownEnergy() * (1 - 0.11) / refPedon.getPedonArea(); // MJ/m2/year
			// crownAbsorbedRadiation += t.getLightResult().getCrownEnergy() *
			// (1 - 0.11) / refScene.getArea(); // MJ/m2/year

			trunkAbsorbedRadiation += t.getLightResult().getTrunkEnergy() * (1 - 0.11) / refPedon.getPedonArea(); // MJ/m2/year
			// trunkAbsorbedRadiation += t.getLightResult().getTrunkEnergy() *
			// (1 - 0.11) / refScene.getArea(); // MJ/m2/year

			// mj+fa-26.07.2017: commented
			// trunkAbsorbedRadiation_direct +=
			// t.getTreeLight().getTrunkDirectEnergy() * (1 - 0.11) /
			// refScene.getArea();
			// trunkAbsorbedRadiation_diffuse +=
			// t.getTreeLight().getTrunkDiffuseEnergy() * (1 - 0.11)
			// / refScene.getArea();

			leafArea_stand += t.getLeafArea();
			sapwoodArea_stand += sp.sapwoodArea.result(t.getDbh());

			addInMap(barkArea_sp, sp, t.getStemBarkArea());
			stemBarkArea_stand += t.getStemBarkArea();
			branchBarkArea_stand += t.getBranchBarkArea();
			
			maxFoliageStorageCapacity_stand += t.getLeafArea() * sp.foliageStorageCapacity_m2leaf; //fa-15.11.2019: modified (species -> tree leaf area) and moved from below

		}

		// mj+fa-04.12.2017: commented
		// // nb+mj-15.09.2017
		// // species.meanLightCompetitionIndex is initialized to 0.0 in
		// HetSpecies
		// // class.
		// for (HetSpecies sp : leafAreaMap_sp.keySet()) { // mj+fa-20.09.2017
		// sp.meanLightCompetitionIndex = 0;
		// sp.meanHcb = 0; // mj+fa-23.10.2017
		// sp.nTrees = 0; // mj+fa-23.10.2017
		// }

		for (Tree t : refPedon.getTrees(refScene)) {
			// for (Tree t : refScene.getTrees()) {

			HetTree tree = (HetTree) t;
			HetSpecies species = tree.getSpecies();

			// mj+fa-04.12.2017: moved to HetModel
			// HetTreeRadiationStatus radiationStatus = new
			// HetTreeRadiationStatus(tree);
			// species.meanLightCompetitionIndex += tree.getLeafArea() *
			// radiationStatus.lightCompetitionIndex
			// / leafAreaMap_sp.get(tree.getSpecies());

			// fc+mj+fa-12.11.2019 unused
			// species.meanHcb += tree.getHcb(); // mj+fa-23.10.2017
			// species.nTrees++; // mj+fa-23.10.2017

			// fc+mj+fa-15.11.2019 REMOVED, unused, can not stay here,
			// there may be one single tree or no trees associated to the pedon
			// mj+fa-20.09.2017
			// crownProjectionSum_stand += tree.getCrownProjection();
			// refScene.setCrownProjectionSum_stand(crownProjectionSum_stand);

			// fa-29.09.2017
			meanBasicCanopyStomatalConductance_stand += species.basicCanopyStomatalConductance * tree.getLeafArea()
					/ leafArea_stand;
		}

		// for (HetSpecies sp : leafAreaMap_sp.keySet()) { // mj+fa-23.10.2017
		Map<Integer, HetSpecies> speciesMap = ip.getSpeciesMap(); // fa+mj-04.12.2017

		// fc+mj+fa-12.11.2019 unused
		// for (HetSpecies sp : speciesMap.values()) { // fa+mj-04.12.2017
		// if (sp.nTrees != 0)
		// sp.meanHcb = sp.meanHcb / sp.nTrees;
		// }

		// fc-15.11.2019 MOVED to run () before the loop
		// // fc+mj+lw-18.10.2016
		// // MJ/m2/year, for vegetation period only
		// double slIncidentGlobalRadiation =
		// slModel.calculateIncidentRadiation(true, SLModel.GLOBAL_RADIATION);
		// newScene.setStandIncidentGlobalRadiation(slIncidentGlobalRadiation);//
		// fc-et-al-20.1.2017
		//
		// double slIncidentDirectRadiation =
		// slModel.calculateIncidentRadiation(true, SLModel.DIRECT_RADIATION);
		// newScene.setStandIncidentDirectRadiation(slIncidentDirectRadiation);//
		// fc+fa-31.7.2017
		//
		// double slIncidentDiffuseRadiation =
		// slModel.calculateIncidentRadiation(true, SLModel.DIFFUSE_RADIATION);
		// newScene.setStandIncidentDiffuseRadiation(slIncidentDiffuseRadiation);//
		// fc+fa-31.7.2017

		// // directRadiationProportion to be calculated from the Samsara light
		// file TODO
		// double directRadiationProportion = 0.47;
		// newScene.setStandIncidentDirectRadiation (directRadiationProportion *
		// slIncidentRadiation);
		// newScene.setStandIncidentDiffuseRadiation ((1 -
		// directRadiationProportion) * slIncidentRadiation);

		// Absorbed solar radiation per unit bark area, MJ/m2 bark/year
		
		if (refPedon.getPedonId() != 0) // fa-19.11.2019: refPedon != remainingPedon, otherwise stembarkArea_stand = 0 => NaN
			barkAbsorbedRadiation_m2bark = trunkAbsorbedRadiation / (stemBarkArea_stand / refPedon.getPedonArea());
		// barkAbsorbedRadiation_m2bark = trunkAbsorbedRadiation /
		// (stemBarkArea_stand / refScene.getArea());

		// mj+fa-26.07.2017: commented
		// newScene.setBarkAbsorbedRadiation(barkAbsorbedRadiation_m2bark);//
		// fc-et-al-20.1.2017
		// newScene.setBarkAbsorbedDirectRadiation(trunkAbsorbedRadiation_direct
		// / (stemBarkArea_stand / refScene.getArea()));
		// newScene.setBarkAbsorbedDiffuseRadiation(trunkAbsorbedRadiation_diffuse
		// / (stemBarkArea_stand / refScene.getArea()));

		branchAbsorbedRadiation = barkAbsorbedRadiation_m2bark * branchBarkArea_stand / refPedon.getPedonArea();
		// branchAbsorbedRadiation = barkAbsorbedRadiation_m2bark *
		// branchBarkArea_stand / refScene.getArea();

		leafAbsorbedRadiation = crownAbsorbedRadiation;// -
														// branchAbsorbedRadiation;

		double leafAreaIndex = leafArea_stand / refPedon.getPedonArea();
		// double leafAreaIndex = leafArea_stand / refScene.getArea();
		double barkAreaIndex = (stemBarkArea_stand + branchBarkArea_stand) / refPedon.getPedonArea();
		// double barkAreaIndex = (stemBarkArea_stand + branchBarkArea_stand) /
		// refScene.getArea();

		// MJ/m2/year / MJ/m2/year
		// Default values for SamsaraLight in Legacy mode
		if (leafAreaIndex != 0) // fa-15.11.2019: true if pedon != remainingPedon
			leafAbsorbedRadiationProportion = leafAbsorbedRadiation / slIncidentGlobalRadiation / leafAreaIndex;
		barkAbsorbedRadiationProportion = (branchAbsorbedRadiation + trunkAbsorbedRadiation)
				/ slIncidentGlobalRadiation;

		// System.out.println("HetModel leafAreaIndex: " + leafAreaIndex +
		// " barkAreaIndex: " + barkAreaIndex);

		leaflessThroughfallProportion_stand = 1 - leaflessStemflowProportion_stand;
		leavedThroughfallProportion_stand = 1 - leavedStemflowProportion_stand; // fc+mj+lw=17.10.2016

		double prevFoliageStorage_stand = 0;
		Map<HetSpecies, Double> prevBarkStorage_sp = new HashMap<>();

//		double maxFoliageStorageCapacity_stand = 0; // l/stand //fa-15.11.2019: moved above before tree loop
		// for (HetSpecies sp : leafAreaMap_sp.keySet()) {
		for (HetSpecies sp : speciesMap.values()) {
//			maxFoliageStorageCapacity_stand += sp.leafArea_sp * sp.foliageStorageCapacity_m2leaf; //fa-15.11.2019: moved above in tree loop
			prevBarkStorage_sp.put(sp, 0d);
		}

		// fa-15.11.2019: waterBalanceMap moved to Pedon
//		newScene.waterBalanceMap = new LinkedHashMap<>(); // keep insertion
//															// order

		// fc-19.11.2019
		newPedon.setWaterBalanceMap (new LinkedHashMap<>());
//		newPedon.waterBalanceMap = new LinkedHashMap<>();

//		newScene.hourlyTreeTranspirationMap = new LinkedHashMap<>(); // fa-17.09.2019 // fa-02.12.2019: moved above to run(), otherwise create a new map for each loop of detailed water balance

		// Process meteo data for the considered year
		int year = newScene.getDate();
		List<HetMeteoLine> meteoLines = ip.meteorology.getMeteoLines(year);

		if (meteoLines.size() == 0)
			throw new Exception("Could not find year: " + year + " in meteorology, aborted");

		HetMethodProvider mp = (HetMethodProvider) model.getMethodProvider();
//		double hDom = mp.getHdom(refScene, refScene.getTrees()); // fa-15.11.2019: moved in run()
//		double canopyBaseHeight = mp.getCanopyBaseHeight(refScene, refScene.getTrees());
		double canopyBaseHeight = mp.getCanopyBaseHeight(refPedon, refPedon.getTrees(refScene)); // fa-15.11.2019

//		HetHorizonsWaterContentCalculator hwcCalculator = new HetHorizonsWaterContentCalculator(refScene, newScene);
		HetHorizonsWaterContentCalculator hwcCalculator = new HetHorizonsWaterContentCalculator(refScene, refPedon, newPedon);	// fa-15.11.2019

		double prevRelativeExtractableWater = 1;
		double prevForestFloorExtractableWater = 1;
		double prevForestFloorRelativeExtractableWater = 1;

		// fc+fa+mj+lw-15.2.2017
		AdditionMap waterError_horizon = new AdditionMap();

		HetWaterBalance wbLast = null; // fc+mj-9.3.2017

		double ladProp_stand = 1; // fc+mj+fa-27.7.2017
		double greenProp_stand = 1; // fc+mj-13.9.2017
		double extinctionCoefficient = 0.5; // fc+mj-13.9.2017

		// Aimed at storing the previous hour
		HetMeteoLine prevMeteoLine = null;

		// Calculates the water content averaged on the horizons at the last
		// hour of previous year
		// nb - 1.8.2017
//		double organicLayerThickness = newScene.getSoil().getOrganicLayerThickness(); // fa-15.11.2019: moved to run ()
		double prevAverageHorizonWaterContent = 0.0;

		for (int horizonId : prevHorizonsWaterContent.keySet()) {

			// fc-13.11.2019
//			if (newScene.getSoil().getPedonSpecimen().getHorizon(horizonId).isOrganic()) {
			if (newPedon.getHorizon(horizonId).isOrganic()) { // fa-15.11.2019

//				double horizonThickness = newScene.getSoil().getPedonSpecimen().getHorizon(horizonId).thickness;
				double horizonThickness = newPedon.getHorizon(horizonId).thickness; // fa-15.11.2019

				prevAverageHorizonWaterContent += prevHorizonsWaterContent.get(horizonId) * horizonThickness;
			}
		}
		prevAverageHorizonWaterContent = prevAverageHorizonWaterContent / organicLayerThickness;

		// fa-15.11.2019: moved to run ()
//		// Calculates the temperature at the interface between the organic layer
//		// and the mineral layer
//
//		int dayWindowWidth = 24; // Size of the time window for moving average
//									// accounting for intra-day temperature
//									// variations (24 hours)
//		int yearWindowWidth = 15; // Size of the time window to account for
//									// intra-year temperature variations (15
//									// days preceding the current date)
//		HetReporter.printInStandardOutput("HeatTransfertInput: Meteo = " + ip.meteorology + ", Year = " + year
//				+ ", Window = " + dayWindowWidth + ", OrganicThickness = " + organicLayerThickness);
//
//		// Calculate average air temperature for over a 15 day period preceding
//		// each day of the current year
//		LinkedHashMap<String, Double> dateAverageAirTemperatureOverPrecedingPeriodMap = HetMeteorology
//				.calculateAverageAirTemperatureOverPrecedingPeriod(ip.meteorology, year, yearWindowWidth);
//		newScene.getSoil().calculateSoilInterfaceTemperature(ip.meteorology, year, dayWindowWidth,
//				organicLayerThickness, dateAverageAirTemperatureOverPrecedingPeriodMap);

		// //////////////////////////////
		// Loop on hourly meteo lines //
		// //////////////////////////////

		// mj+fa: create coefEval for every tree and store it in a Map
		// (computing efficiency in hourly loops below)
		HashMap<String, HetAbsorptionCoefficientEvaluator> coefEvalMap = new HashMap<String, HetAbsorptionCoefficientEvaluator>();
		if (ip.fineResolutionRadiativeBalanceActivated) {
//			for (Iterator it = refScene.getTrees().iterator(); it.hasNext();) {
			for (Iterator it = refPedon.getTrees(refScene).iterator(); it.hasNext();) { // fa-15.11.2019
				HetTree refTree = (HetTree) it.next();
				HetAbsorptionCoefficientEvaluator coefEval = new HetAbsorptionCoefficientEvaluator(refTree, refScene,
						refScene.getVegetationPeriod(), refScene.getBeamSetFactory().getAverageRadiation());
				String treeId = "tree" + refTree.getId();
				coefEvalMap.put(treeId, coefEval);
			}
		}

		// fc+mj+br-1.10.2018
//		double lai_avg3years = calculateLai_avg3years(refScene) / refScene.getArea(); // fa-15.11.2019: commented, leafAreaIndex calculated above will be used instead

		// Log.println("calculateLai_avg3years", "year: " + newScene.getDate() +
		// " lai_avg3years: " + lai_avg3years + " leafAreaIndex:
		// "+leafAreaIndex);

		for (int i = 0; i < meteoLines.size(); ++i) {

			HetMeteoLine meteoLine = meteoLines.get(i);

			String time = meteoLine.year + HetMeteorology.SEP + meteoLine.month + HetMeteorology.SEP + meteoLine.day
					+ HetMeteorology.SEP + meteoLine.hour;

			// Value of water content to be used in the calculation of heat flux
			// in organic layer
			double averageHorizonWaterContent;

			if (i == 0)
				averageHorizonWaterContent = prevAverageHorizonWaterContent;
			else {
				String prevTime = prevMeteoLine.year + HetMeteorology.SEP + prevMeteoLine.month + HetMeteorology.SEP
						+ prevMeteoLine.day + HetMeteorology.SEP + prevMeteoLine.hour;

//				Map<Integer, Double> horizonWaterContent = newScene.waterBalanceMap.get(prevTime).horizonWaterContent;
				Map<Integer, Double> horizonWaterContent = newPedon.getWaterBalanceMap ().get(prevTime).horizonWaterContent;	// fa-15.11.2015

				double waterContent = 0.0;

				for (int horizonId : horizonWaterContent.keySet()) {

					// fc-13.11.2019
//					if (newScene.getSoil().getPedonSpecimen().getHorizon(horizonId).isOrganic()) {
					if (newPedon.getHorizon(horizonId).isOrganic()) { // fa-15.11.2019
//						double horizonThickness = newScene.getSoil().getPedonSpecimen().getHorizon(horizonId).thickness;
						double horizonThickness = newPedon.getHorizon(horizonId).thickness; // fa-15.11.2019

						waterContent += horizonWaterContent.get(horizonId) * horizonThickness;
					}
				}
				averageHorizonWaterContent = waterContent / organicLayerThickness;
			}

			// Log.println("HetModel updateWaterBalance meteorology line: " +
			// line);

			// Get doy
			Calendar cal = new GregorianCalendar();
			cal.set(meteoLine.year, meteoLine.month - 1, meteoLine.day); // month
																			// in
																			// [0,11]
			int month = cal.get(Calendar.MONTH);
			int doy = cal.get(Calendar.DAY_OF_YEAR);
			int dom = cal.get(Calendar.DAY_OF_MONTH);
			int wom = cal.get(Calendar.WEEK_OF_MONTH);
			Date sDate = cal.getTime();

			// Log.println("HetModel updateWaterBalance meteorology line: " +
			// line + " month: " + month + " wom: " + wom
			// + " dom: " + dom + " doy: " + doy + " sDate: " + sDate);

			double foliageStorage_stand = 0; // l
			double nonInterceptedRainfall_stand = 0; // l

//			double rainfall_stand = meteoLine.rainfall * newScene.getArea(); // l
			double rainfall_stand = meteoLine.rainfall * newPedon.getPedonArea(); // l // fa-15.11.2019
			double throughfall_stand = 0; // l

			Map<HetSpecies, Double> barkStorage_sp = new HashMap<>(); // l
			// for (HetSpecies sp : leafAreaMap_sp.keySet()) {
			for (HetSpecies sp : speciesMap.values()) { // fa+mj-04.12.2017
				barkStorage_sp.put(sp, 0d);
			}
			double stemflow_stand = 0;

			// fc+mj+fa-27.7.2017
			if (ip.fineResolutionRadiativeBalanceActivated || ip.phenologyActivated) {

				if (ip.fineResolutionRadiativeBalanceActivated) {
					leafAbsorbedRadiationProportion = 0;
					barkAbsorbedRadiationProportion = 0;
				}
//				if (ip.phenologyActivated) {
				if (ip.phenologyActivated && refPedon.getPedonId() != 0) { // fa-19.11.2019: not reset if refPedon = remainingPedon (id=0), otherwise divisions by zero would occur
					// Reset
					ladProp_stand = 0;
					greenProp_stand = 0;
					extinctionCoefficient = 0;
				}

//				for (Iterator it = refScene.getTrees().iterator(); it.hasNext();) {
				for (Iterator it = refPedon.getTrees(refScene).iterator(); it.hasNext();) { // fa-15.11.2019
					HetTree refTree = (HetTree) it.next();
					HetSpecies sp = refTree.getSpecies();

					SLFoliageStateManager foliageStateManager = (SLFoliageStateManager) refScene;
					// Calculates ladProp at tree level. nb-06.11.2019
					// double ladProp =
					// foliageStateManager.getLadProportionOfNextYear(refTree.getSpeciesCode(),
					// doy);
					double ladProp = foliageStateManager.getLadProportionOfNextYear(refTree.getId(), doy);
					double greenProp = foliageStateManager.getGreenProportionOfNextYear(refTree.getId(), doy);

					if (ip.fineResolutionRadiativeBalanceActivated) {

						// mj+fa-10.08.2017: commented, coefEval created and
						// stored in coefEvalMap before hourly loop (computing
						// efficiency)
						// HetAbsorptionCoefficientEvaluator coefEval = new
						// HetAbsorptionCoefficientEvaluator(refTree,
						// refScene, refScene.getVegetationPeriod(),
						// refScene.getBeamSetFactory()
						// .getAverageRadiation());
						// mj+fa-10.08.2017
						String treeId = "tree" + refTree.getId();
						HetAbsorptionCoefficientEvaluator coefEval = coefEvalMap.get(treeId);

						double crownDirectCoefficient = coefEval.getCrownDirectCoefficient(doy, meteoLine.hour);
						double crownDiffuseCoefficient = coefEval.getCrownDiffuseCoefficient(doy, meteoLine.hour);

						double crownGlobalCoefficient = crownDirectCoefficient * (1 - meteoLine.diffuseToGlobalRatio)
								+ crownDiffuseCoefficient * meteoLine.diffuseToGlobalRatio;

						if (ladProp != 0)
							leafAbsorbedRadiationProportion += crownGlobalCoefficient
									/ (refTree.getLeafArea() * ladProp);

						double barkCoefficient = coefEval.getBarkCoefficient(doy, meteoLine.hour);

						barkAbsorbedRadiationProportion += barkCoefficient;
					}

					if (ip.phenologyActivated) {
						ladProp_stand += (refTree.getLeafArea() * ladProp) / leafArea_stand;
						greenProp_stand += (refTree.getLeafArea() * greenProp) / leafArea_stand;
						extinctionCoefficient += (refTree.getLeafArea() * sp.extinctionCoefficient) / leafArea_stand;
					}

				}

			}

			// fc+mj+fa-31.7.2017
			double foliageStorageCapacity_stand = 0;
			foliageStorageCapacity_stand = maxFoliageStorageCapacity_stand * ladProp_stand;

			// foliageEvaporation_stand l/stand

			// fc+mj+fa+lw-15.2.2017
			double midCanopyHeight = (hDom + canopyBaseHeight) / 2d;
			
			// fa-17.12.2019: average leaf width for stand or for pedon neighboring zone
			double weightedLeafWidthSum = 0d;
			double cumulatedLeafArea = 0d;
			if (refScene.getSoil().isDiscreteSoil() && refPedon.getPedonId() != 0) { // treePedon => meanLeafWidth averaged over trees within 15 m radius neighboring area around the tree
				HetPlot plot = (HetPlot) refScene.getPlot();
				double leafWidthNeighbourhoodDistance = 15d; // m
				RoundMask m = new RoundMask(plot, leafWidthNeighbourhoodDistance, true);
				HetTree pedonTree = (HetTree) refScene.getTree(refPedon.getPedonId());
				Collection neighbourTrees = m.getTreesNear(pedonTree);
				neighbourTrees.add(pedonTree); // we add the pedon tree
				for (Iterator nt = neighbourTrees.iterator(); nt.hasNext();) {
					HetTree t = (HetTree) nt.next();
					HetSpecies tSpecies = t.getSpecies();
					weightedLeafWidthSum += tSpecies.meanLeafWidth * t.getLeafArea();
					cumulatedLeafArea += t.getLeafArea();
				}
			} else { // Legacy water balance mode OR remainingPedon => meanLeafWidth averaged for the whole stand
				for (HetSpecies species : ip.speciesMap.values()) { // initialization
					int speciesId = species.getId();
					weightedLeafWidthSum += species.meanLeafWidth * refScene.getSpeciesLeafAreaMap().get(speciesId);
					cumulatedLeafArea += refScene.getSpeciesLeafAreaMap().get(speciesId);
				}
			}
			double averageLeafWidth = weightedLeafWidthSum / cumulatedLeafArea;

			double[] foliageEvaporation_and_canopyAirConductance = estimateFoliageEvaporation(
					leafAbsorbedRadiationProportion, leafAreaIndex, meteoLine, hDom, midCanopyHeight,
					ip.meteorology.getWindSpeedMeasurementHeight(),
					ip.meteorology.getWindSpeedAttenuationCoefficient(), averageLeafWidth); // fa-17.12.2019: added averageLeafWidth

			double foliageEvaporation_m2leaf = foliageEvaporation_and_canopyAirConductance[0];
			double canopyAirConductance = foliageEvaporation_and_canopyAirConductance[1];

			double foliageEvaporation_stand = foliageEvaporation_m2leaf * leafArea_stand * ladProp_stand;
			// double potentialFoliageEvaporation_stand =
			// foliageEvaporation_stand; // fa-21.10.2019: for F. Joussemet
			foliageEvaporation_stand = Math.min(foliageEvaporation_stand, prevFoliageStorage_stand);

			// barkEvaporation_sp
			
			Map<HetSpecies, Double> barkEvaporation_sp =  new HashMap<HetSpecies, Double>() ; // fa-15.11.2019: created before 'if' statement below to avoid local variable, not used if pedon = remainingPedon
			
			if(refPedon.getPedonId() != 0) { // fa: 15.11.2019: if pedon != remainingPedon, otherwise division by 0 below (barkAreaIndex))
				Map<HetSpecies, Double> barkStorageCapacity_sp = null;

			
				double barkRadiation_m2bark;

				// if (model.isVegetationPeriod(doy)) // nb+lw-23.01.2017
				// if (slModel.isVegetationPeriod(doy))

				if (model.isExtendedVegetationPeriod(newScene, doy)) { // fc+mj-12.9.2017
					barkStorageCapacity_sp = leavedBarkStorageCapacity_sp;
					barkRadiation_m2bark = barkAbsorbedRadiationProportion * meteoLine.radiation / barkAreaIndex;
				} else {
					barkStorageCapacity_sp = leaflessBarkStorageCapacity_sp;
					barkRadiation_m2bark = (1.0 - 0.11) * meteoLine.radiation
							* (1.0 - Math.exp(-extinctionCoefficient * barkAreaIndex)) / barkAreaIndex;
				}

				Map<HetSpecies, Double> barkEvaporation_sp_m2_bark = estimateBarkEvaporation(speciesList,
						prevBarkStorage_sp, barkStorageCapacity_sp, barkRadiation_m2bark, barkAreaIndex, meteoLine, hDom,
						ip.meteorology.getWindSpeedMeasurementHeight(),
						ip.meteorology.getWindSpeedAttenuationCoefficient(), averageLeafWidth); // fa-17.12.2019: added averageLeafWidth

//				Map<HetSpecies, Double> barkEvaporation_sp = createStandBarkEvaporation(barkEvaporation_sp_m2_bark,
//						barkArea_sp, prevBarkStorage_sp);
//				barkEvaporation_sp = createStandBarkEvaporation(barkEvaporation_sp_m2_bark,
				barkEvaporation_sp = computeStandBarkEvaporation(barkEvaporation_sp_m2_bark,
						barkArea_sp, prevBarkStorage_sp, barkEvaporation_sp);	// fa-19.11.2019: as Map barkEvaporation_sp is already created above, before 'if'
			}

			// Are we in vegetation period ?

			// if (slModel.isVegetationPeriod(doy)) {
			// if (model.isVegetationPeriod(doy)) { // nb+lw-23.01.2017

			if (model.isExtendedVegetationPeriod(newScene, doy)) { // fc+mj-12.9.2017

				double remainingFoliageStorageCapacity_stand = foliageStorageCapacity_stand
						- (prevFoliageStorage_stand - foliageEvaporation_stand);
				if (remainingFoliageStorageCapacity_stand > 0) {
					if (remainingFoliageStorageCapacity_stand > rainfall_stand) {
						foliageStorage_stand = prevFoliageStorage_stand - foliageEvaporation_stand + rainfall_stand;
					} else {
						foliageStorage_stand = foliageStorageCapacity_stand;
						nonInterceptedRainfall_stand = rainfall_stand - remainingFoliageStorageCapacity_stand;
					}

				} else { // remainingFoliageStorageCapacity_stand <= 0
					foliageStorage_stand = foliageStorageCapacity_stand;
					nonInterceptedRainfall_stand = rainfall_stand;

				}

				// fc+mj+lw-17.10.2016
				throughfall_stand = leavedThroughfallProportion_stand * nonInterceptedRainfall_stand;

				for (HetSpecies sp : speciesList) {
					double stemflow_sp = 0;
					double preStemflow_sp = leavedStemflowProportion_sp.get(sp) * nonInterceptedRainfall_stand;
					double remainingBarkStorageCapacity_sp = leavedBarkStorageCapacity_sp.get(sp)
							- (prevBarkStorage_sp.get(sp) - barkEvaporation_sp.get(sp));

					if (remainingBarkStorageCapacity_sp > 0) {
						if (remainingBarkStorageCapacity_sp > preStemflow_sp) {
							barkStorage_sp.put(sp,
									prevBarkStorage_sp.get(sp) - barkEvaporation_sp.get(sp) + preStemflow_sp);
						} else {
							barkStorage_sp.put(sp, leavedBarkStorageCapacity_sp.get(sp));
							stemflow_sp = preStemflow_sp - remainingBarkStorageCapacity_sp;
						}

					} else { // remainingBarkStorageCapacity_sp <= 0
						barkStorage_sp.put(sp, leavedBarkStorageCapacity_sp.get(sp));
						stemflow_sp = preStemflow_sp;

					}

					stemflow_stand += stemflow_sp;
				}

			} else { // not in vegetation period

				nonInterceptedRainfall_stand = rainfall_stand;

				// fc+mj+lw-17.10.2016
				throughfall_stand = leaflessThroughfallProportion_stand * nonInterceptedRainfall_stand;

				for (HetSpecies sp : speciesList) {
					double stemflow_sp = 0;
					double preStemflow_sp = leaflessStemflowProportion_sp.get(sp) * nonInterceptedRainfall_stand;
					double remainingBarkStorageCapacity_sp = leaflessBarkStorageCapacity_sp.get(sp)
							- (prevBarkStorage_sp.get(sp) - barkEvaporation_sp.get(sp));

					if (remainingBarkStorageCapacity_sp > 0) {
						if (remainingBarkStorageCapacity_sp > preStemflow_sp) {
							barkStorage_sp.put(sp,
									prevBarkStorage_sp.get(sp) - barkEvaporation_sp.get(sp) + preStemflow_sp);
						} else {
							barkStorage_sp.put(sp, leaflessBarkStorageCapacity_sp.get(sp));
							stemflow_sp = preStemflow_sp - remainingBarkStorageCapacity_sp;
						}

					} else { // remainingBarkStorageCapacity_sp <= 0
						barkStorage_sp.put(sp, leaflessBarkStorageCapacity_sp.get(sp));
						stemflow_sp = preStemflow_sp;

					}

					stemflow_stand += stemflow_sp;
				}
			}

			// Transpiration
			double hourlyTranspiration_stand = 0;
			double potentialHourlyTranspiration_stand = 0; // fa-21.10.2019: for
															// F. Joussemet
			double standLevel_hourlyTranspiration_stand = 0;
			// double treeLevel_hourlyTranspiration_stand = 0;
			double[] real_and_potential_treeLevel_hourlyTranspiration_stand = new double[2];
			real_and_potential_treeLevel_hourlyTranspiration_stand[0] = 0d;
			real_and_potential_treeLevel_hourlyTranspiration_stand[1] = 0d; // fa-21.10.2019:
																			// for
																			// F.
																			// Joussemet

			// mj+fa-7.9.2017: isVegetationPeriod not necessary anymore (ladProp
			// && greenProp)
			// if (model.isExtendedVegetationPeriod(newScene, doy) &&
			// foliageStorage_stand == 0
			// && meteoLine.radiation != 0) {
//			if (model.isExtendedVegetationPeriod(newScene, doy) && meteoLine.radiation != 0) { // mj+fa-07.03.2018
			if (model.isExtendedVegetationPeriod(newScene, doy) && meteoLine.radiation != 0 && refPedon.getPedonId() != 0) { // fa-15.11.2019: added refPedon.getPedonId() != 0, otherwise division by 0 in hourlyStandTranspiration (leafAreaIndex, leafArea_stand) if pedon = remainingPedon (no trees) 

				// fc+mj-13.9.2017
				// Stand level: always calculated
				double standTranspiration_m2leaf = hourlyStandTranspiration(refScene, refPedon, newPedon, leafAreaIndex, meteoLine,
						prevRelativeExtractableWater, ladProp_stand, greenProp_stand, canopyAirConductance,
						leafArea_stand, sapwoodArea_stand, midCanopyHeight, extinctionCoefficient,
						meanBasicCanopyStomatalConductance_stand, hwcCalculator, prevHorizonsWaterContent); // fa-18.06.2019:
																											// added
																											// hwcCalculator
																											// &
																											// prevHorizonsWaterContent

				// standLevel_hourlyTranspiration_stand =
				// standTranspiration_m2leaf * leafArea_stand * ladProp_stand
				// * greenProp_stand;

				// mj+fa-07.03.2018
				double foliageStorageCapacitySaturatedProportion = 0d;
				if (foliageStorageCapacity_stand != 0d)
					foliageStorageCapacitySaturatedProportion = foliageStorage_stand / foliageStorageCapacity_stand;
				standLevel_hourlyTranspiration_stand = standTranspiration_m2leaf * leafArea_stand * greenProp_stand
						* (1d - foliageStorageCapacitySaturatedProportion);

				hourlyTranspiration_stand = standLevel_hourlyTranspiration_stand;

				// Tree level, longer: calculated upon demand and replaces
				// standLevel_hourlyTranspiration_stand
				if (ip.waterBalance_treeLevelTranspiration) {
					real_and_potential_treeLevel_hourlyTranspiration_stand = hourlyTreesTranspiration(refScene, refPedon,	// fa-15.11.2019: added refPedon & newPedon
							newScene, newPedon, meteoLine, barkAbsorbedRadiation_m2bark, slIncidentGlobalRadiation, hDom,
							ip.meteorology.getWindSpeedMeasurementHeight(),
							ip.meteorology.getWindSpeedAttenuationCoefficient(), prevRelativeExtractableWater,
							coefEvalMap, hwcCalculator, prevHorizonsWaterContent, averageLeafWidth); // fa-18.06.2019:
																					// added
																					// hwcCalculator
																					// &
																					// prevHorizonsWaterContent
																					// fa-21.10.2019:
																					// modified
																					// for
																					// F.
																					// Joussemet
																					// fa-17.12.2019: added averageLeafWidth

					// hourlyTranspiration_stand =
					// treeLevel_hourlyTranspiration_stand;
					hourlyTranspiration_stand = real_and_potential_treeLevel_hourlyTranspiration_stand[0]
							* (1d - foliageStorageCapacitySaturatedProportion); // mj+fa-07.03.2018
																				// fa-21.10.2019:
																				// modified
																				// for
																				// F.
																				// Joussemet
					potentialHourlyTranspiration_stand = real_and_potential_treeLevel_hourlyTranspiration_stand[1]; // fa-21.10.2019:
																													// for
																													// F.
																													// Joussemet
				}

			}

			// --- Ground and soil ---------------------------------
			// --- Ground and soil ---------------------------------

//			double meanCellRadiation = calculateSoilRadiation(refScene); // MJ/m2
			double meanCellRadiation = calculateSoilRadiation(refScene, refPedon); // MJ/m2 //fa-15.11.2019: single cell for treePedon
			double meanCellRadiationProportion = meanCellRadiation / slIncidentGlobalRadiation;

			// Ground air conductance
			double dominantHeightWindSpeed = calculateDominantHeightWindSpeed(
					ip.meteorology.getWindSpeedMeasurementHeight(), meteoLine.windSpeed, hDom);

			double n = 10;
//			double meanLeafWidth = 0.04; // m, to be reviewed // fa-17.12.2019: commented, meanLeafWidth is now a species specific parameter. Averaged above for stand or pedon neighboring zone

			double groundHeight = 0;
			double deltaHeight = (hDom - groundHeight) / n;
			double sum = 0;
			for (int k = 0; k <= n; k++) {
				double h = groundHeight + k * deltaHeight; // m
				double ws = windSpeedFunction(dominantHeightWindSpeed, hDom, h,
						ip.meteorology.getWindSpeedAttenuationCoefficient()); // m/s
//				double airConductance = 0.006 * Math.sqrt(ws / meanLeafWidth);
				double airConductance = 0.006 * Math.sqrt(ws / averageLeafWidth); // fa-17.12.2019
				sum += airConductance;
			}
			double groundAirConductance = sum / (n + 1);

			// --- Ground vegetation transpiration l/m2 -------------------

//			double groundVegetationLAI = ip.ecosystemLAI - lai_avg3years;
			double groundVegetationLAI = ip.ecosystemLAI - leafAreaIndex; // fa-15.11.2019: uncomment
			if (refPedon.getPedonId() == 0) // reaminingPedon
				groundVegetationLAI = ip.ecosystemLAI / 2d;

			double groundVegetationRadiation_m2leaf = 0;

			double groundVegetationTranspiration_m2leaf = 0;
			double groundVegetationTranspiration = 0;

			// mj+fa-04.12.2019: commented
//			// fa-15.11.2019: if pedon = remainingPedon, no trees and division by zero with leafArea_stand would occur
//			if (refPedon.getPedonId() == 0 && model.isExtendedVegetationPeriod(newScene, doy)) {
//
//				// fa-19.11.2019: commented, condition was set above
////				ladProp_stand = 1d;
////				greenProp_stand = 1d;
//				leafArea_stand = refScene.getLeafArea();
//			}

			if (model.isExtendedVegetationPeriod(newScene, doy) && meteoLine.radiation != 0 && ladProp_stand != 0
					&& greenProp_stand != 0 && groundVegetationLAI > 0) {

				groundVegetationRadiation_m2leaf = (1 - 0.11) * meteoLine.radiation * meanCellRadiationProportion
						* (1 - Math.exp(-extinctionCoefficient * groundVegetationLAI * greenProp_stand))
						/ (groundVegetationLAI * greenProp_stand);

				groundVegetationTranspiration_m2leaf = estimateGroundVegetationTranspiration(refScene, newPedon,			// fa-15.11.2019: added newPedon //mj+fa-04.12.2019: removed leafArea_stand
						groundVegetationRadiation_m2leaf, meteoLine, prevRelativeExtractableWater, ladProp_stand,
						greenProp_stand, groundAirConductance, hwcCalculator, prevHorizonsWaterContent); // mj+fa-18.06.2019:
																															// added
																															// leafArea_stand,
																															// hwcCalculator
																															// &
																															// prevHorizonsWaterContent

				groundVegetationTranspiration = groundVegetationTranspiration_m2leaf
						* (groundVegetationLAI * greenProp_stand);
			}

			// --- Soil evaporation l/m2 -----------------------------------
			double soilEvaporation = 0;
			// // forestFloor = OL + OF + OH layers
			// if (forestFloorRelativeExtractableWater > 0) {

			// //////////////////////////////////////////////////////
			// Calculates the heat flux through the organic layer //
			// using the water content of the previous hour. //
			// //////////////////////////////////////////////////////

			double organicLayerBulkDensity = newScene.getSoil().getOrganicLayerBulkDensity();

			double organicLayerHeatFlux = 0.0;

			if (organicLayerThickness > 0.0) {
				soilHeatFluxCalculator.calculateOrganicLayerHeatFlux(newScene, meteoLine, averageHorizonWaterContent,
						newScene.getSoil().getSoilInterfaceTemperatureMap(), organicLayerThickness,
						organicLayerBulkDensity);

				organicLayerHeatFlux = newScene.getSoil().getOrganicLayerHeatFluxMap().get(time);
			}

			// organicLayerHeatFlux is positive downwards => sign is '-'
			double soilRadiation;
			if (model.isExtendedVegetationPeriod(newScene, doy)) {
				soilRadiation = (1 - 0.11) * meteoLine.radiation * meanCellRadiationProportion
						* Math.exp(-extinctionCoefficient * groundVegetationLAI * greenProp_stand)
						- organicLayerHeatFlux;
			} else {
				soilRadiation = (1.0 - 0.11) * meteoLine.radiation * Math.exp(-extinctionCoefficient * barkAreaIndex)
						- organicLayerHeatFlux;
			}

			if (soilRadiation < 0)
				soilRadiation = 0;

			soilEvaporation = estimateSoilEvaporation(soilRadiation, refScene.getSoil(), meteoLine,
					prevForestFloorRelativeExtractableWater, groundAirConductance);

			soilEvaporation = Math.min(soilEvaporation, prevForestFloorExtractableWater);

			// Update memories for next iteration
			prevFoliageStorage_stand = foliageStorage_stand;
			for (HetSpecies sp : speciesList) {
				prevBarkStorage_sp.put(sp, barkStorage_sp.get(sp));
			}

			double rainfall = meteoLine.rainfall; // mm
//			double stemflow = stemflow_stand / newScene.getArea(); // mm
			double stemflow = stemflow_stand / newPedon.getPedonArea(); // mm // fa-15.11.2019
//			double throughfall = throughfall_stand / newScene.getArea(); // mm
			double throughfall = throughfall_stand / newPedon.getPedonArea(); // mm // fa-15.11.2019
			double interception = rainfall - throughfall - stemflow; // mm // fa-15.11.2019
			
//			double transpiration = hourlyTranspiration_stand / newScene.getArea() + groundVegetationTranspiration; // mm
			double transpiration = hourlyTranspiration_stand / newPedon.getPedonArea() + groundVegetationTranspiration; // mm // fa-15.11.2019

			// mj+fc-13.9.2017
//			double standLevel_transpiration = standLevel_hourlyTranspiration_stand / newScene.getArea(); // mm
			double standLevel_transpiration = standLevel_hourlyTranspiration_stand / newPedon.getPedonArea(); // mm // fa-15.11.2019 
			// double treeLevel_transpiration =
			// treeLevel_hourlyTranspiration_stand / newScene.getArea(); // mm
			double treeLevel_transpiration = real_and_potential_treeLevel_hourlyTranspiration_stand[0]
					/ newPedon.getPedonArea(); // fa-15.11.2019
//					/ newScene.getArea(); // mm // fa-21.10.2019: modified for
											// F. Joussemet
			double treeLevel_potentialTranspiration = real_and_potential_treeLevel_hourlyTranspiration_stand[1]
					/ newPedon.getPedonArea(); // fa-15.11.2019
//					/ newScene.getArea(); // mm // fa-21.10.2019: for F.
											// Joussemet

//			double foliageEvaporation = foliageEvaporation_stand / refScene.getArea();
			double foliageEvaporation = foliageEvaporation_stand / refPedon.getPedonArea(); // fa-15.11.2019
			// double potentialFoliageEvaporation =
			// potentialFoliageEvaporation_stand / refScene.getArea(); //
			// fa-21.10.2019: for F. Joussemet
//			double barkEvaporation = sumBarkEvaporation(barkEvaporation_sp, refScene.getArea());
			
			// fa-19.11.2019
			double barkEvaporation = 0d;
			if (refPedon.getPedonId() != 0) // not remainingPedon (for which no trees are present)
				barkEvaporation = sumBarkEvaporation(barkEvaporation_sp, refPedon.getPedonArea()); // fa-15.11.2019

			double vegetationEvaporation = foliageEvaporation + barkEvaporation; // mm
			// double soilEvaporation = 0; // mm

			// Horizons water content
			Map<Integer, Double> newHorizonsWaterContent = hwcCalculator.updateHorizonsWaterContent(
					prevHorizonsWaterContent, stemflow, throughfall, transpiration, soilEvaporation, waterError_horizon,
					rainfall, interception, meteoLine.year, meteoLine.month, meteoLine.day, meteoLine.hour); // hourly,
			// m3/m3, fa-13.06.2019: added 'rainfall', 'interception' & date
			prevHorizonsWaterContent = newHorizonsWaterContent; // for next hour

			double deepDrainage = hwcCalculator.getDeepDrainage(); // mm

			// fc-13.11.2019
//			double relativeExtractableWater = calculateRelativeExtractableWater(newHorizonsWaterContent,
//					newScene.getSoil().getPedonSpecimen().getHorizons(), refScene.getArea()); // mm/mm
			double relativeExtractableWater = calculateRelativeExtractableWater(newHorizonsWaterContent,
					newPedon.getHorizons(), refPedon.getPedonArea()); // mm/mm // fa-15.11.2019

//			double[] forestFloor_absolute_and_relative_extractableWater = calculateForestFloorRelativeExtractableWater(
//					newHorizonsWaterContent, newScene.getSoil().getPedonSpecimen().getHorizons()); // mm/mm
			double[] forestFloor_absolute_and_relative_extractableWater = calculateForestFloorRelativeExtractableWater(
					newHorizonsWaterContent, newPedon.getHorizons(), refPedon); // mm/mm // fa-15.11.2019

			double forestFloorExtractableWater = forestFloor_absolute_and_relative_extractableWater[0];
			double forestFloorRelativeExtractableWater = forestFloor_absolute_and_relative_extractableWater[1];

			HetWaterBalance wb = new HetWaterBalance(meteoLine.year, meteoLine.month, meteoLine.day, meteoLine.hour,
					newHorizonsWaterContent, rainfall, stemflow, throughfall, interception, transpiration,
					standLevel_transpiration, treeLevel_transpiration, groundVegetationTranspiration, barkEvaporation,
					foliageEvaporation, vegetationEvaporation, soilEvaporation, deepDrainage, relativeExtractableWater,
					forestFloorRelativeExtractableWater,
					// potentialFoliageEvaporation,
					// treeLevel_potentialTranspiration); // fa-21.10.2019: for
					// F. Joussemet
					treeLevel_potentialTranspiration); // fa-21.10.2019: for F.
														// Joussemet

			wbLast = wb;

			String key = "" + meteoLine.year + "_" + meteoLine.month + "_" + meteoLine.day + "_" + meteoLine.hour;
//			newScene.waterBalanceMap.put(key, wb);
			newPedon.getWaterBalanceMap ().put(key, wb);

			prevRelativeExtractableWater = relativeExtractableWater;
			prevForestFloorExtractableWater = forestFloorExtractableWater;
			prevForestFloorRelativeExtractableWater = forestFloorRelativeExtractableWater;

			prevMeteoLine = meteoLine;
		}

		// fc+mj-9.3.2017

		// fc-13.11.2019
//		storeLastWaterContentValue(wbLast, newScene.getSoil().getPedonSpecimen().getHorizons());
		storeLastWaterContentValue(wbLast, newPedon.getHorizons()); // fa-15.11.2019

//		HetReporter.printInStandardOutput(
//				"HetWaterBalanceCalculator.updateWaterBalance(),waterError_horizon: " + waterError_horizon.toString());
	}

	/**
	 * Search the 3 last years in memory and calculate the average lai_stand. If
	 * Not all 3 scenes are available in memory (Capsis memorizers), consider 2
	 * scenes or 1 only.
	 */
	private double calculateLai_avg3years(HetScene refScene) {

		double res = refScene.getLeafArea();
		int n = 1;

		try {
			HetScene scene = (HetScene) ((Step) refScene.getStep().getFather()).getScene();
			if (scene.getDate() == refScene.getDate() - 1) {
				res += scene.getLeafArea();
				n++;

				scene = (HetScene) ((Step) scene.getStep().getFather()).getScene();
				if (scene.getDate() == refScene.getDate() - 2) {
					res += scene.getLeafArea();
					n++;
				}
			}
		} catch (Exception e) {
			// ignore
		}

		return res / n;
	}

	/**
	 * At the end of the year, store the given last values of water balance in
	 * each horizon to be able to init the process next year.
	 */
	private void storeLastWaterContentValue(HetWaterBalance wbLast, List<HetHorizon> horizons) { // fc+mj-9.3.2017
		for (HetHorizon h : horizons) {
			h.lastWaterContent = wbLast.horizonWaterContent.get(h.id);
		}
	}

	static public double calculateRelativeExtractableWater(Map<Integer, Double> newHorizonsWaterContent,
			List<HetHorizon> newHorizons, double pedonArea) { // fa-15.11.2019
//			List<HetHorizon> newHorizons, double sceneArea) {

		double extractableWaterContent = 0;
		double maxExtractableWaterContent = 0;

		for (HetHorizon h : newHorizons) {

			// fc+mj-14.9.2017 for use with a modelTool where there will be
			// missing entries in newHorizonsWaterContent, coming from an
			// observation file
			if (!newHorizonsWaterContent.containsKey(h.id))
				continue;

			extractableWaterContent += Math.max(0d, (newHorizonsWaterContent.get(h.id) - h.wiltingPointWaterContent)
					* h.volume * pedonArea * 998d * (1d - h.additionalCoarseFraction)); // fa-15.11.2019
//					* h.volume * sceneArea * 998d * (1d - h.additionalCoarseFraction));

			// fc+mj-10.3.2017
			// double maxWaterContent = h.saturatedWaterContent;
			double maxWaterContent = h.fieldCapacityWaterContent;

			maxExtractableWaterContent += Math.max(0d, (maxWaterContent - h.wiltingPointWaterContent) * h.volume
					* pedonArea * 998d * (1d - h.additionalCoarseFraction)); // fa-15.11.2019
//					* sceneArea * 998d * (1d - h.additionalCoarseFraction));
		}

		double relativeExtractableWaterContent = 0;
		if (maxExtractableWaterContent != 0)
			relativeExtractableWaterContent = extractableWaterContent / maxExtractableWaterContent;

		return relativeExtractableWaterContent;
	}

	/**
	 * Returns a double array with 2 values: extractableWaterContent then
	 * relativeExtractableWaterContent.
	 */
	private double[] calculateForestFloorRelativeExtractableWater(Map<Integer, Double> newHorizonsWaterContent,
			List<HetHorizon> newHorizons, Pedon refPedon) {	// fa-15.11.2019: added refPedon

		double extractableWaterContent = 0;
		double maxExtractableWaterContent = 0;

		for (HetHorizon h : newHorizons) {

			if (h.lowerLimit >= 0) {

				extractableWaterContent += Math.max(0d, (newHorizonsWaterContent.get(h.id) - h.wiltingPointWaterContent)
						* h.volume * refPedon.getPedonArea() * 998d * (1d - h.additionalCoarseFraction)); // fa-15.11.2019
//						* h.volume * refScene.getArea() * 998d * (1d - h.additionalCoarseFraction));

				// fc+mj-10.3.2017
				double maxWaterContent = h.saturatedWaterContent;
				// double maxWaterContent = h.fieldCapacityWaterContent;

				maxExtractableWaterContent += Math.max(0d, (maxWaterContent - h.wiltingPointWaterContent) * h.volume
						* refPedon.getPedonArea() * 998d * (1d - h.additionalCoarseFraction));	// fa-15.11.2019
//						* refScene.getArea() * 998d * (1d - h.additionalCoarseFraction));
			}
		}

		double relativeExtractableWaterContent = 0;
		if (maxExtractableWaterContent != 0)
			relativeExtractableWaterContent = extractableWaterContent / maxExtractableWaterContent;

		// fc+mj-13.9.2017 now returns 2 values
		return new double[] { extractableWaterContent, relativeExtractableWaterContent };
	}

	private void addInMap(Map<HetSpecies, Double> map, HetSpecies sp, double value) {
		double sum = 0;
		Double v = map.get(sp);
		if (v != null)
			sum = v;
		sum += value;
		map.put(sp, sum);

	}

	/**
	 * Returns a double array with 2 values: evaporation then
	 * canopyAirConductance.
	 */
	private double[] estimateFoliageEvaporation(double leafAbsorbedRadiationProportion, double leafAreaIndex,
			HetMeteoLine line, double hDom, double midCanopyHeight, double windSpeedMeasurementHeight,
			double windSpeedAttenuationCoefficient, double averageLeafWidth) { // fa-17.12.2019: added averageLeafWidth

		// fc+mj+fa-15.2.2017 W/m2
		// double leafRadiation_m2leaf = leafAbsorbedRadiationProportion *
		// line.radiation / leafAreaIndex;
		// fc+mj+fa REMOVED / leafAreaIndex
		double leafRadiation_m2leaf = leafAbsorbedRadiationProportion * line.radiation;

		double dominantHeightWindSpeed = calculateDominantHeightWindSpeed(windSpeedMeasurementHeight, line.windSpeed,
				hDom);

		double n = 10;
//		double meanLeafWidth = 0.04; // m, to be reviewed // fa-17.12.2019: commented, meanLeafWidth is now a species specific parameter

		// // fc+mj+fa+lw-15.2.2017
		// double midCanopyHeight = (hDom + canopyBaseHeight) / 2d;

		double deltaHeight = (hDom - midCanopyHeight) / n;
		double sum = 0;
		for (int i = 0; i <= n; i++) {
			double h = midCanopyHeight + i * deltaHeight; // m
			double ws = windSpeedFunction(dominantHeightWindSpeed, hDom, h, windSpeedAttenuationCoefficient); // m/s
//			double airConductance = 0.006 * Math.sqrt(ws / meanLeafWidth);
			double airConductance = 0.006 * Math.sqrt(ws / averageLeafWidth); // fa-17.12.2019
			sum += airConductance;
		}
		double canopyAirConductance = sum / (n + 1);
		double airResistance = 1d / canopyAirConductance;

		double surfaceResistance = 0;

		double latentHeat = penmanMonteith(leafRadiation_m2leaf, line.airTemperature, line.relativeHumidity,
				line.windSpeed, airResistance, surfaceResistance);

		final double LAMBDA = 2454000d; // J/kg
		final double WATER_DENSITY = 998d; // kg/m3

		double evaporation = (latentHeat / LAMBDA) / WATER_DENSITY * 1000d * 60d * 60d; // l/h

		return new double[] { evaporation, canopyAirConductance };

	}

	/**
	 * Compute windSpeed at given height.
	 */
	private double windSpeedFunction(double dominantHeightWindSpeed, double hDom, double h,
			double windSpeedAttenuationCoefficient) {
		double ws = dominantHeightWindSpeed * Math.exp(-windSpeedAttenuationCoefficient * (1 - h / hDom));
		return ws;
	}

	// MOVED to SLModel fc-20.1.2017
	// private boolean isVegetationPeriod(int doy) {
	// return doy >= slModel.getSettings().leafOnDoy && doy <=
	// slModel.getSettings().leafOffDoy;
	// }

	private Map<HetSpecies, Double> estimateBarkEvaporation(Set<HetSpecies> speciesList,
			Map<HetSpecies, Double> prevBarkStorage_sp, Map<HetSpecies, Double> barkStorageCapacity_sp,
			double barkRadiation_m2bark, double barkAreaIndex, HetMeteoLine line, double hDom,
			double windSpeedMeasurementHeight, double windSpeedAttenuationCoefficient, double averageLeafWidth) { // fa-17.12.2019: added averageLeafWidth

		double dominantHeightWindSpeed = calculateDominantHeightWindSpeed(windSpeedMeasurementHeight, line.windSpeed,
				hDom);

		double n = 10;
//		double meanLeafWidth = 0.04; // m, to be reviewed // fa-17.12.2019: meanLeafWidth is now a species specific parameter

		double halfHDom = hDom / 2d;

		double deltaHeight = (hDom - halfHDom) / n;
		double sum = 0;
		for (int i = 0; i <= n; i++) {
			double h = halfHDom + i * deltaHeight; // m
			double ws = windSpeedFunction(dominantHeightWindSpeed, hDom, h, windSpeedAttenuationCoefficient); // m/s
//			double airConductance = 0.006 * Math.sqrt(ws / meanLeafWidth);
			double airConductance = 0.006 * Math.sqrt(ws / averageLeafWidth); // fa-17.12.2019
			sum += airConductance;
		}
		double canopyAirConductance = sum / (n + 1);
		double airResistance = 1d / canopyAirConductance;

		//
		Map<HetSpecies, Double> map = new HashMap<>();

		for (HetSpecies sp : speciesList) {

			double surfaceConductance = 0;

			if (barkStorageCapacity_sp.get(sp) != 0) {
				surfaceConductance = sp.minBarkConductance + (sp.maxBarkConductance - sp.minBarkConductance)
						* prevBarkStorage_sp.get(sp) / barkStorageCapacity_sp.get(sp);
			} else {
				surfaceConductance = sp.minBarkConductance;
			}

			double surfaceResistance = 1d / surfaceConductance;
			// double surfaceResistance = 0;

			double latentHeat = penmanMonteith(barkRadiation_m2bark, line.airTemperature, line.relativeHumidity,
					line.windSpeed, airResistance, surfaceResistance);

			final double LAMBDA = 2454000d; // J/kg
			final double WATER_DENSITY = 998d; // kg/m3

			double evaporation = (latentHeat / LAMBDA) / WATER_DENSITY * 1000d * 60d * 60d; // l/h

			map.put(sp, evaporation);
		}

		return map;
	}

//	private Map<HetSpecies, Double> createStandBarkEvaporation(Map<HetSpecies, Double> barkEvaporation_sp_m2_bark,
//			Map<HetSpecies, Double> barkArea_sp, Map<HetSpecies, Double> prevBarkStorage_sp) {
	private Map<HetSpecies, Double> computeStandBarkEvaporation(Map<HetSpecies, Double> barkEvaporation_sp_m2_bark,	
			Map<HetSpecies, Double> barkArea_sp, Map<HetSpecies, Double> prevBarkStorage_sp, Map<HetSpecies, Double> barkEvaporation_sp) { //fa-19.11.2019

//		Map<HetSpecies, Double> sbe = new HashMap<HetSpecies, Double>();
		for (HetSpecies sp : barkEvaporation_sp_m2_bark.keySet()) {
			double v = barkEvaporation_sp_m2_bark.get(sp);
			v *= barkArea_sp.get(sp);
			v = Math.min(v, prevBarkStorage_sp.get(sp));
//			sbe.put(sp, v);
			barkEvaporation_sp.put(sp, v); // fa-19.11.2019
		}
//		return sbe;
		return barkEvaporation_sp;	// fa-19.11.2019
	}

	// mj+fa- 10.08.2017: include coefEvalMap in arguments (improve computing
	// efficiency by avoiding to recreate the coefEval every hour, see above)
	// fa-18.06.2019: added hwcCalculator & prevHorizonsWaterContent
	private double[] hourlyTreesTranspiration(HetScene refScene, Pedon refPedon, HetScene newScene, Pedon newPedon, HetMeteoLine line, // fa-15.11.2019: added refPedon & newPedon
			double barkAbsorbedRadiation, double slIncidentGlobalRadiation, double hDom,
			double windSpeedMeasurementHeight, double windSpeedAttenuationCoefficient,
			double prevRelativeExtractableWater, HashMap<String, HetAbsorptionCoefficientEvaluator> coefEvalMap,
			HetHorizonsWaterContentCalculator hwcCalculator, Map<Integer, Double> prevHorizonsWaterContent, double averageLeafWidth) // fa-17.12.2019: added averageLeafWidth
			throws Exception {

		double hourlyTranspiration_stand = 0; // sum for all trees
		double potentialHourlyTranspiration_stand = 0d; // fa-21.10.2019: for F.
														// Joussemet

//		for (Tree t : refScene.getTrees()) {
		for (Tree t : refPedon.getTrees(refScene)) { // fa-15.11.2019
			HetTree refTree = (HetTree) t;

			HetSpecies sp = refTree.getSpecies();

			// fc+mj-10.3.2017
			if (refTree.getLeafArea() <= 0)
				continue; // tree transpiration = 0, next tree

			double treeBranchAbsorbedRadiation = barkAbsorbedRadiation * refTree.getBranchBarkArea();
			double treeCrownAbsorbedRadiation = refTree.getLightResult().getCrownEnergy() * (1 - 0.11);
			double treeLeafAbsorbedRadiation = treeCrownAbsorbedRadiation;// -
																			// treeBranchAbsorbedRadiation;

			// MJ/tree/year / MJ/m�/year
			double treeLeafAbsorbedRadiationCoefficient = treeLeafAbsorbedRadiation / slIncidentGlobalRadiation;

			// mj+fa+lw-8.9.2017
			// Get doy
			Calendar cal = new GregorianCalendar();
			cal.set(line.year, line.month - 1, line.day); // month in [0,11]
			int month = cal.get(Calendar.MONTH);
			int doy = cal.get(Calendar.DAY_OF_YEAR);

			// fa-13.09.2016: Initialize ladProp and greenProp to 1. Much more
			// efficient in case phenology is not activated. It avoids passing
			// through exception cases returning 1 in getLadProportionOfNextYear
			// and getGreenProportionOfNextYear when pheno is not found (see
			// HetScene), which save execution time.
			double ladProp = 1;
			double greenProp = 1;

			if (ip.phenologyActivated) { // fa-13.9.217: ladProp and greenProp
											// are computed only when phenology
											// mode is activated
				SLFoliageStateManager foliageStateManager = (SLFoliageStateManager) refScene;
				// Calculates ladProp at tree level. nb-06.11.2019
				// ladProp =
				// foliageStateManager.getLadProportionOfNextYear(refTree.getSpeciesCode(),
				// doy);
				ladProp = foliageStateManager.getLadProportionOfNextYear(refTree.getId(), doy);
				greenProp = foliageStateManager.getGreenProportionOfNextYear(refTree.getId(), doy);
			}

			if (ip.fineResolutionRadiativeBalanceActivated) {
				// mj+fa+lw-8.9.2017: moved above
				// // Get doy
				// Calendar cal = new GregorianCalendar();
				// cal.set(line.year, line.month - 1, line.day); // month in
				// [0,11]
				// int month = cal.get(Calendar.MONTH);
				// int doy = cal.get(Calendar.DAY_OF_YEAR);
				// SLFoliageStateManager foliageStateManager =
				// (SLFoliageStateManager) refScene;
				// ladProp =
				// foliageStateManager.getLadProportion(tree.getSpeciesCode(),
				// doy);
				// greenProp =
				// foliageStateManager.getGreenProportion(tree.getSpeciesCode(),
				// doy);

				// HetAbsorptionCoefficientEvaluator coefEval = new
				// HetAbsorptionCoefficientEvaluator(tree, refScene,
				// refScene.getVegetationPeriod(),
				// refScene.getBeamSetFactory().getAverageRadiation());

				String treeId = "tree" + refTree.getId();
				HetAbsorptionCoefficientEvaluator coefEval = coefEvalMap.get(treeId);

				double crownDirectCoefficient = coefEval.getCrownDirectCoefficient(doy, line.hour);
				double crownDiffuseCoefficient = coefEval.getCrownDiffuseCoefficient(doy, line.hour);

				double crownGlobalCoefficient = crownDirectCoefficient * (1 - line.diffuseToGlobalRatio)
						+ crownDiffuseCoefficient * line.diffuseToGlobalRatio;

				treeLeafAbsorbedRadiationCoefficient = crownGlobalCoefficient;

			}

			// fc+mj+fa-15.2.2017 W/m2
			double treeLeafRadiation_m2leaf = treeLeafAbsorbedRadiationCoefficient * line.radiation
					/ refTree.getLeafArea();

			// fc+mj+fa-31.7.2017 added greenProp
			if (ladProp == 0 || greenProp == 0)
				// treeLeafRadiation_m2leaf = 0;
				continue; // mj+fa-8.9.2017: tree transpiration = 0, next tree
			else
				treeLeafRadiation_m2leaf /= greenProp;

			double dominantHeightWindSpeed = calculateDominantHeightWindSpeed(windSpeedMeasurementHeight,
					line.windSpeed, hDom);

			double n = 10;
//			double meanLeafWidth = 0.04; // m, to be reviewed // fa-17.12.2019: meanLeafWidth is now a species specific parameter

			double deltaHeight = (hDom - refTree.getHlce()) / n;
			double sum = 0;
			for (int i = 0; i <= n; i++) {
				double h = refTree.getHlce() + i * deltaHeight; // m
				double ws = windSpeedFunction(dominantHeightWindSpeed, hDom, h, windSpeedAttenuationCoefficient); // m/s
//				double airConductance = 0.006 * Math.sqrt(ws / meanLeafWidth);
				double airConductance = 0.006 * Math.sqrt(ws / averageLeafWidth); // fa-17.12.2019
				sum += airConductance;
			}
			double treeAirConductance = sum / (n + 1);
			double airResistance = 1d / treeAirConductance;

			double radiationModifier = 1;
			// if (line.radiation != 0)
			if (line.radiation != 0 & treeLeafAbsorbedRadiationCoefficient != 0) // fa-23.09.2019:
																					// in
																					// Tag
																					// mode,
																					// treeLeafAbsorbedRadiationCoefficient
																					// =
																					// 0
																					// may
																					// occur
																					// even
																					// with
																					// line.radiation
																					// !=
																					// 0
																					// (if
																					// crownDirectCoeeficient
																					// and
																					// crownDiffuseCoefficient
																					// are
																					// ==
																					// 0)
				radiationModifier = sp.radiationModifier.result(treeLeafRadiation_m2leaf); // mj+fa-17.06.2019
			// radiationModifier = line.radiation / (line.radiation + 82);
			// radiationModifier = treeLeafRadiation_m2leaf /
			// (treeLeafRadiation_m2leaf + 37.20);// MJ
			// +
			// FA
			// 10.11.2017

			double vaporPressureDeficit = computeVaporPressureDeficit(line.airTemperature, line.relativeHumidity);
			double vaporPressureDeficitModifier = 1;
			if (vaporPressureDeficit > 0) // mj+fa-02.03.2017
				// vaporPressureDeficitModifier = 1 - 0.2511 *
				// Math.log(vaporPressureDeficit);
				// vaporPressureDeficitModifier = 1 - 0.123 *
				// Math.log(vaporPressureDeficit);
				vaporPressureDeficitModifier = sp.vpdModifier.result(vaporPressureDeficit); // mj+fa-17.06.2019

			// Soil water content modifier
			// double soilWaterContentModifier = 0.1;
			// double soilWaterContentModifier = 0.7;
			// double soilWaterContentModifier = 1.05 + 0.59 *
			// Math.log10(prevRelativeExtractableWater);

			// double rewSensitivity = -8.94;
			// double rewSensitivity_oak = -11.14; // mj+fa-13.12.2017
			// double rewSensitivity_beech = -2.15; // mj+fa-13.12.2017

			// prevRelativeExtractableWater =
			// Math.max(prevRelativeExtractableWater,
			// Math.pow(10,-1d/rewSensitivity)); // mj+fa-8.9.2017:
			// to
			// avoid
			// zero
			// value
			// in
			// log10
			// below

			// double soilWaterContentModifier = Math.min(1, 1 + rewSensitivity
			// * Math.log10(prevRelativeExtractableWater)); // from
			// Granier
			// (1996),
			// original
			// is
			// 1.05
			// +
			// 0.59
			// *
			// Math.log10(prevRelativeExtractableWater))

			// double soilWaterContentModifier = 1 - Math.exp(rewSensitivity *
			// (prevRelativeExtractableWater));
			// mj+fa-13.12.2017
			// double soilWaterContentModifier = 1 -
			// Math.exp(rewSensitivity_beech * (prevRelativeExtractableWater));
			// if (sp.getName().equals("quercus"))
			// soilWaterContentModifier = 1 - Math.exp(rewSensitivity_oak *
			// (prevRelativeExtractableWater));

			// fa-18.06.2019

			// fc-13.11.2019
//			double weightedMeanPrevWaterPotential = hwcCalculator.calculateWeightedMeanWaterPotential(
//					newScene.getSoil().getPedonSpecimen().getHorizonMap(), prevHorizonsWaterContent);
			double weightedMeanPrevWaterPotential = hwcCalculator.calculateWeightedMeanWaterPotential(
					newPedon.getHorizonMap(), prevHorizonsWaterContent); // fa-15.11.2019
			// double weightedMeanPrevWaterPotential =
			// hwcCalculator.calculateWeightedMeanWaterPotential(newScene.getSoil().getHorizonMap(),
			// prevHorizonsWaterContent);

			double soilPf = Math.log10(weightedMeanPrevWaterPotential);
			double soilWaterContentModifier = sp.swcModifier.result(soilPf); // mj+fa-17.06.2019

			soilWaterContentModifier = Math.max(soilWaterContentModifier, 0);

			double DBH_sapwood = (refTree.getDbh() - refTree.getPastDbh(sp.sapwoodYearNumber));
			double amplifier = DBH_sapwood / (sp.defaultDeltaDbh * sp.sapwoodYearNumber);
			// double sapwoodArea =
			// sp.sapwoodArea.result(refTree.getDbh())*amplifier;
			double sapwoodArea = sp.sapwoodArea.result(refTree.getDbh());
			double basalArea = refTree.getDbh() / 2d * refTree.getDbh() / 2d * Math.PI;
			sapwoodArea = Math.min(sapwoodArea, basalArea);

			// mj+fa14.12.2017: commented
			// double canopyStomatalConductance =
			// sp.basicCanopyStomatalConductance
			// * sp.sapwoodArea.result(refTree.getDbh()) / 10000d /
			// refTree.getLeafArea() * 1d // fa-02.03.2017
			// // /10000d
			// / refTree.getHlce() * radiationModifier *
			// vaporPressureDeficitModifier * soilWaterContentModifier; //
			//
			// double potentialCanopyStomatalConductance =
			// sp.basicCanopyStomatalConductance
			// * sp.sapwoodArea.result(refTree.getDbh()) / 10000d /
			// refTree.getLeafArea() * 1d // fa-02.03.2017
			// // /10000d
			// / refTree.getHlce() * radiationModifier *
			// vaporPressureDeficitModifier * 1.0; //
			// mj+fa14.12.2017: commented

			// mj+fa14.12.2017
			double canopyStomatalConductance = sp.basicCanopyStomatalConductance * sapwoodArea / 10000d
					/ refTree.getLeafArea() * 1d // fa-02.03.2017
													// /10000d
					/ refTree.getHlce() * radiationModifier * vaporPressureDeficitModifier * soilWaterContentModifier; //

			double potentialCanopyStomatalConductance = sp.basicCanopyStomatalConductance * sapwoodArea / 10000d
					/ refTree.getLeafArea() * 1d // fa-02.03.2017
													// /10000d
					/ refTree.getHlce() * radiationModifier * vaporPressureDeficitModifier * 1.0; //
			// Granier
			// // and
			// // Breda
			// // 1996

			// double canopyStomatalConductance = 41884d *
			// sp.sapwoodToLeafAreaRatio * 1d / tree.getHlce()
			// * radiationModifier * vaporPressureDeficitModifier *
			// soilWaterContentModifier; // Granier and Breda 1996

			// double canopyStomatalConductance = 0.2412 - 0.2769 * (Math.log
			// (vaporPressureDeficit) - 1.8) + 0.00044
			// * (line.radiation - 232) + 0.1693 * (0.5 - 0.6); // from Jonard
			// et al. 2011

			final double LAMBDA = 2454000d; // J/kg
			final double WATER_DENSITY = 998d; // kg/m3

			double transpiration_tree = 0;

			if (canopyStomatalConductance != 0) {

				double surfaceResistance = 1d / canopyStomatalConductance;

				// W/m2 = J/s/m2
				double latentHeat = penmanMonteith(treeLeafRadiation_m2leaf, line.airTemperature, line.relativeHumidity,
						line.windSpeed, airResistance, surfaceResistance);

				// hourly transpiration for the tree
				transpiration_tree = (latentHeat / LAMBDA) / WATER_DENSITY * 1000d * 60d * 60d * refTree.getLeafArea()
						* greenProp; // l/h
			}

			// fc-14.11.2017
			// System.out.println("HetWaterBalanceCalculator
			// canopyStomatalConductance: " + canopyStomatalConductance
			// + " transpiration_tree: " + transpiration_tree);

			double potentialSurfaceResistance = 1.0 / potentialCanopyStomatalConductance;
			// W/m2 = J/s/m2
			double potentialLatentHeat = penmanMonteith(treeLeafRadiation_m2leaf, line.airTemperature,
					line.relativeHumidity, line.windSpeed, airResistance, potentialSurfaceResistance);

			// nb+mj-15.09.2017
			// hourly potential transpiration for the tree
			double potentialTranspiration_tree = (potentialLatentHeat / LAMBDA) / WATER_DENSITY * 1000d * 60d * 60d
					* refTree.getLeafArea() * greenProp; // l/h

			// nb-18.09.2017
			// add it to the yearly transpiration for the tree
			// double yt = refTree.getYearlyTranspiration();
			double yt = yearlyTranspirationMemory.getYearlyTranspiration(refTree.getId());

			// fc+mj+fa-newTree does not exist yet, store transpiration value
			// for later
			yearlyTranspirationMemory.storeYearlyTranspiration(refTree.getId(), yt + transpiration_tree);

			// nb-18.09.2017
			// nb+mj-15.09.2017
			// double ypt = refTree.getYearlyPotentialTranspiration();
			double ypt = yearlyTranspirationMemory.getYearlyPotentialTranspiration(refTree.getId());

			// fc+mj+fa-newTree does not exist yet, store transpiration value
			// for later
			yearlyTranspirationMemory.storeYearlyPotentialTranspiration(refTree.getId(),
					ypt + potentialTranspiration_tree);

			// fa-17.09.2019
			if (ip.treesWithSapflow.contains(refTree.getId())) { // only trees
																	// for which
																	// sapflow
																	// measurements
																	// are
																	// available
				HetHourlyTreeTranspiration htt = new HetHourlyTreeTranspiration(refTree.getId(), line.year, line.month,
						line.day, line.hour, transpiration_tree, potentialTranspiration_tree);
				String key = "" + refTree.getId() + "_" + line.year + "_" + line.month + "_" + line.day + "_"
						+ line.hour;
				newScene.hourlyTreeTranspirationMap.put(key, htt);
			}

			if (Double.isNaN(transpiration_tree)) {
				HetReporter.printInStandardOutput("HetWaterBalanceCalculator, transpiration_tree: NaN");
			}

			if (Double.isNaN(potentialTranspiration_tree)) {
				HetReporter.printInStandardOutput("HetWaterBalanceCalculator, potentialTranspiration_tree: NaN");
			}

			// add it to the hourly transpiration for all trees
			hourlyTranspiration_stand += transpiration_tree;
			potentialHourlyTranspiration_stand += potentialTranspiration_tree; // fa-21.10.2019:
																				// for
																				// F.
																				// Joussemet
		}

		// return hourlyTranspiration_stand;
		return new double[] { hourlyTranspiration_stand, potentialHourlyTranspiration_stand }; // fa-21.10.2019:
																								// for
																								// F.
																								// Joussemet
	}

	private double hourlyStandTranspiration(HetScene refScene, Pedon refPedon, Pedon newPedon, double leafAreaIndex, HetMeteoLine line,	// fa-15.11.2019: added newPedon
			double prevRelativeExtractableWater, double ladProp_stand, double greenProp_stand,
			double canopyAirConductance, double leafArea_stand, double sapwoodArea_stand, double midCanopyHeight,
			double extinctionCoefficient, double meanBasicCanopyStomatalConductance_stand,
			HetHorizonsWaterContentCalculator hwcCalculator, Map<Integer, Double> prevHorizonsWaterContent) {

		if (ladProp_stand == 0 || greenProp_stand == 0)
			return 0;

		double leafRadiation_m2leaf = (1 - 0.11) * line.radiation
				* (1 - Math.exp(-extinctionCoefficient * leafAreaIndex * ladProp_stand * greenProp_stand))
				/ (leafAreaIndex * greenProp_stand);

		double airResistance = 1d / canopyAirConductance;

		// mj+fa-18.06.2019
		HetInitialParameters ip = (HetInitialParameters) refScene.getStep().getProject().getModel().getSettings();
		Map<Integer, HetSpecies> speciesMap = ip.getSpeciesMap();

		double radiationModifier = 1d;
		if (line.radiation != 0) {
			radiationModifier = 0d;
			
			// mj+fa-21.11.2019
			for (Iterator it = refPedon.getTrees(refScene).iterator(); it.hasNext();) {
				HetTree refTree = (HetTree) it.next();
				HetSpecies species = refTree.getSpecies();
				radiationModifier += refTree.getLeafArea() * species.radiationModifier.result(leafRadiation_m2leaf)
						/ leafArea_stand;
			}
//			for (HetSpecies species : speciesMap.values()) {
//				radiationModifier += species.leafArea_sp * species.radiationModifier.result(leafRadiation_m2leaf)
//						/ leafArea_stand;
//			}
		}

		// radiationModifier = line.radiation / (line.radiation + 82);
		// radiationModifier = leafRadiation_m2leaf / (leafRadiation_m2leaf +
		// 37.20);// MJ
		// +
		// FA
		// 10.11.2017

		double vaporPressureDeficit = computeVaporPressureDeficit(line.airTemperature, line.relativeHumidity);
		double vaporPressureDeficitModifier = 1;
		if (vaporPressureDeficit > 0) {// mj+fa-18.06.2019
			vaporPressureDeficitModifier = 0d;
			
			// mj+fa-21.11.2019
			for (Iterator it = refPedon.getTrees(refScene).iterator(); it.hasNext();) {
				HetTree refTree = (HetTree) it.next();
				HetSpecies species = refTree.getSpecies();
				vaporPressureDeficitModifier += refTree.getLeafArea() * species.vpdModifier.result(vaporPressureDeficit)
						/ leafArea_stand;
			}
//			for (HetSpecies species : speciesMap.values()) {
//				vaporPressureDeficitModifier += species.leafArea_sp * species.vpdModifier.result(vaporPressureDeficit)
//						/ leafArea_stand;
//			}
		}
		// vaporPressureDeficitModifier = 1 - 0.2512 *
		// Math.log(vaporPressureDeficit);
		// vaporPressureDeficitModifier = 1 - 0.123 *
		// Math.log(vaporPressureDeficit);

		// double rewSensitivity_oak = -11.14; // mj+fa-13.12.2017
		// double rewSensitivity_beech = -2.15; // mj+fa-13.12.2017

		// fa+mj - 23.03.2018
		// HetInitialParameters ip = (HetInitialParameters)
		// refScene.getStep().getProject().getModel().getSettings();
		// Map<Integer, HetSpecies> speciesMap = ip.getSpeciesMap();
		// double leafAreaOak = 0d;
		// double leafAreaBeech = 0d;
		// for (HetSpecies species : speciesMap.values()) {
		// if (species.getId() == 1) // oak
		// leafAreaOak = species.leafArea_sp;
		// if (species.getId() == 2) // beech
		// leafAreaBeech = species.leafArea_sp;
		// }
		// double rewSensitivity = -8.94; // for species other than oak and
		// beech
		// if ((leafAreaOak + leafAreaBeech) != 0d)
		// rewSensitivity = (leafAreaOak * rewSensitivity_oak + leafAreaBeech *
		// rewSensitivity_beech)
		// / (leafAreaOak + leafAreaBeech);

		// prevRelativeExtractableWater =
		// Math.max(prevRelativeExtractableWater,
		// Math.pow(10,-1d/rewSensitivity)); // mj+fa-8.9.2017:
		// to
		// avoid
		// zero
		// value
		// in
		// log10
		// below

		// double soilWaterContentModifier = Math.min(1, 1 + rewSensitivity
		// * Math.log10(prevRelativeExtractableWater)); // from
		// Granier
		// (1996),
		// original
		// is
		// 1.05
		// +
		// 0.59
		// *
		// Math.log10(prevRelativeExtractableWater))

		// double soilWaterContentModifier = 1 - Math.exp(rewSensitivity *
		// (prevRelativeExtractableWater));

		// fa-18.06.2019

		// fc-13.11.2019
//		double weightedMeanPrevWaterPotential = hwcCalculator.calculateWeightedMeanWaterPotential(
//				newScene.getSoil().getPedonSpecimen().getHorizonMap(), prevHorizonsWaterContent);
		double weightedMeanPrevWaterPotential = hwcCalculator.calculateWeightedMeanWaterPotential(
				newPedon.getHorizonMap(), prevHorizonsWaterContent);	// fa-15.11.2019
		// double weightedMeanPrevWaterPotential =
		// hwcCalculator.calculateWeightedMeanWaterPotential(newScene.getSoil().getHorizonMap(),
		// prevHorizonsWaterContent);

		double soilPf = Math.log10(weightedMeanPrevWaterPotential);
		double soilWaterContentModifier = 0d;
		
		// mj+fa-21.11.2019
		for (Iterator it = refPedon.getTrees(refScene).iterator(); it.hasNext();) {
			HetTree refTree = (HetTree) it.next();
			HetSpecies species = refTree.getSpecies();
			soilWaterContentModifier += refTree.getLeafArea() * species.swcModifier.result(soilPf) / leafArea_stand;
		}
//		for (HetSpecies species : speciesMap.values()) {
//			soilWaterContentModifier += species.leafArea_sp * species.swcModifier.result(soilPf) / leafArea_stand;
//		}

		// double soilWaterContentModifier = 1 -
		// Math.exp(rewSensitivity*(prevRelativeExtractableWater));

		soilWaterContentModifier = Math.max(soilWaterContentModifier, 0);

		double canopyStomatalConductance = meanBasicCanopyStomatalConductance_stand * sapwoodArea_stand / 10000d
				/ leafArea_stand * 1d // fa-02.03.2017
										// /10000d
				/ midCanopyHeight * radiationModifier * vaporPressureDeficitModifier * soilWaterContentModifier; // fa-29.09.2017

		double evaporation = 0;

		if (canopyStomatalConductance != 0) {

			double surfaceResistance = 1d / canopyStomatalConductance;

			double latentHeat = penmanMonteith(leafRadiation_m2leaf, line.airTemperature, line.relativeHumidity,
					line.windSpeed, airResistance, surfaceResistance);

			final double LAMBDA = 2454000d; // J/kg
			final double WATER_DENSITY = 998d; // kg/m3

			evaporation = (latentHeat / LAMBDA) / WATER_DENSITY * 1000d * 60d * 60d; // l/h

		}
		return evaporation;

	}

	// fc+mj-12.9.2017
	// fc+mj-12.9.2017
	// fc+mj-12.9.2017
	private double estimateGroundVegetationTranspiration(HetScene refScene, Pedon newPedon, double groundVegetationRadiation_m2leaf, // fa-15.11.2019: added newPedon
			HetMeteoLine line, double prevRelativeExtractableWater, double ladProp_stand, double greenProp_stand,
			double groundAirConductance, HetHorizonsWaterContentCalculator hwcCalculator,
			Map<Integer, Double> prevHorizonsWaterContent) { // mj+fa-18.06.2019:
																// added
																// leafArea_stand,
																// hwcCalculator
																// &
																// prevHorizonsWaterContent

		double sceneLeafArea = refScene.getLeafArea(); // mj+fa-04.12.2019
		
		if (ladProp_stand == 0 || greenProp_stand == 0)
			return 0;

		double airResistance = 1d / groundAirConductance;

		// mj+fa-18.06.2019
		HetInitialParameters ip = (HetInitialParameters) refScene.getStep().getProject().getModel().getSettings();
		Map<Integer, HetSpecies> speciesMap = ip.getSpeciesMap();

		double radiationModifier = 1d;
//		if (line.radiation != 0) { // mj+fa-18.06.2019
		if (groundVegetationRadiation_m2leaf != 0) { // fa-25.11.2019
			radiationModifier = 0d;
			for (HetSpecies species : speciesMap.values()) {
//				radiationModifier += species.leafArea_sp // fa-17.12.2019: commented, moved species leaf area from HetSpecies to HetScene
				radiationModifier += refScene.getSpeciesLeafAreaMap().get(species.getId()) // fa-17.12.2019
						* species.radiationModifier.result(groundVegetationRadiation_m2leaf) / sceneLeafArea; // mj+fa-04.12.2019
//						* species.radiationModifier.result(groundVegetationRadiation_m2leaf) / leafArea_stand;
			}
		}

		// radiationModifier = groundVegetationRadiation_m2leaf /
		// (groundVegetationRadiation_m2leaf + 37.20);

		double vaporPressureDeficit = computeVaporPressureDeficit(line.airTemperature, line.relativeHumidity);
		double vaporPressureDeficitModifier = 1d;
		if (vaporPressureDeficit > 0) {// mj+fa-18.06.2019
			vaporPressureDeficitModifier = 0d;
			for (HetSpecies species : speciesMap.values()) {
//				vaporPressureDeficitModifier += species.leafArea_sp * species.vpdModifier.result(vaporPressureDeficit) // fa-17.12.2019: commented, moved species leaf area from HetSpecies to HetScene
				vaporPressureDeficitModifier += refScene.getSpeciesLeafAreaMap().get(species.getId()) * species.vpdModifier.result(vaporPressureDeficit) // fa-17.12.2019
						/ sceneLeafArea; // mj+fa-04.12.2019
//						/ leafArea_stand;
			}
		}
		// vaporPressureDeficitModifier = 1 - 0.2512 *
		// Math.log(vaporPressureDeficit);
		// vaporPressureDeficitModifier = 1 - 0.123 *
		// Math.log(vaporPressureDeficit);

		// double rewSensitivity = -8.94;

		// prevRelativeExtractableWater = Math.max(prevRelativeExtractableWater,
		// Math.pow(10,-1d/rewSensitivity)); // mj+fa-8.9.2017:
		// to
		// avoid
		// zero
		// value
		// in
		// log10
		// below

		// double soilWaterContentModifier = Math.min(1, 1 + rewSensitivity *
		// Math.log10(prevRelativeExtractableWater)); // from
		// Granier
		// (1996),
		// original
		// is
		// 1.05
		// +
		// 0.59
		// *
		// Math.log10(prevRelativeExtractableWater))

		// fa-18.06.2019

		// fc-13.11.2019
//		double weightedMeanPrevWaterPotential = hwcCalculator.calculateWeightedMeanWaterPotential(
//				newScene.getSoil().getPedonSpecimen().getHorizonMap(), prevHorizonsWaterContent);
		double weightedMeanPrevWaterPotential = hwcCalculator.calculateWeightedMeanWaterPotential(
				newPedon.getHorizonMap(), prevHorizonsWaterContent); // fa-15.11.2019
		// double weightedMeanPrevWaterPotential =
		// hwcCalculator.calculateWeightedMeanWaterPotential(newScene.getSoil().getHorizonMap(),
		// prevHorizonsWaterContent);

		double soilPf = Math.log10(weightedMeanPrevWaterPotential);
		double soilWaterContentModifier = 0d;
		for (HetSpecies species : speciesMap.values()) {
//			soilWaterContentModifier += species.leafArea_sp * species.swcModifier.result(soilPf) / sceneLeafArea; //mj+fa-04.12.2019 // fa-17.12.2019: commented, moved species leaf area from HetSpecies to HetScene
			soilWaterContentModifier += refScene.getSpeciesLeafAreaMap().get(species.getId()) * species.swcModifier.result(soilPf) / sceneLeafArea; // fa-17.12.2019
//			soilWaterContentModifier += species.leafArea_sp * species.swcModifier.result(soilPf) / leafArea_stand;
		}

		// double soilWaterContentModifier = 1 - Math.exp(rewSensitivity *
		// (prevRelativeExtractableWater));

		soilWaterContentModifier = Math.max(soilWaterContentModifier, 0);

		// Granier and Breda 1996
		double groundVegetation_sapwoodToLeafAreaRatio = 0.00001;
		double groundVegetation_midHeight = 1; // m
		double canopyStomatalConductance = 420d * groundVegetation_sapwoodToLeafAreaRatio * 1d // fa-02.03.2017
																								// /10000d
				/ groundVegetation_midHeight * radiationModifier * vaporPressureDeficitModifier
				* soilWaterContentModifier;

		double evaporation = 0;

		if (canopyStomatalConductance != 0) {

			double surfaceResistance = 1d / canopyStomatalConductance;

			double latentHeat = penmanMonteith(groundVegetationRadiation_m2leaf, line.airTemperature,
					line.relativeHumidity, line.windSpeed, airResistance, surfaceResistance);

			final double LAMBDA = 2454000d; // J/kg
			final double WATER_DENSITY = 998d; // kg/m3

			evaporation = (latentHeat / LAMBDA) / WATER_DENSITY * 1000d * 60d * 60d; // l/h/m2
		}
		
		return evaporation;

	}

	/**
	 * Returns the mean of the cells totalSlopeEnergy (in MJ/m2)
	 */
//	private double calculateSoilRadiation(HetScene refScene) {
	private double calculateSoilRadiation(HetScene refScene, Pedon refPedon) { // fa-15.11.2019

		double soilRadiation = 0d; // fa-15.11.2019
		
		if (refPedon.getPedonId() <= 0) { //fa-15.11.2019: stand- or remainingPedon
			double sum = 0;

			HetPlot plot = (HetPlot) refScene.getPlot();
			for (SquareCell c : plot.getCells()) {
				HetCell cell = (HetCell) c;

				SLTargetLightResult cellLight = cell.getLightResult();
				sum += cellLight.get_slopeEnergy();

			}

			soilRadiation = sum / plot.getCells().size();
//			return sum / plot.getCells().size(); // fa-15.11.2019: commented
			
		} else { //fa-15.11.2019: treePedon 
			List<HetTree> trees = (List<HetTree>) refPedon.getTrees(refScene);
			HetTree tree = trees.get(0); // (single tree)
			HetCell cell = (HetCell) tree.getCell();
			
			soilRadiation = cell.getLightResult().get_slopeEnergy();
			
		}
		
		return soilRadiation; // fa-15.11.2019

	}

	private double calculateDominantHeightWindSpeed(double windSpeedMeasurementHeight, double windSpeed, double hDom) {
		double a = Math.log((50d - 0.08) / 0.015) / Math.log((windSpeedMeasurementHeight - 0.08) / 0.015);
		double b = Math.log((hDom - 0.75 * hDom) / (0.1 * hDom)) / Math.log((50d - 0.75 * hDom) / (0.1 * hDom));
		double dominantHeightWindSpeed = windSpeed * a * b; // Jetten 1996
		return dominantHeightWindSpeed;
	}

	/**
	 * Hourly soil evaporation.
	 */
	private double estimateSoilEvaporation(double soilRadiation, HetSoilInterface soil, HetMeteoLine line,
			double prevForestFloorRelativeExtractableWater, double groundAirConductance) {

		double airResistance = 1d / groundAirConductance;

		double surfaceConductance = 0;

		if (prevForestFloorRelativeExtractableWater >= 0) {
			surfaceConductance = soil.getMinSoilSurfaceConductance()
					+ (soil.getMaxSoilSurfaceConductance() - soil.getMinSoilSurfaceConductance())
							* prevForestFloorRelativeExtractableWater;
			surfaceConductance = Math.min(surfaceConductance, soil.getMaxSoilSurfaceConductance());
		} else {
			surfaceConductance = soil.getMinSoilSurfaceConductance();
		}

		double surfaceResistance = 1d / surfaceConductance;

		double latentHeat = penmanMonteith(soilRadiation, line.airTemperature, line.relativeHumidity, line.windSpeed,
				airResistance, surfaceResistance);

		final double LAMBDA = 2454000d; // J/kg
		final double WATER_DENSITY = 998d; // kg/m3

		double evaporation = (latentHeat / LAMBDA) / WATER_DENSITY * 1000d * 60d * 60d; // l/h/m�

		if (Double.isNaN(evaporation))
			HetReporter.printInStandardOutput(
					"HetWaterBalanceCalculator.estimateSoilEvaporation(), Double.isNaN(evaporation)");

		return evaporation;

	}

//	private double sumBarkEvaporation(Map<HetSpecies, Double> barkEvaporation_sp, double sceneArea) {
	private double sumBarkEvaporation(Map<HetSpecies, Double> barkEvaporation_sp, double pedonArea) { // fa-15.11.2019
		double sum = 0;
		for (HetSpecies sp : barkEvaporation_sp.keySet()) {
			double v = barkEvaporation_sp.get(sp);
//			sum += v / sceneArea;
			sum += v / pedonArea; // fa-15.11.2019
		}
		return sum;

	}

	/**
	 * Penman Monteith equation to compute latent heat. radiation (W/m2),
	 * airTemperature (Celsius), relativeHumidity (% or hPa / 100 hPa),
	 * windSpeed (m/s), airResistance & surfaceResistance (s/m)
	 */
	private double penmanMonteith(double radiation, double airTemperature, double relativeHumidity, double windSpeed,
			double airResistance, double surfaceResistance) { // fc+mj+lw-18.10.2016

		final double PSYCHOMETRIC_CONSTANT = 0.658; // mBar/K, Teh 2006
		final double SLOPE_SATURATED_VAPOR_PRESSURE_CURVE = 25029.4
				* Math.exp((17.269 * airTemperature) / (airTemperature + 237.3))
				/ ((airTemperature + 237.3) * (airTemperature + 237.3)); // mBar/K,
																			// Teh
																			// 2006
		final double MOIST_AIR_DENSITY = 1.209; // kg/m3
		final double MOIST_AIR_SPECIFIC_HEAT_CAPACITY = 1010; // J/kg/K

		double vaporPressureDeficit = computeVaporPressureDeficit(airTemperature, relativeHumidity);

		double latentHeat = (SLOPE_SATURATED_VAPOR_PRESSURE_CURVE * radiation
				+ (MOIST_AIR_DENSITY * MOIST_AIR_SPECIFIC_HEAT_CAPACITY * vaporPressureDeficit / airResistance))
				/ (SLOPE_SATURATED_VAPOR_PRESSURE_CURVE
						+ PSYCHOMETRIC_CONSTANT * (airResistance + surfaceResistance) / airResistance);

		return latentHeat; // W/m2

	}

	private double computeVaporPressureDeficit(double airTemperature, double relativeHumidity) {
		double saturatedVaporPressure = 6.1078 * Math.exp(17.269 * airTemperature / (airTemperature + 237.3));
		double vaporPressure = relativeHumidity / 100d * saturatedVaporPressure;
		double vaporPressureDeficit = saturatedVaporPressure - vaporPressure;
		return vaporPressureDeficit;
	}

	public HetYearlyTranspirationMemory getYearlyTranspirationMemory() {
		return yearlyTranspirationMemory;
	}
	
	// fa-25.11.2019
	public LinkedHashMap<String, HetWaterBalance> hourly2DailyWaterBalanceMap (Pedon pedon) throws Exception {
		
		LinkedHashMap<String, HetWaterBalance> hourlyWaterBalanceMap = pedon.getWaterBalanceMap();
		HetWaterBalanceIntegrator wbi = new HetWaterBalanceIntegrator(hourlyWaterBalanceMap, HetWaterBalanceIntegrator.DAY_LEVEL);
		LinkedHashMap<String, HetWaterBalance> dailyWaterBalanceMap = wbi.integrate();
		
		return dailyWaterBalanceMap;
	}

}
