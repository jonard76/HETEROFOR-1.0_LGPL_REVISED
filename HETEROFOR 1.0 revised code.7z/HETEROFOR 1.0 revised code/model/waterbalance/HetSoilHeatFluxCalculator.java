/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.waterbalance;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import heterofor.model.HetInitialParameters;
import heterofor.model.HetReporter;
import heterofor.model.HetScene;
import heterofor.model.meteorology.HetMeteoLine;
import heterofor.model.meteorology.HetMeteorology;
import heterofor.model.soil.HetHorizon;
import heterofor.model.soil.HetSoil;
import heterofor.model.soil.HetSoilInterface;
import heterofor.model.waterbalance.pedon.Pedon;

/**
 * This class contains methods to calculate heat flux through soil horizons over
 * a year. The soil profile is discretised using a constant dz space step.
 *
 * The heat flux in the organic layer of soil is calculated using : K*gradT,
 * where K is the thermal conductivity of the organic layer and gradT is the
 * temperature gradient over the organic layer.
 *
 * An explicit finite difference method is used to resolve the heat transfer
 * equation in the mineral layer of soil over a year. The time step is initially
 * hourly, given by the meteo lines step of the year and can be reduced to
 * respect the stability criterion of the explicit finite difference method.
 *
 * @author N. Beudez, L. de Wergifosse - April 2017
 */
public class HetSoilHeatFluxCalculator {

	/**
	 * The constant organic thermal conductivity.
	 */
	private final double organicThermalConductivity = 0.25;

	/**
	 * The space discretisation step for the mineral layer of soil.
	 */
	private double dz; // unit: m

	/**
	 * The soil reference.
	 */
	private HetSoilInterface hetSoil;

	/**
	 * Map with: - key: the index of a discretisation space point (from 0 to
	 * nbPoints-1 where nbPoints is the number of discretisation space points);
	 * - value: the list of horizon ids to which the space point belongs. It can
	 * be: - a single horizon id if the space point is strictly included between
	 * the upper and the lower values of an horizon; - 2 horizon ids if the
	 * space point is at the interface of these 2 horizons.
	 */
	private Map<Integer, List<Integer>> depthHorizonsMap;

	/**
	 * Map with: - key: the horizon id; - value: the list of index of
	 * discretisation space points (from 0 to nbPoints-1 where nbPoints is the
	 * number of discretisation space points) that belong to the horizon. Note:
	 * an index of discretisation space point can belong to 1 horizon (if it is
	 * stricly included between the upper and the lower values of an horizon) or
	 * 2 horizons (if it is at the interface of these 2 horizons).
	 */
	private Map<Integer, List<Integer>> horizonSpaceDiscretisationIndicesMap;

	/**
	 * Constructor
	 * 
	 * @param hetSoil
	 *            The soil reference
	 */
	public HetSoilHeatFluxCalculator(HetSoilInterface hetSoil) {
		this.hetSoil = hetSoil;
		depthHorizonsMap = new HashMap<Integer, List<Integer>>();
		horizonSpaceDiscretisationIndicesMap = new HashMap<Integer, List<Integer>>();
	}

	/**
	 * Processes some initializations of HetSoil class variables.
	 */
	public void init() {

		if (hetSoil.getOrganicLayerThickness() == HetSoil.NOT_SET) {
			double organicLayerThickness = hetSoil.calculateOrganicLayerThickness();
			hetSoil.setOrganicLayerThickness(organicLayerThickness);
		}

		if (hetSoil.getOrganicLayerBulkDensity() == HetSoil.NOT_SET) {
			double organicLayerBulkDensity = hetSoil.calculateOrganicLayerBulkDensity();
			hetSoil.setOrganicLayerBulkDensity(organicLayerBulkDensity);
		}
	}

	/**
	 * Calculate the heat flux in the organic soil layer and the temperature of
	 * each mineral soil horizon. Note: the calculation of the heat flux through
	 * the organic layer is called in
	 * {@link HetWaterBalanceCalculator#updateWaterBalance(HetInitialParameters, HetScene, HetScene, HetSoilHeatFluxCalculator)}.
	 * 
	 * @param refScene
	 *            The reference to the scene of the previous step
	 * @param newScene
	 *            The reference to the new scene
	 * @param meteoLines
	 *            The meteorological lines of the new year
	 * @param dateDailyAirTemperatureMap
	 *            The reference to the map with key: year_month_day string,
	 *            value: the average air temperature of the day
	 * @throws Exception
	 */
	public void run(HetScene refScene, HetScene newScene, ArrayList<HetMeteoLine> meteoLines,
			// LinkedHashMap<String, Double> dateDailyAirTemperatureMap) throws
			// Exception {
			LinkedHashMap<String, Double> soilInterfaceTemperatureMap) throws Exception { // fa-13.07.2017
		
		// fa-20.11.2019: MOVED here from below
		// It is not possible to obtain the initial parameters from the newScene
		// because the newScene has no attached
		// step for the moment. The reference scene is used instead.
		HetInitialParameters ip = (HetInitialParameters) refScene.getStep().getProject().getModel().getSettings();
		dz = ip.discretisationSpaceStep;

		// Calculate the temperature at the soil bottom and the thermal
		// diffusivity of each horizon.
		calculateSoilBottomTemperature(meteoLines);
		
		createDiscretizationMaps (); // fa-20.11.2019
		
		// fa-20.11.2019: TODO parallelize
		for (Pedon newPedon : newScene.getSoil().getPedons()) { // fa-20.11.2019: loop on pedons to consider detailed water balance option (HetDiscreteSoil), in which horizon water content differs among pedons and will thereby affect thermal diffusivity and then mineral horizon temperature  
			
			if (newPedon.getPedonId() == 0 && newPedon.getPedonArea() == 0) // fa-25.11.2019: skip processing for remainingPedon with area equals to zero
				continue;
			
			calculateThermalDiffusivity(newPedon, meteoLines, newScene); // fa-20.11.2019 //fa-25.11.2019: added newScene
//			calculateThermalDiffusivity(newScene, meteoLines);

		// fa-20.11.2019: MOVED above
//		// It is not possible to obtain the initial parameters from the newScene
//		// because the newScene has no attached
//		// step for the moment. The reference scene is used instead.
//		HetInitialParameters ip = (HetInitialParameters) refScene.getStep().getProject().getModel().getSettings();
//		dz = ip.discretisationSpaceStep;

			if (ip.mineralHorizonsTemperatureCalculationActivated) {
				calculateMineralHorizonsTemperature(newScene, newPedon, meteoLines); // fa-20.11.2019
//				calculateMineralHorizonsTemperature(newScene, meteoLines);
			}
		}
	}

	/**
	 * Calculate the heat flux through the organic layer of the soil.
	 * 
	 * @param newScene
	 *            The reference to the new scene
	 * @param meteoLine
	 *            The meteorological line of the current hour
	 * @param dateDailyAirTemperatureMap
	 *            The reference to the map with key: year_month_day string,
	 *            value: the average air temperature of the day
	 * @param organicLayerThickness
	 *            The thickness of the organic layer
	 * @param bulkDensity
	 *            The bulk density of the organic layer
	 * @throws IOException
	 */
	public synchronized void calculateOrganicLayerHeatFlux(HetScene newScene, HetMeteoLine meteoLine, double waterContent,
			LinkedHashMap<String, Double> soilInterfaceTemperatureMap, double organicLayerThickness, double bulkDensity)
			throws IOException { // fa-13.07.2017

		String time = meteoLine.year + HetMeteorology.SEP + meteoLine.month + HetMeteorology.SEP + meteoLine.day
				+ HetMeteorology.SEP + meteoLine.hour;

		double soilSurfaceTemperature = meteoLine.airTemperature;
		double soilInterfaceTemperature = soilInterfaceTemperatureMap.get(time);

		// Calculate organic thermal conductivity
		double organicThermalConductivity = calculateOrganicThermalConductivity(waterContent, bulkDensity);

		// Calculate heat flux
		double heatFlux = organicThermalConductivity * (soilSurfaceTemperature - soilInterfaceTemperature)
				/ organicLayerThickness; // W.m-2

		// Fill in the organicLayerHeatFluxMap (instance variable of HetSoil
		// class)
		hetSoil.getOrganicLayerHeatFluxMap().put(time, heatFlux);
	}

	/**
	 * Returns the organic thermal conductivity depending on the given water
	 * content and bulk density.
	 * 
	 * @param waterContent
	 *            A value of water content
	 * @param bulkDensity
	 *            A value of bulk density
	 * @return The organic thermal conductivity
	 */
	private double calculateOrganicThermalConductivity(double waterContent, double bulkDensity) {

		return organicThermalConductivity;
	}

	/**
	 * Calculates and returns the quartz content fraction map for each horizon.
	 * Key: horizon's id, value: quartz content fraction.
	 * 
	 * @return A map with key: horizon's id, value: quartz content fraction
	 */
	private Map<Integer, Double> calculateQuartzContentFraction() {

		Map<Integer, Double> quartzContentFractionMap = new HashMap<Integer, Double>();

		// fc-13.11.2019 CAUTION
		// due to HetDiscreteSoil and Pedons introduction, this method initially
		// relying on a SimpleHetSoil with horizons inside should be checked and
		// adapted
		// -> added getPedonSpecimen () meanwhile to work on the first pedon
		// found
		for (HetHorizon horizon : hetSoil.getPedonSpecimen().getHorizons()) {
			// for (HetHorizon horizon : hetSoil.getHorizons()) {

			int horizonId = horizon.id;

			double totalMineralConcentration = 0.0;
			for (String mineralName : horizon.getMineralConcentrations().keySet()) {
				totalMineralConcentration += horizon.getMineralConcentration(mineralName);
			}

			double quartzConcentration = horizon.getMineralConcentration("Quartz");
			quartzContentFractionMap.put(horizonId, quartzConcentration / totalMineralConcentration);
		}

		return quartzContentFractionMap;
	}

	/**
	 * Calculates the temperature of each mineral horizon.
	 * 
	 * @param newScene
	 *            The reference to the new scene // fa-20.11.2019: changed to pedon to consider detailed water balance option
	 * @param meteoLines
	 *            The meteorological lines of the new year
	 * @throws Exception
	 */
//	private void calculateMineralHorizonsTemperature(HetScene newScene, List<HetMeteoLine> meteoLines)
	private void calculateMineralHorizonsTemperature(HetScene newScene, Pedon newPedon, List<HetMeteoLine> meteoLines) // fa-20.11.2019
			throws Exception {
		
		// fa-20.11.2019: commented, MOVED to createDiscretizationMaps ()
//		// Number of discretization points for mineral layer of soil
//		double soilDepth = hetSoil.calculateDepth();
//		int nbPoints = ((int) Math.floor(-soilDepth / dz)) + 1; // Be careful:
//																// soil depth is
//																// < 0
//
//		// System.out.println( "soilDepth: " + soilDepth );
//		// System.out.println( "dz: " + dz );
//		// System.out.println( "nbPoints: " + nbPoints );
//
//		// Builds the depthHorizonsMap map
//		for (int i = 0; i < nbPoints; ++i) {
//			buildsDepthHorizonMap(i, dz);
//		}
//
//		// fc-13.11.2019
//		for (HetHorizon horizon : hetSoil.getPedonSpecimen().getHorizons()) {
//			// for (HetHorizon horizon : hetSoil.getHorizons()) {
//			int horizonId = horizon.id;
//			horizonSpaceDiscretisationIndicesMap.put(horizonId, new ArrayList<Integer>());
//			for (int i = 0; i < nbPoints; ++i) {
//				fillInHorizonSpaceDiscretisationIndicesMap(horizonId, i);
//			}
//		}

		// for (HetHorizon horizon : hetSoil.getHorizons()) {
		// int horizonId = horizon.id;
		// System.out.println("horizonId: " + horizonId + " --> " +
		// horizonSpaceDiscretisationIndicesMap.get(horizonId));
		// }
		
		// fa-20.11.2019: took it from here above
		double soilDepth = hetSoil.calculateDepth();
		int nbPoints = ((int) Math.floor(-soilDepth / dz)) + 1; // Be careful:
																// soil depth is
																// < 0

		// Initialisation

		// First hour of first day of new year: year_1_1_0
		String initialTime = newScene.getDate() + HetMeteorology.SEP + "1" + HetMeteorology.SEP + "1"
				+ HetMeteorology.SEP + "0";

		double[] initialMineralLayerTemperature = new double[nbPoints];

		// Initialtemperatures at first and last discretisation points at
		// initial time
		initialMineralLayerTemperature[0] = hetSoil.getSoilInterfaceTemperatureMap().get(initialTime);
		initialMineralLayerTemperature[nbPoints - 1] = hetSoil.getSoilBottomTemperatureMap().get(initialTime);

		// Linear interpolation for other discretization points at initial time:
		// T(z) = Tsup + z*(Tinf-Tsup)/soildepth, where:
		// Tsup is the temperature at z=0
		// Tinf is the temperature at z=soilDepth
		// z = -i*dz <= 0
		for (int i = 1; i <= nbPoints - 2; ++i) {
			initialMineralLayerTemperature[i] = initialMineralLayerTemperature[0] - i * dz
					* (initialMineralLayerTemperature[nbPoints - 1] - initialMineralLayerTemperature[0]) / (soilDepth);
		}

		// fc-13.11.2019
//		for (HetHorizon horizon : hetSoil.getPedonSpecimen().getHorizons()) {
		for (HetHorizon horizon : newPedon.getHorizons()) { // fa-20.11.2019
			// for (HetHorizon horizon : hetSoil.getHorizons()) {

			if (!horizon.isOrganic()) {

				int horizonId = horizon.id;
				List<Integer> spaceDiscretisationIndices = horizonSpaceDiscretisationIndicesMap.get(horizonId);

				double averagedTemperature = 0.0;
				for (int k = 0; k < spaceDiscretisationIndices.size(); ++k) {
					averagedTemperature += initialMineralLayerTemperature[k];
				}
				averagedTemperature = averagedTemperature / spaceDiscretisationIndices.size();

				horizon.addTimeTemperature(initialTime, averagedTemperature);
			}
		}

		// Calculate hourly temperature of mineral soil horizons

		double[] soilTemperaturePrev = new double[nbPoints];
		double[] soilTemperature = new double[nbPoints];

		for (int i = 0; i < nbPoints; ++i) {
			soilTemperaturePrev[i] = initialMineralLayerTemperature[i];
			// System.out.println("dz: " + i*dz + "
			// initialMineralLayerTemperature[i]: " +
			// initialMineralLayerTemperature[i]);
		}

		// Begins with i=1(that is the second line of meteo lines list)
		// because initial time (that is first line of meteo lines list) has
		// already been processed
		for (int i = 1; i < meteoLines.size(); ++i) {

			// Reset dt at each new hour
			double dt = 3600.0;

			HetMeteoLine meteoLine = meteoLines.get(i);
			HetMeteoLine prevMeteoLine = meteoLines.get(i - 1);

			String prevTime = prevMeteoLine.year + HetMeteorology.SEP + prevMeteoLine.month + HetMeteorology.SEP
						+ prevMeteoLine.day + HetMeteorology.SEP + prevMeteoLine.hour;
			String time = meteoLine.year + HetMeteorology.SEP + meteoLine.month + HetMeteorology.SEP + meteoLine.day
						+ HetMeteorology.SEP + meteoLine.hour;

			// System.out.println("**********");
			// System.out.println("time: " + time);
			// System.out.println("prevTime: " + prevTime);

//			dt = calculateDt(time, dt, dz, hetSoil);
			dt = calculateDt(time, dt, dz, newPedon); // fa-20.11.2019
			// System.out.println("calculated dt: " + dt);

			double internalTime = dt;

			while (internalTime <= 3600.0) {

				// System.out.println("internalTime: " + internalTime);

				// fa-25.07.2017: Calculate the average thermal diffusivity for
				// the soil profile at time = internalTime
//				double prevAverageThermalDiffusivity = hetSoil.getTimeAverageThermalDiffusivityMap().get(prevTime);
				double prevAverageThermalDiffusivity = newPedon.getTimeAverageThermalDiffusivityMap().get(prevTime); // fa-20.11.2019
//				double averageThermalDiffusivity = hetSoil.getTimeAverageThermalDiffusivityMap().get(time);
				double averageThermalDiffusivity = newPedon.getTimeAverageThermalDiffusivityMap().get(time); // fa-20.11.2019

				if (prevAverageThermalDiffusivity < 0.0)
					System.exit(0);

				if (averageThermalDiffusivity < 0.0)
					System.exit(0);

				double interpolatedAverageThermalDiffusivity = prevAverageThermalDiffusivity
						+ internalTime * (averageThermalDiffusivity - prevAverageThermalDiffusivity) / 3600.0;

				// fa-25.07.2017: commented
				/******
				 * // Calculate the thermal diffusivity for each soil horizon at
				 * time = internalTime Map<Integer, Double>
				 * timeInterpolatedThermalDiffusivityMap = new HashMap<Integer,
				 * Double>();
				 * 
				 * for (HetHorizon horizon : hetSoil.getHorizons()) {
				 * 
				 * if (!horizon.isOrganic()) { double prevThermalDiffusivity =
				 * horizon.timeThermalDiffusivityMap.get(prevTime); double
				 * thermalDiffusivity =
				 * horizon.timeThermalDiffusivityMap.get(time);
				 * 
				 * if (prevThermalDiffusivity < 0.0) { //
				 * System.out.println("prevTime: " + prevTime + "
				 * prevThermalDiffusivity: " + prevThermalDiffusivity);
				 * System.exit(0); }
				 * 
				 * if (thermalDiffusivity < 0.0) { // System.out.println("time:
				 * " + time + " thermalDiffusivity: " + thermalDiffusivity);
				 * System.exit(0); }
				 * 
				 * double interpolatedThermalDiffusivity =
				 * prevThermalDiffusivity+internalTime*(thermalDiffusivity-prevThermalDiffusivity)/3600.0;
				 * timeInterpolatedThermalDiffusivityMap.put(horizon.id,
				 * interpolatedThermalDiffusivity);
				 * //timeInterpolatedThermalDiffusivityMap.put(horizon.id,
				 * prevThermalDiffusivity); } }
				 ******/

				// Linear interpolations in time
				Map<String, Double> soilInterfaceTemperatureMap = hetSoil.getSoilInterfaceTemperatureMap();
				Map<String, Double> soilBottomTemperatureMap = hetSoil.getSoilBottomTemperatureMap();
				soilTemperature[0] = soilInterfaceTemperatureMap.get(prevTime) + internalTime
						* (soilInterfaceTemperatureMap.get(time) - soilInterfaceTemperatureMap.get(prevTime)) / 3600.0;
				soilTemperature[nbPoints - 1] = soilBottomTemperatureMap.get(prevTime) + internalTime
						* (soilBottomTemperatureMap.get(time) - soilBottomTemperatureMap.get(prevTime)) / 3600.0;

				for (int j = 1; j < nbPoints - 1; ++j) {

					// fa-25.07.2017: commented
					/*****
					 * List<Integer> horizonIdListOfCurrentPoint =
					 * depthHorizonsMap.get(j); List<Integer>
					 * horizonIdListOfBelowPoint = depthHorizonsMap.get(j+1);
					 * List<Integer> horizonIdListOfAbovePoint =
					 * depthHorizonsMap.get(j-1);
					 * 
					 * if ( (horizonIdListOfCurrentPoint.size() != 1) &&
					 * (horizonIdListOfCurrentPoint.size() != 2) ) { throw new
					 * Exception("HetSoilHeatFluxCalculator.calculateMineralHorizonsTemperature():
					 * point at depth " + j*dz + " belongs to " +
					 * horizonIdListOfCurrentPoint.size() + " horizons.
					 * Impossible: a point can belong to 1 or 2 horizon(s).
					 * Aborted."); } if ( (horizonIdListOfBelowPoint.size() !=
					 * 1) && (horizonIdListOfBelowPoint.size() != 2) ) { throw
					 * new
					 * Exception("HetSoilHeatFluxCalculator.calculateMineralHorizonsTemperature():
					 * point at depth " + (j+1)*dz + " belongs to " +
					 * horizonIdListOfBelowPoint.size() + " horizons.
					 * Impossible: a point can belong to 1 or 2 horizon(s).
					 * Aborted."); } if ( (horizonIdListOfAbovePoint.size() !=
					 * 1) && (horizonIdListOfAbovePoint.size() != 2) ) { throw
					 * new
					 * Exception("HetSoilHeatFluxCalculator.calculateMineralHorizonsTemperature():
					 * point at depth " + (j-1)*dz + " belongs to " +
					 * horizonIdListOfAbovePoint.size() + " horizons.
					 * Impossible: a point can belong to 1 or 2 horizon(s).
					 * Aborted."); }
					 * 
					 * // for heat flux from below discrete space point double
					 * d1 = calculateD1(horizonIdListOfCurrentPoint,
					 * horizonIdListOfBelowPoint,
					 * timeInterpolatedThermalDiffusivityMap); //double d1 =
					 * 4e-7;
					 * 
					 * // for heat flux from same depth discrete space point
					 * double d2 = calculateD2(horizonIdListOfCurrentPoint,
					 * timeInterpolatedThermalDiffusivityMap); //double d2 =
					 * 4e-7;
					 * 
					 * // for heat flux from above discrete space point double
					 * d3 = calculateD3(horizonIdListOfCurrentPoint,
					 * horizonIdListOfAbovePoint,
					 * timeInterpolatedThermalDiffusivityMap); //double d3 =
					 * 4e-7;
					 *****/

					// soilTemperature[j] = soilTemperaturePrev[j] +
					// (dt/Math.pow(dz, 2.0))*(
					// d1*soilTemperaturePrev[j+1]-d2*2.0*soilTemperaturePrev[j]+d3*soilTemperaturePrev[j-1]
					// );
					soilTemperature[j] = soilTemperaturePrev[j] + interpolatedAverageThermalDiffusivity
							* (dt / Math.pow(dz, 2.0))
							* (soilTemperaturePrev[j + 1] - 2.0 * soilTemperaturePrev[j] + soilTemperaturePrev[j - 1]); // fa-25.07.2017
				}

				for (int j = 0; j < nbPoints; ++j) {
					soilTemperaturePrev[j] = soilTemperature[j];
					// System.out.println("t: " + internalTime + " j-depth: " +
					// j*dz + " temperature: " + soilTemperature[j]);
				}

				internalTime += dt;
			}

			// calculateMineralHorizonsTemperature/ Associate a temperature to
			// each horizon : it is the mean of temperatures of the
			// discretisation
			// space points that are included in the horizon

			// fc-13.11.2019
//			for (HetHorizon horizon : hetSoil.getPedonSpecimen().getHorizons()) {
			for (HetHorizon horizon : newPedon.getHorizons()) { // fa-20.11.2019
				// for (HetHorizon horizon : hetSoil.getHorizons()) {

				if (!horizon.isOrganic()) {

					int horizonId = horizon.id;

					List<Integer> spaceDiscretisationIndices = horizonSpaceDiscretisationIndicesMap.get(horizonId);
					double averagedTemperature = 0.0;
					for (int k = 0; k < spaceDiscretisationIndices.size(); ++k) {
						averagedTemperature += soilTemperature[k];
					}
					averagedTemperature = averagedTemperature / spaceDiscretisationIndices.size();

					horizon.addTimeTemperature(time, averagedTemperature);
				}
			}

		}

		// Print calculated temperature of each horizon

		// fc-13.11.2019
//		for (HetHorizon horizon : hetSoil.getPedonSpecimen().getHorizons()) {
		for (HetHorizon horizon : newPedon.getHorizons()) { // fa-20.11.2019
			// for (HetHorizon horizon : hetSoil.getHorizons()) {
			if (!horizon.isOrganic()) {
				HetReporter.printInStandardOutput("****** horizonId: " + horizon.id);
				for (String time : horizon.getTimeMineralHorizonTemperatureMap().keySet()) {
					// System.out.println("time: " + time + " temperature: " +
					// horizon.getTimeTemperatureMap().get(time));
				}
			}
		}

	}

	/**
	 * Calculates the temperature at the soil bottom for each time of the
	 * meteolines. It is constant over a year: it is equal to the average air
	 * temperature over all the meteo lines of the year. The calculated
	 * temperatures are stored in the soilBottomTemperatureMap map of HetSoil
	 * class.
	 * 
	 * @param meteoLines
	 *            The meteorological lines of a year
	 */
	private void calculateSoilBottomTemperature(List<HetMeteoLine> meteoLines) {

		double soilBottomTemperature = 0.0;

		Map<String, Double> soilBottomTemperatureMap = hetSoil.getSoilBottomTemperatureMap();

		for (HetMeteoLine meteoLine : meteoLines) {
			String time = meteoLine.year + HetMeteorology.SEP + meteoLine.month + HetMeteorology.SEP + meteoLine.day
					+ HetMeteorology.SEP + meteoLine.hour;
			double airTemperature = meteoLine.airTemperature;
			soilBottomTemperature += airTemperature;
			soilBottomTemperatureMap.put(time, 0.0);
		}
		soilBottomTemperature /= meteoLines.size();

		for (String time : soilBottomTemperatureMap.keySet()) {
			soilBottomTemperatureMap.put(time, soilBottomTemperature);
		}
	}

	/**
	 * Calculates the thermal diffusivity of each horizon for each time of the
	 * meteolines. The calculated thermal diffusivities are stored in the
	 * timeThermalDiffusivityMap map of the HetHorizon class.
	 * 
	 * @param scene
	 *            The reference to the HetScene // fa-20.11.2019: changed to Pedon to consider detailed water balance option
	 * @param meteoLines
	 *            The meteorological lines of a year
	 */
//	private void calculateThermalDiffusivity(HetScene scene, List<HetMeteoLine> meteoLines) {
	private void calculateThermalDiffusivity(Pedon pedon, List<HetMeteoLine> meteoLines, HetScene scene) { // fa-20.11.2019 / fa-25.11.2019: added scene

		// Map<Integer, Double> quartzContentFractionMap = null;
		// if (HetPhreeqc.isPhreeqcAvailable()) {
		// quartzContentFractionMap = calculateQuartzContentFraction();
		// }

		// Calculate the thermal diffusivity for each horizon.
		for (HetMeteoLine meteoLine : meteoLines) {

			String time = meteoLine.year + HetMeteorology.SEP + meteoLine.month + HetMeteorology.SEP + meteoLine.day
						+ HetMeteorology.SEP + meteoLine.hour;
			
			// fa-25.11.2019: in detailed water balance mode, water balance map is aggregated at the daily time step to save memory
			String time_wbMap;
			if (!scene.getSoil().isDiscreteSoil()) // default water balance mode
				time_wbMap = time;
			else // detailed water balance
				time_wbMap = meteoLine.year + HetMeteorology.SEP + meteoLine.month + HetMeteorology.SEP + meteoLine.day
						+ HetMeteorology.SEP;
			
			Map<Integer, Double> horizonWaterContentMap = pedon.getWaterBalanceMap ().get(time_wbMap).horizonWaterContent; // fa-25.11.2019
//			Map<Integer, Double> horizonWaterContentMap = pedon.getWaterBalanceMap ().get(time).horizonWaterContent; // fa-20.11.2019
//			Map<Integer, Double> horizonWaterContentMap = scene.getWaterBalanceMap ().get(time).horizonWaterContent;
//			Map<Integer, Double> horizonWaterContentMap = scene.waterBalanceMap.get(time).horizonWaterContent;

			double averageThermalDiffusivity = 0.0; // fa-25.07.2017: weighted
													// average thermal
													// diffusivity (weight =
													// horizon thickness)
			double soilDepth = -hetSoil.calculateDepth(); // fa-25.07.2017
															// (calculateDepth()
															// returns negative
															// value)

			// fc-13.11.2019
//			for (HetHorizon horizon : hetSoil.getPedonSpecimen().getHorizons()) {
			for (HetHorizon horizon : pedon.getHorizons()) { // fa-20.11.2019: this modification was not necessary as horizon Id and type (organic vs mineral) are the same for all pedon, but was done for consistency with modifications made above for the detailed water balance option
				// for (HetHorizon horizon : hetSoil.getHorizons()) {

				// Mineral horizons
				if (!horizon.isOrganic()) {

					int horizonId = horizon.id;
					double specificHeatCapacity = calculateSpecificHeatCapacity(horizon.bulkDensity,
							horizonWaterContentMap.get(horizonId));

					double thermalConductivity;
					// if (HetPhreeqc.isPhreeqcAvailable()) {
					// thermalConductivity =
					// calculateMineralThermalConductivity(horizon.porosity,
					// quartzContentFractionMap.get(horizon),
					// horizon.bulkDensity,
					// horizonWaterContentMap.get(horizonId));
					// } else {
					thermalConductivity = calculateMineralThermalConductivity(0.0, 0.0, horizon.bulkDensity,
							horizonWaterContentMap.get(horizonId));
					// }

					double thermalDiffusivity = calculateThermalDiffusivity(thermalConductivity, specificHeatCapacity);

					if (horizon.timeThermalDiffusivityMap == null) {
						horizon.timeThermalDiffusivityMap = new HashMap<String, Double>();
					}
					horizon.timeThermalDiffusivityMap.put(time, thermalDiffusivity);

					averageThermalDiffusivity += thermalDiffusivity * horizon.thickness; // fa-25.07.2017
				}

			}

			// fa-25.07.2017
			averageThermalDiffusivity = averageThermalDiffusivity / soilDepth;

			// fc-13.11.2019 REMOVED the 3 lines below, changed
			// getTimeAverageThermalDiffusivityMap (), never returns a null map
			// if (hetSoil.timeAverageThermalDiffusivityMap == null) {
			// hetSoil.timeAverageThermalDiffusivityMap = new HashMap<String,
			// Double>();
			// }
//			hetSoil.getTimeAverageThermalDiffusivityMap ().put(time, averageThermalDiffusivity);
			pedon.getTimeAverageThermalDiffusivityMap ().put(time, averageThermalDiffusivity); // fa-20.11.2019
		}
	}

	/**
	 * Calculates and returns the specific heat capacity.
	 * 
	 * @param bulkDensity
	 *            The bulk density
	 * @param waterContent
	 *            The water content
	 * @return The specific heat capacity
	 */
	double calculateSpecificHeatCapacity(double bulkDensity, double waterContent) {

		return 836.0 * bulkDensity + 4180.0 * waterContent * 1000.0;
	}

	/**
	 * Calculates and returns the mineral thermal conductivity.
	 * 
	 * @param porosity
	 *            The porosity
	 * @param quartzContentFraction
	 *            The quartz content fraction
	 * @param bulkDensity
	 *            The bulk density
	 * @param waterContent
	 *            The water content
	 * @return The mineral thermal conductivity
	 */
	double calculateMineralThermalConductivity(double porosity, double quartzContentFraction, double bulkDensity,
			double waterContent) {

		double thermalConductivity;

		// if (HetPhreeqc.isPhreeqcAvailable()) {
		// double saturationThermalConductivity = Math.pow(0.57, porosity) *
		// Math.pow(Math.pow(7.7, quartzContentFraction)*Math.pow(2.0,
		// 1.0-quartzContentFraction), 1.0-porosity);
		// double dryThermalConductivity =
		// (0.137*bulkDensity+64.7)/(2650.0-0.947*bulkDensity);
		// double normalizedThermalConductivity = Math.log(waterContent)+1.0;

		// thermalConductivity =
		// (saturationThermalConductivity-dryThermalConductivity)*normalizedThermalConductivity+dryThermalConductivity;
		// }
		// else {
		thermalConductivity = 0.1442 * (0.9 * Math.log10(waterContent * 1000 / bulkDensity * 100.0) - 0.2)
				* Math.pow(10.0, 0.6243 * bulkDensity / 1000.0);
		// }

		return thermalConductivity;
	}

	/**
	 * Calculates and returns the thermal diffusivity for a horizon given its
	 * thermal conductivity and specific heat capacity.
	 * 
	 * @param thermalConductivity
	 *            The thermal conductivity
	 * @param specificHeatCapacity
	 *            The specific heat capacity
	 * @return The thermal diffusivity
	 */
	double calculateThermalDiffusivity(double thermalConductivity, double specificHeatCapacity) {

		return thermalConductivity / specificHeatCapacity;
		// return 4e-7; // constant
	}

	/**
	 * Fills in the depthHorizonsMap which: - key is: the index of a
	 * discretisation space point (from 0 to nbPoints-1 where nbPoints is the
	 * number of discretisation space points); - value is: the list of horizon
	 * ids to which the space point belongs. It can be: - a single horizon id if
	 * the space point is strictly included between the upper and the lower
	 * values of an horizon; - 2 horizon ids if the space point is at the
	 * interface of these 2 horizons.
	 * 
	 * @param spaceDiscretisationPointIndex
	 *            The index of a space discretisation point
	 * @param dz
	 *            The space discretisation step
	 */
	private void buildsDepthHorizonMap(int spaceDiscretisationPointIndex, double dz) {

		depthHorizonsMap.put(spaceDiscretisationPointIndex, new ArrayList<Integer>());

		// fc-13.11.2019
		for (HetHorizon horizon : hetSoil.getPedonSpecimen ().getHorizons()) { // fa-20.11.2019: OK to use getPedonSpecimen () as horizon characteristics used here (Id, limits) are the same for all pedons
//		for (HetHorizon horizon : hetSoil.getHorizons()) {
			int horizonId = horizon.id;
			double depth = -spaceDiscretisationPointIndex * dz; // Note: depth
																// is <0
			if ((depth < horizon.upperLimit && depth > horizon.lowerLimit)
					|| (Math.abs(depth - horizon.upperLimit) < 1e-25)
					|| (Math.abs(depth - horizon.lowerLimit) < 1e-25)) {
				List horizonIdList = depthHorizonsMap.get(spaceDiscretisationPointIndex);
				horizonIdList.add(horizonId);
				depthHorizonsMap.put(spaceDiscretisationPointIndex, horizonIdList);
			}
		}
	}

	/**
	 * Fills in the horizonSpaceDiscretisationIndicesMap map which: - key is:
	 * the horizon id; - value is: the list of index of discretisation space
	 * points (from 0 to nbPoints-1 where nbPoints is the number of
	 * discretisation space points) that belong to the horizon. Note: an index
	 * of discretisation space point can belong to 1 horizon (if it is stricly
	 * included between the upper and the lower values of an horizon) or 2
	 * horizons (if it is at the interface of these 2 horizons).
	 * 
	 * @param horizonId
	 *            The horizon's id
	 * @param indexSpaceDiscretisation
	 *            The index of a space discretisation point
	 */
	private void fillInHorizonSpaceDiscretisationIndicesMap(int horizonId, int indexSpaceDiscretisation) {

		// fc-13.11.2019
		HetHorizon horizon = hetSoil.getPedonSpecimen ().getHorizon(horizonId); // fa-20.11.2019: OK to use getPedonSpecimen () as horizon limits are the same for all pedons
//		HetHorizon horizon = hetSoil.getHorizon(horizonId);
		
		double depth = -indexSpaceDiscretisation * dz;

		if (depth <= horizon.upperLimit && depth >= horizon.lowerLimit) {
			List<Integer> indices = horizonSpaceDiscretisationIndicesMap.get(horizonId);
			indices.add(indexSpaceDiscretisation);
			horizonSpaceDiscretisationIndicesMap.put(horizonId, indices);
		}
	}

	/**
	 * Calculates and returns the time step which respects the following
	 * stability criterion: max(Dq)*dt/dz² <= 1/2
	 * 
	 * @param time
	 *            The year_month_day_hour string representing new time
	 * @param dt
	 *            The time step
	 * @param dz
	 *            The space step
	 * @param hetSoil
	 *            The soil reference
	 * @return The calculated time step that respect the stability criterion
	 */
//	private double calculateDt(String time, double dt, double dz, HetSoilInterface hetSoil) {
	private double calculateDt(String time, double dt, double dz, Pedon pedon) { // fa-20.11.2019

		double validDt = dt;
		double maxDiffusivity = -Double.MAX_VALUE;

		// fc-13.11.2019
//		for (HetHorizon horizon : hetSoil.getPedonSpecimen ().getHorizons()) {
		for (HetHorizon horizon : pedon.getHorizons()) { // fa-20.11.2019
//		for (HetHorizon horizon : hetSoil.getHorizons()) {
			if (!horizon.isOrganic()) {
				double thermalDiffusivity = horizon.timeThermalDiffusivityMap.get(time);
				if (thermalDiffusivity > maxDiffusivity) {
					maxDiffusivity = thermalDiffusivity;
				}
			}
		}

		while (maxDiffusivity * validDt / Math.pow(dz, 2) > 0.5) {
			validDt = validDt / 2;
		}

		return validDt;
	}
	
	// fa-20.11.2019
	private void createDiscretizationMaps () throws Exception {
		// Number of discretization points for mineral layer of soil
		double soilDepth = hetSoil.calculateDepth();
		int nbPoints = ((int) Math.floor(-soilDepth / dz)) + 1; // Be careful:
																// soil depth is
																// < 0

		// System.out.println( "soilDepth: " + soilDepth );
		// System.out.println( "dz: " + dz );
		// System.out.println( "nbPoints: " + nbPoints );

		// Builds the depthHorizonsMap map
		for (int i = 0; i < nbPoints; ++i) {
			buildsDepthHorizonMap(i, dz);
		}
		
		for (HetHorizon horizon : hetSoil.getPedonSpecimen().getHorizons()) {	// fa-19.11.2019: OK for using getPedonSpecimen(), horizon Ids are the same for all pedons		
			// for (HetHorizon horizon : hetSoil.getHorizons()) {
			int horizonId = horizon.id;
			horizonSpaceDiscretisationIndicesMap.put(horizonId, new ArrayList<Integer>());
			for (int i = 0; i < nbPoints; ++i) {
				fillInHorizonSpaceDiscretisationIndicesMap(horizonId, i);
			}
		}
	}

	// fa-25.07.2017: commented
	/**
	 * Returns the d1 coefficient used to take into account the heat flux from
	 * below discrete space point
	 * 
	 * @param horizonIdListOfCurrentPoint
	 *            The list of horizon ids to which the current point belongs
	 * @param horizonIdListOfBelowPoint
	 *            The list of horizon ids to which the below point belongs
	 * @param timeInterpolatedThermalDiffusivityMap
	 *            The thermal diffusivity data
	 * @return The d1 coefficient used to take into account the heat flux from
	 *         below discrete space point
	 */
	/*****
	 * private double calculateD1(List<Integer> horizonIdListOfCurrentPoint,
	 * List<Integer> horizonIdListOfBelowPoint, Map<Integer, Double>
	 * timeInterpolatedThermalDiffusivityMap ) {
	 * 
	 * double d1;
	 * 
	 * // If the horizonIdListOfCurrentPoint list contains a single horizon id:
	 * obvious. // Else (it means the list contains 2 horizon ids because the
	 * point is at the interface of 2 horizons) the inferior // horizon is
	 * chosen. int horizonIdOfCurrentPoint; if
	 * (horizonIdListOfCurrentPoint.size() == 1) { horizonIdOfCurrentPoint =
	 * horizonIdListOfCurrentPoint.get(0); } else { horizonIdOfCurrentPoint =
	 * horizonIdListOfCurrentPoint.get(1); }
	 * 
	 * // If the horizonIdListOfBelowPoint list contains a single horizon id:
	 * obvious. // Else (it means the list contains 2 horizon ids because the
	 * point is at the interface of 2 horizons) the superior // horizon is
	 * chosen. int horizonIdOfBelowPoint = horizonIdListOfBelowPoint.get(0); if
	 * (horizonIdOfCurrentPoint == horizonIdOfBelowPoint) { d1 =
	 * timeInterpolatedThermalDiffusivityMap.get(horizonIdOfCurrentPoint); }
	 * else { // Arithmetic mean d1 = 0.5 * (
	 * timeInterpolatedThermalDiffusivityMap.get(horizonIdOfCurrentPoint) +
	 * timeInterpolatedThermalDiffusivityMap.get(horizonIdOfBelowPoint) ); }
	 * 
	 * return d1; }
	 *****/

	// fa-25.07.2017: commented
	/**
	 *
	 * @param horizonIdListOfCurrentPoint
	 * @param timeInterpolatedThermalDiffusivityMap
	 * @return
	 */
	/*****
	 * private double calculateD2(List<Integer> horizonIdListOfCurrentPoint,
	 * Map<Integer, Double> timeInterpolatedThermalDiffusivityMap) {
	 * 
	 * double d2 = 0.0;
	 * 
	 * for (int horizonId : horizonIdListOfCurrentPoint) { d2 +=
	 * timeInterpolatedThermalDiffusivityMap.get(horizonId); } d2 /=
	 * horizonIdListOfCurrentPoint.size();
	 * 
	 * return d2; }
	 *****/

	// fa-25.07.2017: commented
	/*****
	 * private double calculateD3(List<Integer> horizonIdListOfCurrentPoint,
	 * List<Integer> horizonIdListOfAbovePoint, Map<Integer, Double>
	 * timeInterpolatedThermalDiffusivityMap) {
	 * 
	 * double d3;
	 * 
	 * // If the horizonIdListOfCurrentPoint list contains a single horizon id:
	 * obvious. // Else (it means the list contains 2 horizon ids because the
	 * point is at the interface of 2 horizons) the superior // horizon is
	 * chosen. int horizonIdOfCurrentPoint = horizonIdListOfCurrentPoint.get(0);
	 * 
	 * // If the horizonIdListOfAbovePoint list contains a single horizon id:
	 * obvious. // Else (it means the list contains 2 horizon ids because the
	 * point is at the interface of 2 horizons) the inferior // horizon is
	 * chosen. int horizonIdOfAbovePoint; if (horizonIdListOfAbovePoint.size()
	 * == 1) { horizonIdOfAbovePoint = horizonIdListOfAbovePoint.get(0); } else
	 * { horizonIdOfAbovePoint = horizonIdListOfAbovePoint.get(1); }
	 * 
	 * if (horizonIdOfCurrentPoint == horizonIdOfAbovePoint) { d3 =
	 * timeInterpolatedThermalDiffusivityMap.get(horizonIdOfCurrentPoint); }
	 * else { // Arithmetic mean d3 = 0.5 *
	 * (timeInterpolatedThermalDiffusivityMap.get(horizonIdOfCurrentPoint) +
	 * timeInterpolatedThermalDiffusivityMap.get(horizonIdOfAbovePoint)); }
	 * 
	 * return d3; }
	 *****/

}
