/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model;

import heterofor.model.HetAtmosphericCO2ConcentrationFileLoader.AtmosphericCO2ConcentrationRecord;
import heterofor.model.HetFructificationFileLoader.HetFructificationRecord;
import heterofor.model.HetInventoryLoader.TreeConcentrationLine;
import heterofor.model.HetInventoryLoader.TreeWithSapflowRecord;
import heterofor.model.meteorology.HetMeteorology;
import heterofor.model.meteorology.HetMeteorologyFileLoader;
import heterofor.model.phenology.HetPhenology;
import heterofor.model.soil.HetHorizon;
import heterofor.model.soil.HetSoilHorizonsFileLoader;
import heterofor.model.soilchemistry.HetChemicalElement;
import heterofor.model.soilchemistry.HetPhreeqc;
import heterofor.model.soilchemistry.HetSoilChemistryFileLoader;
import heterofor.model.treechemistry.HetFoliarChemistryThresholds;
import heterofor.model.treechemistry.HetLitterChemistryDistribution;
import heterofor.model.treechemistry.HetTreeChemistryDistribution;
import heterofor.model.treechemistry.HetTreeCompartment;
import heterofor.model.treechemistry.HetTreeElement;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import jeeb.lib.maps.geom.Polygon2;
import jeeb.lib.util.Alert;
import jeeb.lib.util.Automatable;
import jeeb.lib.util.ListMap;
import jeeb.lib.util.Log;
import jeeb.lib.util.MessageDialog;
import jeeb.lib.util.Translator;
import jeeb.lib.util.annotation.Ignore;
import capsis.kernel.GModel;
import capsis.kernel.GScene;
import capsis.kernel.InitialParameters;
import capsis.lib.castanea2018march.FmSettings;
import capsis.lib.castanea2018march.FmSpecies;

/**
 * HetInitialParameters are the initial settings for Heterofor. They are set at
 * the project initialization stage and then stay unchanged during all the
 * simulations within this project.
 *
 * @author M. Jonard, F. Herman - January 2012
 */
public class HetInitialParameters extends FmSettings implements InitialParameters, Automatable {

	// Files

	// Heterofor now has a separated species fileName
	// Heterofor can read Quergus input files with simplified species inside,
	// in this case, the speciesFileName is not needed
	public String speciesFileName; // mj+fc-29.4.2015 Optional

	public String castaneaFileName;

	public String inventoryFileName;

	public String samsaraLightFileName;

	// Soil horizons file is optional // fc-8.9.2016
	public String soilHorizonsFileName;

	// Soil chemistry is optional // fc+mj-27.10.2015
	// If provided, requires soil horizons file to be provided
	public String soilChemistryFileName;

	// Meteorology is optional // fc+mj+lw-27.10.2015
	// If provided, requires soil horizons file to be provided
	public String meteorologyFileName; // used for horizons waterContent
										// management

	// Fructification's observations file name.
	public String fructificationFileName;

	// Radiative balance

	public boolean fineResolutionRadiativeBalanceActivated = false;
	public int radiationCalculationTimeStep = 3;

	// fc+nd+mj+br-2.10.2018 keep treeConcentrationLines found in inventory file
	// to help at trees recruitment time (connection to regeneration lib)
	public List<TreeConcentrationLine> treeConcentrationLines;

	// Main modules

	// nb+lw-24.01.2017
	public boolean phenologyActivated = false;
	public boolean phenologyAtTreeLevel = false;
	public HashMap<Integer, HetPhenology> phenologyMap; // key: species id,
														// value: phenology

	// fc+mj-13.9.2017
	public boolean waterBalanceActivated;
	public boolean waterBalance_treeLevelTranspiration = true;
	// fc-13.11.2019 Related to HetDiscreteSoil and Tree/RemainingPedons
	public boolean waterBalance_fineResolutionActivated = false;

	public boolean castaneaPhotosynthesisActivated = true;

	// mj+fa-22.09.2017
	public boolean pueEmpiricalMethod = false;

	public boolean constantNppToGppRatio = true;

	// nb+lw-25.04.2017
	public boolean mineralHorizonsTemperatureCalculationActivated = false;

	public boolean competitionAccountedForCrownGrowth = true;

	// Nutrient limitation

	// If true, tree growth is limited by nutrient availability
	// reducedGrowth is allowed (HetModel) and tree nutrientStatus influences
	// fineRootToFoliageRatio (HetFunctionalCompartmentsProduction)
	public boolean generalNutrientLimitation;
	// Same, limited to Nitrogen
	public boolean nLimitation = false;

	// Atmospheric CO2 concentration. nb-15.03.2018
	public boolean variableAtmCO2ConcentrationOverTime;
	public String atmCO2ConcentrationsFileName;
	public Map<Integer, Double> yearAtmCO2ConcentrationMap; // key: year, value:
															// atmospheric CO2
															// concentration
	public static final String FIXED_ATMOSPHERIC_CO2_CONCENTRATION = "FIXED_ATMOSPHERIC_CO2_CONCENTRATION";
	public static final String VARIABLE_ATMOSPHERIC_CO2_CONCENTRATION = "VARIABLE_ATMOSPHERIC_CO2_CONCENTRATION";

	// Height growth option

	// IPRFW: Inventaire permanent des ressources forestières de Wallonie /
	// Wallonian Regional forest inventory
	public static final String IPRFW = "IPRFW";
	// BAILEUX_SITE: Site expérimental de Baileux / Baileux experimental site
	public static final String BAILEUX_SITE = "BAILEUX_SITE";
	public static final String POTENTIAL_MODIFIERS_HEIGHT_GROWTH = "POTENTIAL_MODIFIERS_HEIGHT_GROWTH";

	public String heightGrowthOption = BAILEUX_SITE; // IPRFW, BAILEUX_SITE

	// Management and mortality options
	public boolean mortalityActivated;

	public double cuttingDiameter = 7; // cm

	// --- Other options ----------------------------

	// At init time only, if true the processes are simpler
	public boolean fakeGrowth;

	public double ecosystemLAI; // from inventory

	public String plotName;

	public double sensorHeight; // m

	public Map<Integer, HetSpecies> speciesMap;

	// public int LADoption = MEAN_LAD; // MEAN_LAD, MEAN_SLA or SLA_MODEL
	// public int Toption = MEAN_T; // MEAN_T, QUERGUS_T

	public double LADNeighbourhoodDistance = 15; // m, > 0

	public boolean fillGaps = true;

	public boolean sensorLightOnly = false; // if true, only cells containing
											// sensors are considered by
											// SamsaraLight
	public String bufferType = "Jonard"; // by default it will add the buffer
											// zone corresponding to a rectangle

	public boolean yearlyRegenerationCohortsEmergence;

	public HetRegenerationCohortsManager cohortsManager;

	public List<Integer> treesWithSapflow; // fa-18.09.2019: IDs of trees
											// equipped with sapflow sensors,
											// from inventory file

	private Polygon2 inventoryZoneJonard = new Polygon2(); // ?????
	private Polygon2 inventoryZoneRestreint = new Polygon2(); // ?????
	private Polygon2 inventoryZoneElargit2 = new Polygon2(); // ?????
	private Polygon2 inventoryZoneElargit3 = new Polygon2(); // ?????
	private Polygon2 inventoryZoneElargit4 = new Polygon2(); // ?????

	public double massLeafLitter_ha;
	public double massBranchLitter_ha;
	public double massRootLitter_ha;
	public double massFineRootLitter_ha;
	public double massSlowDecompositionPool_ha;

	public double compartmentGrowthRespirationFraction = 0.2; // Hoffmann, 1995

	// meteorologyFileName is loaded in meteorology
	public HetMeteorology meteorology;

	// The content of the fructification's observations is stored in this map.
	// Key: year.
	// Value: map with key: species name and value: fruit litter fall (kg/ha).
	public Map<Integer, Map<String, Double>> fructificationMap;

	public ListMap<String, String> providedTreeCompartmentNames; // key is
																	// spName
	public ListMap<String, String> providedLitterCompartmentNames; // key is
																	// spName

	// Map of chemical elements: elements and exchangeables
	// key is eltName/exchName
	public Map<String, HetChemicalElement> chemicalElements;

	public HetTreeChemistryDistribution treeChemistryDistribution;
	public HetFoliarChemistryThresholds foliarChemistryThresholds;

	// Litter
	// Default values for all species (from species file)
	public HetLitterChemistryDistribution litterChemistryDistribution;
	// Optional specific values for the site (from inventory file)
	public Map<String, HetInventoryLoader.LitterConcentrationLine> litterConcentrationMap;

	// nb+lw-28.04.2017
	/**
	 * The dz discretisation space step
	 */
	public double discretisationSpaceStep = 0.05;

	/**
	 * Coefficient used in checking the validity of the dz discretisation space
	 * step. dz must be lower or equal to the mesh coefficient multiplicated by
	 * this minimal thickness (see the
	 * {@link HetInitialParameters#checkDzValidity(double)} method).
	 */
	private final double meshCoefficient = 1.0 / 3.0;

	// fc+fa-19.5.2017 were in HetModel initializeModel, moved here
	// GL 31/05/2013 - to get similar results with Quergus
	public double treeMaxHeight = 40;
	public double maxCrownRadius = 15;

	// mj+fa-02.03.2018: moved here from HetTreeCompartment
	public static Map<String, Double> q10Map;
	static {
		q10Map = new HashMap<>();
		q10Map.put(HetTreeCompartment.TYPE_LEAF, 2.1);
		q10Map.put(HetTreeCompartment.TYPE_BRANCH, 2.8);
		q10Map.put(HetTreeCompartment.TYPE_STEM, 1.7);
		q10Map.put(HetTreeCompartment.TYPE_ROOT, 1.7);
		q10Map.put(HetTreeCompartment.TYPE_MYCORRHIZAE, 2.1);
	}

	// Other variables

	// fc-29.6.2017 Loads the samsaraLight file
	public HetSamsaFileLoader samsaFileLoader;

	// Helper tags set in buildInitScene
	public boolean speciesFileNameProvided;
	public boolean castaneaFileNameProvided;
	public boolean inventoryFileNameProvided;
	public boolean samsaraLightFileNameProvided;
	public boolean soilHorizonsFileNameProvided;
	public boolean soilChemistryFileNameProvided;
	public boolean meteoFileNameProvided; // fc+mj+fa-27.7.2017
	public boolean fructificationFileNameProvided;
	public boolean maintenanceRespirationActivated = !constantNppToGppRatio;

	// fc+mj+fa+br-22.5.2019 for very specific uses (e.g.
	// VirtualUnderstoreyGeneration), we may want to sometimes disable lighting
	public boolean virtualUnderstoreyGeneration;

	@Ignore
	private HetScene initScene;

	/**
	 * Default constructor.
	 */
	public HetInitialParameters() {

		super();

		phenologyMap = new HashMap<>();
		yearAtmCO2ConcentrationMap = null;
		speciesMap = new HashMap<Integer, HetSpecies>();
		cohortsManager = null;
		meteorology = null;
		fructificationMap = null;
		providedTreeCompartmentNames = null;
		providedLitterCompartmentNames = null;
		chemicalElements = new LinkedHashMap<>(); // keeps insertion order
		treeChemistryDistribution = null;
		foliarChemistryThresholds = null;
		litterChemistryDistribution = null;
		litterConcentrationMap = null;
		samsaFileLoader = null;
		this.Ca = 380; // Was done in buildInitScene(). nb-14.03.2018
	}

	/**
	 * Copy constructor.
	 */
	public HetInitialParameters(HetInitialParameters original) { // fc-12.9.2017

		this();

		this.speciesFileName = original.speciesFileName;
		this.castaneaFileName = original.castaneaFileName;
		this.inventoryFileName = original.inventoryFileName;
		this.samsaraLightFileName = original.samsaraLightFileName;
		this.soilHorizonsFileName = original.soilHorizonsFileName;
		this.soilChemistryFileName = original.soilChemistryFileName;
		this.meteorologyFileName = original.meteorologyFileName;
		this.fructificationFileName = original.fructificationFileName;
		this.fineResolutionRadiativeBalanceActivated = original.fineResolutionRadiativeBalanceActivated;
		this.radiationCalculationTimeStep = original.radiationCalculationTimeStep;
		// treeConcentrationLines initialized to the default value = null.
		this.phenologyActivated = original.phenologyActivated;
		this.phenologyAtTreeLevel = original.phenologyAtTreeLevel;
		// phenologyMap initialized in HetInitialParameters() constructor.
		this.waterBalanceActivated = original.waterBalanceActivated;
		this.waterBalance_treeLevelTranspiration = original.waterBalance_treeLevelTranspiration;
		this.waterBalance_fineResolutionActivated = original.waterBalance_fineResolutionActivated;
		this.castaneaPhotosynthesisActivated = original.castaneaPhotosynthesisActivated;
		this.pueEmpiricalMethod = original.pueEmpiricalMethod;
		this.constantNppToGppRatio = original.constantNppToGppRatio;
		this.mineralHorizonsTemperatureCalculationActivated = original.mineralHorizonsTemperatureCalculationActivated;
		this.competitionAccountedForCrownGrowth = original.competitionAccountedForCrownGrowth;
		this.generalNutrientLimitation = original.generalNutrientLimitation;
		this.nLimitation = original.nLimitation;
		this.variableAtmCO2ConcentrationOverTime = original.variableAtmCO2ConcentrationOverTime;
		this.atmCO2ConcentrationsFileName = original.atmCO2ConcentrationsFileName;
		// yearAtmCO2ConcentrationMap initialized in HetInitialParameters()
		// constructor.
		// FIXED_ATMOSPHERIC_CO2_CONCENTRATION is static.
		// VARIABLE_ATMOSPHERIC_CO2_CONCENTRATION is static.
		// IPRFW is static.
		// BAILEUX_SITE is static.
		// POTENTIAL_MODIFIERS_HEIGHT_GROWTH is static.
		this.heightGrowthOption = original.heightGrowthOption;
		this.mortalityActivated = original.mortalityActivated;
		this.cuttingDiameter = original.cuttingDiameter;
		this.fakeGrowth = original.fakeGrowth;
		// ecosystemLAI initialized to the default value = 0.0.
		this.plotName = original.plotName;
		this.sensorHeight = original.sensorHeight;
		// speciesMap initialized in HetInitialParameters() constructor.
		this.LADNeighbourhoodDistance = original.LADNeighbourhoodDistance;
		this.fillGaps = original.fillGaps;
		this.sensorLightOnly = original.sensorLightOnly;
		this.bufferType = original.bufferType;
		// yearlyRegenerationCohortsEmergence initialized to the default value =
		// false.
		// cohortsManager initialized in HetInitialParameters() constructor.
		this.inventoryZoneJonard = original.inventoryZoneJonard; // ??????
		this.inventoryZoneRestreint = original.inventoryZoneRestreint; // ??????
		this.inventoryZoneElargit2 = original.inventoryZoneElargit2; // ??????
		this.inventoryZoneElargit3 = original.inventoryZoneElargit3; // ??????
		this.inventoryZoneElargit4 = original.inventoryZoneElargit4; // ??????
		this.massLeafLitter_ha = original.massLeafLitter_ha;
		this.massBranchLitter_ha = original.massBranchLitter_ha;
		this.massRootLitter_ha = original.massRootLitter_ha;
		this.massFineRootLitter_ha = original.massFineRootLitter_ha;
		this.massSlowDecompositionPool_ha = original.massSlowDecompositionPool_ha;
		this.compartmentGrowthRespirationFraction = original.compartmentGrowthRespirationFraction;
		// meteorology initialized in HetInitialParameters() constructor.
		// fructificationMap initialized in HetInitialParameters() constructor.
		// providedTreeCompartmentNames initialized in HetInitialParameters()
		// constructor.
		// providedLitterCompartmentNames initialized in HetInitialParameters()
		// constructor.
		// chemicalElements initialized in HetInitialParameters() constructor.
		// treeChemistryDistribution initialized in HetInitialParameters()
		// constructor.
		// foliarChemistryThresholds initialized in HetInitialParameters()
		// constructor.
		// litterChemistryDistribution initialized in HetInitialParameters()
		// constructor.
		// litterConcentrationMap initialized in HetInitialParameters()
		// constructor.
		this.discretisationSpaceStep = original.discretisationSpaceStep;
		// meshCoefficient is a constant (declared final).
		this.treeMaxHeight = original.treeMaxHeight;
		this.maxCrownRadius = original.maxCrownRadius;
		// q10Map is static.
		// samsaFileLoader initialized in HetInitialParameters() constructor.
		this.speciesFileNameProvided = original.speciesFileNameProvided;
		this.castaneaFileNameProvided = original.castaneaFileNameProvided;
		this.inventoryFileNameProvided = original.inventoryFileNameProvided;
		this.samsaraLightFileNameProvided = original.samsaraLightFileNameProvided;
		this.soilHorizonsFileNameProvided = original.soilHorizonsFileNameProvided;
		this.soilChemistryFileNameProvided = original.soilChemistryFileNameProvided;
		this.meteoFileNameProvided = original.meteoFileNameProvided;
		this.fructificationFileNameProvided = original.fructificationFileNameProvided;
		this.maintenanceRespirationActivated = original.maintenanceRespirationActivated;
		initScene = null;
	}

	/**
	 * A constructor for scripts. speciesFileName can be null if a Quergus
	 * inventory is given.
	 */
	public HetInitialParameters(String speciesFileName, String inventoryFileName, String samsaraLightFileName)
			throws Exception {

		this();

		this.speciesFileName = speciesFileName;
		this.inventoryFileName = inventoryFileName;
		this.samsaraLightFileName = samsaraLightFileName;
	}

	/**
	 * Adds the given pair (speciesId, phenology) in the phenologyMap
	 *
	 * @param speciesId
	 *            The species id
	 * @param phenology
	 *            The phenology
	 */
	public void addPhenology(int speciesId, HetPhenology phenology) {
		if (phenologyMap == null)
			phenologyMap = new HashMap();
		phenologyMap.put(speciesId, phenology);
	}

	@Override
	public GScene getInitScene() {
		return initScene;
	}

	/**
	 * Builds the initial scene.
	 */
	@Override
	public void buildInitScene(GModel m) throws Exception {

		HetReporter.printInStandardOutput("**************************");
		HetReporter.printInStandardOutput("* DEBUT buildInitScene() *");
		HetReporter.printInStandardOutput("**************************");

		HetModel model = (HetModel) m;

		model.setSettings(this);

		// fc-29.6.2017
		// Create a tmpSamsaManager to load the SamsaraLight file name and run
		// few controls. This tmpSamsaManager is not initialized completely, can
		// not run processLighting ()
		samsaFileLoader = new HetSamsaFileLoader(samsaraLightFileName);

		// Helper tags to check more easily lower if files were provided
		speciesFileNameProvided = speciesFileName != null && speciesFileName.length() > 0;
		castaneaFileNameProvided = castaneaFileName != null && castaneaFileName.length() > 0;
		inventoryFileNameProvided = inventoryFileName != null && inventoryFileName.length() > 0;
		samsaraLightFileNameProvided = samsaraLightFileName != null && samsaraLightFileName.length() > 0;
		soilHorizonsFileNameProvided = soilHorizonsFileName != null && soilHorizonsFileName.length() > 0;
		soilChemistryFileNameProvided = soilChemistryFileName != null && soilChemistryFileName.length() > 0;
		meteoFileNameProvided = meteorologyFileName != null && meteorologyFileName.length() > 0;
		fructificationFileNameProvided = fructificationFileName != null && fructificationFileName.length() > 0;

		maintenanceRespirationActivated = !constantNppToGppRatio;

		if (maintenanceRespirationActivated && !meteoFileNameProvided)
			throw new Exception("If maintenance respiration is activated, meteorology file must be provided");

		if (maintenanceRespirationActivated
				&& (!mineralHorizonsTemperatureCalculationActivated || !waterBalanceActivated)) {
			throw new Exception(
					"If maintenance respiration is activated, mineral horizons temperature calculation and water balance must be activated.");
		}

		if (castaneaPhotosynthesisActivated
				&& (!meteoFileNameProvided || !soilHorizonsFileNameProvided || !waterBalanceActivated))
			throw new Exception(
					"If castanea photosynthesis is activated, meteorology and soil horizons files must be provided and water balance activated");

		if (mineralHorizonsTemperatureCalculationActivated
				&& (!soilHorizonsFileNameProvided || !meteoFileNameProvided || !waterBalanceActivated))
			throw new Exception(
					"If calculation of mineral horizon temperature is activated, meteorology and soil horizons files must be provided and water balance activated");

		// fc+fa-26.4.2017
		if (fineResolutionRadiativeBalanceActivated && !meteoFileNameProvided)
			throw new Exception("If fine resolution radiative balance is activated, meteorology file must be provided");

		boolean foundMonthlyRecords = samsaFileLoader.hasMonthlyRecords();
		boolean foundHourlyRecords = samsaFileLoader.hasHourlyRecords();

		if (!fineResolutionRadiativeBalanceActivated && !foundMonthlyRecords && !foundHourlyRecords)
			throw new Exception(
					"If fine resolution radiative balance is not activated, monthly or hourly records must be provided in the SamsaraLight file");

		if (fineResolutionRadiativeBalanceActivated && !phenologyActivated)
			throw new Exception("If fine resolution radiative balance is activated, phenology must be activated");

		if (waterBalanceActivated && (!meteoFileNameProvided || !soilHorizonsFileNameProvided))
			throw new Exception("If water balance is activated, meteorology and soil horizons files must be provided");

		// fc+mj-29.4.2015
		// Load the speciesFileName if any (not needed if Quergus
		// inventory)
		if (speciesFileName != null && speciesFileName.length() > 0) {

			try {
				HetSpeciesFileLoader l = new HetSpeciesFileLoader();
				l.load(speciesFileName, model, speciesMap);

			} catch (Exception e) {
				MessageDialog.print(this, Translator.swap("HetInitialParameters.couldNotLoadSeparatedSpeciesFile"), e);
				return;
			}

			// fc-6.12.2017 no more report in FileLoader

			// String loaderReport = l.load(speciesFileName, model, speciesMap);
			// // In case of trouble, tell user
			// if (!l.succeeded()) {
			// MessageDialog.print(this,
			// Translator.swap("HetInitialParameters.couldNotLoadSeparatedSpeciesFile")
			// + " :\n" + loaderReport);
			// return;
			// }

		}

		// Load the Castanea species file // fc-et-al-20.1.2017
		if (castaneaPhotosynthesisActivated) { // fc+mj-10.3.2017
			try {
				// castaneaSpeciesMap is in FmSettings: superclass of this
				// object
				castaneaSpeciesMap = FmSpecies.loadCastaneaSpecies(this, castaneaFileName);

				// fc+mj-10.3.2017
				// Castanea extra parameters (found in castaneaonly)
				// nb-14.03.2018 Affectation moved in constructor in order to be
				// used as default value in the initial dialog box.
				// this.Ca = 380; // can be simulated according IPCC scenario

				// System.out.println("Ca: " + Ca);

				// LAI_FIXED, LAI_NSC, LAI_NSC_AND_DBH, LAI_NSC_DBH_AND_RDI
				this.LAImode = FmSettings.LAI_FIXED;

				// PHENO_CASTANEA, PHENO_FITLIB_UNIFORC,
				// PHENO_FITLIB_UNICHILL_THRESHOLD,
				// PHENO_FITLIB_GAUZERE, PHENO_PHELIB
				this.phenoMode = FmSettings.PHENO_CASTANEA;

				// STOMATA_STRESS_GRANIER, STOMATA_STRESS_RAMBAL
				this.stomataStress = STOMATA_STRESS_GRANIER;

				// TEMPERATURE_EFFECT_BERNACCHI, TEMPERATURE_EFFECT_ARRHENIUS
				this.temperatureEffectOnPhotosynthesis = FmSettings.TEMPERATURE_EFFECT_BERNACCHI; // fc-et-al-12.4.2017

				// ALLOC_REMAIN_WOOD, ALLOC_REMAIN_RESERVES
				this.allocRemain = FmSettings.ALLOC_REMAIN_WOOD;

				// ALLOC_SCHEMA_DAVI2009
				this.allocSchema = FmSettings.ALLOC_SCHEMA_DAVI2009;

			} catch (Exception e) {
				Log.println(Log.ERROR, "CastInitialParameters.buildInitScene ()",
						"Could not load Castanea species file", e);
				throw new Exception("Could not load Castanea species file, see Log file", e);
			}
		}

		// Load the inventory file
		try {

			// fc+fa-18.5.2017 Latitude, longitude and other params may be
			// changed in slSettings
			initScene = (HetScene) ((HetModel) model).loadInitStand(inventoryFileName);

			// fc+fa-17.5.2017 We need the phenologyMap in the initScene (see
			// initializeModel ())
			initScene.setPhenologyMap(this.phenologyMap);

			HetReporter.printInStandardOutput("phenologyMap size: " + phenologyMap.size());
			for (int speciesId : phenologyMap.keySet()) {
				HetPhenology pheno = phenologyMap.get(speciesId);
				HetReporter.printInStandardOutput("  speciesId: " + speciesId + " --> " + pheno.toString());
			}

		} catch (Exception e) {
			Log.println(Log.ERROR, "HetInitialParameters.buildInitScene ()", "Error during inventory file loading", e);
			throw new Exception("Error during inventory file loading, see Log file", e);
		}

		// fc+mj+fa-15.11.2019 MOVED HERE from HetModel.initializeModel (),
		// before pedons creations (see horizons below)
		// Fill gaps method (GL - 17/05/2013 move before the next loop to update
		// crownpart of
		// virtual trees)
		if (fillGaps) {
			((HetModel) model).fillGaps(initScene);
		}

		// Load soil horizons if a file name is provided
		if (soilHorizonsFileName != null && soilHorizonsFileName.length() > 0) {

			// fc-13.11.2019 loadHorizonFile () must be called after
			// loadInitStand() (in case waterBalance_fineResolutionActivated is
			// true)
			loadHorizonFile(model); // fc+mj-8.12.2016

		}

		// fc+mj+fa-15.11.2019 MIGHT be MOVED in HetModel.initializeModel () in case
		// this process would need pedon areas
		// Load soil chemistry if a file name is provided
		if (soilChemistryFileName != null && soilChemistryFileName.length() > 0) {

			if (!HetPhreeqc.isPhreeqcAvailable()) {

				// fc+nb-13.12.2016 Alert was not stopping the initialization
				// resulting in an error later
				throw new Exception(Translator.swap("HetInitialParameters.PhreeqcNotAvailable"));
			}

			try {

				HetSoilChemistryFileLoader l = new HetSoilChemistryFileLoader();
				l.load(soilChemistryFileName, this, model, initScene);

				// fc-6.12.2017 no more report in FileLoader

				// String loaderReport = l.load(soilChemistryFileName, this,
				// model, initScene);
				//
				// // In case of trouble, tell user
				// if (!l.succeeded())
				// throw new Exception("Could not load soil chemistry file: " +
				// soilChemistryFileName + "\n"
				// + loaderReport);

			} catch (Exception e) {
				Log.println(Log.ERROR, "HetInitialParameters.buildInitScene ()",
						"Error during soil chemistry file loading", e);
				throw new Exception("Error during soil chemistry file loading, see Log file", e);

			}
		}

		// Load meteorology if a file name is provided
		if (meteorologyFileName != null && meteorologyFileName.length() > 0) {

			try {

				HetMeteorologyFileLoader l = new HetMeteorologyFileLoader();
				l.load(meteorologyFileName, this);

				// fc-6.12.2017 no more report in FileLoader

				// String loaderReport = l.load(meteorologyFileName, this);
				//
				// // In case of trouble, tell user
				// if (!l.succeeded())
				// throw new Exception("Could not load meteorology file: " +
				// meteorologyFileName + "\n" + loaderReport);

				// Write trace in the log
				HetReporter.printInStandardOutput(this.meteorology.toString());

			} catch (Exception e) {
				Log.println(Log.ERROR, "HetInitialParameters.buildInitScene ()",
						"Error during meteorology file loading", e);
				throw new Exception("Error during meteorology file loading, see Log file", e);
			}
		}

		// Loads fructification's observations if a file name is provided
		if (fructificationFileNameProvided) {

			try {
				HetFructificationFileLoader loader = new HetFructificationFileLoader();
				loader.load(fructificationFileName);

				// fc-6.12.2017 no more report in FileLoader

				// String loaderReport = loader.load(fructificationFileName);
				//
				// // Trouble during loading.
				// if (!loader.succeeded()) {
				// throw new
				// Exception("Could not load fructification's observations file:
				// "
				// + fructificationFileName + "\n" + loaderReport);
				// }

				// Creates map.
				fructificationMap = new HashMap<Integer, Map<String, Double>>();

				// Fills in map.
				for (HetFructificationRecord observation : loader.fructificationObservationList) {

					int year = observation.year;
					String speciesName = observation.speciesName;
					double fruitLitterFall = observation.fruitLitterFall;

					if (fructificationMap.get(year) == null) {
						fructificationMap.put(year, new HashMap<String, Double>());
					}

					fructificationMap.get(year).put(speciesName, fruitLitterFall);
				}
			} catch (Exception e) {
				Log.println(Log.ERROR, "HetInitialParameters.buildInitScene()",
						"Error during fructification's observations file loading", e);
				throw new Exception("Error during fructification's observations file loading, see Log file", e);
			}
		}

		// Adjust dz and then check its validity: needs the soil of the initial
		// scene.
		if (mineralHorizonsTemperatureCalculationActivated) {

			// Adjust dz in order the soil depth is a multiple of dz
			double soilDepth = initScene.getSoil().calculateDepth();
			double finalDz = adjustDiscretisationSpaceStep(discretisationSpaceStep, soilDepth);

			if (finalDz != discretisationSpaceStep) {

				String infoMessage = "With the soil depth " + soilDepth + " m, " + "the initial dz value: "
						+ discretisationSpaceStep + " m\n"
						+ "has been automatically adjusted in order the soil depth is a multiple of dz.\n"
						+ "The adjusted value of dz is: " + finalDz + " m.";

				HetReporter.printInLog(Log.INFO, "HetInitialParameters.buildInitScene()", infoMessage);

				// Allows to open a dialog box in graphical mode or write in the
				// terminal in script mode
				Alert.print("HetInitialParameters.buildInitScene(), Information:\n" + infoMessage);

				discretisationSpaceStep = finalDz;
			}

			// Check dz validity
			try {
				checkDzValidity(discretisationSpaceStep);
			} catch (Exception e) {
				throw e;
			}
		}

		// Check file loading
		HetReporter.printInLog("Heterofor-tree-chemistry-distribution", treeChemistryDistribution.toString());

		// Loads the file containing atmospheric CO2 concentrations.
		if (variableAtmCO2ConcentrationOverTime) {

			try {
				HetAtmosphericCO2ConcentrationFileLoader loader = new HetAtmosphericCO2ConcentrationFileLoader();
				loader.load(atmCO2ConcentrationsFileName);

				yearAtmCO2ConcentrationMap = new HashMap();

				for (AtmosphericCO2ConcentrationRecord atmCO2ConcRecord : loader.atmCO2ConcRecords) {
					yearAtmCO2ConcentrationMap.put(atmCO2ConcRecord.year, atmCO2ConcRecord.atmCO2Concentration);
				}

			} catch (Exception e) {
				Log.println(Log.ERROR, "HetInitialParameters.buildInitScene()",
						"Error during atmospheric CO2 concentrations file loading", e);
				throw new Exception("Error during atmospheric CO2 concentrations file loading, see Log file", e);
			}
		}

		HetReporter.printInStandardOutput("************************");
		HetReporter.printInStandardOutput("* FIN buildInitScene() *");
		HetReporter.printInStandardOutput("************************");
	}

	public void loadHorizonFile(HetModel model) throws Exception {
		try {

			HetSoilHorizonsFileLoader l = new HetSoilHorizonsFileLoader();
			l.load(soilHorizonsFileName, this, model, initScene);

			// fc-6.12.2017 no more report in FileLoader

			// String loaderReport = l.load(soilHorizonsFileName, this, model,
			// initScene);
			//
			// // In case of trouble, tell user
			// if (!l.succeeded())
			// throw new Exception("Could not load soil horizons file: " +
			// soilHorizonsFileName + "\n" + loaderReport);

		} catch (Exception e) {
			Log.println(Log.ERROR, "HetInitialParameters.loadHorizonFile ()", "Error during soil horizons file loading",
					e);
			throw new Exception("Error during soil horizons file loading, see Log file", e);

		}

	}

	/**
	 * Clones a HetInitialParameters object. Caution: the cloned object has
	 * references to the same objects than the original.
	 */
	@Override
	public Object clone() {
		try {
			HetInitialParameters ip2 = (HetInitialParameters) super.clone();

			return ip2;
		} catch (Exception e) {
			Log.println(Log.ERROR, "HetInitialParameters.clone ()", "Error while cloning HetInitialParameters: " + this,
					e);
			return null;
		}
	}

	/**
	 * For all the loaded trees, init their tree compartments with mineral
	 * element concentrations.
	 */
	/*
	 * public void initTreeCompartments(HetScene initScene) throws Exception {
	 *
	 * for (Object o : initScene.getTrees()) { HetTree t = (HetTree) o;
	 *
	 * t.initTreeCompartments (this);
	 *
	 * // // Get the mandatory LEAVES_UPPER_CURRENT compartment //
	 * HetTreeCompartment luc = null; // for (HetTreeCompartment c :
	 * t.getTreeCompartments()) { // // if
	 * (c.name.equals(HetTreeCompartment.LEAVES_UPPER_CURRENT)) { // i.e. // //
	 * luc // luc = c; // break; // } // } // if (luc == null) // throw new
	 * Exception( //
	 * "HetInitialParameters, could not find the mandatory LEAVES_UPPER_CURRENT compartment for tree "
	 * // + t.getId() + " (" + t.getSpecies().getName() + ")"); // //
	 * createTreeCompartments(luc, t);
	 *
	 * }
	 *
	 * }
	 */

	/**
	 * Creates the missing compartments for the given tree, based on
	 * LEAVES_UPPER_CURRENT concentrations. Note: the given tree must contain
	 * the luc compartment.
	 */
	public void createTreeCompartments(HetTreeCompartment luc, HetTree t) {
		String speciesName = t.getSpecies().getName();

		Set<String> existingCompartmentNames = new HashSet<>();
		for (HetTreeCompartment c : t.getTreeCompartments()) {

			// Init existing compartment biomass and diameter
			c.init(t);

			existingCompartmentNames.add(c.name);
		}

		for (String cName : HetTreeCompartment.compartmentNames) {
			if (!existingCompartmentNames.contains(cName)) {
				// Create the missing compartment

				HetTreeCompartment newCompartment = new HetTreeCompartment(cName);

				// Init new compartment biomass and diameter
				newCompartment.init(t);

				t.addTreeCompartment(newCompartment);

				for (String eName : HetTreeElement.elementNames) {

					double lucConc = luc.getConcentration(eName);
					double lucMeanConc = treeChemistryDistribution.getConcentration(speciesName, luc, eName);

					double conc = treeChemistryDistribution.getConcentration(speciesName, newCompartment, eName);

					double deviationCoefficient = 1;
					if (lucMeanConc != 0) {
						deviationCoefficient = 1 + (lucConc - lucMeanConc) / lucMeanConc;
					}
					double newConc = conc * deviationCoefficient;

					newCompartment.setConcentration(eName, newConc);

				}

			}
		}

	}

	/**
	 * Creates the litter compartments for the alive trees in this scene.
	 */
	// public void createLitterCompartments(HetScene scene) {
	//
	// // Living trees
	// for (Object o : scene.getTrees()) {
	// HetTree t = (HetTree) o;
	//
	// createLitterCompartments(scene, t);
	//
	// }
	// }
	//
	// /**
	// * Creates the litter compartments for an alive tree, based on
	// * LEAVES_UPPER_CURRENT. fc+mj-11.5.2016
	// */
	// public void createLitterCompartments(HetScene scene, HetTree aliveTree) {
	//
	// createLitterCompartment(scene, aliveTree, HetLitterCompartment.LEAVES,
	// aliveTree.getLeafLitterAmount_kgOM() * 0.5);
	// createLitterCompartment(scene, aliveTree, HetLitterCompartment.BRANCHES,
	// aliveTree.getBranchLitterFall_kgC());
	// createLitterCompartment(scene, aliveTree, HetLitterCompartment.ROOTS,
	// aliveTree.getRootLitterFall_kgC());
	// createLitterCompartment(scene, aliveTree,
	// HetLitterCompartment.FINE_ROOTS,
	// aliveTree.getFineRootLitterFall_kgC());
	// createLitterCompartment(scene, aliveTree,
	// HetLitterCompartment.MYCORRHIZAE,
	// aliveTree.getMycorrhizaeLitterFall_kgC());
	// createLitterCompartment(scene, aliveTree, HetLitterCompartment.FRUITS,
	// aliveTree.getFruitLitterFall_kgC()); // fa+mj-01.12.2017
	//
	// }

	// /**
	// * Basic method to create a litter compartment with the given name and
	// * biomass in the given tree. The tree must contain its luc (i.e.
	// * LEAVES_UPPER_CURRENT tree compartment).
	// */
	// public void createLitterCompartment(HetScene scene, HetTree t, String
	// compartmentName, double biomass_kgC) {
	//
	// HetLitterCompartment litterCompartment = new
	// HetLitterCompartment(compartmentName);
	// litterCompartment.setBiomass(biomass_kgC);
	//
	// String speciesName = t.getSpecies().getName();
	// HetTreeCompartment luc =
	// t.getTreeCompartment(HetTreeCompartment.LEAVES_UPPER_CURRENT); // i.e.
	// // luc
	//
	// for (String eName : HetTreeElement.elementNames) {
	//
	// double conc = litterChemistryDistribution.getConcentration(speciesName,
	// litterCompartment, eName);
	//
	// double lucConc = luc.getConcentration(eName);
	// double lucMeanConc =
	// treeChemistryDistribution.getConcentration(speciesName, luc, eName);
	//
	// double deviationCoefficient = 1;
	// if (lucMeanConc != 0) {
	// deviationCoefficient = 1 + (lucConc - lucMeanConc) / lucMeanConc;
	// }
	// double newConc = conc * deviationCoefficient;
	//
	// if (scene.isInitialScene()) {
	// // Is there site data overriding the species file data ?
	// String key = speciesName + '.' + compartmentName;
	// HetInventoryLoader.LitterConcentrationLine litterConcentration =
	// litterConcentrationMap.get(key);
	// if (litterConcentration != null) {
	// double siteConc =
	// litterConcentration.getLitterCompartment(t).getConcentration(eName);
	// newConc = siteConc;
	// }
	// }
	//
	// litterCompartment.setConcentration(eName, newConc);
	// }
	//
	// t.addLitterCompartment(litterCompartment);
	//
	// }

	/**
	 * Calculates and returns the final value of discretisation space step that
	 * make the soil depth be a multiple of the discretisation space step. The
	 * soil depth is not necessary a multiple of the initial dz value.
	 *
	 * @param dz
	 *            The initial value of discretisation space step
	 * @param soildepth
	 *            The soil depth
	 * @return The adjusted discretisation space step that will be used in heat
	 *         fluxes calculations
	 */
	private double adjustDiscretisationSpaceStep(double dz, double soilDepth) {

		return -soilDepth / Math.ceil(-soilDepth / dz); // soilDepth is < 0
	}

	/**
	 * Checks the validity of the given space discretisation step. Throws an
	 * exception and stops program execution if the value of the dz space
	 * discretisation step is not valid: dz must be lower than the minimal
	 * thickness of all mineral horizons of soil.
	 *
	 * @param dz
	 *            The space discretisation step
	 * @throws Exception
	 */
	public void checkDzValidity(double dz) throws Exception {

		double minimalHorizonThickness = Double.MAX_VALUE;

		// fc-12.11.2019 all pedons have same horizon number and sizes
		for (HetHorizon horizon : initScene.getSoil().getPedonSpecimen().getHorizons()) {
			// for (HetHorizon horizon : initScene.getSoil().getHorizons()) {

			if (!horizon.isOrganic()) {
				double horizonThickness = horizon.thickness;
				if (horizonThickness < minimalHorizonThickness)
					minimalHorizonThickness = horizonThickness;
			}
		}

		double minimalValidDz = meshCoefficient * minimalHorizonThickness;

		if (dz > minimalValidDz) {
			String errorMessage = "dz=" + dz + " m. dz must be lower than " + minimalValidDz + " (=" + meshCoefficient
					+ " x " + "minimal mineral horizon thickness), where:\n" + "minimal mineral horizon thickness = "
					+ minimalHorizonThickness + " m.\n" + "Aborted.";
			Log.println(Log.ERROR, "HetInitialParameters.checkDzValidity()", errorMessage);
			throw new Exception("HetInitialParameters.checkDzValidity(): Error: " + errorMessage);
		}
	}

	public Polygon2 getInventoryZoneJonard() {
		return inventoryZoneJonard;
	}

	public void setInventoryZoneJonard(Polygon2 p) {
		this.inventoryZoneJonard = p;
	}

	public Polygon2 getInventoryZoneR2() {
		return inventoryZoneRestreint;
	}

	public void setInventoryZoneR2(Polygon2 p) {
		this.inventoryZoneRestreint = p;
	}

	public Polygon2 getInventoryZoneE2() {
		return inventoryZoneElargit2;
	}

	public void setInventoryZoneE2(Polygon2 p) {
		this.inventoryZoneElargit2 = p;
	}

	public Polygon2 getInventoryZoneE3() {
		return inventoryZoneElargit3;
	}

	public void setInventoryZoneE3(Polygon2 p) {
		this.inventoryZoneElargit3 = p;
	}

	public Polygon2 getInventoryZoneE4() {
		return inventoryZoneElargit4;
	}

	public void setInventoryZoneE4(Polygon2 p) {
		this.inventoryZoneElargit4 = p;
	}

	public HetChemicalElement getChemicalElement(String name) {
		HetChemicalElement ce = chemicalElements.get(name);
		if (ce == null)
			HetReporter.printInLog(Log.WARNING, "HetInitialParameters.getChemicalElement (name)",
					"Could not find a chemical element: " + name + ", returned null");
		return ce;
	}

	public Map<String, HetChemicalElement> getChemicalElements() {
		return chemicalElements;
	}

	public List<HetChemicalElement> getChemicalElementList() {
		return new ArrayList<>(chemicalElements.values());
	}

	public Map<Integer, HetSpecies> getSpeciesMap() { // fa-10.11.2017
		return speciesMap;
	}
}
