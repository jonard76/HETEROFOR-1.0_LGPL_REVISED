/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.meteorology;

import heterofor.model.HetInitialParameters;

import java.util.List;

import capsis.util.Fit2018Date;
import jeeb.lib.util.Log;
import jeeb.lib.util.Translator;
import jeeb.lib.util.fileloader.FileLoader;

/**
 * A file loader for the Heterofor meteorology file.
 *
 * @author F. de Coligny - September 2016
 */
public class HetMeteorologyFileLoader extends FileLoader {

	public double windSpeedMeasurementHeight; // fc+mj+lw-18.10.2016
	public double windSpeedAttenuationCoefficient; // fc+mj+lw-18.10.2016
	public List<HetMeteoLine> meteoLines;

	private StringBuffer warningReport;// fc+mj-9.3.2017

	/**
	 * Constructor
	 */
	public HetMeteorologyFileLoader() throws Exception {
		super();

		// // Needed: the complex sections will be evaluated afterwards based on
		// // expected line prefixes (e.g. soilSolution...)
		// // -> unrecognized lines are turned into UnknownRecords
		// setMemorizeWrongLines(true);
		//
		addAdditionalClass(HetMeteoLine.class);
	}

	/**
	 * Loads the meteorology file and store meteo lines in ip.
	 */
	public void load(String fileName, HetInitialParameters ip) throws Exception {

		// 1. Load the file
		super.load(fileName);

		// fc-6.12.2017 no more report in FileLoader

		// String report = super.load(fileName);

		// for (Record record : this) {
		// System.out.println("Record: " + record.getClass() + ": " + record);
		// }

		// 2. Evaluate content
		try {
			warningReport = new StringBuffer();// fc+mj-9.3.2017

			// Create the soil object
			ip.meteorology = new HetMeteorology();
			ip.meteorology.setWindSpeedMeasurementHeight(windSpeedMeasurementHeight);
			ip.meteorology.setWindSpeedAttenuationCoefficient(windSpeedAttenuationCoefficient);

			// Load and add the soil horizons
			for (HetMeteoLine l : meteoLines) {

				// fc+mj-9.3.2017 windSpeed correction: never 0
				if (l.windSpeed <= 0) {
					l.windSpeed = 0.1;
					warningReport
							.append(Translator
									.swap("HetMeteorologyFileLoader.someWindSpeedValuesEqualToZeroHaveBeenFoundInMeteoFileAndSetTo")
									+ " " + l.windSpeed + " : " + fileName);
				}

				ip.meteorology.addMeteoLine(l);

			}

		} catch (Exception e) {
			setSuccess(false);
			Log.println(Log.ERROR, "HetMeteorologyFileLoader.load ()",
					"An error occurred during meteorology file loading", e);
			throw new Exception("An error occurred during meteorology file loading: " + e
					+ ", see the Log for further information", e);
		}

		// return report;
	}

	public StringBuffer getWarningReport() {
		return warningReport;
	}

	@Override
	protected void checks() throws Exception {

		// Checks that dates and hours in meteorological file are not missing and are ordered. nb-04.10.2018
		if (meteoLines.size() == 0) {
			Log.println(Log.ERROR, "HetMeteorologyFileLoader.checks()", "An error occurred during meteorology file checking.");
			throw new Exception("There is no meteo line in meteorology file.");
		}

		int meteoLineIndex = 0;

		// First meteo line.
		int yearOfFirstMeteoLine = meteoLines.get(meteoLineIndex).year;
		int monthOfFirstMeteoLine = meteoLines.get(meteoLineIndex).month;
		int dayOfFirstMeteoLine = meteoLines.get(meteoLineIndex).day;
		int hourOfFirstMeteoLine = meteoLines.get(meteoLineIndex).hour;
		Fit2018Date date = Fit2018Date.getInstance(yearOfFirstMeteoLine, monthOfFirstMeteoLine, dayOfFirstMeteoLine);

		if (monthOfFirstMeteoLine != 1) {
			Log.println(Log.ERROR, "HetMeteorologyFileLoader.checks()", "An error occurred during meteorology file checking.");
			throw new Exception("The month of the first meteo line is equal to " + monthOfFirstMeteoLine + ". It should be equal to 1.");
		}

		if (dayOfFirstMeteoLine != 1) {
			Log.println(Log.ERROR, "HetMeteorologyFileLoader.checks()", "An error occurred during meteorology file checking.");
			throw new Exception("The day of the first meteo line is equal to " + dayOfFirstMeteoLine + ". It should be equal to 1.");
		}

		if (hourOfFirstMeteoLine != 0) {
			Log.println(Log.ERROR, "HetMeteorologyFileLoader.checks()", "An error occurred during meteorology file checking.");
			throw new Exception("The hour of the first meteo line is equal to " + hourOfFirstMeteoLine + ". It should be equal to 0.");
		}

		int yearOfLastValidMeteoLine = yearOfFirstMeteoLine;
		int monthOfLastValidMeteoLine = monthOfFirstMeteoLine;
		int dayOfLastValidMeteoLine = dayOfFirstMeteoLine;
		int hourOfLastValidMeteoLine = hourOfFirstMeteoLine;

		int year, month, day, hour;

		while (meteoLineIndex < meteoLines.size()) {

			// Meteo line that should be the first hour of a day.
			year = meteoLines.get(meteoLineIndex).year;
			month = meteoLines.get(meteoLineIndex).month;
			day = meteoLines.get(meteoLineIndex).day;
			hour = meteoLines.get(meteoLineIndex).hour;

			if (year != date.getYear() || month != date.getMonth() || day != date.getDayOfMonth() || hour != 0) {
				Log.println(Log.ERROR, "HetMeteorologyFileLoader.checks()", "An error occurred during meteorology file checking.");
				throw new Exception("Bad year/month/day/hour combination for meteo line following the one with year: " + yearOfLastValidMeteoLine
						+ ", month: " + monthOfLastValidMeteoLine + ", day: " + dayOfLastValidMeteoLine + ", hour: " + hourOfLastValidMeteoLine
						+ ". Index of meteo line: " + meteoLineIndex);
			}

			// The other hours of the day.
			for (int cptHour = 1 ; cptHour <= 23 ; cptHour++) {

				meteoLineIndex++;

				year = meteoLines.get(meteoLineIndex).year;
				month = meteoLines.get(meteoLineIndex).month;
				day = meteoLines.get(meteoLineIndex).day;
				hour = meteoLines.get(meteoLineIndex).hour;

				if (year != date.getYear() || month != date.getMonth() || day != date.getDayOfMonth() || hour != cptHour) {
					Log.println(Log.ERROR, "HetMeteorologyFileLoader.checks()", "An error occurred during meteorology file checking.");
					throw new Exception("Bad year/month/day/hour combination for meteo line following the one with year: " + yearOfLastValidMeteoLine
							+ ", month: " + monthOfLastValidMeteoLine + ", day: " + dayOfLastValidMeteoLine + ", hour: "
							+ hourOfLastValidMeteoLine  + ". Index of meteo line: " + meteoLineIndex);
				}

				yearOfLastValidMeteoLine = year;
				monthOfLastValidMeteoLine = month;
				dayOfLastValidMeteoLine = day;
				hourOfLastValidMeteoLine = hour;
			}

			// Adds a day to the current date.
			date = date.addDays(1.0);

			meteoLineIndex++;
		}

	}

}
