/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model;

import java.util.ArrayList;
import java.util.Arrays;
//import java.util.concurrent.atomic.AtomicLong; //fa-12.10.2017
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;

import capsis.defaulttype.Tree;
import capsis.defaulttype.TreeList;
import capsis.defaulttype.plotofcells.Cell;
import capsis.defaulttype.plotofcells.CellTree;
import capsis.defaulttype.plotofcells.RoundMask;
import capsis.defaulttype.plotofcells.SquareCell;
import capsis.kernel.EvolutionParameters;
import capsis.kernel.GModel;
import capsis.kernel.GScene;
import capsis.kernel.InitialParameters;
import capsis.kernel.MethodProvider;
import capsis.kernel.Step;
import capsis.lib.regeneration.RGCohort;
import capsis.lib.regeneration.RGCohortSizeClass;
import capsis.lib.regeneration.RGModel;
import capsis.lib.regeneration.RGProcess;
import capsis.lib.regeneration.RGUnderstorey;
import capsis.lib.samsaralight.SLCrownPart;
import capsis.lib.samsaralight.SLFoliageStateManager;
import capsis.lib.samsaralight.SLModel;
import capsis.lib.samsaralight.SLTargetLightResult;
import capsis.lib.samsaralight.SLTrunk;
import capsis.util.GTreeIdComparator;
import capsis.util.group.GrouperManager;
import heterofor.model.meteorology.HetMeteoLine;
import heterofor.model.meteorology.HetMeteorology;
import heterofor.model.nutrientlimitation.ActualUptakeCalculator;
import heterofor.model.nutrientlimitation.NutrientDemandCalculator;
import heterofor.model.nutrientlimitation.PotentialtUptakeCalculator;
import heterofor.model.phenology.HetPhenology;
import heterofor.model.soil.HetHorizon;
import heterofor.model.soil.HetSoil;
import heterofor.model.soil.HetSoilInterface;
import heterofor.model.soilchemistry.HetChemicalElement;
import heterofor.model.soilchemistry.HetPhreeqc;
import heterofor.model.soilchemistry.HetSoilChemistryFileLoader;
import heterofor.model.treechemistry.HetLitterCompartment;
import heterofor.model.treechemistry.HetTreeCompartment;
import heterofor.model.treechemistry.HetTreeElement;
import heterofor.model.vegetationperiod.HetVegetationPeriod;
import heterofor.model.waterbalance.HetSoilHeatFluxCalculator;
import heterofor.model.waterbalance.HetWaterBalance;
import heterofor.model.waterbalance.HetWaterBalanceCalculator;
import heterofor.model.waterbalance.HetYearlyTranspirationMemory;
import heterofor.model.waterbalance.pedon.Pedon;
import jeeb.lib.maps.geom.Point2;
import jeeb.lib.maps.geom.Polygon2;
import jeeb.lib.util.Alert;
import jeeb.lib.util.AmapTools;
import jeeb.lib.util.Log;
import jeeb.lib.util.ProgressDispatcher;
import jeeb.lib.util.StatusDispatcher;
import jeeb.lib.util.TicketDispenser;
import jeeb.lib.util.Translator;
import jeeb.lib.util.Vertex2d;

/**
 * The main class for Heterofor. It usually contains methods to create the
 * initial scene in the project. This can be done by loading a file or by
 * specific generation methods. It contains an initializeModel
 * (InitialParameters p) method that is run at project initialisation time. It
 * also contains the main processEvolution (Step s, EvolutionParameters p)
 * method to calculate the evolution of the scene over time, i.e. the growth or
 * dynamics model.
 *
 * @author M. Jonard, F. Herman - January 2012
 */
public class HetModel extends GModel implements RGModel {

	// A way to get unique ids for the trees
	private TicketDispenser treeIdDispenser;

	// fc-29.6.2017 ENCAPSULATES and replaces slModel
	private HetSamsaManager samsaManager;

	// fc-29.6.2017 REMOVED, replaced by samsaManager
	// private SLModel slModel; // SamsaraLight
	private Random random;

	// For automatic groups creation
	private HetSpecies speciesSpecimen;

	private SLModel slModel;

	private int dateOfInitialScene;

	// fc-22.5.2019 Kept this ref to help write VirtualUnderstroeyGeneration
	private HetInventoryLoader inventoryLoader;

	/**
	 * Constructor
	 */
	public HetModel() throws Exception {
		super();
		treeIdDispenser = new TicketDispenser();

		random = new Random();

		setSettings(new HetInitialParameters());

		// slModel = new SLModel();

		// sensors = new ArrayList<HetSensor> ();
	}

	/**
	 * Creates a MethodProvider for the module.
	 */
	protected MethodProvider createMethodProvider() {
		return new HetMethodProvider();
	}

	/**
	 * Convenient method.
	 */
	public HetInitialParameters getSettings() {
		return (HetInitialParameters) settings;
	}

	/**
	 * Loads the inventory file with the given fileName. Creates HetTree
	 * instances and adds them into the initial scene.
	 */
	public GScene loadInitStand(String fileName) throws Exception {

		// fc-22.5.2019 we keep the ref to inventoryLoader to help write
		// VirtualUnderstroeyGeneration
		inventoryLoader = new HetInventoryLoader(fileName);
		HetScene initScene = (HetScene) inventoryLoader.load(this);

		return initScene;
	}

	/**
	 * Creates the map containing the phenology objects for all species for the
	 * given year (i.e. year of bud burst). prevPhenologyMap is the same map for
	 * previous year. First time, initialLeafOnDoy must be passed (e.g.135),
	 * then it must be set to -1.
	 *
	 */
	private HashMap<Integer, HetPhenology> createPhenologyMap(int year, HetMeteorology meteorology,
			Map<Integer, HetSpecies> speciesMap, Map<Integer, HetPhenology> prevPhenologyMap,
			double plotLatitudeInRadians, int initialLeafOnDoy) throws Exception {

		// System.out.println("-- createPhenologyMap() begin ------------- year:
		// "
		// + year);
		// System.out.println("initialLeafOnDoy: " + initialLeafOnDoy);

		List<HetMeteoLine> meteoLines = meteorology.getMeteoLines(year);

		if (meteoLines.size() == 0) {
			throw new Exception(
					"HetModel.createPhenologyMap(): could not find year: " + year + " in meteorology, aborted");
		}

		// Calculate the average daily air temperatures for next year
		LinkedHashMap<String, Double> dateDailyAverageAirTemperatureMap = HetMeteorology
				.calculateDailyAverageAirTemperature(meteoLines);

		LinkedHashMap<String, Double> dateDailyAverageWindSpeedMap = HetMeteorology
				.calculateDailyAverageWindSpeed(meteoLines);

		HashMap<Integer, HetPhenology> phenologyMap = new HashMap();

		for (int speciesId : speciesMap.keySet()) {

			// prevPhenology contains phenologyModel
			HetPhenology prevPhenology = prevPhenologyMap.get(speciesId);

			HetPhenology newPhenology = null;
			if (initialLeafOnDoy >= 0)
				newPhenology = new HetPhenology(prevPhenology, year, initialLeafOnDoy);
			else
				newPhenology = new HetPhenology(prevPhenology, year);

			newPhenology.run(year, dateDailyAverageAirTemperatureMap, dateDailyAverageWindSpeedMap, meteoLines,
					plotLatitudeInRadians);

			// newPhenology.displayDates();
			// newPhenology.displayFoliageState();

			HetReporter.printInStandardOutput("-------- createPhenologyMap() end");

			phenologyMap.put(speciesId, newPhenology);
		}

		return phenologyMap;
	}

	/**
	 * This method is called for the first scene of the project at project
	 * creation time.
	 */
	@Override
	public Step initializeModel(InitialParameters p) throws Exception {

		HetReporter.printInStandardOutput("***************************");
		HetReporter.printInStandardOutput("* DEBUT initializeModel() *");
		HetReporter.printInStandardOutput("***************************");

		slModel = ((HetInitialParameters) p).samsaFileLoader.slModel;

		// System.out.println("***************************");
		// System.out.println("* Debut initializeModel() *");
		// System.out.println("***************************");
		// System.out.println("Settings de slModel:");
		// System.out.println("");
		// System.out.println("parallelMode: " +
		// slModel.getSettings().isParallelMode());
		// System.out.println("tagMode: " + slModel.getSettings().isTagMode());
		// System.out.println("fileName: " +
		// slModel.getSettings().getFileName());
		// System.out.println("turbidMedium: " +
		// slModel.getSettings().isTurbidMedium());
		// System.out.println("trunkInterception: " +
		// slModel.getSettings().isTrunkInterception());
		// System.out.println("directAngleStep: " +
		// slModel.getSettings().getDirectAngleStep());
		// System.out.println("heightAngleMin: " +
		// slModel.getSettings().getHeightAngleMin());
		// System.out.println("diffuseAngleStep: " +
		// slModel.getSettings().getDiffuseAngleStep());
		// System.out.println("soc: " + slModel.getSettings().isSoc());
		// System.out.println("leafOnDoy: " +
		// slModel.getSettings().getLeafOnDoy());
		// System.out.println("leafOffDoy: " +
		// slModel.ge to help write
		// VirtualUnderstroeyGenerationtSettings().getLeafOffDoy());
		// if (slModel.getSettings().getMontlyRecords() != null) {
		// System.out.println("monthlyRecords: " +
		// slModel.getSettings().getMontlyRecords().size());
		// } else {
		// System.out.println("monthly records null");
		// }
		// if (slModel.getSettings().getHourlyRecords() != null) {
		// System.out.println("hourlyRecords: " +
		// slModel.getSettings().getHourlyRecords().size());
		// } else {
		// System.out.println("hourly records null");
		// }
		// System.out.println("writeStatusDispatcher: " +
		// slModel.getSettings().isWriteStatusDispatcher());
		// System.out.println("GMT: " + slModel.getSettings().getGMT());
		// System.out.println("plotLatitude_deg: " +
		// slModel.getSettings().getPlotLatitude_deg());
		// System.out.println("plotLongitude_deg: " +
		// slModel.getSettings().getPlotLongitude_deg());
		// System.out.println("plotSlope_deg: " +
		// slModel.getSettings().getPlotSlope_deg());
		// System.out.println("plotAspect_deg: " +
		// slModel.getSettings().getPlotAspect_deg());
		// System.out.println("northToXAngle_cw_deg: " +
		// slModel.getSettings().getNorthToXAngle_cw_deg());
		// System.out.println("sensorLightOnly: " +
		// slModel.getSettings().isSensorLightOnly());

		// Optional process at project creation time
		HetScene initScene = (HetScene) p.getInitScene();

		// Update tree crown shapes
		HetInitialParameters ip = (HetInitialParameters) p;

		// Calculate the phenology dates for next year
		if (ip.phenologyActivated) {

			// fc-28.6.2017 REFACTORED phenology maps creation for year and next
			// year

			// Create phenologyMap for initial year
			HashMap<Integer, HetPhenology> initialPhenologyMap = createPhenologyMap(initScene.getDate(), ip.meteorology,
					ip.speciesMap, ip.phenologyMap, Math.toRadians(ip.samsaFileLoader.getPlotLatitude_deg()),
					ip.samsaFileLoader.getLeafOnDoy());
			initScene.setPhenologyMap(initialPhenologyMap); // root step

			HetReporter.printInStandardOutput("****** initialPhenologyMap: ");
			for (int speciesId : initialPhenologyMap.keySet()) {
				HetPhenology pheno = initialPhenologyMap.get(speciesId);
				HetReporter.printInStandardOutput("  speciesId: " + speciesId);
				pheno.displayDates();
			}

			// Create phenologyMap for next year
			// fc+mj+fa-28.6.2017 calc pheno for nextYear to get a light map
			// matching nextYear's pheno
			HashMap<Integer, HetPhenology> nextYearPhenologyMap = createPhenologyMap(initScene.getDate() + 1,
					ip.meteorology, ip.speciesMap, initialPhenologyMap,
					Math.toRadians(ip.samsaFileLoader.getPlotLatitude_deg()), -1);
			initScene.setPhenologyMapOfNextYear(nextYearPhenologyMap); // next
																		// year
			HetReporter.printInStandardOutput("****** nextYearPhenologyMap: ");
			for (int speciesId : nextYearPhenologyMap.keySet()) {
				HetPhenology pheno = nextYearPhenologyMap.get(speciesId);
				HetReporter.printInStandardOutput("  speciesId: " + speciesId + " --> " + pheno.toString());
			}

			// Vegetation period with 3 phases inside: leafDevevelopment,
			// completeDevelopment, yellowing
			HetVegetationPeriod vegetationPeriod = new HetVegetationPeriod(initScene.getPhenologyMap());
			initScene.setVegetationPeriod(vegetationPeriod);

			HetVegetationPeriod vegetationPeriodOfNextYear = new HetVegetationPeriod(
					initScene.getPhenologyMapOfNextYear());
			initScene.setVegetationPeriodOfNextYear(vegetationPeriodOfNextYear);

		}

		// fa-5.7.2017: Set vegetation period length for initial and next years
		if (ip.phenologyActivated) {
			initScene.setCurrentVegetationPeriodLength(initScene.getVegetationPeriod().yellowingPhase.endDoy
					- initScene.getVegetationPeriod().leafDevelopmentPhase.startDoy);
			initScene.setNextYearVegetationPeriodLength(initScene.getVegetationPeriodOfNextYear().yellowingPhase.endDoy
					- initScene.getVegetationPeriodOfNextYear().leafDevelopmentPhase.startDoy); // fa-6.7.2017
		} else {
			initScene.setCurrentVegetationPeriodLength(
					ip.samsaFileLoader.getLeafOffDoy() - ip.samsaFileLoader.getLeafOnDoy());
			initScene.setNextYearVegetationPeriodLength(
					ip.samsaFileLoader.getLeafOffDoy() - ip.samsaFileLoader.getLeafOnDoy()); // fa-6.7.2017
		}

		// // UNDER REFACTORING ------------ fc-29.6.2017 ------------
		// initializeModel()...
		// if (ip.fineResolutionRadiativeBalanceActivated) {
		//
		// // fc+fa-25.4.2017 Activation of the detailed result mode based on
		// // tags in beams and tree parts
		// // There will be additional results
		// slSettings.setTagMode(true);
		//
		// // Vegetation period with 3 phases inside: leafDevevelopment,
		// // completeDevelopment, yellowing
		// HetVegetationPeriod vegetationPeriod = new
		// HetVegetationPeriod(initScene.getPhenologyMapOfNextYear());
		// initScene.setVegetationPeriodOfNextYear(vegetationPeriod);
		//
		// // fc+fa-27.4.2017 BeamSet creation in fine resolution mode
		// // Create beamSet for root step, valid for 3 years (if
		// // radiationCalculationTimeStep = 3)
		// int startYear = initScene.getDate();
		// int endYear = startYear + ip.radiationCalculationTimeStep - 1;
		//
		// // Create a custom beamSet
		// HetBeamSetFactory beamSetFactory = new HetBeamSetFactory(startYear,
		// endYear, vegetationPeriod,
		// ip.meteorology, slSettings);
		//
		// // Memo factory in the scene, available for 3 years
		// initScene.setBeamSetFactory(beamSetFactory);
		//
		// // Create a custom beamSet
		// SLBeamSet beamSet = beamSetFactory.getBeamSet();
		// slModel.setBeamSet(beamSet, initScene, ip.treeMaxHeight, cellWidth,
		// ip.maxCrownRadius);
		//
		// } else {
		//
		// // Create the legacy beamSet slModel.init2_createLegacyBeamSet();
		//
		// }

		// fc+mj+fa-15.11.2019 MOVED in ip.buildInitScene () before horizons /
		// pedons creation
		// // Fill gaps method (GL - 17/05/2013 move before the next loop to
		// update
		// // crownpart of
		// // virtual trees)
		// if (ip.fillGaps) {
		// fillGaps(initScene);
		// }

		// fa+mj-20.03.2018
		HashMap<Integer, Double> meanUpperCrownHeightMap = new HashMap<Integer, Double>();
		HashMap<Integer, Double> meanLowerCrownHeightMap = new HashMap<Integer, Double>();
		HashMap<Integer, Integer> speciesTreeNumberMap = new HashMap<Integer, Integer>();
		Map<Integer, HetSpecies> speciesMap = ip.getSpeciesMap();
		for (int spId : speciesMap.keySet()) {
			meanUpperCrownHeightMap.put(spId, 0d);
			meanLowerCrownHeightMap.put(spId, 0d);
			speciesTreeNumberMap.put(spId, 0);
		}
		for (Iterator i = initScene.getTrees().iterator(); i.hasNext();) {
			HetTree t = (HetTree) i.next();

			double meanUpperCrownHeight = (t.getHlce() + t.getHeight()) / 2d;
			double meanLowerCrownHeight = (t.getHcb() + t.getHlce()) / 2d;

			meanUpperCrownHeightMap.put(t.getSpecies().getId(),
					meanUpperCrownHeightMap.get(t.getSpecies().getId()) + meanUpperCrownHeight);
			meanLowerCrownHeightMap.put(t.getSpecies().getId(),
					meanLowerCrownHeightMap.get(t.getSpecies().getId()) + meanLowerCrownHeight);
			speciesTreeNumberMap.put(t.getSpecies().getId(), speciesTreeNumberMap.get(t.getSpecies().getId()) + 1);

		}
		for (int spId : speciesMap.keySet()) {
			if (speciesTreeNumberMap.get(spId) != 0) {
				meanUpperCrownHeightMap.put(spId,
						(double) meanUpperCrownHeightMap.get(spId) / speciesTreeNumberMap.get(spId));
				meanLowerCrownHeightMap.put(spId,
						(double) meanLowerCrownHeightMap.get(spId) / speciesTreeNumberMap.get(spId));
			}
		}
		initScene.setMeanUpperCrownHeightMap(meanUpperCrownHeightMap);
		initScene.setMeanLowerCrownHeightMap(meanLowerCrownHeightMap);

		// At simulation initialisation time, tree initialisation is finished in
		// different steps.
		// Finish trees construction: SLCrownParts, LAD, SLTrunk if needed
		for (Iterator i = initScene.getTrees().iterator(); i.hasNext();) {
			HetTree t = (HetTree) i.next();

			t.createSLStructures(ip, initScene);

			// // fc-29.6.2017
			// if (ip.samsaFileLoader.isTrunkInterception())
			// t.createSLTrunk();
			//
			// t.createSLCrownParts(ip.LADNeighbourhoodDistance, initScene); //
			// including
			// LAD
		}

		if (ip.phenologyAtTreeLevel) {
			
			// Calculates for each tree:
			// - the sum of leaf areas of the trees smaller than it and that belong to the same species. This sum 
			// will be then used in the calculation of the ladProp (proportion of leaf area compared to the level 
			// of maximum development) at tree level. 
			// - the sum of leaf areas of the trees taller than it and that belong to the same species. This sum 
			// will be then used in the calculation of the ladProp and the greenProp (proportion of green leaves 
			// compared to the level of maximum development) at tree level. nb-17.12.2019
			initScene.calculateCumulatedLeafAreasOfSmallerAndTallersTrees();			
		}

		// System.out.println("Avant calcul:");
		// for (int speciesId : ip.speciesMap.keySet()) {
		// System.out.println("speciesId: " + speciesId + " / code:" +
		// speciesMap.get(speciesId).hashCode() + " --> leafArea: " +
		// ip.speciesMap.get(speciesId).leafArea_sp);
		// }

		// Calculates the leaf area of the species. Needed in calculation of lad
		// proportion. nb-07.11.2019
		
		// fa-17.12.2019: moved species leaf area from HetSpecies to HetScene
		HashMap<Integer, Double> speciesLeafAreaMap = new HashMap<Integer, Double>();
		for (int speciesId : ip.speciesMap.keySet()) { // initialization
			speciesLeafAreaMap.put(speciesId, 0d);
		}
		for (Tree t : initScene.getTrees()) {
			HetTree tree = (HetTree) t;
			HetSpecies species = tree.getSpecies();
			int speciesId = species.getId(); // fa-17.12.2019
//			species.leafArea_sp += tree.getLeafArea(); // fa-17.12.2019: commented
			addInMap(speciesLeafAreaMap, speciesId, tree.getLeafArea()); // fa-17.12.2019
		}
		initScene.setSpeciesLeafAreaMap(speciesLeafAreaMap);
		

		System.out.println("Apres calcul:");
		for (int speciesId : ip.speciesMap.keySet()) {
			System.out.println("speciesId: " + speciesId + " / code:" + speciesMap.get(speciesId).hashCode()
					+ " --> leafArea: " + initScene.getSpeciesLeafAreaMap().get(speciesId)); // fa-17.12.2019
//					+ " --> leafArea: " + ip.speciesMap.get(speciesId).leafArea_sp); // fa-17.12.2019: commented
		}

		// System.exit(0);

		// fc-15.11.2019 Horizons must be loaded when all trees have been
		// created (after fillGaps() upper) and when leaf area values are
		// available (afeter createSLCrownParts () upper). This way, the Pedons
		// in a HetDiscreteSoil (if this option was selected) option will be
		// created correctly.
		initScene.getSoil ().updatePedonProperties(initScene);
		
		// fc-15.11.2019 COULD BE MOVED here from HetInitialParameters (Pedons / fillGaps
		// () / trees leafArea availability) if it needes the pedonAreas updated in 
		// updatePedonProperties() upper
		// Load soil chemistry if a file name is provided
//		if (ip.soilChemistryFileName != null && ip.soilChemistryFileName.length() > 0) {
//
//			if (!HetPhreeqc.isPhreeqcAvailable()) {
//
//				// fc+nb-13.12.2016 Alert was not stopping the initialization
//				// resulting in an error later
//				throw new Exception(Translator.swap("HetInitialParameters.PhreeqcNotAvailable"));
//			}
//
//			try {
//
//				HetSoilChemistryFileLoader l = new HetSoilChemistryFileLoader();
//				l.load(ip.soilChemistryFileName, ip, this, initScene);
//
//				// fc-6.12.2017 no more report in FileLoader
//
//				// String loaderReport = l.load(soilChemistryFileName, this,
//				// model, initScene);
//				//
//				// // In case of trouble, tell user
//				// if (!l.succeeded())
//				// throw new Exception("Could not load soil chemistry file: " +
//				// soilChemistryFileName + "\n"
//				// + loaderReport);
//
//			} catch (Exception e) {
//				Log.println(Log.ERROR, "HetModel.initializeModel ()", "Error during soil chemistry file loading", e);
//				throw new Exception("Error during soil chemistry file loading, see Log file", e);
//
//			}
//		}

		// fc-29.8.2017 Run processLighting () on initScene
		SLFoliageStateManager foliageStateManager = (SLFoliageStateManager) initScene;

		// System.out.println("*************************");
		// System.out.println("* Avant processLighting *");
		// System.out.println("*************************");
		//
		// System.out.println("Settings de slModel:");
		// System.out.println("");
		// System.out.println("parallelMode: " +
		// slModel.getSettings().isParallelMode());
		// System.out.println("tagMode: " + slModel.getSettings().isTagMode());
		// System.out.println("fileName: " +
		// slModel.getSettings().getFileName());
		// System.out.println("turbidMedium: " +
		// slModel.getSettings().isTurbidMedium());
		// System.out.println("trunkInterception: " +
		// slModel.getSettings().isTrunkInterception());
		// System.out.println("directAngleStep: " +
		// slModel.getSettings().getDirectAngleStep());
		// System.out.println("heightAngleMin: " +
		// slModel.getSettings().getHeightAngleMin());
		// System.out.println("diffuseAngleStep: " +
		// slModel.getSettings().getDiffuseAngleStep());
		// System.out.println("soc: " + slModel.getSettings().isSoc());
		// System.out.println("leafOnDoy: " +
		// slModel.getSettings().getLeafOnDoy());
		// System.out.println("leafOffDoy: " +
		// slModel.getSettings().getLeafOffDoy());
		// if (slModel.getSettings().getMontlyRecords() != null) {
		// System.out.println("monthlyRecords: " +
		// slModel.getSettings().getMontlyRecords().size());
		// } else {
		// System.out.println("monthly records null");
		// }
		// if (slModel.getSettings().getHourlyRecords() != null) {
		// System.out.println("hourlyRecords: " +
		// slModel.getSettings().getHourlyRecords().size());
		// } else {
		// System.out.println("hourly records null");
		// }
		// System.out.println("writeStatusDispatcher: " +
		// slModel.getSettings().isWriteStatusDispatcher());
		// System.out.println("GMT: " + slModel.getSettings().getGMT());
		// System.out.println("plotLatitude_deg: " +
		// slModel.getSettings().getPlotLatitude_deg());
		// System.out.println("plotLongitude_deg: " +
		// slModel.getSettings().getPlotLongitude_deg());
		// System.out.println("plotSlope_deg: " +
		// slModel.getSettings().getPlotSlope_deg());
		// System.out.println("plotAspect_deg: " +
		// slModel.getSettings().getPlotAspect_deg());
		// System.out.println("northToXAngle_cw_deg: " +
		// slModel.getSettings().getNorthToXAngle_cw_deg());
		// System.out.println("sensorLightOnly: " +
		// slModel.getSettings().isSensorLightOnly());
		// for (Tree t : initScene.getTrees()) {
		// if (t.getId() == 8) {
		// HetTree tt = (HetTree) t;
		// System.out.println("ControlLegacyTreeEnergy: " +
		// tt.getLightResult().getControlLegacyTreeEnergy());
		// System.out.println("ControlTagBasedTreeEnergy: " +
		// tt.getLightResult().getControlTagBasedTreeEnergy());
		// System.out.println("CrownDiffuseEnergy: " +
		// tt.getLightResult().getCrownDiffuseEnergy());
		// System.out.println("CrownDirectEnergy: " +
		// tt.getLightResult().getCrownDirectEnergy());
		// System.out.println("CrownEnergy: " +
		// tt.getLightResult().getCrownEnergy());
		// System.out.println("CrownPotentialEnergy: " +
		// tt.getLightResult().getCrownPotentialEnergy());
		// System.out.println("ImpactNumber: " +
		// tt.getLightResult().getImpactNumber());
		// System.out.println("LowerCrownPotentialEnergy: " +
		// tt.getLightResult().getLowerCrownPotentialEnergy());
		// System.out.println("TrunkDiffuseEnergy: " +
		// tt.getLightResult().getTrunkDiffuseEnergy());
		// System.out.println("TrunkDirectEnergy: " +
		// tt.getLightResult().getTrunkDirectEnergy());
		// System.out.println("TrunkEnergy: " +
		// tt.getLightResult().getTrunkEnergy());
		// System.out.println("ConnectedTree: " +
		// tt.getLightResult().getConnectedTree());
		// System.out.println(" lightCompetitionIndex: " +
		// tt.getLightCompetitionIndex());
		// }
		// }

		processLighting(initScene, foliageStateManager, null, null, null, slModel);

		// System.out.println("*************************");
		// System.out.println("* Apres processLighting *");
		// System.out.println("*************************");

		// System.out.println("Settings de slModel:");
		// System.out.println("");
		// System.out.println("parallelMode: " +
		// slModel.getSettings().isParallelMode());
		// System.out.println("tagMode: " + slModel.getSettings().isTagMode());
		// System.out.println("fileName: " +
		// slModel.getSettings().getFileName());
		// System.out.println("turbidMedium: " +
		// slModel.getSettings().isTurbidMedium());
		// System.out.println("trunkInterception: " +
		// slModel.getSettings().isTrunkInterception());
		// System.out.println("directAngleStep: " +
		// slModel.getSettings().getDirectAngleStep());
		// System.out.println("heightAngleMin: " +
		// slModel.getSettings().getHeightAngleMin());
		// System.out.println("diffuseAngleStep: " +
		// slModel.getSettings().getDiffuseAngleStep());
		// System.out.println("soc: " + slModel.getSettings().isSoc());
		// System.out.println("leafOnDoy: " +
		// slModel.getSettings().getLeafOnDoy());
		// System.out.println("leafOffDoy: " +
		// slModel.getSettings().getLeafOffDoy());
		// if (slModel.getSettings().getMontlyRecords() != null) {
		// System.out.println("monthlyRecords: " +
		// slModel.getSettings().getMontlyRecords().size());
		// } else {
		// System.out.println("monthly records null");
		// }
		// if (slModel.getSettings().getHourlyRecords() != null) {
		// System.out.println("hourlyRecords: " +
		// slModel.getSettings().getHourlyRecords().size());
		// } else {
		// System.out.println("hourly records null");
		// }
		// System.out.println("writeStatusDispatcher: " +
		// slModel.getSettings().isWriteStatusDispatcher());
		// System.out.println("GMT: " + slModel.getSettings().getGMT());
		// System.out.println("plotLatitude_deg: " +
		// slModel.getSettings().getPlotLatitude_deg());
		// System.out.println("plotLongitude_deg: " +
		// slModel.getSettings().getPlotLongitude_deg());
		// System.out.println("plotSlope_deg: " +
		// slModel.getSettings().getPlotSlope_deg());
		// System.out.println("plotAspect_deg: " +
		// slModel.getSettings().getPlotAspect_deg());
		// System.out.println("northToXAngle_cw_deg: " +
		// slModel.getSettings().getNorthToXAngle_cw_deg());
		// System.out.println("sensorLightOnly: " +
		// slModel.getSettings().isSensorLightOnly());
		// for (Tree t : initScene.getTrees()) {
		// if (t.getId() == 8) {
		// HetTree tt = (HetTree) t;
		// System.out.println("ControlLegacyTreeEnergy: " +
		// tt.getLightResult().getControlLegacyTreeEnergy());
		// System.out.println("ControlTagBasedTreeEnergy: " +
		// tt.getLightResult().getControlTagBasedTreeEnergy());
		// System.out.println("CrownDiffuseEnergy: " +
		// tt.getLightResult().getCrownDiffuseEnergy());
		// System.out.println("CrownDirectEnergy: " +
		// tt.getLightResult().getCrownDirectEnergy());
		// System.out.println("CrownEnergy: " +
		// tt.getLightResult().getCrownEnergy());
		// System.out.println("CrownPotentialEnergy: " +
		// tt.getLightResult().getCrownPotentialEnergy());
		// System.out.println("ImpactNumber: " +
		// tt.getLightResult().getImpactNumber());
		// System.out.println("LowerCrownPotentialEnergy: " +
		// tt.getLightResult().getLowerCrownPotentialEnergy());
		// System.out.println("TrunkDiffuseEnergy: " +
		// tt.getLightResult().getTrunkDiffuseEnergy());
		// System.out.println("TrunkDirectEnergy: " +
		// tt.getLightResult().getTrunkDirectEnergy());
		// System.out.println("TrunkEnergy: " +
		// tt.getLightResult().getTrunkEnergy());
		// System.out.println("ConnectedTree: " +
		// tt.getLightResult().getConnectedTree());
		// System.out.println(" lightCompetitionIndex: " +
		// tt.getLightCompetitionIndex());
		// }
		// }

		// Initial regeneration lighting // fc+nd+mj+br-2.10.2018
		understoreyLighting(ip, initScene);

		// At simulation initialisation time, tree initialisation is finished in
		// different steps.
		// Create the missing compartment (some have been read in the inventory
		// file)
		// ip.initTreeCompartments(initScene);
		for (Object o : initScene.getTrees()) {
			HetTree t = (HetTree) o;

			t.initTreeCompartments(ip);
		}

		// mj+fc-3.3.2016 MOVED in HetTree constructor
		// for (Iterator i = initScene.getTrees().iterator(); i.hasNext();) {
		// HetTree t = (HetTree) i.next();
		// t.updateNutrientStatusMap(ip.foliarChemistryThresholds);
		// }

		// Adapt leafBiomass and fineRootBiomass based on current NPP
		// Launch a fake growth step to pickup these two values

		// Fake initial parameters: to simplify fake growth
		HetInitialParameters fakeIp = new HetInitialParameters(ip);
		fakeIp.fakeGrowth = true;
		fakeIp.castaneaPhotosynthesisActivated = false;
		fakeIp.constantNppToGppRatio = true;
		fakeIp.competitionAccountedForCrownGrowth = false;
		fakeIp.mortalityActivated = false;
		fakeIp.generalNutrientLimitation = false;
		fakeIp.nLimitation = false;
		fakeIp.phenologyActivated = false;
		fakeIp.mineralHorizonsTemperatureCalculationActivated = false;
		fakeIp.fineResolutionRadiativeBalanceActivated = false;

		for (Iterator i = initScene.getTrees().iterator(); i.hasNext();) {
			HetTree t = (HetTree) i.next();

			// fa+mj-05.12.2017
			HetTreeRadiationStatus radiationStatus = new HetTreeRadiationStatus(t);
			t.setLightCompetitionIndex(radiationStatus.lightCompetitionIndex);

			// Normal growth
			// fc+mj-12.9.2017, forcedNppToGppRatio used if > 0
			double forcedNppToGppRatio = 0; // disabled

			HetTreeForwardGrower grower = new HetTreeForwardGrower(fakeIp, random, initScene, t,
					initScene.getDate() + 1, null, this, forcedNppToGppRatio, null, t.getFruitLitterFall_kgC());

			// HetTreeBuilder treeBuilder = new HetTreeBuilder(t, grower);
			// HetTree t1 = treeBuilder.getNewTree ();

			t.updateBiomasses(grower.getProduction());

			if (speciesSpecimen == null)
				speciesSpecimen = t.getSpecies();

		}

		// At simulation initialisation time, tree initialisation is finished in
		// different steps.
		// Can not be called before the first processGrotwh ()
		// ip.createLitterCompartments(initScene);
		// Living trees
		for (Object o : initScene.getTrees()) {
			HetTree t = (HetTree) o;

			t.createLitterCompartments(initScene, ip);
		}

		initScene.updateHorizonFineRootLengths();

		// Call Phreeqc
		if (initScene.isSoilChemistryAvailable()) {

			// fc-13.11.2019 introducing HetDiscreteSoil and Pedons, added this
			// temporary limitation for Phreeqc
			HetSoilInterface soil = initScene.getSoil();
			if (soil.isDiscreteSoil()) // fc+fa-21.11.2019
//			if (!(soil instanceof HetSoil))
				throw new Exception(
						"HetPhreeqc expects a HetSoil, found an instance of " + soil + getClass().getName());

			HetPhreeqc ph = new HetPhreeqc((HetSoil) soil, ip);

		}

		// SIMPLIFIED, see upper fc-8.9.2016
		// // Note fc+mj-1.3.2016 phreeqC may be available but soil (optional)
		// // may be null
		// if (HetPhreeqc.isPhreeqcAvailable() && initScene.getSoil() != null) {
		// HetPhreeqc ph = new HetPhreeqc(initScene.getSoil(), ip);
		// }

		// fc-4.3.2016
		GrouperManager.getInstance().buildGroupers(speciesSpecimen, TreeList.GROUP_ALIVE_TREE);

		// // TRACE fc+fa-16.5.2017
		// String fileName = "heterofor_beamset.txt";
		// try {
		// BufferedWriter out = new BufferedWriter(new FileWriter(fileName));
		//
		// out.write("beamTag" + "\t" + "azimut_deg" + "\t" + "heightAngle_deg"
		// + "\t" + "initialEnergy" + "\t"
		// + "direct");
		// out.newLine();
		//
		// for (SLBeam b : ip.samsaFileLoader.getBeamSet().getBeams()) {
		// out.write("" + b.getTag() + "\t" + Math.toDegrees(b.getAzimut_rad())
		// + "\t"
		// + Math.toDegrees(b.getHeightAngle_rad()) + "\t" +
		// b.getInitialEnergy() + "\t" + b.isDirect());
		// out.newLine();
		//
		// }
		//
		// out.close();
		// } catch (Exception e) {
		// Log.println(Log.ERROR, "HetModel.initializeModel ()", "Could not
		// write in file: " + fileName, e);
		// }

		// // TRACE fc+fa-16.5.2017
		// fileName = "heterofor_tag_results.txt";
		// try {
		// BufferedWriter out = new BufferedWriter(new FileWriter(fileName));
		//
		// HetTree t1 = (HetTree) initScene.getTrees().iterator().next();
		// SLTreeLightResult tl = t1.getLightResult();
		//
		// // fc-6.9.2017 there may be no tag results, check
		// if (tl.getTagResultMap() != null && !tl.getTagResultMap().isEmpty())
		// {
		//
		// out.write("beamTag" + "\t" + "interceptionTag" + "\t" + "energyTag" +
		// "\t" + "energy_MJ");
		// out.newLine();
		//
		// for (SLTagTreeResult r : tl.getTagResultMap().allValues()) {
		// out.write("" + r.beamTag + "\t" + r.interceptionTag + "\t" +
		// r.energyTag + "\t" + r.energy_MJ);
		// out.newLine();
		//
		// }
		//
		// out.close();
		//
		// } // fc-6.9.2017
		//
		// } catch (Exception e) {
		// Log.println(Log.ERROR, "HetModel.initializeModel ()", "Could not
		// write in file: " + fileName, e);
		// }

		// // TRACE fa-12.07.2017
		// fileName = "heterofor_sensorTag_results.txt";
		// try {
		// BufferedWriter out = new BufferedWriter(new FileWriter(fileName));
		//
		// // fc-6.9.2017 there may be no sensors, check
		// List<SLSensor> sensors = initScene.getSensors();
		//
		// if (sensors != null && !sensors.isEmpty()) { // fc-6.9.2017
		//
		// SLSensor s = (SLSensor) initScene.getSensors().iterator().next();
		//
		// out.write("sensorID" + "\t" + "beamTag" + "\t" + "energyTag" + "\t" +
		// "energy_MJ");
		// out.newLine();
		//
		// for (SLTagTargetResult r : s.getLightResult().getTagResults()) {
		// out.write("" + s.getId() + "\t" + r.beamTag + "\t" + r.energyTag +
		// "\t" + r.energy_MJm2);
		// out.newLine();
		//
		// }
		//
		// out.close();
		//
		// } // fc-6.9.2017
		//
		// } catch (Exception e) {
		// Log.println(Log.ERROR, "HetModel.initializeModel ()", "Could not
		// write in file: " + fileName, e);
		// }

		// HetTree t1 = (HetTree) initScene.getTrees().iterator().next();
		// SLTreeLightResult tl = t1.getTreeLight();
		// int k = 0;
		// int l = 101;
		// for (SLTagTreeResult r : tl.getTagTreeResults()) {
		//
		// // Write 100 lines
		// if (k <= 100) {
		// k++;
		// System.out.println("HetModel, initialize, t1: " + r);
		// } else {
		// System.out.println("...jumping 100 lines...");
		// l = 0;
		// }
		//
		// // Jump 100 lines
		// if (l <= 100) {
		// // do not write
		// l++;
		// } else {
		// k = 0;
		// }
		//
		// }

		// fc+som-7.7.2017 Castanea related
		if (ip.castaneaPhotosynthesisActivated)
			ip.checkConsistency();

		// Print a message specifying the years for which meterology data have
		// been duplicated (if they are).
		Alert.printStoredMessages();

		HetReporter.printInStandardOutput("*************************");
		HetReporter.printInStandardOutput("* FIN initializeModel() *");
		HetReporter.printInStandardOutput("*************************");

		return p.getInitScene().getStep();
	}

	/**
	 * This method is called when a project is loaded from disk.
	 */
	@Override
	protected void projectJustOpened() {
		// Optional process at project opening time

		// fc-4.3.2016
		GrouperManager.getInstance().buildGroupers(speciesSpecimen, TreeList.GROUP_ALIVE_TREE);
	}

	/**
	 * Fills the gaps around the main rectangle in the plot. The SamsaraLight
	 * torus will work better.
	 */
	protected void fillGaps(HetScene initScene) {
		HetInitialParameters ip = getSettings();
		String bufferType = ip.bufferType;

		if (bufferType.equals("Jonard")) {
			Polygon2 inventoryZoneJonard = ip.getInventoryZoneJonard();

			Vertex2d a = new Vertex2d(inventoryZoneJonard.getX(0), inventoryZoneJonard.getY(0));
			Vertex2d b = new Vertex2d(inventoryZoneJonard.getX(1), inventoryZoneJonard.getY(1));
			Vertex2d c = new Vertex2d(inventoryZoneJonard.getX(2), inventoryZoneJonard.getY(2));
			Vertex2d d = new Vertex2d(inventoryZoneJonard.getX(3), inventoryZoneJonard.getY(3));

			List<HetTree> newTrees = new ArrayList<HetTree>();

			translateTrees(initScene, a, b, newTrees);
			translateTrees(initScene, b, c, newTrees);
			translateTrees(initScene, c, d, newTrees);
			translateTrees(initScene, d, a, newTrees);

			for (HetTree t : newTrees) {
				initScene.addTree(t);
			}
		} else {
			fillWithRandomTrees(initScene);
		}

	}

	/**
	 * Tree translation and next verify that the new tree are within the
	 * inventory zone
	 *
	 * @author MJ, FC
	 */
	private void translateTrees(HetScene initScene, Vertex2d a, Vertex2d b, List<HetTree> newTrees) {

		HetInitialParameters ip = getSettings();
		// SLSettings slSettings = this.getSLModel().getSettings();

		double xMin = initScene.getOrigin().x;
		double xMax = xMin + initScene.getXSize();
		double yMin = initScene.getOrigin().y;
		double yMax = yMin + initScene.getYSize();

		double xShift = b.x - a.x;
		double yShift = b.y - a.y;

		// System.out.println ("HetModel.translateTrees ()...");
		// System.out.println ("xMin: " + xMin);
		// System.out.println ("xMax: " + xMax);
		// System.out.println ("yMin: " + yMin);
		// System.out.println ("yMax: " + yMax);
		// System.out.println ("xShift: " + xShift);
		// System.out.println ("yShift: " + yShift);

		for (Iterator i = initScene.getTrees().iterator(); i.hasNext();) {
			HetTree t = (HetTree) i.next();

			double x0 = t.getX();
			double y0 = t.getY();

			double x1 = x0 + xShift;
			double y1 = y0 + yShift;

			double z0 = t.getZ();
			double z1 = getZCoordinate(x1, y1, Math.toRadians(ip.samsaFileLoader.getPlotSlope_deg()),
					Math.toRadians(ip.samsaFileLoader.getPlotAspect_deg()));

			if (xMin <= x1 && x1 < xMax && yMin <= y1 && y1 < yMax) {

				// System.out.println ("x1: " + x1 + " y1: " + y1 +
				// " is inside the plot");
				// Copy the tree
				int newId = treeIdDispenser.next();
				HetTree copy = t.getCopy(initScene, newId, x1 - x0, y1 - y0, z1 - z0);
				copy.setXYZ(x1, y1, z1);
				copy.setVirtual(true); // GL 11/03/2013
				newTrees.add(copy);
			}
		}
	}

	/**
	 * Fill with random virtual trees
	 *
	 * @author GL 7/3/13
	 */
	private void fillWithRandomTrees(HetScene initScene) {

		HetInitialParameters ip = getSettings();
		// SLSettings slSettings = this.getSLModel().getSettings();
		ArrayList treesInMeasuredZone = new ArrayList(initScene.getTrees());
		ArrayList bigTreesInInventoryZone = new ArrayList();
		Collections.sort(treesInMeasuredZone, new Comparator<Tree>() {

			public int compare(Tree a, Tree b) {
				return Integer.signum(a.getId() - b.getId());
			}
		});

		// keep only the biggest
		// compute the basal area for all trees with girth greater than 40 cm
		// are measured
		double treshold = 40d / Math.PI;
		double basalAreaInsideInventoryZone = 0;
		double basalAreaOutsideInventoryZone = 0;
		double areaInventoryZone_m2 = 0;

		if (ip.bufferType.equals("clotureElargit") || ip.bufferType.equals("clotureRestreint")) {
			areaInventoryZone_m2 = Math.abs(ip.getInventoryZoneR2().getArea());
		} else if (ip.bufferType.equals("Jonard")) {
			areaInventoryZone_m2 = Math.abs(ip.getInventoryZoneJonard().getArea());
		} else {
			Log.println(Log.ERROR, "HetModel.fillWithRandomTrees()",
					"This inventory type has not been implemented yet.");
		}

		for (Iterator i = treesInMeasuredZone.iterator(); i.hasNext();) {

			HetTree t = (HetTree) i.next();

			if (t.getDbh() >= treshold) {
				bigTreesInInventoryZone.add(t);
				if (ip.bufferType.equals("clotureElargit") || ip.bufferType.equals("clotureRestreint")) {
					if (ip.getInventoryZoneR2().contains(new Point2(t.getX(), t.getY()))) {
						basalAreaInsideInventoryZone += t.getBasalArea();
					} else {
						basalAreaOutsideInventoryZone += t.getBasalArea();
					}
				} else {
					basalAreaOutsideInventoryZone += t.getBasalArea();
				}
			}
		}

		double basalAreaHaInsideInventoryZone = basalAreaInsideInventoryZone / areaInventoryZone_m2 * 10000;

		Random random = new Random(69); // 69 is the seed. It generates a fixed
										// sequence of random
										// numbers. The same at each simulation.
		double xmin = initScene.getOrigin().x;
		double xSize = initScene.getXSize();
		double ymin = initScene.getOrigin().y;
		double ySize = initScene.getYSize();
		double areaRectangularPlot_m2 = xSize * ySize;

		double basalAreaHaInRectangularPlot = (basalAreaInsideInventoryZone + basalAreaOutsideInventoryZone) * 10000
				/ areaRectangularPlot_m2;

		double x;
		double y;
		double z;

		int nTreesInMeasuredZone = bigTreesInInventoryZone.size();
		int treeNumber;
		int virtualTreeNumber = 0;

		// create virtual in the unmeasured zones untill it reaches the basal
		// area limit
		while (basalAreaHaInsideInventoryZone >= basalAreaHaInRectangularPlot) {

			x = xmin + xSize * random.nextDouble();
			y = ymin + ySize * random.nextDouble();
			z = getZCoordinate(x, y, Math.toRadians(ip.samsaFileLoader.getPlotSlope_deg()),
					Math.toRadians(ip.samsaFileLoader.getPlotAspect_deg()));

			treeNumber = (int) (nTreesInMeasuredZone * random.nextDouble());
			HetTree t = (HetTree) bigTreesInInventoryZone.get(treeNumber);

			double x0 = t.getX();
			double y0 = t.getY();
			double z0 = t.getZ();

			HetTree copiedTree = t.getCopy(initScene, treeIdDispenser.getNext(), x - x0, y - y0, z - z0);
			copiedTree.setXYZ(x, y, z);
			copiedTree.setVirtual(true);

			if (ip.bufferType.equals("clotureElargit")) {
				if (t.getGirth() < 150 && !ip.getInventoryZoneE3().contains(new Point2(x, y))) {
					initScene.addTree(copiedTree);
					virtualTreeNumber++;
					basalAreaHaInRectangularPlot += t.getBasalArea() * 10000 / areaRectangularPlot_m2; // basal
																										// area
																										// per
																										// hectare
				}
				if (t.getGirth() > 150 && !ip.getInventoryZoneE4().contains(new Point2(x, y))) { // not
																									// in
																									// 40cm
																									// zone
																									// =>
																									// in
																									// 150
																									// cm
																									// zone
					initScene.addTree(copiedTree);
					virtualTreeNumber++;
					basalAreaHaInRectangularPlot += t.getBasalArea() * 10000 / areaRectangularPlot_m2; // basal
																										// area
																										// per
																										// hectare
				}

			} else if (ip.bufferType.equals("clotureRestreint")
					&& !ip.getInventoryZoneR2().contains(new Point2(x, y))) {
				initScene.addTree(copiedTree);
				virtualTreeNumber++;
				basalAreaHaInRectangularPlot += t.getBasalArea() * 10000 / areaRectangularPlot_m2; // basal
																									// area
																									// per
																									// hectare

			} else if (ip.bufferType.equals("Jonard") && !ip.getInventoryZoneJonard().contains(new Point2(x, y))) {
				initScene.addTree(copiedTree);
				virtualTreeNumber++;
				basalAreaHaInRectangularPlot += t.getBasalArea() * 10000 / areaRectangularPlot_m2;

			}
		}

		// System.out.println (" area rectangle = " + areaRectangularPlot_m2 +
		// " basalAreaHaInsideInventoryZone = "
		// + basalAreaHaInsideInventoryZone +
		// " basalAreaOutsideInventoryZone = " +
		// basalAreaOutsideInventoryZone);

		// System.out.println ("HetModel.fillWithRandomTrees() : " +
		// virtualTreeNumber
		// +
		// " virtuals trees have been added at plot periphery to obtain a basal
		// area of "
		// + Math.round (basalAreaHaInsideInventoryZone) + "m2/ha");
	}

	/**
	 * A comparator for HetTrees: first original, then virtual, then id
	 */
	private static class HetOriginalTreesFirstComparator implements Comparator<HetTree> {

		@Override
		public int compare(HetTree t1, HetTree t2) {

			// if t1 smaller: return -1

			if (!t1.isVirtual() && t2.isVirtual())
				return -1;
			if (t1.isVirtual() && !t2.isVirtual())
				return +1;

			return t1.getId() - t2.getId();

		}

	}

	// TODO: to be deleted. Replaced by HetReporter.printInLog(). nb-23.11.2018
	// /**
	// * Can be used to log simulation progress to help check the simulator.
	// */
	// static public void log(String message) {
	// // Log.println("Heterofor_Process", message);
	// }

	/**
	 * Evolution loop.
	 */
	@Override
	public Step processEvolution(Step step, EvolutionParameters p) throws Exception {

		HetEvolutionParameters ep = (HetEvolutionParameters) p;
		HetInitialParameters ip = getSettings();

		int lightprocessCounter = 0; // fc+mj-23.3.2016

		// fa-5.7.2017: refactored, see below
		// int vegetationPeriodLength;

		// fc+mj-27.4.2015, added an optional true thinning map
		Map<Integer, Integer> trueThinningMap = null;
		try {
			trueThinningMap = HetEvolutionParameters.getTrueThinningMap(ep.trueThinningFileName);
		} catch (Exception e) {
			// This trueThinningMap is optional, ignore it if trouble
		}
		// fa-05.01.2018: create the sorted list of the thinning dates contained
		// in trueThinningMap (TreeSet => no duplicates)
		TreeSet<Integer> thinningDates = new TreeSet<Integer>();
		if (trueThinningMap == null)
			thinningDates = null;
		else {
			for (int thDate : trueThinningMap.values()) {
				thinningDates.add(thDate);
			}
		}

		int originYear = step.getScene().getDate();
		int numberOfYears = ep.getNumberOfYears();
		HetScene originScene = (HetScene) step.getScene();

		// In PUE mode, calculate number of years between refStep and targetStep
		if (ep.pueEstimationMode) {
			numberOfYears = ep.pueEstimationTargetScene.getDate() - originYear;
		}

		// for (int i=1 ; i<=numberOfYears ; ++i) {
		//
		// }
		// //ip.radiationCalculationTimeStep
		// ip.meteorology.getMeteoLines(year)

		// Activate the storage of messages in the
		// HetMeteorology.completeBufferMap() method.
		if (ip.meteoFileNameProvided) // fc-11.4.2018 meteo file is optional
			ip.meteorology.setMessagesStorageActivated(true);

		// nb-26.11.2018
		HetReporter.manageDispatchers();

		ProgressDispatcher.setMinMax(0, numberOfYears);

		// nb-23.11.2018
		// log("HetModel: starting evolution loop from " + originYear + " for "
		// + numberOfYears + " years...");
		HetReporter.printInLog(
				"HetModel: starting evolution loop from " + originYear + " for " + numberOfYears + " years...");

		for (int k = 1; k <= numberOfYears; k++) {

			int newYear = originYear + k;

			HetReporter.printInStandardOutput("**************************");
			HetReporter.printInStandardOutput("* year = " + newYear + " *");
			HetReporter.printInStandardOutput("**************************");

			StatusDispatcher.print(Translator.swap("HetModel.evolutionForYear") + " " + newYear);
			ProgressDispatcher.setValue(k);

			// Create the new scene by partial copy
			HetScene refScene = (HetScene) step.getScene();

			// fc+mj+fa-28.6.2017 getEvolutionBase () manages pheno transfers
			HetScene newScene = (HetScene) refScene.getEvolutionBase();

			newScene.setDate(newYear);

			// fa-5.7.2017: Set vegetation period length for current year
			// fa-6.7.2017: Moved at the end of evolution loop to be provided in
			// argument 'refScene' to HetTreeForwardGrower, otherwise null
			// exception occurs in initialStep ('newScene' argument of
			// HetTreeForwardGrower is null for initialStep)
			// if (ip.phenologyActivated)
			// newScene.setCurrentVegetationPeriodLength(newScene.getVegetationPeriod().yellowingPhase.endDoy
			// - newScene.getVegetationPeriod().leafDevelopmentPhase.startDoy);
			// else
			// newScene.setCurrentVegetationPeriodLength(ip.samsaFileLoader.getLeafOffDoy()
			// - ip.samsaFileLoader.getLeafOnDoy());

			// fa-6.7.2017: Set current vegetation period
			newScene.setCurrentVegetationPeriodLength(refScene.getNextYearVegetationPeriodLength());

			// fc+mj+fa-28.6.2017 MOVED phenologyMap creation lower

			// Make all the trees grow, add them in newScene
			List trees = new ArrayList(refScene.getTrees());
			Collections.sort(trees, new HetOriginalTreesFirstComparator());

			Set<Integer> removedTreeIds = new HashSet<>();

			// fc+mj+lw-6.9.2016
			HetElementState refSceneLitterNutrientReturn = refScene.getLitterNutrientReturn();

			// fa-5.7.2017: Removed -> put on the scene
			// (currentVegetationPeriodLength) (see above)
			// vegetationPeriodLength = ip.samsaFileLoader.getLeafOffDoy() -
			// ip.samsaFileLoader.getLeafOnDoy(); // days

			// fc+mj+lw-8.9.2016 Only if meteo and horizons
			// if (ip.meteorology != null && refScene.getSoil() != null) {

			// fc+mj+fa-14.11.2017 yearlyTranspirationMemory may stay null
			HetYearlyTranspirationMemory yearlyTranspirationMemory = null;

			// nb+mj-15.09.2017
			// species.meanLightCompetitionIndex is initialized to 0.0 in
			// HetSpecies
			// class.
			Map<Integer, HetSpecies> speciesMap = ip.getSpeciesMap();
			for (HetSpecies sp : speciesMap.values()) { // mj+fa-20.09.2017
				sp.meanLightCompetitionIndex = 0;
//				sp.leafArea_sp = 0; // fa-17.12.2019: commented
			}

//			// fa+mj-04.12.2017: moved here from HetWaterBalanceCalculator
			// fa-17.12.2019: commented, moved species leaf area from HetSpecies to HetScene
			// 				  speciesLeafAreaMap of refScene has already been processed (newScene of previous step)
//			for (Tree t : refScene.getTrees()) {
//				HetTree tree = (HetTree) t;
//				HetSpecies species = tree.getSpecies();
//				int speciesId = species.getId();
//				// Sum leaf areas
////				species.leafArea_sp += tree.getLeafArea(); // fa-17.12.2019: commented
//				addInMap(refScene.getSpeciesLeafAreaMap(), speciesId, tree.getLeafArea()); 
//			}

			// fa+mj-04.12.2017: moved here from HetWaterBalanceCalculator
			for (Tree t : refScene.getTrees()) {
				HetTree tree = (HetTree) t;
				HetSpecies species = tree.getSpecies();
				int speciesId = species.getId();
				HetTreeRadiationStatus radiationStatus = new HetTreeRadiationStatus(tree);
				species.meanLightCompetitionIndex += tree.getLeafArea() * radiationStatus.lightCompetitionIndex
						/ refScene.getSpeciesLeafAreaMap().get(speciesId); // fa-17.12.2019
//						/ species.leafArea_sp;
			}

			if (ip.waterBalanceActivated) {

				// fa-13.07.2017: moved here from below -> organicLayerThickness
				// set in hetSoilHeatFluxCalculator.init() needed
				// as input variable for calculateSoilInterfaceTemperature

				// fa-13.07.2017: moved here from below -> organicLayerThickness
				// set in hetSoilHeatFluxCalculator.init() needed as input
				// variable for calculateSoilInterfaceTemperature

				HetSoilHeatFluxCalculator hetSoilHeatFluxCalculator = new HetSoilHeatFluxCalculator(newScene.getSoil());
				hetSoilHeatFluxCalculator.init();

				HetWaterBalanceCalculator wbc = new HetWaterBalanceCalculator(ip, refScene, newScene, this,
						hetSoilHeatFluxCalculator);
				wbc.run();

				// fc+mj+fa-14.11.2017 retrieve yearlyTranspiration for
				// treeGrowth later
				yearlyTranspirationMemory = wbc.getYearlyTranspirationMemory();

				hetSoilHeatFluxCalculator.run(refScene, newScene, ip.meteorology.getMeteoLines(newYear),
						newScene.getSoil().getSoilInterfaceTemperatureMap()); // fa-13.07.2017
			}

			// mj+fa-04.12.2017: FruitLitterParameter optimization
			if (ip.fructificationFileNameProvided && ip.fructificationMap.get(newYear) != null) { // Observed
																									// litter
																									// fall
																									// data
																									// file
																									// provided
																									// AND
																									// observed
																									// litter
																									// fall
																									// data
																									// provided
																									// for
																									// current
																									// year
				Map<String, Double> fructificationMap = ip.fructificationMap.get(newYear);
				for (HetSpecies sp : speciesMap.values()) {
					if (sp.optimizedFruitLitterFallP1Map_mainSp == null)
						sp.optimizedFruitLitterFallP1Map_mainSp = new HashMap<>();
					sp.optimizedFruitLitterFallP1Map_mainSp.put(newYear, -1d); // Re-initialize
																				// parameter
																				// value
																				// for
																				// each
																				// year
					for (String speciesName : fructificationMap.keySet()) {
						HetSpecies hetSpecies = null;
						double observedFruitLitterFall_kgC = fructificationMap.get(speciesName);

						if (sp.getName().equals(speciesName)) {
							hetSpecies = sp;
							double optimizedFruitLitterFallP1 = 0d;
							if (observedFruitLitterFall_kgC != 0d)
								optimizedFruitLitterFallP1 = optimizeFruitLitterParameter(refScene, hetSpecies,
										observedFruitLitterFall_kgC);
							hetSpecies.optimizedFruitLitterFallP1Map_mainSp.replace(newYear,
									optimizedFruitLitterFallP1);

							// Compare observed and optimized stand fruit litter
							// fall, for checking
							double optimizedStandFruitLitterFall_ha = fruitProductionCalculation_sp(refScene,
									hetSpecies, optimizedFruitLitterFallP1);
							Double[] standFruitLitterFallComparison = new Double[2];
							standFruitLitterFallComparison[0] = observedFruitLitterFall_kgC;
							standFruitLitterFallComparison[1] = optimizedStandFruitLitterFall_ha;
							if (sp.standFruitLitterFallComparisonMap_mainSp == null)
								sp.standFruitLitterFallComparisonMap_mainSp = new HashMap<>();
							sp.standFruitLitterFallComparisonMap_mainSp.put(newYear, standFruitLitterFallComparison);
						}
					}
				}
			}

			// fc-14.11.2014
			// We need a final variable to be compatible with the
			// trees.parallelStream().forEach((t) notation below
			final HetYearlyTranspirationMemory finalYearlyTranspirationMemory = yearlyTranspirationMemory;

			// Calculate refStandLeafArea
			double refStandLeafArea = 0;
			for (Iterator i = refScene.getTrees().iterator(); i.hasNext();) {
				HetTree t = (HetTree) i.next();
				refStandLeafArea += t.getLeafArea();
			}

			// Calculate refNStandDemand
			double refNStandDemand = 0;
			if (!refScene.isInitialScene())
				for (Iterator i = refScene.getTrees().iterator(); i.hasNext();) {
					HetTree t = (HetTree) i.next();

					// fc+nd+mj+br-3.10.2018
					// TODO: Take into account the demand of the newly recruited
					// trees,
					// regeneration cohorts and vegetation layers
					// Trees recruited last year do not have their demand set
					// yet, omit them
					if (t.getDemand() != null)
						refNStandDemand += t.getDemand().getValue("N");
				}

			// Calculate refStandLitterNReturn_kg
			double refStandLitterNReturn_kg = 0;
			for (Iterator i = refScene.getTrees().iterator(); i.hasNext();) {
				HetTree t = (HetTree) i.next();
				refStandLitterNReturn_kg += t.getLitterNutrientReturn().getValue("N");
			}

			// mj+fa-02.03.2018: Calculate Q10 sums (optimization of
			// maintenanceRespiration calculation)
			if (!ip.constantNppToGppRatio) {
				List<HetMeteoLine> lines = ip.meteorology.getMeteoLines(newYear);
				HashMap<String, Double> q10SumMap = new HashMap<String, Double>();
				HashMap<Integer, Double> q10SumMapLeaf = new HashMap<Integer, Double>();
				HashMap<Integer, Double> q10SumMapFineRoot = new HashMap<Integer, Double>();
				for (String tcType : ip.q10Map.keySet()) {
					if (tcType.equals(HetTreeCompartment.TYPE_LEAF)) // Leaves
																		// are
																		// treated
																		// apart
						continue;
					q10SumMap.put(tcType, 0d);
				}
				for (int speciesId : ip.getSpeciesMap().keySet()) {
					q10SumMapLeaf.put(speciesId, 0d);
					q10SumMapFineRoot.put(speciesId, 0d);
				}

				double temperatureDependency = 0d;
				double leafTemperatureDependency = 0d;
				double fineRootTemperatureDependency = 0d;
				for (HetMeteoLine line : lines) {
					for (String tcType : ip.q10Map.keySet()) {
						double exponent = 0d;
						if (tcType.equals(HetTreeCompartment.TYPE_ROOT)) {

							// fc-13.11.2019
//							for (HetHorizon horizon : newScene.getSoil().getPedonSpecimen().getHorizons()) {
							
							// fa-20.11.2019
							Pedon newPedon = null;
							if (!newScene.getSoil().isDiscreteSoil()) // Default water balance mode
								newPedon = newScene.getSoil().getPedonSpecimen();
							else { // Detailed water balance
									// We assume temperature of the horizons of
									// the treePedon associated with the first
									// tree to be representative of that for the
									// other trees (though it is -slightly-
									// affected by water content given its
									// effect on thermal diffusivity)
								Set sortedTrees = new TreeSet(new GTreeIdComparator()); // sorted trees to ensure to catch the same tree in HetTreeForwardGrower.calculateMaintenanceRespiration_kgC()
								sortedTrees.addAll(refScene.getTrees());
								Iterator it = sortedTrees.iterator() ;
								HetTree firstTree = (HetTree) it.next();
								newPedon = newScene.getSoil().getPedonMap().get(firstTree.getId());
							}
							for (HetHorizon horizon : newPedon.getHorizons()) { 
								
								// for (HetHorizon horizon :
								// newScene.getSoil().getHorizons()) {

								double horizonTemperature = 0d;
								String time = line.year + "_" + line.month + "_" + line.day + "_" + line.hour;
								if (!horizon.isOrganic()) { // mineral horizon
									horizonTemperature = horizon.getTimeMineralHorizonTemperatureMap().get(time);
								} else { // organic horizon
									horizonTemperature = (line.airTemperature
											+ newScene.getSoil().getSoilInterfaceTemperatureMap().get(time)) / 2.0;
								}
								exponent = (horizonTemperature - 15d) / 10d;
								temperatureDependency = Math.pow(ip.q10Map.get(tcType), exponent)
										* horizon.fineRootProportion;
								fineRootTemperatureDependency = Math.pow(ip.q10Map.get(HetTreeCompartment.TYPE_LEAF),
										exponent) * horizon.fineRootProportion;
								q10SumMap.put(tcType, q10SumMap.get(tcType) + temperatureDependency);

								double greenProp = 1d;
								if (ip.phenologyActivated) {
									for (int speciesId : q10SumMapLeaf.keySet()) {
										//greenProp = refScene.getGreenProportionOfNextYearAtSpeciesLevel(speciesId, line.getDoy()); nb-18.12.2019
										greenProp = refScene.getGreenProportionAtSpeciesLevel(speciesId, line.getDoy(), refScene.getPhenologyMapOfNextYear());
										fineRootTemperatureDependency = fineRootTemperatureDependency * greenProp;
										q10SumMapFineRoot.put(speciesId,
												q10SumMapFineRoot.get(speciesId) + fineRootTemperatureDependency);
									}
								}
							}
						} else {
							exponent = (line.airTemperature - 15d) / 10d;

							if (tcType.equals(HetTreeCompartment.TYPE_LEAF)) {

								double lightInihibition = 1d; // no inhibition
								// Leaves + during daylight: special case //
								// fc+mj-9.3.2017
								if (line.radiation > 0) {
									// For deciduous species only, to be
									// reviewed for evergreen
									// trees: 1 - 0.51
									lightInihibition = 1d - 0.62;
								}

								double greenProp = 1d;
								if (ip.phenologyActivated) {
									for (int speciesId : q10SumMapLeaf.keySet()) {
										//greenProp = refScene.getGreenProportionOfNextYearAtSpeciesLevel(speciesId, line.getDoy()); nb-18.12.2019
										greenProp = refScene.getGreenProportionAtSpeciesLevel(speciesId, line.getDoy(), refScene.getPhenologyMapOfNextYear());
										leafTemperatureDependency = Math
												.pow(ip.q10Map.get(HetTreeCompartment.TYPE_LEAF), exponent) * greenProp;
										q10SumMapLeaf.put(speciesId, q10SumMapLeaf.get(speciesId)
												+ leafTemperatureDependency * lightInihibition);
									}
								}
							} else {
								temperatureDependency = Math.pow(ip.q10Map.get(tcType), exponent);
								q10SumMap.put(tcType, q10SumMap.get(tcType) + temperatureDependency);
							}
						}
					}
				}
				// fa-06.03.2018
				newScene.setQ10SumMap(q10SumMap);
				newScene.setQ10SumMapLeaf(q10SumMapLeaf);
				newScene.setQ10SumMapFineRoot(q10SumMapFineRoot);
			}

			double scene_npp = 0;
			double scene_gpp = 0;
			double scene_maintenanceRespiration = 0;
			double scene_retranslocation = 0;
			// fa-12.10.2017: for thead-safe operations during parallel
			// processing
			// AtomicLong scene_npp = new AtomicLong(0);
			// AtomicLong scene_gpp = new AtomicLong(0);
			// AtomicLong scene_maintenanceRespiration = new AtomicLong(0);
			// AtomicLong scene_retranslocation = new AtomicLong(0);
			// fa-12.10.2017: vectors are thread-safe collections
			Vector<double[]> treeNppGppRespirationRetranslocationVector = new Vector();
			// Vector<Double> nppVector = new Vector();
			// Vector<Double> gppVector = new Vector();
			// Vector<Double> maintenanceRespirationVector = new Vector();
			// Vector<Double> retranslocationVector = new Vector();

			// fa-12.10.2017: local variables in lambda expression must be final
			final int innerNumberOfYears = numberOfYears;
			final double innerRefStandLeafArea = refStandLeafArea;
			final double innerRefNStandDemand = refNStandDemand;
			final double innerRefStandLitterNReturn_kg = refStandLitterNReturn_kg;

			// for (Iterator i = trees.iterator(); i.hasNext();) {
			trees.parallelStream().forEach((t) -> { // fa-12.10.2017: parallel
													// processing
				// HetTree refTree = (HetTree) i.next();
				HetTree refTree = (HetTree) t;

				// //fa+mj-01.12.2017 Tree fruit litter computation
				HetSpecies refTreeSpecies = refTree.getSpecies();
				HetTreeRadiationStatus treeRadiationStatus = new HetTreeRadiationStatus(refTree);
				double treeLightCompetitionIndex = treeRadiationStatus.lightCompetitionIndex;
				double fruitLitterProduction_kgC = 0d;
				if (refTree.getDbh() > refTreeSpecies.fruitProdMinDbh) {
					if (!ip.fructificationFileNameProvided || ip.fructificationMap.get(newYear) == null
							|| refTreeSpecies.optimizedFruitLitterFallP1Map_mainSp.get(newYear) == -1d) // No
																										// fructification
																										// file
																										// OR
																										// no
																										// observed
																										// litter
																										// fall
																										// data
																										// (1)
																										// for
																										// current
																										// year
																										// OR
																										// (2)
																										// for
																										// given
																										// species
																										// (=>
																										// no
																										// optimized
																										// parameter
																										// value),
																										// fruitLitterProduction
																										// determined
																										// based
																										// on
																										// default
																										// parameters
																										// (heterofor_species
																										// file)
						fruitLitterProduction_kgC = refTreeSpecies.fruitLitterFallP1 * treeLightCompetitionIndex
								* Math.pow(refTree.getDbh() - refTreeSpecies.fruitProdMinDbh,
										refTreeSpecies.fruitLitterFallP2);
					else
						fruitLitterProduction_kgC = refTreeSpecies.optimizedFruitLitterFallP1Map_mainSp.get(newYear)
								* treeLightCompetitionIndex
								* Math.pow(refTree.getDbh() - refTreeSpecies.fruitProdMinDbh,
										refTreeSpecies.fruitLitterFallP2);
				}

				double[] treeNppGppRespirationRetranslocation = new double[4]; // fa-12.10.2017

				// System.out.println("\nGrowth year: " + newYear +
				// " tree: " +
				// refTree.getId() + "...");

				// fc+mj+fa-28.6.2017 MOVED lower
				// // A virtual tree may have been removed when removing
				// its
				// // original tree (see below)
				// if (removedTreeIds.contains(refTree.getId()))
				// continue;
				//
				// // True thinning management
				// if (trueThinningMap != null) {
				// Integer v = trueThinningMap.get(refTree.getId());
				// if (v != null) {
				// int lastYear = v.intValue();
				// if (newYear > lastYear) {
				//
				// // Remove the tree
				// HetTree copy = (HetTree) refTree.clone();
				// newScene.storeStatus(copy, "cut");
				// removedTreeIds.add(refTree.getId());
				//
				// // Remove virtual trees based on the removed tree
				// if (!refTree.isVirtual()) {
				// List<Integer> virtualTreeIds =
				// refTree.getVirtualTreeIdsBasedOnMe();
				// if (virtualTreeIds != null &&
				// !virtualTreeIds.isEmpty()) {
				// for (int vId : virtualTreeIds) {
				// HetTree vt = (HetTree) refScene.getTree(vId);
				// if (vt != null) {
				// // Remove the virtual tree
				// HetTree vCopy = (HetTree) vt.clone();
				// newScene.storeStatus(vCopy, "cut");
				// removedTreeIds.add(vt.getId());
				// }
				// }
				// }
				//
				// }
				//
				// continue;
				// }
				// }
				// }

				// Growth

				// Calculate tree uptake
				// nb-23.11.2018
				// log("HetModel: Growth for tree: " + refTree.getId());
				HetReporter.printInLog("HetModel: Growth for tree: " + refTree.getId());

				// PotentialtUptakeCalculator potentialUptakeCalc = new
				// PotentialtUptakeCalculator(ip,
				// vegetationPeriodLength,
				// refScene, refTree);
				PotentialtUptakeCalculator potentialUptakeCalc = new PotentialtUptakeCalculator(ip,
						newScene.getCurrentVegetationPeriodLength(), refScene, refTree); // fa-6.7.2017:
																							// refactored
																							// vegetationPeriodLength
																							// computation
																							// (see
																							// above)
				potentialUptakeCalc.execute();
				// nb-23.11.2018
				// log("HetModel: potentialUptake: " +
				// potentialUptakeCalc.getPotentialUptake());
				HetReporter.printInLog("HetModel: potentialUptake: " + potentialUptakeCalc.getPotentialUptake());

				StatusDispatcher.print(Translator.swap("HetModel.growthYear") + " : " + newYear + " / "
						+ Translator.swap("HetModel.tree") + " : " + refTree.getId());

				// System.out.println("HetModel year: "+newYear+" tree:
				// "+refTree.getId
				// ()+" treeGrowth ()...");

				// fc+mj-12.9.2017, forcedNppToGppRatio used if > 0
				double forcedNppToGppRatio = 0; // disabled
				// HetTree newTree = treeGrowth(ip, ep, random,
				// originScene, numberOfYears, refScene, refTree,
				// newYear,
				// newScene, forcedNppToGppRatio);
				HetTree newTree = null;
				try {
					newTree = treeGrowth(ip, ep, random, originScene, innerNumberOfYears, refScene, refTree, newYear,
							newScene, forcedNppToGppRatio, finalYearlyTranspirationMemory, fruitLitterProduction_kgC);
				} catch (Exception e) {
					Log.println(Log.ERROR, "HetModel.processEvolution()",
							"Error during growth process for refTree with id " + refTree.getId(), e);
					throw new RuntimeException("Error during growth process for refTree with id " + refTree.getId(), e);
				} // fa-12.10.2017

				// Demand
				NutrientDemandCalculator demandCalc = new NutrientDemandCalculator(ip, random, refScene, refTree,
						newTree);
				demandCalc.execute();

				// nb-23.11.2018
				// log("HetModel: requirement: " + demandCalc.getRequirement());
				// log("HetModel: retranslocation: " +
				// demandCalc.getRetranslocation());
				// log("HetModel: demand: " + demandCalc.getDemand());
				HetReporter.printInLog("HetModel: requirement:     " + demandCalc.getRequirement());
				HetReporter.printInLog("HetModel: retranslocation: " + demandCalc.getRetranslocation());
				HetReporter.printInLog("HetModel: demand:          " + demandCalc.getDemand());

				// ActualUptakeCalculator actualUptakeCalc = new
				// ActualUptakeCalculator(ip, this, random, refScene,
				// refSceneLitterNutrientReturn, refTree, newTree,
				// potentialUptakeCalc.getPotentialUptake(),
				// demandCalc.getRequirement(),
				// demandCalc.getRetranslocation(),
				// demandCalc.getDemand(),
				// RefStandLeafArea, refNStandDemand,
				// refStandLitterNReturn_kg, ep.pueEstimationMode);
				ActualUptakeCalculator actualUptakeCalc = new ActualUptakeCalculator(ip, this, random, refScene,
						refSceneLitterNutrientReturn, refTree, newTree, potentialUptakeCalc.getPotentialUptake(),
						demandCalc.getRequirement(), demandCalc.getRetranslocation(), demandCalc.getDemand(),
						innerRefStandLeafArea, innerRefNStandDemand, innerRefStandLitterNReturn_kg,
						ep.pueEstimationMode, finalYearlyTranspirationMemory, fruitLitterProduction_kgC); // fa-12.10.2017
				try {
					actualUptakeCalc.execute();
				} catch (Exception e) {
					Log.println(Log.ERROR, "HetModel.processEvolution()",
							"Error in actual uptake process for refTree with id " + refTree.getId(), e);
				}

				// If growth was reduced during actual uptake
				// calculation,
				// the whole procedure must be rerun to consider this
				// limitation
				if (ip.generalNutrientLimitation && actualUptakeCalc.isReducedGrowth()) {

					// nb-23.11.2018
					// log("HetModel: *** Growth was reduced during
					// ActualUptake, relaunching tree growth...");
					HetReporter.printInLog(
							"HetModel: *** Growth was reduced during ActualUptake, relaunching tree growth...");

					HetInitialParameters ip2 = (HetInitialParameters) ip.clone();
					ip2.constantNppToGppRatio = true;

					// fc+mj-12.9.2017, forcedNppToGppRatio used if > 0
					forcedNppToGppRatio = actualUptakeCalc.getMinNppToGppRatio();

					// fc+mj-8.12.2016 changed ip to ip2 in line below
					// newTree = treeGrowth(ip2, ep, random,
					// originScene, numberOfYears, refScene, refTree,
					// newYear,
					// newScene, forcedNppToGppRatio);
					try {
						newTree = treeGrowth(ip2, ep, random, originScene, innerNumberOfYears, refScene, refTree,
								newYear, newScene, forcedNppToGppRatio, finalYearlyTranspirationMemory,
								fruitLitterProduction_kgC);
					} catch (Exception e) {
						Log.println(Log.ERROR, "HetModel.processEvolution()",
								"Error during growth process for refTree with id " + refTree.getId(), e);
					} // fa-12.10.2017

					// fc+mj-28.9.2016
					newTree.setNppToGppRatio(forcedNppToGppRatio);

					// Demand
					demandCalc = new NutrientDemandCalculator(ip, random, refScene, refTree, newTree);
					demandCalc.execute();

					// nb-23.11.2018
					// log("HetModel: requirement: " +
					// demandCalc.getRequirement());
					// log("HetModel: retranslocation: " +
					// demandCalc.getRetranslocation());
					// log("HetModel: demand: " + demandCalc.getDemand());
					HetReporter.printInLog("HetModel: requirement:     " + demandCalc.getRequirement());
					HetReporter.printInLog("HetModel: retranslocation: " + demandCalc.getRetranslocation());
					HetReporter.printInLog("HetModel: demand:          " + demandCalc.getDemand());

					// actualUptakeCalc = new ActualUptakeCalculator(ip,
					// this, random, refScene,
					// refSceneLitterNutrientReturn, refTree, newTree,
					// potentialUptakeCalc.getPotentialUptake(),
					// demandCalc.getRequirement(),
					// demandCalc.getRetranslocation(),
					// demandCalc.getDemand(),
					// refStandLeafArea, refNStandDemand,
					// refStandLitterNReturn_kg, ep.pueEstimationMode);
					actualUptakeCalc = new ActualUptakeCalculator(ip, this, random, refScene,
							refSceneLitterNutrientReturn, refTree, newTree, potentialUptakeCalc.getPotentialUptake(),
							demandCalc.getRequirement(), demandCalc.getRetranslocation(), demandCalc.getDemand(),
							innerRefStandLeafArea, innerRefNStandDemand, innerRefStandLitterNReturn_kg,
							ep.pueEstimationMode, finalYearlyTranspirationMemory, fruitLitterProduction_kgC); // fa-12.10.2017

					try {
						actualUptakeCalc.execute();
					} catch (Exception e) {
						Log.println(Log.ERROR, "HetModel.processEvolution()",
								"Error in actual uptake process for refTree with id " + refTree.getId(), e);
					}

				}

				// Recalculate fineRootToFoliageRatio // fc+mj-9.12.2016
				HetSpecies refSpecies = refTree.getSpecies();
				double fineRootToFoliageRatio = refTree.fineRootSensitivityToNutrientStatus(
						ip.foliarChemistryThresholds, refSpecies.minFineRootToFoliageRatio,
						refSpecies.maxFineRootToFoliageRatio);
				HetTreeRadiationStatus radiationStatus = new HetTreeRadiationStatus(refTree);

				// fineRootToFoliageRatio *=
				// radiationStatus.lightCompetitionIndex
				// / refSpecies.meanLightCompetitionIndex;

				newTree.setFineRootToFoliageRatio(fineRootToFoliageRatio);

				// All values below in g
				newTree.setPotentialUptake(potentialUptakeCalc.getPotentialUptake());
				newTree.setHorizonPotentialUptake(potentialUptakeCalc.getHorizonPotentialUptake());
				newTree.setRequirement(demandCalc.getRequirement());
				newTree.setRetranslocation(demandCalc.getRetranslocation());
				newTree.setDemand(demandCalc.getDemand());
				newTree.setActualUptake(actualUptakeCalc.getActualUptake());

				// nb-23.11.2018
				// log("HetModel: actualUptake: " +
				// actualUptakeCalc.getActualUptake());
				HetReporter.printInLog("HetModel: actualUptake:          " + actualUptakeCalc.getActualUptake());

				// Update tree and litter compartments
				updateTreeAndLitterCompartments(ip, refScene, refTree, newScene, newTree);

				// // Nutrients: copy refTree's LEAVES_UPPER_CURRENT
				// compartment in
				// // newTree
				// HetTreeCompartment lucCopy =
				// refTree.getTreeCompartment(
				// HetTreeCompartment.LEAVES_UPPER_CURRENT).getCopy();
				// lucCopy.biomass = 0;
				// lucCopy.livingFraction = 0;
				// lucCopy.diameter = 0;
				// newTree.addTreeCompartment(lucCopy);
				//
				// // Set retranslocation and demand in the newTree
				// newTree.setRetranslocation(demandCalc.getRetranslocation());
				// newTree.setDemand(demandCalc.getDemand());

				// Dead trees will be processed lower mj+fc-6.12.2016
				newScene.addTree(newTree);

				// scene_npp += newTree.getNetPrimaryProduction_kgC();
				// scene_gpp += newTree.getGrossPrimaryProduction_kgC();
				// scene_maintenanceRespiration +=
				// newTree.getMaintenanceRespiration_kgC();
				// scene_retranslocation +=
				// newTree.getLeafRetranslocation_kgC()
				// + newTree.getFineRootRetranslocation_kgC();
				// fa-12.10.2017 (using ATOMIC methods)
				// scene_npp.addAndGet((long)
				// newTree.getNetPrimaryProduction_kgC());
				// scene_gpp.addAndGet((long)
				// newTree.getGrossPrimaryProduction_kgC());
				// scene_maintenanceRespiration.addAndGet((long)
				// newTree.getMaintenanceRespiration_kgC());
				// scene_retranslocation.addAndGet((long)
				// newTree.getLeafRetranslocation_kgC() + (long)
				// newTree.getFineRootRetranslocation_kgC());
				// fa-12.10.2017 (using vectors)
				// nppVector.add(newTree.getNetPrimaryProduction_kgC());
				// gppVector.add(newTree.getGrossPrimaryProduction_kgC());
				// maintenanceRespirationVector.add(newTree.getMaintenanceRespiration_kgC());
				// retranslocationVector.add(newTree.getLeafRetranslocation_kgC()
				// + newTree.getFineRootRetranslocation_kgC());
				treeNppGppRespirationRetranslocation[0] = newTree.getNetPrimaryProduction_kgC();
				treeNppGppRespirationRetranslocation[1] = newTree.getGrossPrimaryProduction_kgC();
				treeNppGppRespirationRetranslocation[2] = newTree.getMaintenanceRespiration_kgC();
				treeNppGppRespirationRetranslocation[3] = newTree.getLeafRetranslocation_kgC()
						+ newTree.getFineRootRetranslocation_kgC();
				treeNppGppRespirationRetranslocationVector.add(treeNppGppRespirationRetranslocation);

				// }
			}); // fa-12.10.2017: end of parallel processing

			// Sums in HetScene npp, gpp... // fc+mj-9.3.2017
			// fa-12.10.2017 (using vectors)
			/*
			 * for (int i = 0; i < nppVector.size(); i++) { //The four vectors
			 * have the same dimension scene_npp += nppVector.get(i); scene_gpp
			 * += gppVector.get(i); scene_maintenanceRespiration +=
			 * maintenanceRespirationVector.get(i); scene_retranslocation +=
			 * retranslocationVector.get(i); }
			 */
			for (int i = 0; i < treeNppGppRespirationRetranslocationVector.size(); i++) {
				double[] treeNppGppRespirationRetranslocation = treeNppGppRespirationRetranslocationVector.get(i);
				scene_npp += treeNppGppRespirationRetranslocation[0];
				scene_gpp += treeNppGppRespirationRetranslocation[1];
				scene_maintenanceRespiration += treeNppGppRespirationRetranslocation[2];
				scene_retranslocation += treeNppGppRespirationRetranslocation[3];
			}

			newScene.setNetPrimaryProduction_gC_m2(scene_npp * 1000d / newScene.getArea());
			newScene.setGrossPrimaryProduction_gC_m2(scene_gpp * 1000d / newScene.getArea());
			newScene.setMaintenanceRespiration_gC_m2(scene_maintenanceRespiration * 1000d / newScene.getArea());
			newScene.setRetranslocation_gC_m2(scene_retranslocation * 1000d / newScene.getArea());
			// fa-12.10.2017 (using ATOMIC methods)
			// newScene.setNetPrimaryProduction_gC_m2(scene_npp.doubleValue() *
			// 1000d / newScene.getArea());
			// newScene.setGrossPrimaryProduction_gC_m2(scene_gpp.doubleValue()
			// * 1000d / newScene.getArea());
			// newScene.setMaintenanceRespiration_gC_m2(scene_maintenanceRespiration.doubleValue()
			// * 1000d / newScene.getArea());
			// newScene.setRetranslocation_gC_m2(scene_retranslocation.doubleValue()
			// * 1000d / newScene.getArea());

			// Add N nutrition check values in the scene in case nLimitation is
			// desactivated
			double newStandLitterNReturn_kg = 0;
			for (Iterator i = newScene.getTrees().iterator(); i.hasNext();) {
				HetTree t = (HetTree) i.next();
				newStandLitterNReturn_kg += t.getLitterNutrientReturn().getValue("N");
			}

			double area_ha = refScene.getArea() / 10000d;

			// nb-09.12.2016 + 16.12.2016
			if (refScene.getSoil() != null) {
				HetElementState nutrientDeposition = refScene.getSoil().getNutrientDeposition();
				double NDeposition_kg = 0.0;
				double NAvailable_kg = 0.0;
				if (nutrientDeposition.getValue("N") != null) {
					NDeposition_kg = nutrientDeposition.getValue("N") * area_ha;
					NAvailable_kg = NDeposition_kg + newStandLitterNReturn_kg;
				}
				newScene.setNAvailable_kg(NAvailable_kg);
			}

			// New crowns
			recalculateCrownDimensions(refScene, newScene);

			// fa+mj-20.03.2018
			HashMap<Integer, Double> meanUpperCrownHeightMap = new HashMap<Integer, Double>();
			HashMap<Integer, Double> meanLowerCrownHeightMap = new HashMap<Integer, Double>();
			HashMap<Integer, Integer> speciesTreeNumberMap = new HashMap<Integer, Integer>();
			for (int spId : speciesMap.keySet()) {
				meanUpperCrownHeightMap.put(spId, 0d);
				meanLowerCrownHeightMap.put(spId, 0d);
				speciesTreeNumberMap.put(spId, 0);
			}
			for (Iterator i = newScene.getTrees().iterator(); i.hasNext();) {
				HetTree t = (HetTree) i.next();

				double meanUpperCrownHeight = (t.getHlce() + t.getHeight()) / 2d;
				double meanLowerCrownHeight = (t.getHcb() + t.getHlce()) / 2d;

				meanUpperCrownHeightMap.put(t.getSpecies().getId(),
						meanUpperCrownHeightMap.get(t.getSpecies().getId()) + meanUpperCrownHeight);
				meanLowerCrownHeightMap.put(t.getSpecies().getId(),
						meanLowerCrownHeightMap.get(t.getSpecies().getId()) + meanLowerCrownHeight);
				speciesTreeNumberMap.put(t.getSpecies().getId(), speciesTreeNumberMap.get(t.getSpecies().getId()) + 1);

			}
			for (int spId : speciesMap.keySet()) {
				if (speciesTreeNumberMap.get(spId) != 0) {
					meanUpperCrownHeightMap.put(spId,
							(double) meanUpperCrownHeightMap.get(spId) / speciesTreeNumberMap.get(spId));
					meanLowerCrownHeightMap.put(spId,
							(double) meanLowerCrownHeightMap.get(spId) / speciesTreeNumberMap.get(spId));
				}
			}
			newScene.setMeanUpperCrownHeightMap(meanUpperCrownHeightMap);
			newScene.setMeanLowerCrownHeightMap(meanLowerCrownHeightMap);

			// Mortality mj+fc-6.12.2016
			if (ip.mortalityActivated) {
				for (Object o : new ArrayList(newScene.getTrees())) {
					HetTree newTree = (HetTree) o;

					HetTree refTree = (HetTree) refScene.getTree(newTree.getId());

					if (!isStillAlive(refTree, newTree)) {
						// Create the 3D trunk and crown parts
						// if (slSettings.trunkInterception)
						// newTree.createSLTrunk();
						// newTree.createSLCrownParts(ip.LADNeighbourhoodDistance,
						// newScene); // including
						// // LAD

						// System.out.println("" + newScene.getDate() +
						// " deadTree: " + newTree.getId() + " height: "
						// + newTree.getHeight());

						newScene.removeTree(newTree);
						newScene.storeStatus(newTree, "dead");
					}

				}
			}

			createLitterCompartmentsForCutTrees(ip, newScene);
			createLitterCompartmentsForDeadTrees(ip, newScene);

			// Update of soil chemistry
			updateSoilChemistry(ip, refScene, newScene);
		
//			newScene.updateHorizonFineRootLengths(); // fa-25.11.2019: moved below

			// Create the tree and litter compartments in the new trees
			// nutrientLimitedGrowth.updateTreeAndLitterCompartments(ip,
			// refScene,
			// newScene);

			// // New crowns
			// recalculateCrownDimensions(refScene, newScene);

			// fc+nd+mj+br-2.10.2018 Regeneration lib connection
			processUnderstoreyGrowth(refScene, newScene);

			// fc+mj+fa-28.6.2017 MOVED phenologyMap creation here, just before
			// light
			// Calculate the phenology dates for next year
			if (ip.phenologyActivated) {

				// Create phenologyMap for next year
				// fc+mj+fa-28.6.2017 calc pheno for nextYear to get a light map
				// matching nextYear's pheno
				HashMap<Integer, HetPhenology> nextYearPhenologyMap = createPhenologyMap(newYear + 1, ip.meteorology,
						ip.speciesMap, newScene.getPhenologyMap(),
						Math.toRadians(ip.samsaFileLoader.getPlotLatitude_deg()), -1);
				newScene.setPhenologyMapOfNextYear(nextYearPhenologyMap); // next
																			// year

				HetReporter.printInStandardOutput("****** nextYearPhenologyMap: ");
				for (int speciesId : nextYearPhenologyMap.keySet()) {
					HetPhenology pheno = nextYearPhenologyMap.get(speciesId);
					HetReporter.printInStandardOutput("  --> speciesId: " + speciesId);
					pheno.displayDates();
				}

				// Vegetation period with 3 phases inside: leafDevevelopment,
				// completeDevelopment, yellowing
				HetVegetationPeriod vegetationPeriodOfNextYear = new HetVegetationPeriod(
						newScene.getPhenologyMapOfNextYear());
				newScene.setVegetationPeriodOfNextYear(vegetationPeriodOfNextYear);

			}

			// nb-05.06.2019 Moved in processTrueThinning().
			// // fc+mj+fa-28.6.2017 True thinningMap management, moved here,
			// was
			// // upper
			// // True thinning management
			// if (trueThinningMap != null) {
			//
			// Collection newTrees = newScene.getTrees();
			//
			// // Loop and pick the ids of trees to be removed
			// for (Iterator i = newTrees.iterator(); i.hasNext();) {
			// HetTree t = (HetTree) i.next();
			//
			// Integer v = trueThinningMap.get(t.getId());
			// if (v != null) {
			// int lastYear = v.intValue();
			// if (newYear >= lastYear) { // fc+mj+fa was >, now >=
			//
			// // Pick tree id
			// removedTreeIds.add(t.getId());
			//
			// // Remove virtual trees based on the removed tree
			// if (!t.isVirtual()) {
			// List<Integer> virtualTreeIds = t.getVirtualTreeIdsBasedOnMe();
			// if (virtualTreeIds != null && !virtualTreeIds.isEmpty()) {
			// for (int vId : virtualTreeIds) {
			// HetTree vt = (HetTree) refScene.getTree(vId);
			// if (vt != null) {
			// // Pick virtual tree id
			// removedTreeIds.add(vt.getId());
			// }
			// }
			// }
			//
			// }
			//
			// }
			// }
			// }
			//
			// // Remove the trees with a picked id
			// for (Iterator i = new ArrayList(newTrees).iterator();
			// i.hasNext();) {
			// HetTree t = (HetTree) i.next();
			//
			// if (removedTreeIds.contains(t.getId())) {
			// // Remove the tree
			// HetTree copy = (HetTree) t.clone();
			// newScene.storeStatus(copy, "cut");
			// newScene.removeTree(t); // unregisters from cell...
			//
			// }
			//
			// }
			// }

			// fc+mj+fa-28.5.2019 moved here, was lower
			// Run it on initScene
			ip.cohortsManager.run(ip, newScene);

			// Light calculation
			SLFoliageStateManager foliageStateManager = (SLFoliageStateManager) newScene;

			// nb-14.06.2019
			// processLighting(newScene, foliageStateManager, refScene,
			// trueThinningMap, thinningDates, slModel);
			processLighting(newScene, foliageStateManager, refScene, null, null, slModel);

			// Annual regeneration lighting // fc+nd+mj+br-2.10.2018
			understoreyLighting(ip, newScene);

			// // Run it on initScene
			// ip.cohortsManager.run(ip, newScene);

			// fa-5.7.2017: Set vegetation period length for next year
			// fa-6.7.2017: Moved here from beginning of evolution loop TO BE
			// CHECKED!!!!!!!!!!!!!!!!!!
			if (ip.phenologyActivated)
				// newScene.setCurrentVegetationPeriodLength(newScene.getVegetationPeriod().yellowingPhase.endDoy
				// -
				// newScene.getVegetationPeriod().leafDevelopmentPhase.startDoy);
				newScene.setNextYearVegetationPeriodLength(
						newScene.getVegetationPeriodOfNextYear().yellowingPhase.endDoy
								- newScene.getVegetationPeriodOfNextYear().leafDevelopmentPhase.startDoy); // fa-6.7.2017
			else
				// newScene.setCurrentVegetationPeriodLength(ip.samsaFileLoader.getLeafOffDoy()
				// - ip.samsaFileLoader.getLeafOnDoy());
				newScene.setNextYearVegetationPeriodLength(
						ip.samsaFileLoader.getLeafOffDoy() - ip.samsaFileLoader.getLeafOnDoy()); // fa-6.7.2017

			if (ip.waterBalanceActivated)
				traceWaterBalance(newScene); // rainfall, stemflow, throughfall,
												// interception

			if (ip.phenologyAtTreeLevel) {
				
				// Calculates for each tree:
				// - the sum of leaf areas of the trees smaller than it and that belong to the same species. This sum 
				// will be then used in the calculation of the ladProp (proportion of leaf area compared to the level 
				// of maximum development) at tree level. 
				// - the sum of leaf areas of the trees taller than it and that belong to the same species. This sum 
				// will be then used in the calculation of the ladProp and the greenProp (proportion of green leaves 
				// compared to the level of maximum development) at tree level. nb-17.12.2019
				newScene.calculateCumulatedLeafAreasOfSmallerAndTallersTrees();
			}

			// System.out.println("Avant calcul:");
			// for (int speciesId : ip.speciesMap.keySet()) {
			// System.out.println("speciesId: " + speciesId + " / code:" +
			// speciesMap.get(speciesId).hashCode() + " --> leafArea: " +
			// ip.speciesMap.get(speciesId).leafArea_sp);
			// }

			// Calculates the leaf area of the species. Needed in calculation of
			// lad proportion. nb-07.11.2019
			
			// fa-17.12.2019: moved species leaf area from HetSpecies to HetScene
			HashMap<Integer, Double> newSceneSpeciesLeafAreaMap = new HashMap<Integer, Double>();
			for (int speciesId : ip.speciesMap.keySet()) { // initialization
				newSceneSpeciesLeafAreaMap.put(speciesId, 0d);
			}
			for (Tree t : newScene.getTrees()) {
				HetTree tree = (HetTree) t;
				HetSpecies species = tree.getSpecies();
				int speciesId = species.getId();
				addInMap(newSceneSpeciesLeafAreaMap, speciesId, tree.getLeafArea()); 
//				species.leafArea_sp += tree.getLeafArea(); // fa-17.12.2019: commented
			}
			newScene.setSpeciesLeafAreaMap(newSceneSpeciesLeafAreaMap);

			// System.out.println("Apres calcul:");
			// for (int speciesId : ip.speciesMap.keySet()) {
			// System.out.println("speciesId: " + speciesId + " / code:" +
			// speciesMap.get(speciesId).hashCode() + " --> leafArea: " +
			// ip.speciesMap.get(speciesId).leafArea_sp);
			// }

			// fc-mj-fa-15.11.2019 Update the pedons in the soil, calc their
			// area...

			newScene.getSoil().updatePedonList(newScene);
			newScene.getSoil().updatePedonProperties(newScene);
			
			newScene.updateHorizonFineRootLengths(); // fa-25.11.2019: moved here, after updatePedonList(), from above to consider dead trees

			String reason = "Evolution to year " + newYear; // a free String

			Step newStep = step.getProject().processNewStep(step, newScene, reason);
			step = newStep;

			// System.out.println("**********************");
			// System.out.println("Check meteo !!!!!!!!!");
			// System.out.println("**********************");
			//
			// Map<Integer, LinkedHashMap<HetDate, HetMeteoLine>> bufferMap =
			// ip.meteorology.getBufferMap();
			//
			// for (int year : bufferMap.keySet()) {
			//
			// int size = bufferMap.get(year).size()/24;
			// System.out.println("year: " + year + " --> " + size);
			//
			//// if (year == 2008)
			//// for (HetDate date : bufferMap.get(year).keySet()) {
			//// System.out.println("date: " + date + " --> " +
			// bufferMap.get(year).get(date));
			//// }
			//
			// }

			// True thinning management. nb-14.06.2019
			if (trueThinningMap != null && trueThinningMap.containsValue(step.getScene().getDate())) {
				Step newInterventionStep = processTrueThinning(trueThinningMap, step);
				if (newInterventionStep != null) {
					step = newInterventionStep;
				}
			}

		}

		StatusDispatcher.print(Translator.swap("HetModel.evolutionIsOver"));
		ProgressDispatcher.stop();

		// Print a message specifying the years for which meterology data have
		// been duplicated.
		if (!ip.virtualUnderstoreyGeneration)
			Alert.printStoredMessages();

		// System.out.println("HetModel.processEvolution() for " + numberOfYears
		// + " years is over, lightProcessCounter: "
		// + lightprocessCounter);

		// Return the last Step
		return step;

	}

	/**
	 * Manage understorey objects during evolution
	 */
	private void processUnderstoreyGrowth(HetScene refScene, HetScene newScene) throws Exception {

		HetPlot refPlot = (HetPlot) refScene.getPlot();
		HetPlot newPlot = (HetPlot) newScene.getPlot();
		Collection cells = refPlot.getCells();

		// List all the understorey items to be grown
		List<RGUnderstorey> underStoreyList = new ArrayList();

		for (Iterator i = cells.iterator(); i.hasNext();) {
			HetCell refCell = (HetCell) i.next();

			HetCell newCell = (HetCell) newScene.getPlot ().getCell(refCell.getId ());
			
			if (refCell.getVegetationLayers() != null)
				underStoreyList.addAll(refCell.getVegetationLayers());
			if (refCell.getCohorts() != null) {
				underStoreyList.addAll(refCell.getCohorts().allValues());
				
//				// fa-15.11.2019: select waterBalanceMap to be assigned to cohorts associated with the current cell
//				LinkedHashMap<String, HetWaterBalance> wbMap = new LinkedHashMap<>();
//				ArrayList<CellTree> treeList = (ArrayList<CellTree>) refCell.getTrees();
//				if (treeList.size() > 0) { // trees are present on this cell
//					HetTree t = (HetTree) treeList.get(0); // select first tree in the list
//					Pedon tPedon = newScene.getSoil().getPedonMap().get(t.getId());
//					wbMap = tPedon.getWaterBalanceMap ();
//				}
//				else { // no tree on the cell
//					Pedon rPedon = newScene.getSoil().getPedonMap().get(0); // remainingPedon
//					wbMap = rPedon.getWaterBalanceMap ();
//				}

				// fc+mj+br-4.10.2018
				// Set additional variables in the cohort size classes, needed
				// during the understoreyGrowth() process
				for (RGCohort refCohort : refCell.getCohorts().allValues()) {
					for (RGCohortSizeClass rc : refCohort.getSizeClasses()) {
						HetCohortSizeClass refClass = (HetCohortSizeClass) rc;
//						refClass.setWaterBalanceMap(newScene.waterBalanceMap);
						refClass.setWaterBalanceMap(newCell.getWaterBalanceMap()); // fa-19.11.2019
//						refClass.setWaterBalanceMap(wbMap);	// fa-15.11.2019

					}
				}
			}
		}

		// Growth for all the understorey items
		RGProcess.processGrowth(underStoreyList, newScene, this);

		// fc+mj+br-4.10.2018
		// Sum regeneration (i.e. here cohorts size classes) NPP and GPP in the
		// newScene. Be aware that if recruitment occurred, the matching
		// sizeClasses have been removed and the recruited NPP and GPP is
		// missing at this point
		double sum_yearlyNPPAvg_kgC = 0;
		double sum_yearlyGPP_kgC = 0;

		for (SquareCell ce : newScene.getPlot().getCells()) {
			HetCell cell = (HetCell) ce;
			if (cell.getCohorts() != null)
				for (RGCohort co : cell.getCohorts().allValues()) {
					for (RGCohortSizeClass sc : co.getSizeClasses()) {
						HetCohortSizeClass newClass = (HetCohortSizeClass) sc;

						sum_yearlyNPPAvg_kgC += newClass.getYearlyNPPAvg_kgC() * newClass.getNumber();
						sum_yearlyGPP_kgC += newClass.getYearlyGPP_kgC();
					}
				}

		}

		newScene.setRegenerationNetPrimaryProduction_gC_m2(sum_yearlyNPPAvg_kgC * 1000d / newScene.getArea());
		newScene.setRegenerationGrossPrimaryProduction_gC_m2(sum_yearlyGPP_kgC * 1000d / newScene.getArea());

	}

	/**
	 * Manage understorey lighting
	 */
	private void understoreyLighting(HetInitialParameters ip, HetScene scene) {

		// fc+mj+fa+br-22.5.2019 for very specific uses (e.g.
		// VirtualUnderstoreyGeneration), we may want to sometimes disable
		// lighting
		// fc+mj-28.6.2019 understoreyLighting is always run (needed by
		// VirtualUnderstoreyGeneration) -> commented the 2 lines below
		// if (ip.lightingDisabled)
		// return;

		// Annual regeneration lighting // fc+nd+mj+br-2.10.2018
		HetPlot plot = scene.getPlot();
		plot.setIncidentEnergy_MJ((samsaManager.getSLModel().getBeamSet().getHorizontalDiffuse()
				+ samsaManager.getSLModel().getBeamSet().getHorizontalDirect()) * plot.getCellWidth()
				* plot.getCellWidth());

		for (Iterator ic = plot.getCells().iterator(); ic.hasNext();) {
			HetCell cell = (HetCell) ic.next();
			SLTargetLightResult cellLigth = cell.getLightResult();
			double energy_MJ = cellLigth.get_slopeEnergy() * cell.getArea();
			cell.setRemainingEnergy_MJ(energy_MJ);
			// cell.setEnergyUnderTree(energy_MJ);
		}

		RGProcess.processLighting(scene);
	}

	/**
	 * Copy the tree light info or run the lighting process on the given scene,
	 * update the cells colors accordingly, if some trees got no light at all,
	 * try to copy their light info from previousScene, or send an exception if
	 * not possible.
	 */
	private void processLighting(HetScene scene, SLFoliageStateManager foliageStateManager, HetScene previousScene,
			Map<Integer, Integer> trueThinningMap, TreeSet<Integer> thinningDates, SLModel slModel) throws Exception { // fa-05.01.2018:
																														// added
																														// thinningDates

		HetInitialParameters ip = getSettings();

		// fc-24.6.2019 moved lower to copyLight () before returning
		// // fc+mj+fa+br-22.5.2019 for very specific uses (e.g.
		// // VirtualUnderstoreyGeneration), we may want to sometimes disable
		// // lighting
		// if (ip.lightingDisabled)
		// return;

		// nb-04.01.2018
		// The light process calculation is needed in the following situations:
		// - every ip.radiationCalculationTimeStep year after initial year
		// (includes initial year)
		// - after an intervention (whatever the year)
		// - if the year of the current scene is in the true thinning map
		boolean lightProcessNeeded = false;

		// TODO: dateOfInitialScene is now calculated in initializeModel()
		if (scene.isInitialScene()) {
			dateOfInitialScene = scene.getDate();
		}
		lightProcessNeeded = ((scene.getDate() - dateOfInitialScene) % ip.radiationCalculationTimeStep == 0)
				|| (scene.isInterventionResult());
		// nb-14.06.2019
		if (trueThinningMap != null) {
			lightProcessNeeded = lightProcessNeeded || (trueThinningMap.containsValue(scene.getDate()));
		}

		// fc-24.6.2019 moved virtualUnderstoreyGeneration here to copyLight ()
		// before
		// returning
		if (!lightProcessNeeded || ip.virtualUnderstoreyGeneration) {
			// if (!lightProcessNeeded) {

			// Copy the previous light info
			copyLight(previousScene, scene);

			// fa-5.7.2017: Copy reference vegetation period length
			// (corresponding to last radiative balance run)
			scene.setRefVegetationPeriodLength(previousScene.getRefVegetationPeriodLength());
			return;
		}

		// Create SamsaraLight manager depending on options
		boolean legacyMode = !ip.fineResolutionRadiativeBalanceActivated;

		if (legacyMode) {

			// System.out.println("*** legacyMode ***");

			if (ip.phenologyActivated)
				updateLeafOnDoyAndLeadOffDoy(ip.samsaFileLoader, scene.getPhenologyMapOfNextYear());

			samsaManager = new HetSamsaLegacyMode(ip.samsaFileLoader, ip.radiationCalculationTimeStep, scene,
					ip.treeMaxHeight, ip.maxCrownRadius, ip.meteorology, thinningDates, dateOfInitialScene, slModel); // fa-05.01.2018:
																														// added
																														// thinningDates
																														// &
																														// dateOfInitialScene

		} else { // fineResolution

			// System.out.println("*** pas legacyMode ***");

			// fc+mj+fa-29.6.2017 MOVED upper
			// Vegetation period with 3 phases inside: leafDevevelopment,
			// completeDevelopment, yellowing
			// HetVegetationPeriod vegetationPeriod = new
			// HetVegetationPeriod(scene.getPhenologyMapOfNextYear());
			// scene.setVegetationPeriodOfNextYear(vegetationPeriod);

			// Recreated each time (reads meteorology)
			// fa-05.01.2018: added thinningDates & dateOfInitialScene
			samsaManager = new HetSamsaTagMode(ip.samsaFileLoader, ip.radiationCalculationTimeStep, scene,
					ip.treeMaxHeight, ip.maxCrownRadius, ip.meteorology, scene.getVegetationPeriodOfNextYear(),
					thinningDates, dateOfInitialScene, slModel); // fa-05.01.2018:
																	// added
																	// thinningDates
																	// &
																	// dateOfInitialScene

		}
		// fc-29.6.2017...

		// fc-29.6.2017 Call samsaManager.processLighting ()
		samsaManager.processLighting(scene, foliageStateManager, previousScene);

		// fa-5.7.2017: Set reference vegetation period length TO BE
		// CHECKED!!!!!!!!!!!!!!!!!!
		if (ip.phenologyActivated)
			scene.setRefVegetationPeriodLength(scene.getVegetationPeriodOfNextYear().yellowingPhase.endDoy
					- scene.getVegetationPeriodOfNextYear().leafDevelopmentPhase.startDoy);
		else
			scene.setRefVegetationPeriodLength(ip.samsaFileLoader.getLeafOffDoy() - ip.samsaFileLoader.getLeafOnDoy());

		// fa-7.7.2017: check
		// Collection newTrees = scene.getTrees();
		// Loop and pick the ids of trees
		// for (Iterator i = newTrees.iterator(); i.hasNext();) {
		// HetTree t = (HetTree) i.next();
		// System.out.println("TreeLightAfter: CrownDirect = " +
		// t.getTreeLight().getCrownDirectEnergy() + ", CrownDiffuse = " +
		// t.getTreeLight().getCrownDiffuseEnergy() + ", Trunk = " +
		// t.getTreeLight().getTrunkEnergy());
		// }
	}

	/**
	 * Recalculate leafOnDoy and leafOffDoy from the phenologyMap (one entry per
	 * species) and overwrite them in samsaFileLoader
	 */
	private void updateLeafOnDoyAndLeadOffDoy(HetSamsaFileLoader samsaFileLoader,
			HashMap<Integer, HetPhenology> phenologyMap) {

		// fc+mj+fa-29.6.2017

		int t2a_min = Integer.MAX_VALUE;
		int t2b_max = Integer.MIN_VALUE;

		int t4a_min = Integer.MAX_VALUE;
		int t4b_max = Integer.MIN_VALUE;

		for (HetPhenology pheno : phenologyMap.values()) {

			t2a_min = Math.min(t2a_min, pheno.getT2b_averageTreeBudburstDate().getDoy());
			t2b_max = Math.max(t2b_max, pheno.getT2c_completeLeafDevelopmentDate().getDoy());

			t4a_min = Math.min(t4a_min, pheno.getT4a_yellowingStartingDate().getDoy());
			t4b_max = Math.max(t4b_max, pheno.getT4b_yellowingEndingDate().getDoy());
		}

		int leafOnDoy = (int) Math.round((t2a_min + t2b_max) / 2d);
		int leafOffDoy = (int) Math.round((t4a_min + t4b_max) / 2d);

		samsaFileLoader.setLeafOnDoy(leafOnDoy);
		samsaFileLoader.setLeafOffDoy(leafOffDoy);

	}

	/**
	 * Check if the given doy is in extended vegetation period, i.e. between
	 * phenology t2a_min and t5b_max. If !phenologyActivated, ask samsaraLight.
	 */
	public boolean isExtendedVegetationPeriod(HetScene scene, int doy) {
		return isExtendedVegetationPeriod(scene.getPhenologyMap(), doy);
	}

	// fc+mj+br-4.10.2018 Added, for cohort size classes growth
	public boolean isExtendedVegetationPeriod(Map<Integer, HetPhenology> phenologyMap, int doy) {

		// fc+mj-12.9.2017 changed this method, now 'extended'

		if (phenologyMap != null) {

			int t2a_min = Integer.MAX_VALUE;
			int t5b_max = Integer.MIN_VALUE;

			for (HetPhenology pheno : phenologyMap.values()) {

				t2a_min = Math.min(t2a_min, pheno.getT2b_averageTreeBudburstDate().getDoy());
				t5b_max = Math.max(t5b_max, pheno.getT5b_fallingEndingDate().getDoy());

			}

			return t2a_min <= doy && doy <= t5b_max;

		} else {
			HetSamsaFileLoader samsaFileLoader = getSettings().samsaFileLoader;
			return samsaFileLoader.isVegetationPeriod(doy);

		}

	}

	private void traceWaterBalance(HetScene scene) { // rainfall, stemflow,
														// throughfall,
														// interception
		for (Pedon pedon : scene.getSoil().getPedons()) { // fa-15.11.2019
			
			double rainfall = 0;
			double stemflow = 0;
			double throughfall = 0;
			double interception = 0;
			double barkEvaporation = 0;
			double foliageEvaporation = 0;
			double transpiration = 0;
			double vegetationEvaporation = 0;
			double soilEvaporation = 0;
			double deepDrainage = 0;

//			for (String key : scene.waterBalanceMap.keySet()) {
			for (String key : pedon.getWaterBalanceMap ().keySet()) { // fa-15.11.2019
//				HetWaterBalance wb = scene.waterBalanceMap.get(key); // fc-20.1.2017
																	// now a map
				HetWaterBalance wb = pedon.getWaterBalanceMap ().get(key); // fa-15.11.2019

				rainfall += wb.rainfall;
				stemflow += wb.stemflow;
				throughfall += wb.throughfall;
				interception += wb.interception;

				barkEvaporation += wb.barkEvaporation;
				foliageEvaporation += wb.foliageEvaporation;
				transpiration += wb.transpiration;
				vegetationEvaporation += wb.vegetationEvaporation;
				soilEvaporation += wb.soilEvaporation;

				deepDrainage += wb.deepDrainage;
			}
			// System.out.println("HetModel date: " + scene.getDate() +
			// " waterBalance sums: rainfall: " + rainfall
			// + " stemflow: " + stemflow + " throughfall: " + throughfall +
			// " interception: " + interception
			// + " barkEvaporation: " + barkEvaporation + " foliageEvaporation: " +
			// foliageEvaporation
			// + " transpiration: " + transpiration + " vegetationEvaporation: " +
			// vegetationEvaporation
			// + " soilEvaporation: " + soilEvaporation + " deepDrainage: " +
			// deepDrainage);
		
		}
	}

	private String extractEName(String horizonId_eName) {
		String eName = horizonId_eName.substring(horizonId_eName.indexOf("_") + 1);
		return eName;
	}

	/**
	 * Update soil chemistry, then run PhreeqC.
	 */
	private void updateSoilChemistry(HetInitialParameters ip, HetScene refScene, HetScene newScene) throws Exception {

		// fc-13.11.2019 introducing HetDiscreteSoil and Pedons, added this
		// temporary limitation for Phreeqc
		HetSoilInterface soil = refScene.getSoil();
		
		// fa-21.11.2019: temporary commented to avoid exception even with HetDiscreteSoil option (nutrient cycling module still under development and currently not used in simulations)
		// !!!!!!!!!!!!!!! CAUTION: TO BE CONSIDERED WHEN APPLYING THE NUTRIENT CYCLE !!!!!!!!!!!!!!!!!!!!
//		if (soil.isDiscreteSoil())
////		if (!(soil instanceof HetSoil))
//			throw new Exception(
//					"updateSoilChemistry () expects a HetSoil, found an instance of " + soil + getClass().getName());

		// Soil chemistry is optional // fc-8.9.2016
		if (!refScene.isSoilChemistryAvailable())
			return;

		// key = horizonId_eName
		Map<String, Double> totalUptakeMap1 = new HashMap<>();

		// key = eName (treeElement)
		Map<String, Double> totalUptakeMap2 = new HashMap<>();

		for (Tree t : newScene.getTrees()) {
			HetTree newTree = (HetTree) t;

			for (String horizonId_eName : newTree.getHorizonPotentialUptake().keySet()) {

				double value = newTree.getHorizonPotentialUptake().get(horizonId_eName);

				// key = horizonId_eName
				if (!totalUptakeMap1.containsKey(horizonId_eName))
					totalUptakeMap1.put(horizonId_eName, 0d);
				double prevUptake = totalUptakeMap1.get(horizonId_eName);
				totalUptakeMap1.put(horizonId_eName, prevUptake + value);

				// key = eName
				String eName = extractEName(horizonId_eName);
				if (!totalUptakeMap2.containsKey(eName))
					totalUptakeMap2.put(eName, 0d);
				prevUptake = totalUptakeMap2.get(eName);
				totalUptakeMap2.put(eName, prevUptake + value);

			}

		}

		// nb-23.11.2018
		// log("HetModel: totalUptakeMap1 (uptakes): " +
		// AmapTools.toString(totalUptakeMap1));
		// log("HetModel: totalUptakeMap2: " +
		// AmapTools.toString(totalUptakeMap2));
		HetReporter.printInLog("HetModel: totalUptakeMap1 (uptakes): " + AmapTools.toString(totalUptakeMap1));
		HetReporter.printInLog("HetModel: totalUptakeMap2: " + AmapTools.toString(totalUptakeMap2));

		// Estimate uptake proportion per horizon
		for (String horizonId_eName : totalUptakeMap1.keySet()) {

			double v1 = totalUptakeMap1.get(horizonId_eName);

			String eName = extractEName(horizonId_eName);
			double v2 = totalUptakeMap2.get(eName);
			double proportion = v2 == 0 ? 0 : v1 / v2;

			totalUptakeMap1.put(horizonId_eName, proportion);

		}

		// nb-23.11.2018
		// log("HetModel: totalUptakeMap1 (proportions): " +
		// AmapTools.toString(totalUptakeMap1));
		HetReporter.printInLog("HetModel: totalUptakeMap1 (proportions): " + AmapTools.toString(totalUptakeMap1));

		// Estimate exchangeable stocks per soil horizon
		HetElementState standLitterNutrientReturn = refScene.getLitterNutrientReturn();

		// Stand actual uptake
		// key = eName
		HetElementState standUptakeMap = new HetElementState();

		for (Tree t : newScene.getTrees()) {
			HetTree newTree = (HetTree) t;

			for (String eName : HetTreeElement.elementNames) {
				double value = newTree.getActualUptake().getValue(eName);
				standUptakeMap.addValue(eName, value); // g
			}

		}
		// log("HetModel: standUptakeMap: " + standUptakeMap);

		HetElementState nutrientDeposition = refScene.getSoil().getNutrientDeposition();
		double standAreaHa = refScene.getArea() / 10000d; // m2 -> ha

		// Nutrient budget

		// fc-13.11.2019 CAUTION
		// due to HetDiscreteSoil and Pedons introduction, this method initially
		// relying on a SimpleHetSoil with horizons inside should be checked and
		// adapted
		// -> added getPedonSpecimen () meanwhile to work on the first pedon
		// found
		// Possible alternative to work on all horizons in the soil:
		// Pedon.getAllHorizonsInSoil(soil).allValues ()
		for (HetHorizon refH : refScene.getSoil().getPedonSpecimen().getHorizons()) {
			// for (HetHorizon refH : refScene.getSoil().getHorizons()) {

			// fc+mj-7.9.2016
			boolean trace = refH.id == 4;

			// fc-7.9.2016 newSoil horizons have been created in
			// getEvolutionBase ()

			// fc-13.11.2019 CAUTION
			// due to HetDiscreteSoil and Pedons introduction, this method
			// initially
			// relying on a SimpleHetSoil with horizons inside should be checked
			// and
			// adapted
			// -> added getPedonSpecimen () meanwhile to work on the first pedon
			// found
			HetHorizon newH = newScene.getSoil().getPedonSpecimen().getHorizon(refH.id);
			// HetHorizon newH = newScene.getSoil().getHorizon(refH.id);

			// pH -> copied from refH
			newH.solution_pH = refH.solution_pH;

			// Solutions -> copied from refH
			for (String eltName : refH.getSolutionConcentrations().keySet()) {
				double conc = refH.getSolutionConcentration(eltName);
				newH.setSolutionConcentration(eltName, conc);
			}

			// Minerals -> copied from refH
			for (String mineralName : refH.getMineralConcentrations().keySet()) {
				double conc = refH.getMineral(mineralName).concentration;
				newH.setMineralConcentration(mineralName, conc);
			}

			// Cations
			Map<String, Double> refCationStock = refH.concentrationToStock(ip, refScene,
					refH.getExchangeableCationConcentrations());
			Map<String, Double> newCationStock = new LinkedHashMap<>();

			for (String exchName : refH.getExchangeableCationConcentrations().keySet()) {

				HetChemicalElement elt = ip.getChemicalElement(exchName);
				String eName = elt.treeElement; // maybe "-"

				if (eName.equals("-")) {
					double newStock = refCationStock.get(exchName);
					newCationStock.put(exchName, newStock);

				} else {
					String horizonId_eName = "" + refH.id + "_" + eName;
					double horizonUptakeProportion = totalUptakeMap1.get(horizonId_eName);

					if (eName.equals("K"))
						HetReporter.printInLog(
								"Horizon " + refH.id + " *** horizonUptakeProportion(K): " + horizonUptakeProportion);

					double exchProportion = refH.getExchangeableCationProportion(ip, exchName);
					// double exchProportion = 1 / 3d; // TODO

					// Log.println("HetModel exchProportion: " +
					// exchProportion);

					// Stock in Kg
					double newStock = refCationStock.get(exchName);

					if (!eName.equals("N")) {
						newStock = refCationStock.get(exchName)
								- (standUptakeMap.getValue(eName) / 1000d - standLitterNutrientReturn.getValue(eName)
										- nutrientDeposition.getValue(eName) * standAreaHa) * horizonUptakeProportion
										* exchProportion;
						// TODO: take drainage into account (drainageVolume *
						// eltConcentration)

						if (trace)
							HetReporter.printInLog("HetModel horizon: " + refH.id + " CATIONS" + " newStock: "
									+ newStock + " exchName: " + exchName + " eName: " + eName
									+ " refCationStock.get(exchName): " + refCationStock.get(exchName)
									+ " standUptakeMap.getValue(eName): " + standUptakeMap.getValue(eName)
									+ " standLitterNutrientReturn.getValue(eName): "
									+ standLitterNutrientReturn.getValue(eName)
									+ " nutrientDeposition.getValue(eName): " + nutrientDeposition.getValue(eName)
									+ " standAreaHa: " + standAreaHa + " horizonUptakeProportion: "
									+ horizonUptakeProportion + " exchProportion: " + exchProportion);

					}

					if (newStock <= 0)
						HetReporter.printInLog("HetModel.updateSoilChemistry(), In horizon: " + refH.id
								+ " newStock for exchName: " + exchName + " has reached 0");

					newCationStock.put(exchName, newStock < 0 ? 0 : newStock);

				}

			}

			Map<String, Double> newCationConcentrations = refH.stockToConcentration(ip, refScene, newCationStock);
			newH.setExchangeableCationConcentrations(newCationConcentrations);

			// Anions
			Map<String, Double> refAnionStock = refH.concentrationToStock(ip, refScene,
					refH.getExchangeableAnionConcentrations());
			Map<String, Double> newAnionStock = new LinkedHashMap<>();

			for (String exchName : refH.getExchangeableAnionConcentrations().keySet()) {

				HetChemicalElement elt = ip.getChemicalElement(exchName);
				String eName = elt.treeElement; // maybe "-"

				if (eName.equals("-")) {
					double newStock = refAnionStock.get(exchName);
					newAnionStock.put(exchName, newStock);

				} else {

					String horizonId_eName = "" + refH.id + "_" + eName;
					double horizonUptakeProportion = totalUptakeMap1.get(horizonId_eName);

					double exchProportion = 1d;

					double newStock = refAnionStock.get(exchName);

					if (!eName.equals("N")) {
						newStock = refAnionStock.get(exchName)
								- (standUptakeMap.getValue(eName) / 1000d - standLitterNutrientReturn.getValue(eName)
										- nutrientDeposition.getValue(eName) * standAreaHa) * horizonUptakeProportion
										* exchProportion;
						// TODO: take drainage into account (drainageVolume *
						// eltConcentration)

						if (trace)
							HetReporter.printInLog("HetModel horizon: " + refH.id + " ANIONS" + " newStock: " + newStock
									+ " exchName: " + exchName + " eName: " + eName + " refAnionStock.get(exchName): "
									+ refAnionStock.get(exchName) + " standUptakeMap.getValue(eName): "
									+ standUptakeMap.getValue(eName) + " standLitterNutrientReturn.getValue(eName): "
									+ standLitterNutrientReturn.getValue(eName)
									+ " nutrientDeposition.getValue(eName): " + nutrientDeposition.getValue(eName)
									+ " standAreaHa: " + standAreaHa + " horizonUptakeProportion: "
									+ horizonUptakeProportion + " exchProportion: " + exchProportion);

					}

					if (newStock <= 0)
						HetReporter.printInLog("HetModel.updateSoilChemistry(), In horizon: " + refH.id
								+ " newStock for exchName: " + exchName + " has reached 0");

					newAnionStock.put(exchName, newStock < 0 ? 0 : newStock);

				}
			}

			Map<String, Double> newAnionConcentrations = refH.stockToConcentration(ip, refScene, newAnionStock);
			newH.setExchangeableAnionConcentrations(newAnionConcentrations);

			// adjust H+ to maintain a similar CEC
			String[] names = new String[] { "HXo", "KXo", "CaXo2", "MgXo2", "NaXo", "NamH4Xo", "AlXo3", "MnXo2",
					"FeXo3" };
			double refCECXo = sum(refH.getExchangeableCationConcentrations(), names);
			double newCECXo = sum(newH.getExchangeableCationConcentrations(), names);
			if (newCECXo > refCECXo) {
				multiply(newH.getExchangeableCationConcentrations(), names, refCECXo / newCECXo);
				newCECXo = refCECXo;
			}

			names = new String[] { "HXm", "KXm", "CaXm2", "MgXm2", "NaXm", "NamH4Xm", "AlXm3", "MnXm2", "FeXm3" };
			double refCECXm = sum(refH.getExchangeableCationConcentrations(), names);
			double newCECXm = sum(newH.getExchangeableCationConcentrations(), names);
			if (newCECXm > refCECXm) {
				multiply(newH.getExchangeableCationConcentrations(), names, refCECXm / newCECXm);
				newCECXm = refCECXm;
			}

			names = new String[] { "HXs", "KXs", "CaXs2", "MgXs2", "NaXs", "NamH4Xs", "AlXs3", "MnXs2", "FeXs3" };
			double refCECXs = sum(refH.getExchangeableCationConcentrations(), names);
			double newCECXs = sum(newH.getExchangeableCationConcentrations(), names);
			if (newCECXs > refCECXs) {
				multiply(newH.getExchangeableCationConcentrations(), names, refCECXs / newCECXs);
				newCECXs = refCECXs;
			}

			names = new String[] { "YaCl", "YaNnitO3", "Ya2SO4	", "YaH2PO4", "YaH3SiO4", "Ya3Cit", "YaHCO3", "YaOH" };
			double refAEC = sum(refH.getExchangeableAnionConcentrations(), names);
			double newAEC = sum(newH.getExchangeableAnionConcentrations(), names);
			if (newAEC > refAEC) {
				multiply(newH.getExchangeableAnionConcentrations(), names, refAEC / newAEC);
				newAEC = refAEC;
			}

			double newHXo = newH.getExchCationConcentration("HXo");
			double newHXm = newH.getExchCationConcentration("HXm");
			double newHXs = newH.getExchCationConcentration("HXs");
			double newYaOH = newH.getExchAnionConcentration("YaOH");

			// TMP, report the 4 values (debugging, fc+mj-7.9.2016)
			// newH.getExchangeableCationConcentrations().put("HXo",
			// refH.getExchangeableCationConcentrations().get("HXo"));
			// newH.getExchangeableCationConcentrations().put("HXm",
			// refH.getExchangeableCationConcentrations().get("HXm"));
			// newH.getExchangeableCationConcentrations().put("HXs",
			// refH.getExchangeableCationConcentrations().get("HXs"));
			// newH.getExchangeableAnionConcentrations().put("YaOH",
			// refH.getExchangeableAnionConcentrations().get("YaOH"));

			newH.getExchangeableCationConcentrations().put("HXo", refCECXo - (newCECXo - newHXo));
			newH.getExchangeableCationConcentrations().put("HXm", refCECXm - (newCECXm - newHXm));
			newH.getExchangeableCationConcentrations().put("HXs", refCECXs - (newCECXs - newHXs));
			newH.getExchangeableAnionConcentrations().put("YaOH", refAEC - (newAEC - newYaOH));

			if (trace)
				HetReporter.printInLog("HetModel horizon: " + refH.id + " HXo" + " newHXo: " + newHXo + " refCECXo: "
						+ refCECXo + " newCECXo: " + newCECXo + " refCECXo - (newCECXo - newHXo): "
						+ (refCECXo - (newCECXo - newHXo)));
			if (trace)
				HetReporter.printInLog("HetModel horizon: " + refH.id + " HXm" + " newHXm: " + newHXm + " refCECXm: "
						+ refCECXm + " newCECXm: " + newCECXm + " refCECXm - (newCECXm - newHXm): "
						+ (refCECXm - (newCECXm - newHXm)));
			if (trace)
				HetReporter.printInLog("HetModel horizon: " + refH.id + " HXs" + " newHXs: " + newHXs + " refCECXs: "
						+ refCECXs + " newCECXs: " + newCECXs + " refCECXs - (newCECXs - newHXs): "
						+ (refCECXs - (newCECXs - newHXs)));
			if (trace)
				HetReporter.printInLog("HetModel horizon: " + refH.id + " YaOH" + " newYaOH: " + newYaOH + " refAEC: "
						+ refAEC + " newAEC: " + newAEC + " refAEC - (newAEC - newYaOH): "
						+ (refAEC - (newAEC - newYaOH)));

		}

		// fc-13.11.2019 CAUTION
		// due to HetDiscreteSoil and Pedons introduction, this method initially
		// relying on a SimpleHetSoil with horizons inside should be checked and
		// adapted
		// -> added getPedonSpecimen () meanwhile to work on the first pedon
		// found
		HetReporter.printInLog(
				"HetModel refScene 1st horizon: " + refScene.getSoil().getPedonSpecimen().getHorizon(1).toString());
		HetReporter.printInLog(
				"HetModel newScene 1st horizon: " + newScene.getSoil().getPedonSpecimen().getHorizon(1).toString());
		// HetReporter.printInLog("HetModel refScene 1st horizon: " +
		// refScene.getSoil().getHorizon(1).toString());
		// HetReporter.printInLog("HetModel newScene 1st horizon: " +
		// newScene.getSoil().getHorizon(1).toString());

		// Call Phreeqc

		// fc-13.11.2019 CAUTION introduced HetDiscreteSoil, added (HetSoil)
		// here
		HetPhreeqc ph = new HetPhreeqc((HetSoil) newScene.getSoil(), ip);
		// HetPhreeqc ph = new HetPhreeqc(newScene.getSoil(), ip);

		// SIMPLIFIED fc-8.9.2016 chemistry has been checked available at this
		// point, PhreeqC wil send an error if can not run
		//
		// // Note fc+mj-1.3.2016 phreeqC may be available but soil (optional)
		// // may be null
		// if (HetPhreeqc.isPhreeqcAvailable() && newScene.getSoil() != null) {
		// HetPhreeqc ph = new HetPhreeqc(newScene.getSoil(), ip);
		// }

	}

	private double sum(Map<String, Double> map, String[] names) {
		Set<String> setNames = new HashSet<>(Arrays.asList(names));
		double sum = 0;
		for (String name : map.keySet()) {
			if (setNames.contains(name)) {
				double v = map.get(name);
				sum += v;
			}

		}
		return sum;
	}

	/**
	 * Multiplies all values in the given map by the given coefficient.
	 */
	private void multiply(Map<String, Double> map, String[] names, double coefficient) {
		Set<String> setNames = new HashSet<>(Arrays.asList(names));
		for (String name : map.keySet()) {
			if (setNames.contains(name)) {
				double v = map.get(name);
				map.put(name, v * coefficient);
			}
		}

	}

	/**
	 * Update the tree and litter compartments after tree growth
	 */
	private void updateTreeAndLitterCompartments(HetInitialParameters ip, HetScene refScene, HetTree refTree,
			HetScene newScene, HetTree newTree) {

		// This method works with or without soil

		HetSpecies species = newTree.getSpecies();
		String speciesName = species.getName();
		HetElementState statusMap = newTree.getNutrientStatusMap();

		HetTreeCompartment refLuc = refTree.getTreeCompartment(HetTreeCompartment.LEAVES_UPPER_CURRENT);

		HetTreeCompartment newLuc = new HetTreeCompartment(HetTreeCompartment.LEAVES_UPPER_CURRENT);
		newLuc.init(newTree);

		for (String eName : HetTreeElement.elementNames) {

			if (statusMap.contains(eName)) {
				// Estimate concentration for element with status
				double status = statusMap.getValue(eName);

				double def = ip.foliarChemistryThresholds.getDeficiencyConcentration(speciesName, eName);
				double opt = ip.foliarChemistryThresholds.getOptimumConcentration(speciesName, eName);
				double c1 = def + status * (opt - def);

				if (Double.isNaN(c1)) {
					HetReporter.printInLog("HetModel.updateTreeAndLitterCompartments () -1- eName: " + eName
							+ " C1: NaN *** status: " + status + " def: " + def + " opt: " + opt);
				}

				newLuc.setConcentration(eName, c1);

			} else {

				if (!refScene.isSoilChemistryAvailable()) {

					newLuc.setConcentration(eName, refLuc.getConcentration(eName));

				} else {

					// Estimate concentration for element without status
					// conc = fraction of actual uptake allocated to luc divided
					// by
					// luc biomass
					HetElementState actualUptake = newTree.getActualUptake();
					double newBiomass = newLuc.biomass;

					double Cconc = 0.5;
					double refLucReq = refLuc.getConcentration(eName) * refLuc.getBiomassProduction(refTree, newTree)
							/ Cconc;

					double fractionAllocatedToLuc = 0;
					if (newTree.getRequirement().getValue(eName) != 0)
						fractionAllocatedToLuc = refLucReq / newTree.getRequirement().getValue(eName);

					double newConc = 0;
					if (newBiomass != 0)
						newConc = ((actualUptake.getValue(eName) / 1000) * fractionAllocatedToLuc)
								/ (newBiomass / Cconc) * 1000; // mg/g

					if (Double.isNaN(newConc)) {
						HetReporter.printInLog("HetModel.updateTreeAndLitterCompartments () -2- eName: " + eName
								+ " newConc: NaN *** newBiomass: " + newBiomass + " refLucReq: " + refLucReq
								+ " fractionAllocatedToLuc: " + fractionAllocatedToLuc
								+ " actualUptake.getValue(eName): " + actualUptake.getValue(eName)
								+ " newTree.getRequirement().getValue(eName): "
								+ newTree.getRequirement().getValue(eName));
					}

					newLuc.setConcentration(eName, newConc);
				}

			}

		}

		// Manage the provided tree compartments
		if (ip.providedTreeCompartmentNames != null && ip.providedTreeCompartmentNames.get(speciesName) != null) {

			for (String treeCompartmentName : ip.providedTreeCompartmentNames.get(speciesName)) {
				HetTreeCompartment tc = new HetTreeCompartment(treeCompartmentName);
				tc.init(newTree);

				for (String eName : HetTreeElement.elementNames) {

					double newLucConc = newLuc.getConcentration(eName);
					HetTreeCompartment refTc = refTree.getTreeCompartment(treeCompartmentName);
					double newConc = refTc.getConcentration(eName); // fc+mj-7.12.2016
					if (refLuc.getConcentration(eName) != 0)
						if (newLucConc != 0) // fc+mj-7.12.2016
							newConc = newLucConc * refTc.getConcentration(eName) / refLuc.getConcentration(eName);

					tc.setConcentration(eName, newConc);
				}

				newTree.addTreeCompartment(tc);
			}

		}
		// Manage the provided litter compartments
		if (ip.providedLitterCompartmentNames != null && ip.providedLitterCompartmentNames.get(speciesName) != null) {

			for (String litterCompartmentName : ip.providedLitterCompartmentNames.get(speciesName)) {
				HetLitterCompartment lc = new HetLitterCompartment(litterCompartmentName);
				double biomass_kgC = newTree.getLitterBiomass_kgC(litterCompartmentName);
				lc.setBiomass(biomass_kgC);

				for (String eName : HetTreeElement.elementNames) {

					double newLucConc = newLuc.getConcentration(eName);
					HetLitterCompartment refLc = refTree.getLitterCompartment(litterCompartmentName);
					double newConc = 0;
					if (refLuc.getConcentration(eName) != 0)
						newConc = newLucConc * refLc.getConcentration(eName) / refLuc.getConcentration(eName);

					lc.setConcentration(eName, newConc);

				}

				newTree.addLitterCompartment(lc);
			}

		}

		// Create the missing compartments
		newTree.addTreeCompartment(newLuc);
		ip.createTreeCompartments(newLuc, newTree);

		newTree.createLitterCompartments(newScene, ip);
		// ip.createLitterCompartments(newScene, newTree);

		// nb-23.11.2018
		// log("HetModel: updateTreeAndLitterCompartments() litter compartments
		// for tree " + newTree.getId() + ": "
		// + AmapTools.toString(newTree.getLitterCompartments()));
		HetReporter.printInLog("HetModel: updateTreeAndLitterCompartments() litter compartments for tree "
				+ newTree.getId() + ": " + AmapTools.toString(newTree.getLitterCompartments()));

	}

	private void createLitterCompartmentsForDeadTrees(HetInitialParameters ip, HetScene newScene) {

		// Dead trees if any
		for (Object o : newScene.getTrees("dead")) {
			HetTree t = (HetTree) o;
			HetSpecies species = t.getSpecies();

			t.createLitterCompartment(newScene, HetLitterCompartment.LEAVES,
					t.getLeafBiomass_kgC() * (1 - species.leafRetranslocationRate), ip); //
			t.createLitterCompartment(newScene, HetLitterCompartment.BRANCHES,
					t.getBranchBiomass_kgC() + t.getStemBiomass_kgC(), ip);
			t.createLitterCompartment(newScene, HetLitterCompartment.ROOTS, t.getRootBiomass_kgC(), ip);
			t.createLitterCompartment(newScene, HetLitterCompartment.FINE_ROOTS, t.getFineRootBiomass_kgC(), ip);
			t.createLitterCompartment(newScene, HetLitterCompartment.MYCORRHIZAE, t.getMycorrhizaeBiomass_kgC(), ip);
			t.createLitterCompartment(newScene, HetLitterCompartment.FRUITS, t.getFruitLitterFall_kgC(), ip); // fa+mj-01.12.2017

		}

	}

	private void createLitterCompartmentsForCutTrees(HetInitialParameters ip, HetScene newScene) {
		// Cut trees if any
		// (To be done later if needed: adapt litter concentrations for cut
		// trees to account for the fact that living biomass was cut and was
		// therefore maybe more concentrated in nutrients) // fc+mj-9.5.2016
		for (Object o : newScene.getTrees("cut")) {
			HetTree t = (HetTree) o;
			HetSpecies species = t.getSpecies();

			t.createLitterCompartment(newScene, HetLitterCompartment.LEAVES,
					t.getLeafBiomass_kgC() * (1 - species.leafRetranslocationRate), ip); //
			// ip.createLitterCompartment(newScene, t,
			// HetLitterCompartment.LEAVES,
			// t.getLeafBiomass_kgC() * (1 - species.leafRetranslocationRate));
			// //

			// Branches: remove the exported biomass
			double exportedBranchBiomass = 0;
			for (HetTreeCompartment tc : t.getTreeCompartments()) {
				if (tc.getType().equals(HetTreeCompartment.TYPE_BRANCH)
						|| tc.getType().equals(HetTreeCompartment.TYPE_STEM)) {
					if (tc.diameter <= ip.cuttingDiameter) {
						exportedBranchBiomass += tc.biomass;
					}
				}
			}
			t.createLitterCompartment(newScene, HetLitterCompartment.BRANCHES,
					t.getBranchBiomass_kgC() + t.getStemBiomass_kgC() - exportedBranchBiomass, ip);

			t.createLitterCompartment(newScene, HetLitterCompartment.ROOTS, t.getRootBiomass_kgC(), ip);
			t.createLitterCompartment(newScene, HetLitterCompartment.FINE_ROOTS, t.getFineRootBiomass_kgC(), ip);
			t.createLitterCompartment(newScene, HetLitterCompartment.MYCORRHIZAE, t.getMycorrhizaeBiomass_kgC(), ip);
			t.createLitterCompartment(newScene, HetLitterCompartment.FRUITS, t.getFruitLitterFall_kgC(), ip);

		}
	}

	private void recalculateCrownDimensions(HetScene refScene, HetScene newScene) {

		HetInitialParameters ip = getSettings();
		// SLSettings slSettings = slModel.getSettings();

		// Recalculate the crown dimensions and 3D shape
		HetPlot newPlot = (HetPlot) newScene.getPlot();
		for (Iterator i = newScene.getTrees().iterator(); i.hasNext();) {
			HetTree newTree = (HetTree) i.next();

			HetTree refTree = (HetTree) refScene.getTree(newTree.getId());

			// hlce, rnorth...
			if (ip.competitionAccountedForCrownGrowth) {

				HetSpecies species = newTree.getSpecies();
				double maxDistance = 2 * species.maxCrownRadius;
				boolean torusEnabled = true;

				RoundMask m = new RoundMask(newPlot, maxDistance, torusEnabled);
				Collection neighbours = m.getTreesNear(newTree);

				Map distances = m.getTreeDistances();
				Map locationsWithinTorus = m.getTreeLocationsWithinTorus();
				Map treeAngles = m.getTreeAngles();

				List<HetTree> northTrees = new ArrayList<HetTree>();
				List<HetTree> eastTrees = new ArrayList<HetTree>();
				List<HetTree> southTrees = new ArrayList<HetTree>();
				List<HetTree> westTrees = new ArrayList<HetTree>();

				for (Object o : treeAngles.keySet()) {
					HetTree nei = (HetTree) o;
					double angle = (Double) treeAngles.get(nei);
					if (angle >= 315 && angle <= 360 || angle >= 0 && angle < 45) {
						northTrees.add(nei);
						// double dist = (Double) distances.get (nei);
						// Vertex2d coord = (Vertex2d)
						// locationsWithinTorus.get (nei);
						// System.out.println
						// (" North neighbour: treeId: "+nei.getId
						// ()+" angle: "+angle+" dist: "+dist+" coord: "+coord);
					}
					if (angle >= 45 && angle < 135) {
						eastTrees.add(nei);
						// double dist = (Double) distances.get (nei);
						// Vertex2d coord = (Vertex2d)
						// locationsWithinTorus.get (nei);
						// System.out.println
						// (" East neighbour: treeId: "+nei.getId
						// ()+" angle: "+angle+" dist: "+dist+" coord: "+coord);
					}
					if (angle >= 135 && angle < 225) {
						southTrees.add(nei);
						// double dist = (Double) distances.get (nei);
						// Vertex2d coord = (Vertex2d)
						// locationsWithinTorus.get (nei);
						// System.out.println
						// (" South neighbour: treeId: "+nei.getId
						// ()+" angle: "+angle+" dist: "+dist+" coord: "+coord);
					}
					if (angle >= 225 && angle < 315) {
						westTrees.add(nei);
						// double dist = (Double) distances.get (nei);
						// Vertex2d coord = (Vertex2d)
						// locationsWithinTorus.get (nei);
						// System.out.println
						// (" West neighbour: treeId: "+nei.getId
						// ()+" angle: "+angle+" dist: "+dist+" coord: "+coord);
					}

				}

				// For newTree
				double height = newTree.getHeight();
				double refHcb = refTree.getHcb();
				// double hcbEstimated = (species.hcbA * height + species.hcbB *
				// height * height - hlce)
				// / (species.hcbA - 1 + species.hcbB * height);

				double hcbEstimated = species.hcbHeightProportion * height;

				double deltaHcb = 0;
				if ((hcbEstimated - refHcb) >= 0) {
					deltaHcb = Math.min(species.deltaHlceMax, hcbEstimated - refHcb);
				} else {
					// if (newNeighbourhoodBasalArea <
					// refNeighbourhoodBasalArea) {
					deltaHcb = Math.max(species.deltaHlceMin, hcbEstimated - refHcb);
					// } else {
					// deltaHcb = 0;
					// }
				}

				newTree.setHcb(refHcb + deltaHcb);

				// boolean traceOn = newTree.getId () == 447;
				boolean traceOn = false; // fc-26.11.2013 removed trace

				if (traceOn)
					HetReporter.printInStandardOutput("HetModel competitionAccountedForCrownGrowth, tree 447...");

				double[] hlce_radius1 = estimateHlce(newTree, refTree, refScene, refTree.getRnorth(), distances,
						northTrees, maxDistance);
				if (traceOn)
					HetReporter.printInStandardOutput(
							"Result for North: hlce: " + hlce_radius1[0] + " radius: " + hlce_radius1[1]);

				double[] hlce_radius2 = estimateHlce(newTree, refTree, refScene, refTree.getReast(), distances,
						eastTrees, maxDistance);
				if (traceOn)
					HetReporter.printInStandardOutput(
							"Result for East: hlce: " + hlce_radius2[0] + " radius: " + hlce_radius2[1]);

				double[] hlce_radius3 = estimateHlce(newTree, refTree, refScene, refTree.getRsouth(), distances,
						southTrees, maxDistance);
				if (traceOn)
					HetReporter.printInStandardOutput(
							"Result for South: hlce: " + hlce_radius3[0] + " radius: " + hlce_radius3[1]);

				double[] hlce_radius4 = estimateHlce(newTree, refTree, refScene, refTree.getRwest(), distances,
						westTrees, maxDistance);
				if (traceOn)
					HetReporter.printInStandardOutput(
							"Result for West: hlce: " + hlce_radius4[0] + " radius: " + hlce_radius4[1]);

				double hlce = (hlce_radius1[0] + hlce_radius2[0] + hlce_radius3[0] + hlce_radius4[0]) / 4d;
				newTree.setHlce(hlce);

				newTree.setRnorth(hlce_radius1[1]);
				newTree.setReast(hlce_radius2[1]);
				newTree.setRsouth(hlce_radius3[1]);
				newTree.setRwest(hlce_radius4[1]);

				newTree.updateMean2CrownRadius();

			}

			// Create the 3D trunk and crown parts
			if (ip.samsaFileLoader.isTrunkInterception())
				newTree.createSLTrunk();
			newTree.createSLCrownParts(ip.LADNeighbourhoodDistance, newScene); // including
																				// LAD

		}
	}

	private HetTree treeGrowth(HetInitialParameters ip, HetEvolutionParameters ep, Random random, HetScene originScene,
			int numberOfYears, HetScene refScene, HetTree t, int newYear, HetScene newScene, double forcedNppToGppRatio,
			HetYearlyTranspirationMemory yearlyTranspirationMemory, double fruitLitterProduction_kgC)
			throws RuntimeException, Exception {

		// fc+mj-12.9.2017 added forcedNppToGppRatio, used only if > 0

		// fc+fa-17.5.2017 added refScene to get vegetationPeriod in
		// SamsaraLight fineResolutionMode in HetForwardGrower

		HetTree newTree = null;

		if (!ep.pueEstimationMode) {

			// Normal growth
			// fc+mj-12.9.2017 fakeGrowth is now in ip
			// boolean fakeGrowth = false;
			HetTreeForwardGrower grower = new HetTreeForwardGrower(ip, random, refScene, t, newYear, newScene, this,
					forcedNppToGppRatio, yearlyTranspirationMemory, fruitLitterProduction_kgC);
			HetTreeBuilder treeBuilder = new HetTreeBuilder(t, grower);

			newTree = treeBuilder.getNewTree();
			newTree.setFruitLitterFall_kgC(fruitLitterProduction_kgC); // fa+mj-04.12.2017

		} else {
			// PAR Use Efficiency mode growth
			int treeId = t.getId();

			// For virtual tree, we rely on their original tree
			if (t.isVirtual())
				treeId = t.getVirtualOriginalTreeId();

			HetTree originTree = (HetTree) originScene.getTree(treeId);
			HetScene targetScene = ep.pueEstimationTargetScene;
			HetTree targetTree = (HetTree) targetScene.getTree(treeId);

			double annualDeltaDbh = 0;
			double annualDeltaHeight = 0;

			// t not found in target observation file: was thinned or
			// missing observation
			if (targetTree == null) {
				annualDeltaDbh = t.getDefaultDeltaDbh();
				annualDeltaHeight = t.getDefaultDeltaHeight();
				// if (!t.isVirtual())
				// System.out.println("HetModel processEvolution () PUE mode
				// targetTree == null, newYear: "
				// + newYear + ", treeId: " + treeId);
			} else {
				annualDeltaDbh = (targetTree.getDbh() - originTree.getDbh()) / numberOfYears;
				annualDeltaHeight = (targetTree.getHeight() - originTree.getHeight()) / numberOfYears;
			}

			// Inverse growth
			HetTreeInverseGrower grower = new HetTreeInverseGrower(refScene, newScene, ip, random, t, newYear,
					annualDeltaDbh, annualDeltaHeight, forcedNppToGppRatio, yearlyTranspirationMemory,
					fruitLitterProduction_kgC);
			HetTreeBuilder treeBuilder = new HetTreeBuilder(t, grower);

			newTree = treeBuilder.getNewTree();
			newTree.setFruitLitterFall_kgC(fruitLitterProduction_kgC); // fa+mj-04.12.2017
		}

		return newTree;
	}

	/**
	 * Estimates an hlce and crown radius in the direction accounting for
	 * heighbourhood in the given sector. Returns defaultHlce and defaultRadius
	 * if there is no competiting tree in this sector.
	 */
	private double[] estimateHlce(HetTree newTree, HetTree refTree, HetScene refScene, double refRadius, Map distances,
			List<HetTree> neighboursInSector, double maxDistance) {

		// boolean traceOn = newTree.getId () == 447;
		boolean traceOn = false; // fc-26.11.2013 removed trace

		// refHlce is hlce of the previous year tree
		double refHlce = refTree.getHlce();

		// Prefix 0 for the target central tree
		// Prefix 1 for the neighbour tree

		// Target tree: newTree
		HetSpecies species = newTree.getSpecies();

		// fc+mj+br-1.10.2018
		double hlcePot0 = newTree.getHcb() + 0.1;
		// double hlcePot0_working = species.hlcePotA + species.hlcePotB *
		// newTree.getHeight();
		// double hlcePot0 = species.hcbHeightProportion * newTree.getHeight();

		// Log.println("estimateHlce", "hlcePot0_working: "+hlcePot0_working+"
		// hlcePot0: "+hlcePot0);

		// double rPot0 = species.rPotA + species.rPotB * newTree.getDbh() *
		// Math.PI;
		double rPot0 = newTree.getDbh() / 200d
				* species.crownToStemDiameterEstimation.result(newTree.getDbh() * Math.PI)
				* species.crownToStemDiameterShift;

		// double meanHeight0 = newTree.getHeight() + hlcePot0 / 2d;

		HetTree candidateNeighbour = null;
		double candidateDistance = maxDistance;
		for (HetTree nei : neighboursInSector) {
			double dist = (Double) distances.get(nei);
			if (dist > candidateDistance)
				continue;

			HetSpecies neiSpecies = nei.getSpecies();

			// double hlcePot1 = neiSpecies.hlcePotA + neiSpecies.hlcePotB *
			// nei.getHeight();
			double hlcePot1 = nei.getHcb();
			// if (nei.getHeight () > meanHeight0 && hlcePot1 < meanHeight0) {
			if (nei.getHeight() > hlcePot0) {
				candidateNeighbour = nei;
				candidateDistance = dist;
			}

		}

		// No candidate neighbour found in this sector
		if (candidateNeighbour == null) {
			if (traceOn)
				HetReporter.printInStandardOutput("Could not find a neighbour within " + maxDistance + "m");
			return new double[] { hlcePot0, rPot0 };
		}

		if (traceOn)
			HetReporter.printInStandardOutput("Found a candidateNeighbour: " + candidateNeighbour.getId());

		// Check if the candidate is too far
		HetSpecies candidateSpecies = candidateNeighbour.getSpecies();
		// double rPot1 = candidateSpecies.rPotA + candidateSpecies.rPotB *
		// candidateNeighbour.getDbh() * Math.PI;
		double rPot1 = candidateNeighbour.getDbh() / 200d
				* species.crownToStemDiameterEstimation.result(candidateNeighbour.getDbh() * Math.PI)
				* species.crownToStemDiameterShift;

		// Their crowns are not in interaction
		if (rPot0 + rPot1 < candidateDistance) {
			if (traceOn)
				HetReporter.printInStandardOutput("Too far, aborted");
			return new double[] { hlcePot0, rPot0 };
		}

		// Check the candidate intersection
		// double hlcePot1 = candidateSpecies.hlcePotA +
		// candidateSpecies.hlcePotB * candidateNeighbour.getHeight();
		double hlcePot1 = candidateNeighbour.getHcb();
		double l0 = newTree.getHeight() - hlcePot0;
		double l1 = candidateNeighbour.getHeight() - hlcePot1;

		double resolution = 0.2;
		double maxIteration = 100000;
		Vertex2d xz = ellipsoidIntersection(rPot0, l0, rPot1, l1, hlcePot0, hlcePot1, candidateDistance, resolution,
				maxIteration);

		// Could not find an intersection
		if (xz == null) {
			if (traceOn)
				HetReporter.printInStandardOutput("No crown intersection found, aborted");
			return new double[] { hlcePot0, rPot0 };
		}

		// Found an intersection
		HetTree refNeighbour = (HetTree) refScene.getTree(candidateNeighbour.getId());

		double height0 = newTree.getHeight();
		double height1 = candidateNeighbour.getHeight();
		double hlceMax = xz.y;
		if (hlceMax < hlcePot0)
			hlceMax = hlcePot0;// necessary?

		double hlceEstimated = hlcePot0
				+ (hlceMax - hlcePot0) * Math.max(0, Math.min(1, (height1 - hlcePot0) / (height0 - hlcePot0)));

		double deltaHlce = 0;
		if ((hlceEstimated - refHlce) >= 0) {
			deltaHlce = Math.min(species.deltaHlceMax, hlceEstimated - refHlce);
		} else {
			// if (newNeighbourhoodBasalArea < refNeighbourhoodBasalArea) {
			deltaHlce = Math.max(species.deltaHlceMin, hlceEstimated - refHlce);
			// } else {
			// deltaHlce = 0;
			// }
		}

		double deltaRadius = 0;
		// double meanCrownOverlappingRatio = (species.crownOverlappingRatio +
		// candidateSpecies.crownOverlappingRatio)
		// / 2d;
		// double radiusEstimated = rPot0 / (rPot0 + rPot1) * candidateDistance
		// * meanCrownOverlappingRatio;
		double radiusEstimated = (rPot0) / (rPot0 + rPot1) * candidateDistance * species.crownOverlappingRatio;// MJ
																												// 11_10_2018

		double deltaDbh0 = newTree.getDbh() - refTree.getDbh();
		double deltaRadiusMax = deltaDbh0 / 200d
				* species.crownToStemDiameterEstimation.result(newTree.getDbh() * Math.PI)
				* species.crownToStemDiameterShift;

		double deltaDbh1 = candidateNeighbour.getDbh() - refNeighbour.getDbh();
		double deltaRadiusMin = -deltaDbh1 / 200d
				* candidateSpecies.crownToStemDiameterEstimation.result(candidateNeighbour.getDbh() * Math.PI)
				* candidateSpecies.crownToStemDiameterShift;

		if ((radiusEstimated - refRadius) >= 0) {
			deltaRadius = Math.min(deltaRadiusMax, radiusEstimated - refRadius);
		} else {
			deltaRadius = Math.max(deltaRadiusMin, radiusEstimated - refRadius);
		}

		return new double[] { refHlce + deltaHlce, refRadius + deltaRadius };

	}

	/**
	 * Calculates the intersection between two ellipsoids based on a random
	 * iterative approach. Returns null if no intersection found.
	 */
	private Vertex2d ellipsoidIntersection(double rPot0, double l0, double rPot1, double l1, double hlcePot0,
			double hlcePot1, double candidateDistance, double resolution, double maxIteration) {

		for (int i = 0; i < maxIteration; i++) {

			double z0 = random.nextDouble() * l0 + hlcePot0;
			double x0 = rPot0 / l0 * Math.sqrt(l0 * l0 - (z0 - hlcePot0) * (z0 - hlcePot0));

			double z1 = random.nextDouble() * l1 + hlcePot1;

			double a = 1;
			double b = -2 * candidateDistance;
			double c = candidateDistance * candidateDistance
					+ (rPot1 * rPot1) / (l1 * l1) * (z1 - hlcePot1) * (z1 - hlcePot1) - rPot1 * rPot1;
			double delta = b * b - 4 * a * c;

			// We are in the case where delta is positive
			double x1 = (-b - Math.sqrt(delta)) / (2 * a);

			double d = Math.sqrt((x0 - x1) * (x0 - x1) + (z0 - z1) * (z0 - z1));

			if (d < resolution) { // found
				// System.out.println
				// ("HetModel ellipsoidIntersection, found in "+i+"
				// iterations");
				double x = (x0 + x1) / 2d;
				double z = (z0 + z1) / 2d;
				return new Vertex2d(x, z);
			}

		}
		// System.out.println ("HetModel ellipsoidIntersection, not found ***");

		return null;
	}

	private boolean isStillAlive(HetTree refTree, HetTree newTree) {

		// return true; // always alive

		// fc+mj-9.3.2017 New mortality
		return newTree.getDefoliation() <= 90;

		// Former mortality
		// double delta = newTree.getDbh() - refTree.getDbh();
		// if (delta == 0)
		// return false; // dead
		// else
		// return true;

	}

	/**
	 * Post intervention processing
	 */
	@Override
	public void processPostIntervention(GScene newGScene, GScene refGScene) throws Exception {
		// Add here if needed an optional process to be run after intervention

		HetInitialParameters ip = getSettings();

		// Light: initial radiative balance
		HetScene newScene = (HetScene) newGScene;
		HetScene refScene = (HetScene) refGScene;
		// HetReporter.printInStandardOutput("date refScene: " +
		// refScene.getDate());
		// HetReporter.printInStandardOutput("date newScene: " +
		// newScene.getDate());
		// HetReporter.printInStandardOutput("intervention refScene ? " +
		// refScene.isInterventionResult());
		// HetReporter.printInStandardOutput("intervention newScene ? " +
		// newScene.isInterventionResult());

		// fc+mj-12.5.2016
		createLitterCompartmentsForCutTrees(ip, newScene);

		// --- fc-10.1.2018 REMOVED the 4 lines below: tree energy is now better
		// --- reset in lightResult.resetEnergy (), called in processLighting ()
		// below
		// fc-15.5.2014
		// Reset energy and impact number for all trees before new computation
		// was missing, is commented in slModel.processLighting (newScene);
		// restored in this location by fc-15.5.2014 because M. Jonard found the
		// bug
		// for (Iterator i = newScene.getTrees().iterator(); i.hasNext();) {
		// HetTree t = (HetTree) i.next();
		//
		// // fc-10.1.2018 refactored, tree.resetEnergy () replaced by
		// tree.getLightResult ().resetEnergy ()
		// t.getLightResult().resetEnergy();
		//
		// }
		// fc-15.5.2014
		// --- fc-10.1.2018 REMOVED the 4 lines upper

		// Light calculation
		SLFoliageStateManager foliageStateManager = (SLFoliageStateManager) newScene;

		processLighting(newScene, foliageStateManager, refScene, null, null, slModel);

		// Run lighting on understorey after an intervention (maybe more light
		// available if some trees were cut)
		understoreyLighting(ip, newScene);


		if (ip.phenologyAtTreeLevel) {
			
			// Calculates for each tree:
			// - the sum of leaf areas of the trees smaller than it and that belong to the same species. This sum 
			// will be then used in the calculation of the ladProp (proportion of leaf area compared to the level 
			// of maximum development) at tree level. 
			// - the sum of leaf areas of the trees taller than it and that belong to the same species. This sum 
			// will be then used in the calculation of the ladProp and the greenProp (proportion of green leaves 
			// compared to the level of maximum development) at tree level. nb-17.12.2019
			newScene.calculateCumulatedLeafAreasOfSmallerAndTallersTrees();
		}

		// Calculates the leaf area of the species. Needed in calculation of lad
		// proportion. nb-07.11.2019
		
		// fa-17.12.2019: moved species leaf area from HetSpecies to HetScene
		HashMap<Integer, Double> newSceneSpeciesLeafAreaMap = new HashMap<Integer, Double>();
		for (int speciesId : ip.speciesMap.keySet()) { // initialization
			newSceneSpeciesLeafAreaMap.put(speciesId, 0d);
		}
		for (Tree t : newScene.getTrees()) {
			HetTree tree = (HetTree) t;
			HetSpecies species = tree.getSpecies();
			int speciesId = species.getId();
			addInMap(newSceneSpeciesLeafAreaMap, speciesId, tree.getLeafArea()); // fa-17.12.2019: moved species leaf area from HetSpecies to HetScene
//			species.leafArea_sp += tree.getLeafArea(); // fa-17.12.2019: commented
		}
		newScene.setSpeciesLeafAreaMap(newSceneSpeciesLeafAreaMap);

		// fc-mj-fa-15.11.2019 Update the pedons in the soil, calc their area...
		newScene.getSoil().updatePedonList(newScene);
		newScene.getSoil().updatePedonProperties(newScene);

	}

	public TicketDispenser getTreeIdDispenser() {
		return treeIdDispenser;
	}

	/**
	 * Copies the light properties from the reference scene to the newScene :
	 * when the light is not recomputed each year to save time.
	 */
	private void copyLight(HetScene refScene, HetScene newScene) {

		for (Tree t : newScene.getTrees()) {

			HetTree newTree = (HetTree) t;
			// System.out.println(" --> tree id: " + newTree.getId());
			HetTree refTree = (HetTree) refScene.getTree(newTree.getId());

			if (refTree == null)
				continue; // newTree was just recruited

			// System.out.println("REF TREE");
			// System.out.println("controlLegacyTreeEnergy: " +
			// refTree.getLightResult().getControlLegacyTreeEnergy());
			// System.out.println("controlTagBasedTreeEnergy: " +
			// refTree.getLightResult().getControlTagBasedTreeEnergy());
			// System.out.println("crownDiffuseEnergy: " +
			// refTree.getLightResult().getCrownDiffuseEnergy());
			// System.out.println("crownDirectEnergy: " +
			// refTree.getLightResult().getCrownDirectEnergy());
			// System.out.println("crownEnergy: " +
			// refTree.getLightResult().getCrownEnergy());
			// System.out.println("crownPotentialEnergy: " +
			// refTree.getLightResult().getCrownPotentialEnergy());
			// System.out.println("impactNumber: " +
			// refTree.getLightResult().getImpactNumber());
			// System.out.println("lowerCrownPotentialEnergy: " +
			// refTree.getLightResult().getLowerCrownPotentialEnergy());
			// System.out.println("numberOfAddResult: " +
			// refTree.getLightResult().numberOfAddResult);
			// System.out.println("trunkDiffuseEnergy:" +
			// refTree.getLightResult().getTrunkDiffuseEnergy());
			// System.out.println("trunkDirectEnergy:" +
			// refTree.getLightResult().getTrunkDirectEnergy());
			// System.out.println("trunkEnergy:" +
			// refTree.getLightResult().getTrunkEnergy());

			// System.out.println("\nAVANT SETLIGHTRESULT()");
			// System.out.println("controlLegacyTreeEnergy: " +
			// newTree.getLightResult().getControlLegacyTreeEnergy());
			// System.out.println("controlTagBasedTreeEnergy: " +
			// newTree.getLightResult().getControlTagBasedTreeEnergy());
			// System.out.println("crownDiffuseEnergy: " +
			// newTree.getLightResult().getCrownDiffuseEnergy());
			// System.out.println("crownDirectEnergy: " +
			// newTree.getLightResult().getCrownDirectEnergy());
			// System.out.println("crownEnergy: " +
			// newTree.getLightResult().getCrownEnergy());
			// System.out.println("crownPotentialEnergy: " +
			// newTree.getLightResult().getCrownPotentialEnergy());
			// System.out.println("impactNumber: " +
			// newTree.getLightResult().getImpactNumber());
			// System.out.println("lowerCrownPotentialEnergy: " +
			// newTree.getLightResult().getLowerCrownPotentialEnergy());
			// System.out.println("numberOfAddResult: " +
			// newTree.getLightResult().numberOfAddResult);
			// System.out.println("trunkDiffuseEnergy:" +
			// newTree.getLightResult().getTrunkDiffuseEnergy());
			// System.out.println("trunkDirectEnergy:" +
			// newTree.getLightResult().getTrunkDirectEnergy());
			// System.out.println("trunkEnergy:" +
			// newTree.getLightResult().getTrunkEnergy());

			// fc-10.1.2018 Reset energy (in particular in trunk and crownParts)
			// before copy to avoid doubling values, bug found by fa and nb
			newTree.getLightResult().resetEnergy();

			// fc-22.6.2017 this is where we manage treeLight in case of copy
			newTree.setLightResult(refTree.getLightResult().getCopy(newTree));

			// System.out.println("\nAPRES SETLIGHTRESULT()");
			// System.out.println("controlLegacyTreeEnergy: " +
			// newTree.getLightResult().getControlLegacyTreeEnergy());
			// System.out.println("controlTagBasedTreeEnergy: " +
			// newTree.getLightResult().getControlTagBasedTreeEnergy());
			// System.out.println("crownDiffuseEnergy: " +
			// newTree.getLightResult().getCrownDiffuseEnergy());
			// System.out.println("crownDirectEnergy: " +
			// newTree.getLightResult().getCrownDirectEnergy());
			// System.out.println("crownEnergy: " +
			// newTree.getLightResult().getCrownEnergy());
			// System.out.println("crownPotentialEnergy: " +
			// newTree.getLightResult().getCrownPotentialEnergy());
			// System.out.println("impactNumber: " +
			// newTree.getLightResult().getImpactNumber());
			// System.out.println("lowerCrownPotentialEnergy: " +
			// newTree.getLightResult().getLowerCrownPotentialEnergy());
			// System.out.println("numberOfAddResult: " +
			// newTree.getLightResult().numberOfAddResult);
			// System.out.println("trunkDiffuseEnergy:" +
			// newTree.getLightResult().getTrunkDiffuseEnergy());
			// System.out.println("trunkDirectEnergy:" +
			// newTree.getLightResult().getTrunkDirectEnergy());
			// System.out.println("trunkEnergy:" +
			// newTree.getLightResult().getTrunkEnergy());

			// Copy the light values of the trunk if any
			SLTrunk refTrunk = refTree.getTrunk();
			SLTrunk newTrunk = newTree.getTrunk();
			if (refTrunk != null && newTrunk != null) {
				// The three values in newTrunk are zero, so adding a value is
				// like setting this
				// value
				// if (newTree.getId() == 8) {
				// System.out.println("newTrunk: " + newTrunk.getDirectEnergy()
				// + " " + newTrunk.getDiffuseEnergy());
				// System.out.println("refTrunk: " + refTrunk.getDirectEnergy()
				// + " " + refTrunk.getDiffuseEnergy());
				// }

				newTrunk.addDirectEnergy(refTrunk.getDirectEnergy());
				newTrunk.addDiffuseEnergy(refTrunk.getDiffuseEnergy());
				// newTrunk.addPotentialEnergy(refTrunk.getPotentialEnergy());
			}

			Iterator<SLCrownPart> refCrownParts = refTree.getCrownParts().iterator();
			Iterator<SLCrownPart> newCrownParts = newTree.getCrownParts().iterator();
			while (refCrownParts.hasNext() && newCrownParts.hasNext()) {
				SLCrownPart refPart = refCrownParts.next();
				SLCrownPart newPart = newCrownParts.next();

				// if (newTree.getId() == 8) {
				// System.out.println("newPart: " + newPart.getDirectEnergy() +
				// " " + newPart.getDiffuseEnergy());
				// System.out.println("refPart: " + refPart.getDirectEnergy() +
				// " " + refPart.getDiffuseEnergy());
				// }

				// The three values in newPart are zero, so adding a value is
				// like setting this
				// value
				newPart.addDirectEnergy(refPart.getDirectEnergy());
				newPart.addDiffuseEnergy(refPart.getDiffuseEnergy());
				// newPart.addPotentialEnergy(refPart.getPotentialEnergy());

			}
			// newTree.getTreeLight().tagResultMap =
			// refTree.getTreeLight().tagResultMap; //fa-16.06.2017

			// System.out.println("\nAPRES AJOUT");
			// System.out.println("controlLegacyTreeEnergy: " +
			// newTree.getLightResult().getControlLegacyTreeEnergy());
			// System.out.println("controlTagBasedTreeEnergy: " +
			// newTree.getLightResult().getControlTagBasedTreeEnergy());
			// System.out.println("crownDiffuseEnergy: " +
			// newTree.getLightResult().getCrownDiffuseEnergy());
			// System.out.println("crownDirectEnergy: " +
			// newTree.getLightResult().getCrownDirectEnergy());
			// System.out.println("crownEnergy: " +
			// newTree.getLightResult().getCrownEnergy());
			// System.out.println("crownPotentialEnergy: " +
			// newTree.getLightResult().getCrownPotentialEnergy());
			// System.out.println("impactNumber: " +
			// newTree.getLightResult().getImpactNumber());
			// System.out.println("lowerCrownPotentialEnergy: " +
			// newTree.getLightResult().getLowerCrownPotentialEnergy());
			// System.out.println("numberOfAddResult: " +
			// newTree.getLightResult().numberOfAddResult);
			// System.out.println("trunkDiffuseEnergy:" +
			// newTree.getLightResult().getTrunkDiffuseEnergy());
			// System.out.println("trunkDirectEnergy:" +
			// newTree.getLightResult().getTrunkDirectEnergy());
			// System.out.println("trunkEnergy:" +
			// newTree.getLightResult().getTrunkEnergy());
		}

		HetPlot refPlot = (HetPlot) refScene.getPlot();
		HetPlot newPlot = (HetPlot) newScene.getPlot();

		// newPlot.setPlotLight (refPlot.getPlotLight().getCopy(newPlot));

		for (Cell c : newPlot.getCells()) {
			HetCell newCell = (HetCell) c;
			HetCell refCell = (HetCell) refPlot.getCell(newCell.getId());

			newCell.setLightResult(refCell.getLightResult().getCopy(newCell));
		}

	}

	// mj+fa-01.12.2017
	private double fruitProductionCalculation_sp(HetScene refScene, HetSpecies species, double fruitLitterFallP1) {

		double standFruitLitterFall_kgC_ha = 0d;
		List trees = new ArrayList(refScene.getTrees());

		for (Iterator i = trees.iterator(); i.hasNext();) {
			HetTree t = (HetTree) i.next();

			double treeFruitLitterFall_kgC = 0d;
			HetTreeRadiationStatus radiationStatus = new HetTreeRadiationStatus(t);

			if (t.getSpecies() == species && t.getDbh() >= species.fruitProdMinDbh)
				treeFruitLitterFall_kgC = fruitLitterFallP1 * radiationStatus.lightCompetitionIndex
						* Math.pow(t.getDbh() - species.fruitProdMinDbh, species.fruitLitterFallP2);

			standFruitLitterFall_kgC_ha += treeFruitLitterFall_kgC / (refScene.getArea() / 10000d);
		}

		return standFruitLitterFall_kgC_ha;
	}

	// mj+fa-01.12.2017
	/**
	 * Optimize fruitLitterFallP1 to match observed and predicted fruit litter
	 * fall. Returns 1 double.
	 */
	private double optimizeFruitLitterParameter(HetScene refScene, HetSpecies species, double observedFruitLitterFall)
			throws RuntimeException {
		int max = 500;
		int i = 0;
		double inf = 0;
		double sup = 300 * species.fruitLitterFallP1;

		double predictedFruitLitterFall = -1;
		double fruitLitterFallP1 = -1;

		double EPSILON = 0.000001;
		while (Math.abs(sup - inf) > EPSILON && i <= max) {
			i++;

			fruitLitterFallP1 = (inf + sup) / 2d;

			predictedFruitLitterFall = fruitProductionCalculation_sp(refScene, species, fruitLitterFallP1);

			if (observedFruitLitterFall - predictedFruitLitterFall > 0)
				inf = fruitLitterFallP1;
			else
				sup = fruitLitterFallP1;
		}

		if (i >= max) {
			HetReporter.printInStandardOutput("HetModel optimizeFruitLitterParameter() did not converge in " + i
					+ " iterations, final fruitLitterFallP1: " + fruitLitterFallP1);
		}

		return fruitLitterFallP1;
	}

	/**
	 * A method that compute z coordinates for every HetCell in the constructor
	 *
	 * @author Gauthier Ligot, 13/05/2013
	 */
	public static double getZCoordinate(double x, double y, double slope_rad, double aspect_rad) {
		double z;
		double azimut = 0; // azimut of the point (x,y) angle from north
							// measured clockwise
							// (similarly to the aspect)
		double d = Math.sqrt(x * x + y * y); // distance to origin

		if (d == 0 || slope_rad == 0) {
			return 0;
		} else {
			if (y >= 0 && x >= 0) {
				azimut = Math.PI / 2 - Math.acos(x / d);
			} else if (y < 0 && x >= 0) {
				azimut = Math.PI / 2 + Math.acos(x / d);
			} else if (y < 0 && x < 0) {
				azimut = Math.PI / 2 + Math.acos(x / d);
			} else if (y >= 0 && x < 0) {
				azimut = 2 * Math.PI - (Math.acos(x / d) - Math.PI / 2);
			}

			double deltaAzimut = Math.abs(aspect_rad - azimut);
			z = -d * Math.cos(deltaAzimut) * Math.tan(slope_rad);

			// System.out.println ("Math.cos(deltaZimut) = " +
			// Math.cos(deltaAzimut) +
			// "Math.tan(slope_rad) =" + Math.tan(slope_rad));
			// System.out.println ("QGCell - getZCoordinate : x =" + x + " y=" +
			// y + " z=" + z);

			return z;
		}
	}

	/**
	 * If no tree has to be removed: does nothing and returns null. Else:
	 * processes true thinning on the given step, creates newScene by
	 * duplicating refScene linked to given step, removes trees, processes post
	 * intervention and marks newScene as the result of an intervention result.
	 */
	private Step processTrueThinning(Map<Integer, Integer> trueThinningMap, Step step) throws Exception {

		HetScene refScene = (HetScene) step.getScene();
		int refDate = refScene.getDate();

		// Removes trees.
		// fc+mj+fa-28.6.2017 True thinningMap management, moved here, was
		// upper
		// True thinning management.

		// Trees ids of refScene to be removed.
		Set<Integer> removedTreeIds = new HashSet<>();

		Collection refTrees = refScene.getTrees();

		// Loop and pick the ids of trees to be removed
		for (Iterator i = refTrees.iterator(); i.hasNext();) {

			HetTree t = (HetTree) i.next();
			Integer v = trueThinningMap.get(t.getId());

			if (v != null) {
				int lastYear = v.intValue();
				if (refDate >= lastYear) { // fc+mj+fa was >, now >=

					// Pick tree id
					removedTreeIds.add(t.getId());

					// Remove virtual trees based on the removed tree
					if (!t.isVirtual()) {
						List<Integer> virtualTreeIds = t.getVirtualTreeIdsBasedOnMe();
						if (virtualTreeIds != null && !virtualTreeIds.isEmpty()) {
							for (int vId : virtualTreeIds) {
								HetTree vt = (HetTree) refScene.getTree(vId);
								if (vt != null) {
									// Pick virtual tree id
									removedTreeIds.add(vt.getId());
								}
							}
						}
					}

				}
			}
		}

		System.out.println("True thinning -- Trees ids to be removed: " + removedTreeIds);

		if (removedTreeIds.isEmpty()) {

			// No tree to remove: no step resulting from an intervention (that
			// is marked with a star *) is created.
			return null;

		} else {

			// Creates a copy of the scene.
			HetScene newScene = refScene.getInterventionBase();
			newScene.setInterventionResult(true);

			// Initial version, before 14.06.2019
			// Removes the trees with a picked id.
			// for (Iterator i = new ArrayList(refTrees).iterator();
			// i.hasNext();) {
			//
			// HetTree t = (HetTree) i.next();
			//
			// if (removedTreeIds.contains(t.getId())) {
			// // Remove the tree
			// HetTree copy = (HetTree) t.clone();
			// newScene.storeStatus(copy, "cut");
			// newScene.removeTree(t); // unregisters from cell...
			// }
			// }

			// Version nb-14.06.2019. Removed trees.
			for (int treeId : removedTreeIds) {
				Tree tree = newScene.getTree(treeId);
				Tree copy = (Tree) tree.clone();
				newScene.storeStatus(copy, "cut");
				newScene.removeTree(tree);
			}

			processPostIntervention(newScene, refScene);

			String reason = "True thinning for year " + refDate;
			Step newStep = step.getProject().processNewStep(step, newScene, reason);

			return newStep;
		}

	}

	public Random getRandom() {
		return random;
	}

	public HetSamsaManager getSamsaManager() {
		return samsaManager;
	}
	/*
	 * // fa-12.10.2017: for parallel processing public synchronized double
	 * cumulateNetPrimaryProduction(double netPrimaryProduction, double
	 * deltaNetPrimaryProduction) { netPrimaryProduction +=
	 * deltaNetPrimaryProduction; return netPrimaryProduction; }
	 *
	 * // fa-12.10.2017: for parallel processing public synchronized double
	 * cumulateGrossPrimaryProduction(double grossPrimaryProduction, double
	 * deltaGrossPrimaryProduction) { grossPrimaryProduction +=
	 * deltaGrossPrimaryProduction; return grossPrimaryProduction; }
	 *
	 * // fa-12.10.2017: for parallel processing public synchronized double
	 * cumulateMaintenanceRespiration(double maintenanceRespiration, double
	 * deltaMaintenanceRespiration) { maintenanceRespiration +=
	 * deltaMaintenanceRespiration; return maintenanceRespiration; }
	 *
	 * // fa-12.10.2017: for parallel processing public synchronized double
	 * cumulateRetranslocation(double retranslocation, double
	 * deltaRetranslocation) { retranslocation += deltaRetranslocation; return
	 * retranslocation; }
	 */

	public HetInventoryLoader getInventoryLoader() {
		return inventoryLoader;
	}
	
	// fa-17.12.2019
	private void addInMap(HashMap<Integer, Double> map, int spId, double value) {
		double sum = 0;
		Double v = map.get(spId);
		if (v != null)
			sum = v;
		sum += value;
		map.put(spId, sum);
	}

}
