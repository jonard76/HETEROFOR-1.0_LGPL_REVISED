/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import capsis.defaulttype.Tree;
import capsis.defaulttype.plotofcells.Cell;
import capsis.defaulttype.plotofcells.SquareCell;
import capsis.lib.regeneration.RGStand;
import capsis.lib.samsaralight.SLFoliageStateManager;
import capsis.lib.samsaralight.SLLightableScene;
import capsis.lib.samsaralight.SLSensor;
import capsis.util.TreeHeightComparator;
import heterofor.model.fineresolutionradiativebalance.HetBeamSetFactoryOptimized; // for optimized tag mode
//import heterofor.model.fineresolutionradiativebalance.HetBeamSetFactory; // fa-09.08.2017: for non-optimized tag mode
import heterofor.model.phenology.HetPhenology;
import heterofor.model.phenology.HetPhenologyDate;
import heterofor.model.soil.HetHorizon;
import heterofor.model.soil.HetSoil;
import heterofor.model.soil.HetSoilInterface;
import heterofor.model.treechemistry.HetLitterCompartment;
import heterofor.model.treechemistry.HetTreeElement;
import heterofor.model.vegetationperiod.HetVegetationPeriod;
import heterofor.model.waterbalance.HetHourlyTreeTranspiration;
import heterofor.model.waterbalance.HetWaterBalance;
import heterofor.model.waterbalance.pedon.Pedon;
import jeeb.lib.util.ListMap;
import jeeb.lib.util.Log;

/**
 * HetScene is the description of the Heterofor scene. It is a list of HetTree
 * instances.
 *
 * @author M. Jonard, F. Herman - January 2012
 */
public class HetScene extends RGStand implements SLLightableScene, SLFoliageStateManager {

	private HetInitialParameters ip; // nb-08.11.2019

	// private List<Vertex2d> mainRectangle; //GL 8/3/13
	private List<SLSensor> sensors; // gl 23-05-2013

	private HetSoilInterface soil; // optional, may be null, linked to PhreeqC
									// //
	// fc+mj-27.10.2015

	private double NAvailable_kg;
	private double NStandUptake;
	private double NStandOptimalUptake;

	// public double barkStorageCapacity; // l/stand
	// public double foliageStorageCapacity; // l/stand

	// fc-et-al-20.1.2017 was a list, key is year_month_day_hour
	// public LinkedHashMap<String, HetWaterBalance> waterBalanceMap; //
	// fa-15.11.2015: moved to Pedon
	// public List<HetWaterBalance> waterBalanceList;

//	public LinkedHashMap<String, HetHourlyTreeTranspiration> hourlyTreeTranspirationMap; // fa-17.09.2019
	public Map<String, HetHourlyTreeTranspiration> hourlyTreeTranspirationMap ; // fa-02.12.2019: to enable cast to ConcurrentMap

	private double[] dailyGPP_kgC; // fc-et-al-20.1.2017
	private double[] dailyMaintenanceLeafRespiration_kgC; // fc-et-al-20.1.2017

	// fc_et_al_20.1.2017
	private double barkAbsorbedRadiation;
	private double barkAbsorbedDirectRadiation;
	private double barkAbsorbedDiffuseRadiation;
	private double standIncidentGlobalRadiation;

	// fc+fa-31.7.2017 reactivated the two lines below
	private double standIncidentDirectRadiation;
	private double standIncidentDiffuseRadiation;

	// nb+lw-24.01.2017 key: speciesId, value: phenology
	private HashMap<Integer, HetPhenology> phenologyMap;

	// fc+mj+fa-28.6.2017 added next year pheno
	// pheno of year y is now calc at year y - 1 and stored in
	// phenologyMapOfNextYear
	private HashMap<Integer, HetPhenology> phenologyMapOfNextYear;

	// fa-5.7.2017
	private int refVegetationPeriodLength; // Length of the vegetation period
											// corresponding to previous
											// radiative balance run
											// (Samsaralight)
	private int currentVegetationPeriodLength; // Length of the vegetation
												// period for current year
	// fa-6.7.2017
	private int nextYearVegetationPeriodLength; // Length of the vegetation
												// period for next year

	// fc+mj-9.3.2017 added integrative variables at the scene level
	private double grossPrimaryProduction_gC_m2;
	private double netPrimaryProduction_gC_m2;
	private double maintenanceRespiration_gC_m2;
	private double retranslocation_gC_m2;
	
	private HashMap<Integer, Double> horizonTotalFineRootLengthMap = new HashMap<Integer, Double>(); // fa-20.11.2019

	// fc+mj+br-4.10.2018 regeneration library connection
	private double regenerationGrossPrimaryProduction_gC_m2;
	private double regenerationNetPrimaryProduction_gC_m2;

	// Optional, only if ip.fineResolutionRadiativeBalanceActivated, related to
	// photosynthesis at hourly level
	private HetVegetationPeriod vegetationPeriod;
	private HetVegetationPeriod vegetationPeriodOfNextYear;

	// Optional, only if ip.fineResolutionRadiativeBalanceActivated, the
	// beamSetFactory which beams were used for the radiative balance on this
	// scene, changed every n years with n = ip.radiationCalculationTimeStep
	private HetBeamSetFactoryOptimized beamSetFactory; // for optimized tag mode
	// private HetBeamSetFactory beamSetFactory; // fa-09.08.2017: for
	// non-optimized tag mode

	private double crownProjectionSum_stand;

	// mj+fa-05.03.2018
	private HashMap<String, Double> q10SumMap;
	private HashMap<Integer, Double> q10SumMapLeaf;
	private HashMap<Integer, Double> q10SumMapFineRoot;

	// fa+mj-20.03.2018
	private HashMap<Integer, Double> meanUpperCrownHeightMap;
	private HashMap<Integer, Double> meanLowerCrownHeightMap;

	// fc+fa-21.11.2019
	private LinkedHashMap<String, HetWaterBalance> averageWaterBalanceMapCache;
	
	// fa-17.12.2019
	private HashMap<Integer, Double> speciesLeafAreaMap;

	/**
	 * Constructor.
	 */
	public HetScene(HetInitialParameters ip) {

		super();

		// InitialParameters are given to the scene because they are needed in
		// getLadProportionOfNextYear() called
		// sometimes on a new scene not yet linked to a step so that
		// InitialParameters cannot be found from this
		// scene. nb-08.11.2019
		this.ip = ip;

		// Create a default plot
		// setPlot(new DefaultPlot());
		// getPlot().setScene(this);

		// this.waterBalanceMap = new LinkedHashMap<>(); // Linked: keep
		// insertion // fa-15.11.2019: moved to Pedon
		// order

	}

	/**
	 * Returns the sum of trees leaf areas.
	 */
	public double getLeafArea() {

		// fc+mj+br-1.10.2018 see HetWaterBalanceCalculator

		double leafArea_stand = 0;

		for (Iterator i = this.getTrees().iterator(); i.hasNext();) {
			HetTree t = (HetTree) i.next();
			leafArea_stand += t.getLeafArea();
		}
		return leafArea_stand;
	}
	
	/**
	 * Calculates for each tree of current scene:
	 * - the sum of the leaf areas of the trees smaller than it and that belong to the same species;
	 * - the sum of the leaf areas of the trees taller than it and that belong to the same species.
	 * The leaf area of the considered tree is included in each calculated sum.
	 */
	public void calculateCumulatedLeafAreasOfSmallerAndTallersTrees() {

		// Key: species id, value: list of trees belonging to this species.
		ListMap<Integer, HetTree> speciesIdTreeIdListMap = new ListMap<Integer, HetTree>();

		// Fills in speciesIdTreeIdListMap.
		for (Tree t : this.getTrees()) {
			HetTree tree = (HetTree) t;
			int speciesId = tree.getSpecies().getId();
			speciesIdTreeIdListMap.addObject(speciesId, tree);
		}

//		System.out.println("**** ASCENDING ORDER ****");
		
		// Sorts the trees of each species in ascending order of their height. Then, for each tree, calculates
		// the sum of leaf areas of trees belonging to the same species and that are smaller than it. The leaf area
		// of the considered tree is included in the sum.
		for (int speciesId : speciesIdTreeIdListMap.getKeys()) {

			List<HetTree> treeList = speciesIdTreeIdListMap.get(speciesId);
			Collections.sort(treeList, new TreeHeightComparator(true)); // ascending order of height

//			 System.out.println("speciesId: " + speciesId + " --> ");
//			 for (HetTree tree : treeList) {
//				 System.out.println(" treeId: " + tree.getId() + " --> height: " + tree.getHeight());
//			 }

			double cumulatedLeafArea = 0.0;
			for (HetTree tree : treeList) {
				cumulatedLeafArea += tree.getLeafArea();
				tree.setCumulatedLeafAreasOfSmallerTrees(cumulatedLeafArea);
				//System.out.println("  treeId: " + tree.getId() + " / cumulatedLeafArea: " + cumulatedLeafArea);
			}
		}
		
		//System.out.println("**** DESCENDING ORDER ****");

		// Sorts the trees of each species in descending order of their height. Then, for each tree, calculates 
		// the sum of leaf areas of trees belonging to the same species and that are taller than it. The leaf area 
		// of the considered tree is included in the sum.
		for (int speciesId : speciesIdTreeIdListMap.getKeys()) {

			List<HetTree> treeList = speciesIdTreeIdListMap.get(speciesId);
			Collections.sort(treeList, new TreeHeightComparator(false)); // descending order of height

//			 System.out.println("speciesId: " + speciesId + " --> ");
//			 for (HetTree tree : treeList) {
//				 System.out.println(" treeId: " + tree.getId() + " --> height: " + tree.getHeight());
//			 }

			double cumulatedLeafArea = 0.0;
			for (HetTree tree : treeList) {
				cumulatedLeafArea += tree.getLeafArea();
				tree.setCumulatedLeafAreasOfTallerTrees(cumulatedLeafArea);
				//System.out.println("  treeId: " + tree.getId() + " / cumulatedLeafArea: " + cumulatedLeafArea);
			}
		}

	}
	
	
	@Override
	public HetPlot getPlot() {
		return (HetPlot) super.getPlot();
	} // optional
		// @Override
		// public PlotOfCells getPlot () {return (PlotOfCells) super.getPlot
		// ();} //
		// optional

	@Override
	public HetScene getEvolutionBase() {

		HetScene eb = (HetScene) super.getEvolutionBase(); // calls
		// getLightClone ()

		// fc+mj+fa-28.6.2017 transfer next year pheno into eb
		// e.g. 2001.setPheno (2000.nextPheno)
		eb.setPhenologyMap(this.getPhenologyMapOfNextYear());
		eb.setPhenologyMapOfNextYear(null);

		// fc+mj+fa-29.6.2017 same for vegetation period
		eb.setVegetationPeriod(this.getVegetationPeriodOfNextYear());
		eb.setVegetationPeriodOfNextYear(null);

		// fc-9.5.2017
		Cell c1 = this.getPlot().getCell(1);
		Cell c2 = eb.getPlot().getCell(1);
		if (c1 == c2)
			HetReporter.printInStandardOutput(
					"HetScene getEvolutionBase () WARNING: cell 1 in this.plot and cloned plot is the same object !");

		return eb;

	}

	/**
	 * Clone a HetScene with the super method and, next, add the variable that
	 * are not primitive
	 *
	 * @author gl 23-5-2013
	 */
	public Object clone() {
		try {
			HetScene s = (HetScene) super.clone();

			// copy the sensors that are not primitive
			List<SLSensor> copiedsensors = new ArrayList<SLSensor>();
			if (this.sensors != null) {
				for (SLSensor sensor : this.sensors) {
					SLSensor copiedSensor = sensor.getCopy();
					copiedsensors.add(copiedSensor);
				}
				s.sensors = copiedsensors;
			}

			// fc-7.9.2016 was missing during evolution (warning: soil is
			// optional, depends on user's choice at start time, provides a soil
			// file or not)
			// fc-15.11.2019 Soil if available is now HetSoil or HetDiscreteSoil
			if (this.soil != null)
				s.soil = this.soil.getCopy(); // fc-12.11.2019
			// if (this.soil != null)
			// s.soil = new HetSoil(this.soil);
			
			// fc+fa-21.11.2019 Cache will need recalculation
			s.averageWaterBalanceMapCache = null;
			
			return s;

		} catch (Exception exc) {
			Log.println(Log.ERROR, "HetScene.clone ()", "Exception caught, source scene=" + this, exc);
			return null;
		}
	}

	/**
	 * Returns a complete copy of the HetScene with its trees, soil, horizons,
	 * sensors and water balance list.
	 */
	public HetScene getInterventionBase() { // nb-15.12.2016

		// Copy the GScene containing clones of every tree
		// The super.getInterventionBase() instruction calls the above clone()
		// method
		// which creates a new sensors list and a new soil for the copied scene.
		// So, here,
		// it is not to handle the sensors and the soil.
		HetScene copiedScene = (HetScene) super.getInterventionBase();

		// fc+mj+fa-28.6.2017 transfer pheno and next year pheno into ib
		// e.g. *2002.setNextPheno (2002.nextPheno)
		copiedScene.setPhenologyMapOfNextYear(this.getPhenologyMapOfNextYear());
		copiedScene.setPhenologyMap(this.getPhenologyMap());

		// fc+mj+fa-29.6.2017 same for vegetationPeriod
		copiedScene.setVegetationPeriodOfNextYear(this.getVegetationPeriodOfNextYear());
		copiedScene.setVegetationPeriod(this.getVegetationPeriod());

		// fa-15.11.2019: waterBalanceMap moved to pedon, copy now processed
		// below in pedon loop
		// // Processing with variables of non primitive type
		// copiedScene.waterBalanceMap = new LinkedHashMap<>();
		// for (String key : this.waterBalanceMap.keySet()) {
		// HetWaterBalance refWaterBalance = this.waterBalanceMap.get(key); //
		// fc-20.1.2017
		// // now
		// // a
		// // Map
		// copiedScene.waterBalanceMap.put(key, refWaterBalance.getCopy());
		// }

		// fa-17.09.2019
		copiedScene.hourlyTreeTranspirationMap = new LinkedHashMap<>();
		for (String key : this.hourlyTreeTranspirationMap.keySet()) {
			HetHourlyTreeTranspiration refHourlyTreeTranspiration = this.hourlyTreeTranspirationMap.get(key);
			// now
			// a
			// Map
			copiedScene.hourlyTreeTranspirationMap.put(key, refHourlyTreeTranspiration.getCopy());
		}

		// Processing with variables which value is set to 0 in the HetHorizon
		// per copy constructor.

		// fc-12.11.2019 Added the loop on pedons
		List<Pedon> copiedPedonList = copiedScene.soil.getPedons();
		Map<Integer, Pedon> originalPedonMap = this.soil.getPedonMap();

		// fc-12.11.2019
		for (Pedon copiedPedon : copiedPedonList) {

			// fc-12.11.2019
			Pedon originalPedon = originalPedonMap.get(copiedPedon.getPedonId());
			Map<Integer, HetHorizon> copiedHorizonMap = copiedPedon.getHorizonMap();
			Map<Integer, HetHorizon> originalHorizonMap = originalPedon.getHorizonMap();

			// List<HetHorizon> copiedHorizonList =
			// copiedScene.soil.getHorizons(); // fc-12.11.2019
			for (HetHorizon copiedHorizon : copiedHorizonMap.values()) { // fc-12.11.2019

				// Using the id to identify a horizon
				HetHorizon refHorizon = originalHorizonMap.get(copiedHorizon.id); // fc-12.11.2019

				copiedHorizon.solution_pH = refHorizon.solution_pH;
				copiedHorizon.totalFineRootLength = refHorizon.totalFineRootLength;

				for (String elementName : refHorizon.getSolutionConcentrations().keySet()) {
					double refConcentration = refHorizon.getSolutionConcentration(elementName);
					copiedHorizon.setSolutionConcentration(elementName, refConcentration);
				}

				for (String elementName : refHorizon.getMineralConcentrations().keySet()) {
					double refConcentration = refHorizon.getMineralConcentration(elementName);
					copiedHorizon.setMineralConcentration(elementName, refConcentration);
				}

				for (String elementName : refHorizon.getExchangeableCationConcentrations().keySet()) {
					double refConcentration = refHorizon.getExchCationConcentration(elementName);
					copiedHorizon.setExchCationConcentration(elementName, refConcentration);
				}

				for (String elementName : refHorizon.getExchangeableAnionConcentrations().keySet()) {
					double refConcentration = refHorizon.getExchAnionConcentration(elementName);
					copiedHorizon.setExchAnionConcentration(elementName, refConcentration);
				}

			}

			// fa-15.11.2019
			LinkedHashMap<String, HetWaterBalance> originalWaterBalanceMap = originalPedon.getWaterBalanceMap();
			copiedPedon.setWaterBalanceMap(new LinkedHashMap<>());
			for (String key : originalWaterBalanceMap.keySet()) {
				HetWaterBalance refWaterBalance = originalWaterBalanceMap.get(key);
				copiedPedon.getWaterBalanceMap().put(key, refWaterBalance.getCopy());
			}

		}

		return copiedScene;
	}

	/**
	 * Returns a leaf area development proportion in [0,1] for any given doy in
	 * the year and the given species. If pheno is not found, return 1.
	 */
	// Added phenologyMap argument and removed "OfNextYear" in method's name. nb-18.12.2019
	//@Override
	//public double getLadProportionOfNextYearAtSpeciesLevel(int speciesId, int doy) {
	public double getLadProportionAtSpeciesLevel(int speciesId, int doy, HashMap<Integer,HetPhenology> phenologyMap) {
		// fa+fc-01.08.2017
		// fc+mj-12.9.2017 changed name method: ofNextYear
		if (doy == 366) // leap year
			return 0;

		try {
			
			// We now use phenologyMap argument instead of phenologyMapOfNextYear instance variable. nb-18.12.2019
//			// fc+mj+fa-28.6.2017 refactored, we now return values of next year
//			HetPhenology pheno = phenologyMapOfNextYear.get(speciesId);
//			// HetPhenology pheno = phenologyMap.get(speciesId);
			HetPhenology pheno = phenologyMap.get(speciesId);
			
			if (pheno == null)
				throw new Exception("Error in HetScene " + this
						+ ", getLadProportionAtSpeciesLevel() could not find an HetPhenology for speciesId: "
						+ speciesId);

			return pheno.getLadProportion(doy);

		} catch (Exception e) {
			// fc+mj+fa-31.7.2017 return 1 if no phenology
			// (phenology is optional)
			return 1;
		}
	}

	/**
	 * Returns a leaf area development proportion in [0,1] for any given doy in
	 * the year and the given tree. If pheno is not found, return 1. nb-06.11.2019
	 */
	@Override
	public double getLadProportionOfNextYear(int treeId, int doy) {

		return getLadProportion(treeId, doy, phenologyMapOfNextYear);
	}

	/**
	 * This method is aimed at being called in exports. fc+nb-18.12.2019
	 */
	public double getLadProportion(int treeId, int doy, HashMap<Integer,HetPhenology> phenologyMap) {

		HetTree tree = (HetTree) this.getTree(treeId);
		int speciesId = tree.getSpeciesCode();

		// Calculates ladProp at species level.
		
		// nb-18.12.2019
		//double ladPropSpecies = getLadProportionOfNextYearAtSpeciesLevel(speciesId, doy);
		double ladPropSpecies = getLadProportionAtSpeciesLevel(speciesId, doy, phenologyMap);

		HetPhenologyDate t2a_standBudburstStartingDate = phenologyMap.get(speciesId).getT2a_standBudburstStartingDate();
		HetPhenologyDate t2c_completeLeafDevelopmentDate = phenologyMap.get(speciesId).getT2c_completeLeafDevelopmentDate();
		HetPhenologyDate t5a_fallingStartingDate = phenologyMap.get(speciesId).getT5a_fallingStartingDate();
		HetPhenologyDate t5b_fallingEndingDate = phenologyMap.get(speciesId).getT5b_fallingEndingDate();

		// Calculates ladProp at tree level.
		double ladPropTree = ladPropSpecies;
		
		// The budburst of the smallest trees begins before the one of the tallest.
		if (ip.phenologyAtTreeLevel && doy >= t2a_standBudburstStartingDate.getDoy()
				&& doy <= t2c_completeLeafDevelopmentDate.getDoy()) {

//			if (ladPropSpecies >= tree.getCumulatedLeafAreasOfSmallerTrees() / tree.getSpecies().leafArea_sp) {
			if (ladPropSpecies >= tree.getCumulatedLeafAreasOfSmallerTrees() / this.getSpeciesLeafAreaMap().get(tree.getSpecies().getId())) { // fa-17.12.2019: moved species leaf area from HetSpecies to HetScene
				ladPropTree = 1.0;
			} else {
				ladPropTree = 0.0;
			}
		}

		// The leaves of the tallest trees begin to fall before those of the smallest trees. nb-17.12.2019
		if (ip.phenologyAtTreeLevel && doy >= t5a_fallingStartingDate.getDoy() 
				&& doy <= t5b_fallingEndingDate.getDoy()) {

//			if (1.0-ladPropSpecies >= tree.getCumulatedLeafAreasOfTallerTrees() / tree.getSpecies().leafArea_sp) {
			if (1.0-ladPropSpecies >= tree.getCumulatedLeafAreasOfTallerTrees() / this.getSpeciesLeafAreaMap().get(tree.getSpecies().getId())) { // fa-17.12.2019: moved species leaf area from HetSpecies to HetScene
				ladPropTree = 0.0;
			} else {
				ladPropTree = 1.0;
			}
		}

		return ladPropTree;
	}

	// fa-19.06.2017
	/**
	 * Returns a green leaf proportion in [0,1] for any given doy in the year
	 * and the given species. If pheno is not found, return 1.
	 */
	// Added phenologyMap argument and removed "OfNextYear" in method's name. nb-18.12.2019
	//@Override
	//public double getGreenProportionOfNextYearAtSpeciesLevel(int speciesId, int doy) {
	public double getGreenProportionAtSpeciesLevel(int speciesId, int doy, HashMap<Integer,HetPhenology> phenologyMap) {
		// fa+fc-01.08.2017
		// fc+mj-12.9.2017 changed name method: ofNextYear
		if (doy == 366) // leap year
			return 0;

		try {
			// We now use phenologyMap argument instead of phenologyMapOfNextYear instance variable. nb-18.12.2019
//			// fc+mj+fa-28.6.2017 refactored, we now return values of next year
//			HetPhenology pheno = phenologyMapOfNextYear.get(speciesId);
//			// HetPhenology pheno = phenologyMap.get(speciesId);
			HetPhenology pheno = phenologyMap.get(speciesId);

			if (pheno == null)
				throw new Exception("Error in HetScene " + this
						+ ", getGreenProportionAtSpeciesLevel() could not find an HetPhenology for speciesId: "
						+ speciesId);

			return pheno.getGreenProportion(doy);

		} catch (Exception e) {
			// fc+mj+fa-31.7.2017 return 1 if no phenology
			// (phenology is optional)
			return 1;
		}
	}

	/**
	 * Returns a green leaf proportion in [0,1] for any given doy in
	 * the year and the given tree. If pheno is not found, return 1.
	 * nb-17.12.2019
	 */
	@Override
	public double getGreenProportionOfNextYear(int treeId, int doy) {

		return getGreenProportion(treeId, doy, phenologyMapOfNextYear);
	}

	/**
	 * This method is aimed at being called in exports.
	 */
	// Added phenologyMap argument and removed "OfNextYear" in method's name. nb-18.12.2019
	//public double getGreenProportionOfNextYear(int treeId, int doy) {
	public double getGreenProportion(int treeId, int doy, HashMap<Integer,HetPhenology> phenologyMap) {
			
		HetTree tree = (HetTree) this.getTree(treeId);
		int speciesId = tree.getSpeciesCode();

		// Calculates greenProp at species level.		
		//double greenPropSpecies = getGreenProportionOfNextYearAtSpeciesLevel(speciesId, doy); nb-18.12.2019
		double greenPropSpecies = getGreenProportionAtSpeciesLevel(speciesId, doy, phenologyMap);

		HetPhenologyDate t2a_standBudburstStartingDate = phenologyMap.get(speciesId).getT2a_standBudburstStartingDate();
		HetPhenologyDate t2c_completeLeafDevelopmentDate = phenologyMap.get(speciesId).getT2c_completeLeafDevelopmentDate();
		HetPhenologyDate t4a_yellowingStartingDate = phenologyMap.get(speciesId).getT4a_yellowingStartingDate();
		HetPhenologyDate t4b_yellowingEndingDate = phenologyMap.get(speciesId).getT4b_yellowingEndingDate();

		// Calculates greenProp at tree level
		double greenPropTree = greenPropSpecies;

		// The budburst of the smallest trees begins before the one of the tallest. mj+fa+nb-18.12.2019
		if (ip.phenologyAtTreeLevel && doy >= t2a_standBudburstStartingDate.getDoy()
				&& doy <= t2c_completeLeafDevelopmentDate.getDoy()) {

//			if (ladPropSpecies >= tree.getCumulatedLeafAreasOfSmallerTrees() / tree.getSpecies().leafArea_sp) {
			if (greenPropSpecies >= tree.getCumulatedLeafAreasOfSmallerTrees() / this.getSpeciesLeafAreaMap().get(tree.getSpecies().getId())) { // fa-17.12.2019: moved species leaf area from HetSpecies to HetScene
				greenPropTree = 1.0;
			} else {
				greenPropTree = 0.0;
			}
		}

		// The yellowing of the tallest trees begins before the one of the smallest.
		if (ip.phenologyAtTreeLevel && doy >= t4a_yellowingStartingDate.getDoy() && doy <= t4b_yellowingEndingDate.getDoy()) {

//			if (1.0-greenPropSpecies >= tree.getCumulatedLeafAreasOfTallerTrees() / tree.getSpecies().leafArea_sp) {
			if (1.0-greenPropSpecies >= tree.getCumulatedLeafAreasOfTallerTrees() / this.getSpeciesLeafAreaMap().get(tree.getSpecies().getId())) { // fa-17.12.2019: moved species leaf area from HetSpecies to HetScene
				greenPropTree = 0.0;
			} else {
				greenPropTree = 1.0;
			}
		}

		return greenPropTree;
	}

	// public List<Vertex2d> getMainRectangle () { //GL 8/3/13
	// return mainRectangle;
	// }

	// public void setMainRectangle (List<Vertex2d> mainRectangle) { //GL 8/3/13
	// this.mainRectangle = mainRectangle;
	//
	// for (Iterator i = mainRectangle.iterator (); i.hasNext ();) {
	// Vertex2d v = (Vertex2d) i.next ();
	// System.out.println ("HetScene mainRectangle: "+v);
	// }
	//
	// }

	// Accessors
	public void addSensor(SLSensor sensor) {
		if (sensors == null) {
			sensors = new ArrayList<SLSensor>();
		}
		sensors.add(sensor);
	}

	public List<SLSensor> getSensors() {
		return sensors;
	}

	public double getNAvailable_kg() {
		return NAvailable_kg;
	}

	public void setNAvailable_kg(double nAvailable_kg) {
		NAvailable_kg = nAvailable_kg;
	}

	public double getNStandUptake() {
		return NStandUptake;
	}

	public void setNStandUptake(double nStandUptake) {
		NStandUptake = nStandUptake;
	}

	public double getNStandOptimalUptake() {
		return NStandOptimalUptake;
	}

	public void setNStandOptimalUptake(double nStandOptimalUptake) {
		NStandOptimalUptake = nStandOptimalUptake;
	}

	@Override
	public String toString() {
		return "HetScene_" + getCaption();
	}

	@Override
	public List<SquareCell> getCellstoEnlight() {
		return null;
	}

	public void setSoil(HetSoilInterface soil) {
		this.soil = soil;
	}

	public HetSoilInterface getSoil() {
		return soil;
	}

	// fc+mj+lw-8.9.2016
	public boolean isSoilHorizonsAvailable() {
		// soil is optional
		// soil may be null, or it may contain only horizons without chemistry
		try {
			// If we can find a NON empty solution concentration map in 1st
			// horizon, chemistry was loaded
			return soil.getHorizonSpecimen() != null; // fc-12.11.2019
			// return soil.getHorizon(1) != null;

		} catch (Exception e) {
			// if soil is null, no 1st horizon found... no horizons
			return false;
		}
	}

	// fc+mj+lw-8.9.2016
	public boolean isSoilChemistryAvailable() {
		// soil is optional
		// soil may be null, or it may contain only horizons without chemistry
		try {
			// If we can find a NON empty solution concentration map in 1st
			// horizon, chemistry was loaded
			return !soil.getHorizonSpecimen().getSolutionConcentrations().isEmpty(); // fc-12.11.2019
			// return !soil.getHorizon(1).getSolutionConcentrations().isEmpty();

		} catch (Exception e) {
			// if soil is null, no 1st horizon found... no chemistry
			return false;
		}
	}

	public void updateHorizonFineRootLengths() {
		if (soil == null)
			return;

		// 1. Provides fineRootLengths within each horizon of each pedon
		// fc-12.11.2019 Added the loop on pedons
		for (Pedon p : soil.getPedons()) {

			for (HetHorizon h : p.getHorizons()) {
				h.totalFineRootLength = 0;
				
//				for (Tree tree : getTrees()) {
				for (Tree tree : p.getTrees(this)) {	// fa+mj-20.11.2019
					HetTree t = (HetTree) tree;
					double horizonFineRootLength = h.fineRootProportion * t.getFineRootLength();
					h.totalFineRootLength += horizonFineRootLength;
				}
			}
		}
		
		// fa-20.11.2019
		// Aggregate totalFineRootLength in each horizon for the scene
		for (Pedon p : soil.getPedons()) {
			for (int hId : p.getHorizonMap().keySet()) {			
				addInMap(horizonTotalFineRootLengthMap, hId, p.getHorizon(hId).totalFineRootLength);
			}
		}

	}

	public HetElementState getLitterNutrientReturn() {
		// Estimate exchangeable stocks per soil horizon
		HetElementState standLitterNutrientReturn = new HetElementState();
		// We do not consider here the trees cut by an intervener extension
		List<Tree> list = new ArrayList<>(this.getTrees());
		list.addAll(this.getTrees("dead"));
		list.addAll(this.getTrees("cut"));

		for (Tree t : list) {
			HetTree refTree = (HetTree) t;

			for (HetLitterCompartment lc : refTree.getLitterCompartments()) {

				for (String eName : HetTreeElement.elementNames) {
					double value = lc.getNutrientFlux(eName);

					standLitterNutrientReturn.addValue(eName, value);

				}
			}
		}

		return standLitterNutrientReturn;
	}

	public double[] getDailyGPP_kgC() {
		return dailyGPP_kgC;
	}

	public void setDailyGPP_kgC(double[] dailyGPP_kgC) {
		this.dailyGPP_kgC = dailyGPP_kgC;
	}

	public double[] getDailyMaintenanceLeafRespiration_kgC() {
		return dailyMaintenanceLeafRespiration_kgC;
	}

	public void setDailyMaintenanceLeafRespiration_kgC(double[] dailyMaintenanceLeafRespiration_kgC) {
		this.dailyMaintenanceLeafRespiration_kgC = dailyMaintenanceLeafRespiration_kgC;
	}

	public double getBarkAbsorbedRadiation() {
		return barkAbsorbedRadiation;
	}

	public void setBarkAbsorbedRadiation(double barkAbsorbedRadiation) {
		this.barkAbsorbedRadiation = barkAbsorbedRadiation;
	}

	public double getBarkAbsorbedDirectRadiation() {
		return barkAbsorbedDirectRadiation;
	}

	public void setBarkAbsorbedDirectRadiation(double barkAbsorbedDirectRadiation) {
		this.barkAbsorbedDirectRadiation = barkAbsorbedDirectRadiation;
	}

	public double getBarkAbsorbedDiffuseRadiation() {
		return barkAbsorbedDiffuseRadiation;
	}

	public void setBarkAbsorbedDiffuseRadiation(double barkAbsorbedDiffuseRadiation) {
		this.barkAbsorbedDiffuseRadiation = barkAbsorbedDiffuseRadiation;
	}

	public double getStandIncidentGlobalRadiation() {
		return standIncidentGlobalRadiation;
	}

	public void setStandIncidentGlobalRadiation(double standIncidentGlobalRadiation) {
		this.standIncidentGlobalRadiation = standIncidentGlobalRadiation;
	}

	public void setStandIncidentDirectRadiation(double standIncidentDirectRadiation) {
		this.standIncidentDirectRadiation = standIncidentDirectRadiation;
	}

	public double getStandIncidentDirectRadiation() {
		return standIncidentDirectRadiation;
	}

	public void setStandIncidentDiffuseRadiation(double standIncidentDiffuseRadiation) {
		this.standIncidentDiffuseRadiation = standIncidentDiffuseRadiation;
	}

	public double getStandIncidentDiffuseRadiation() {
		return standIncidentDiffuseRadiation;
	}

	// Year pheno
	public HashMap<Integer, HetPhenology> getPhenologyMap() {
		return phenologyMap;
	}

	public void setPhenologyMap(HashMap<Integer, HetPhenology> phenologyMap) {
		this.phenologyMap = phenologyMap;
	}

	// fc+mj+fa-28.6.2017 added next year pheno
	// pheno of year y is now calc at year y - 1 and stored in
	// phenologyMapOfNextYear
	public HashMap<Integer, HetPhenology> getPhenologyMapOfNextYear() {
		return phenologyMapOfNextYear;
	}

	public void setPhenologyMapOfNextYear(HashMap<Integer, HetPhenology> nextYearPhenologyMap) {
		this.phenologyMapOfNextYear = nextYearPhenologyMap;
	}

	public void setGrossPrimaryProduction_gC_m2(double grossPrimaryProduction_gC_m2) {
		this.grossPrimaryProduction_gC_m2 = grossPrimaryProduction_gC_m2;
	}

	public double getGrossPrimaryProduction_gC_m2() {
		return grossPrimaryProduction_gC_m2;
	}

	public void setNetPrimaryProduction_gC_m2(double netPrimaryProduction_gC_m2) {
		this.netPrimaryProduction_gC_m2 = netPrimaryProduction_gC_m2;
	}

	public double getNetPrimaryProduction_gC_m2() {
		return netPrimaryProduction_gC_m2;
	}

	public double getRegenerationGrossPrimaryProduction_gC_m2() {
		return regenerationGrossPrimaryProduction_gC_m2;
	}

	public void setRegenerationGrossPrimaryProduction_gC_m2(double regenerationGrossPrimaryProduction_gC_m2) {
		this.regenerationGrossPrimaryProduction_gC_m2 = regenerationGrossPrimaryProduction_gC_m2;
	}

	public double getRegenerationNetPrimaryProduction_gC_m2() {
		return regenerationNetPrimaryProduction_gC_m2;
	}

	public void setRegenerationNetPrimaryProduction_gC_m2(double regenerationNetPrimaryProduction_gC_m2) {
		this.regenerationNetPrimaryProduction_gC_m2 = regenerationNetPrimaryProduction_gC_m2;
	}

	public void setMaintenanceRespiration_gC_m2(double maintenanceRespiration_gC_m2) {
		this.maintenanceRespiration_gC_m2 = maintenanceRespiration_gC_m2;
	}

	public double getMaintenanceRespiration_gC_m2() {
		return maintenanceRespiration_gC_m2;
	}

	public void setRetranslocation_gC_m2(double retranslocation_gC_m2) {
		this.retranslocation_gC_m2 = retranslocation_gC_m2;
	}

	public double getRetranslocation_gC_m2() {
		return retranslocation_gC_m2;
	}

	public void setVegetationPeriod(HetVegetationPeriod vegetationPeriod) {
		this.vegetationPeriod = vegetationPeriod;
	}

	public HetVegetationPeriod getVegetationPeriod() {
		return vegetationPeriod;
	}

	public void setVegetationPeriodOfNextYear(HetVegetationPeriod vegetationPeriodOfNextYear) {
		this.vegetationPeriodOfNextYear = vegetationPeriodOfNextYear;
	}

	public HetVegetationPeriod getVegetationPeriodOfNextYear() {
		return vegetationPeriodOfNextYear;
	}

	// fa-5.7.2017
	public void setCurrentVegetationPeriodLength(int currentVegetationPeriodLength) {
		this.currentVegetationPeriodLength = currentVegetationPeriodLength;
	}

	public int getCurrentVegetationPeriodLength() {
		return currentVegetationPeriodLength;
	}

	public void setRefVegetationPeriodLength(int refVegetationPeriodLength) {
		this.refVegetationPeriodLength = refVegetationPeriodLength;
	}

	public int getRefVegetationPeriodLength() {
		return refVegetationPeriodLength;
	}

	// fa-6.7.2017
	public void setNextYearVegetationPeriodLength(int nextYearVegetationPeriodLength) {
		this.nextYearVegetationPeriodLength = nextYearVegetationPeriodLength;
	}

	public int getNextYearVegetationPeriodLength() {
		return nextYearVegetationPeriodLength;
	}

	// mj+fa-20.09.2017
	public void setCrownProjectionSum_stand(double crownProjectionSum_stand) {
		this.crownProjectionSum_stand = crownProjectionSum_stand;
	}

	public double getCrownProjectionSum_stand() {
		return crownProjectionSum_stand;
	}

	//
	// /**
	// * Check if the given doy is in vegetation period. In FineResolutionMode,
	// * check in the scene's HetVegetationPeriod (null if not fineResolution),
	// * otherwise, check in the SamsaraLight model
	// */
	// public boolean isVegetationPeriod(HetVegetationPeriod vegetationPeriod,
	// HetSamsaFileLoader samsaFileLoader, int doy) {
	//
	// // fc+fa-18.5.2017
	// if (vegetationPeriod != null)
	// return vegetationPeriod.isVegetationPeriod(doy);
	// else
	// return samsaFileLoader.isVegetationPeriod(doy);
	//
	// }

	// fc+fa-04.08.2017: optimized tag mode
	public void setBeamSetFactory(HetBeamSetFactoryOptimized beamSetFactory) {
		this.beamSetFactory = beamSetFactory;
	}

	// fc+fa-04.08.2017: optimized tag mode
	public HetBeamSetFactoryOptimized getBeamSetFactory() {
		return beamSetFactory;
	}

	// fa-09.08.2017: for non-optimized tag mode
	// public void setBeamSetFactory(HetBeamSetFactory beamSetFactory) {
	// this.beamSetFactory = beamSetFactory;
	// }

	// fa-09.08.2017: for non-optimized tag mode
	// public HetBeamSetFactory getBeamSetFactory() {
	// return beamSetFactory;
	// }

	// private HashMap<String, Double> q10SumMap;
	// private HashMap<Integer, Double> q10SumMapLeaf;
	// private HashMap<Integer, Double> q10SumMapFineRoot;

	// fa-06.03.2018
	public void setQ10SumMap(HashMap<String, Double> q10SumMap) {
		this.q10SumMap = q10SumMap;
	}

	// fa-06.03.2018
	public HashMap<String, Double> getQ10SumMap() {
		return q10SumMap;
	}

	// fa-06.03.2018
	public void setQ10SumMapLeaf(HashMap<Integer, Double> q10SumMapLeaf) {
		this.q10SumMapLeaf = q10SumMapLeaf;
	}

	// fa-06.03.2018
	public HashMap<Integer, Double> getQ10SumMapLeaf() {
		return q10SumMapLeaf;
	}

	// fa-06.03.2018
	public void setQ10SumMapFineRoot(HashMap<Integer, Double> q10SumMapFineRoot) {
		this.q10SumMapFineRoot = q10SumMapFineRoot;
	}

	// fa-06.03.2018
	public HashMap<Integer, Double> getQ10SumMapFineRoot() {
		return q10SumMapFineRoot;
	}

	// fa+mj-20.03.2018
	public void setMeanUpperCrownHeightMap(HashMap<Integer, Double> meanUpperCrownHeightMap) {
		this.meanUpperCrownHeightMap = meanUpperCrownHeightMap;
	}

	// fa+mj-20.03.2018
	public HashMap<Integer, Double> getMeanUpperCrownHeightMap() {
		return meanUpperCrownHeightMap;
	}

	// fa+mj-20.03.2018
	public void setMeanLowerCrownHeightMap(HashMap<Integer, Double> meanLowerCrownHeightMap) {
		this.meanLowerCrownHeightMap = meanLowerCrownHeightMap;
	}

	// fa+mj-20.03.2018
	public HashMap<Integer, Double> getMeanLowerCrownHeightMap() {
		return meanLowerCrownHeightMap;
	}
	
	// fa-20.11.2019
	public HashMap<Integer, Double> getHorizonTotalFineRootLengthMap() {
		return horizonTotalFineRootLengthMap;
	}

	public void setHorizonTotalFineRootLengthMap(HashMap<Integer, Double> horizonTotalFineRootLengthMap) {
		this.horizonTotalFineRootLengthMap = horizonTotalFineRootLengthMap;
	}
	
	// fa-17.12.2019
	public HashMap<Integer, Double> getSpeciesLeafAreaMap() {
		return speciesLeafAreaMap;
	}
		
	public void setSpeciesLeafAreaMap(HashMap<Integer, Double> speciesLeafAreaMap) {
		this.speciesLeafAreaMap = speciesLeafAreaMap;
	}

	// fc-19.11.2019 REMOVED, see new getWaterBalanceMap() below
//	/**
//	 * Returns the waterBalanceMap in the HetSoil or an average waterBalanceMap
//	 * in the HetDiscreteSoil.
//	 */
//	public LinkedHashMap<String, HetWaterBalance> getDefaultWaterBalanceMap() {
//
//		// fc-19.11.2019 (a bit later)
//		// Also works for a HetDiscreteSoil, relies on average waterBalanceMaps
//		return getWaterBalanceMap();
//
//		// // fc+mj+fa-19.11.2019 Works only for an HetSoil, more work to be
//		// done
//		// // for a HetDiscreteSoil (the waterBalanceMap should not be asked to
//		// // HetScene in this case).
//		//
//		// if (!soil.isDiscreteSoil()) {
//		// return soil.getPedonSpecimen().getWaterBalanceMap();
//		// } else {
//		// return null;
//		// }
//
//	}
	
	/**
	 * The waterBalanceMap at the scene level is sometimes an average of the
	 * waterBalanceMaps in the soil pedons
	 */
	public LinkedHashMap<String, HetWaterBalance> getWaterBalanceMap() {

		// fc+mj+fa-19.11.2019
//		if (soil instanceof HetSoil) { // fa-19.11.2019: problem with this line, returns TRUE even in case of discrete water balance (=> soil should be instanceof HetDiscreteSoil)
//		if (!ip.waterBalance_fineResolutionActivated) { // fa-19.11.2019: temporary, to replace condition on previous line
		if (!soil.isDiscreteSoil()) { // fa-19.11.2019: temporary, to replace condition on previous line
			return soil.getPedonSpecimen().getWaterBalanceMap();
		} else {
			// HetDiscreteSoil
			
			// fc+fa-21.11.209 Added a cache to avoid re-averaging
			if (averageWaterBalanceMapCache == null)
				averageWaterBalanceMapCache = Pedon.averageWaterBalanceMaps(soil.getPedons());
			
			return averageWaterBalanceMapCache;
		}

	}
	
	// fa-20.11.2019
	private void addInMap(HashMap<Integer, Double> map, int hId, double value) {
		double sum = 0;
		Double v = map.get(hId);
		if (v != null)
			sum = v;
		sum += value;
		map.put(hId, sum);

	}


}
