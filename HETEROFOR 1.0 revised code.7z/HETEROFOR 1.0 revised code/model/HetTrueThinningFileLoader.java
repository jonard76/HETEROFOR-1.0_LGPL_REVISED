/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import jeeb.lib.util.Record;
import jeeb.lib.util.fileloader.FileLoader;

/**
 * A file loader for a true thinning file
 *
 * @author F. de Coligny - April 2015
 */
public class HetTrueThinningFileLoader extends FileLoader {

	public List<Line> lines;

	@Override
	protected void checks() throws Exception {
		// Each treeId must be found only once in the file
		Set<Integer> treeIds = new HashSet<Integer> ();
		for (Line l : lines) {
			if (treeIds.contains(l.treeId))
				throw new Exception ("Error in file: found a treeId several times: "+l.treeId);
		}

	}

	/**
	 * A line in the input file
	 */
	static public class Line extends Record {

		public int treeId;
		public int lastYear;

		/**
		 * Constructor (super constructor is automatic, based on introspection).
		 *
		 * @param line
		 *            : the line to be turned into a Line object
		 * @throws Exception
		 *             : if the line format does not match a Line
		 */
		public Line(String line) throws Exception {
			super(line);
		}

	}

	/**
	 * Constructor
	 */
	public HetTrueThinningFileLoader() throws Exception {
		super ();
	}

}
