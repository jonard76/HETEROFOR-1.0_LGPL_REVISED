/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.soil;

import heterofor.model.HetReporter;

/**
 * The Mualem-van Genuchten function computes hydraulic conductivity based on
 * soil water content.
 *
 * @author M. Jonard, Louis de Wergifoose, F. de Coligny - October 2016
 */
public class HetMualemVanGenuchten {

	private HetHorizon horizon;
	private HetHydraulicPedotransferParameters params;
	private double prevWaterContent;

	/**
	 * Constructor
	 */
	public HetMualemVanGenuchten(HetHorizon horizon, HetHydraulicPedotransferParameters params, double prevWaterContent) {
		this.horizon = horizon;
		this.params = params;
		this.prevWaterContent = prevWaterContent;
	}

	public double execute() {

		double relativeSaturation = (prevWaterContent - params.residualWaterContent)
				/ (params.saturatedWaterContent - params.residualWaterContent);

		//mj+fa-02.10.2017
		relativeSaturation = Math.min(1d, relativeSaturation);
//		relativeSaturation = Math.max(0d, relativeSaturation);
		relativeSaturation = Math.max(0.00000000001, relativeSaturation); // 0.00000000001 to be just above 0, otherwise below 'K' will be Infinity with lambda negative

		double m = 1d - 1d / params.n;

		double a = 1d - Math.pow(relativeSaturation, params.n / (params.n - 1));
		double b = 1d - Math.pow (a, m);
		double K = params.K0 * Math.pow(relativeSaturation, params.lambda) * b * b;

		if (Double.isNaN(K))
			HetReporter.printInStandardOutput("HetMualemVanGenuchten, relativeSaturation= " + relativeSaturation + ", K= " + K + ", a= " + a + ", b=" + b + ", lambda= " + params.lambda);

		return K;

	}

}
