package heterofor.model.soil;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import heterofor.model.HetElementState;
import heterofor.model.HetScene;
import heterofor.model.meteorology.HetMeteorology;
import heterofor.model.waterbalance.pedon.Pedon;

/**
 * An interface for soils in Heterofor
 *
 * @author F. de Coligny - November 2019
 */
public interface HetSoilInterface extends Serializable {

	public static final double NOT_SET = -999.0;

	// ---- Pedons specific methods

	/**
	 * Returns all the pedons in this soil in a generic way (HetSoil has a
	 * single Pedon, HetDiscreteSoil has several pedons).
	 */
	public List<Pedon> getPedons();

	/**
	 * Returns the pedons (soil blocks made of horizons) in this soil in a map
	 * which key is the pedon id.
	 */
	public Map<Integer, Pedon> getPedonMap();

	/**
	 * Returns some pedon found in the soil (can be used to get size and numbers
	 * shared by all pedons in a soil)
	 */
	public Pedon getPedonSpecimen();

	/**
	 * Returns some horizon found in a pedon in the soil
	 */
	public HetHorizon getHorizonSpecimen();

	/**
	 * Called at pedons construction time (and each year to reinit), updates the
	 * list of pedons in the soil.
	 */
	public void updatePedonList(HetScene scene) throws Exception;
	
	/**
	 * Called at pedons construction time (and each year to reinit), updates the
	 * pedon properties (area...).
	 */
	public void updatePedonProperties(HetScene scene) throws Exception;

	/**
	 * Returns true if soil instanceof HetDiscreteSoil, false otherwise.
	 */
	public boolean isDiscreteSoil (); // fc+fa-21.11.2019
	
	// ----- Other soil methods

	/**
	 * Returns a copy of the soil object
	 */
	public HetSoilInterface getCopy();

	/**
	 * Calculate the thickness of the organic layer
	 */
	public double calculateOrganicLayerThickness();

	/**
	 * Calculates and returns the bulk density of the organic layer. It is equal
	 * to the average bulk density over the organic horizons.
	 */
	public double calculateOrganicLayerBulkDensity();

	/**
	 * Returns the soil's depth.
	 */
	public double calculateDepth();

	/**
	 * Calculates and returns soil temperature at interface between organic and
	 * mineral horizons.
	 * 
	 * @param meteorology:
	 *            Meteorological lines
	 * @param year:
	 *            Year considered for computations
	 * @param dayWindowWidth:
	 *            Number of meteorological lines (hours) to be considered in the
	 *            moving average time window accounting for intra-day
	 *            temperature variations
	 * @param organicLayerThickness:
	 *            Thickness of the organic layers (m)
	 * @return An ordered map with key: year_month_day_hour string and value:
	 *         the temperature at the interface between organic and mineral soil
	 *         horizons
	 * @throws Exception
	 */
	public void calculateSoilInterfaceTemperature(HetMeteorology meteorology, int year, int dayWindowWidth,
			double organicLayerThickness, LinkedHashMap<String, Double> dateAverageAirTemperatureOverPrecedingPeriodMap)
			throws Exception;

	// fc-13.11.2019 This static method can be found in HetSoil
	// -> static not in the interface
	// static public double
	// calculatePreciseMaxAirTemperatureIndex(ArrayList<HetMeteoLine>
	// meteoLinesWindow,
	// int maxWindowIndex, ArrayList<Integer> meteoLinesWindowGeneralIndex,
	// double maxTemp)

	// fc-15.11.2019 MOVED to Pedon
//	public Map<Integer, Double> getLastWaterContent();

	public HetElementState getNutrientDeposition();

	public double getMinSoilSurfaceConductance();

	public void setMinSoilSurfaceConductance(double minSoilSurfaceConductance);

	public double getMaxSoilSurfaceConductance();

	public void setMaxSoilSurfaceConductance(double maxSoilSurfaceConductance);

	public double getCompensatoryEffectConductance();

	public void setCompensatoryEffectConductance(double compensatoryEffectConductance);

	public double getPreferentialFlowProportion();

	public void setPreferentialFlowProportion(double preferentialFlowProportion);

	public void setOrganicLayerThickness(double organicLayerThickness);

	public double getOrganicLayerThickness();

	public void setOrganicLayerBulkDensity(double organicLayerBulkDensity);

	public double getOrganicLayerBulkDensity();

	public Map<String, Double> getOrganicLayerHeatFluxMap();

	public LinkedHashMap<String, Double> getSoilInterfaceTemperatureMap();

	public Map<String, Double> getSoilBottomTemperatureMap();

//	public Map<String, Double> getTimeAverageThermalDiffusivityMap(); // fa-20.11.2019: commented, MOVED to Pedon

	// fc-13.11.2019 These methods are not in the interface, they are in Pedon
	// (and in HetSoil which contains itself as a single Pedon)
	// public void addHorizon(HetHorizon h);
	// public boolean isLowestHorizon(int hId);
	// public List<HetHorizon> getHorizons();
	// public Map<Integer, HetHorizon> getHorizonMap()
	// public HetHorizon getHorizon(int id)

}
