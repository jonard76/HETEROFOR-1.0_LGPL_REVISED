/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.soil;

/**
 * The van Genuchten function computes water content from matric potential (cm).
 *
 * @author M. Jonard, Louis de Wergifosse, F. de Coligny - October 2016
 */
public class HetVanGenuchten {

	private HetHorizon horizon;
	private HetHydraulicPedotransferParameters params;
	private double matricPotential;

	/**
	 * Constructor
	 */
	public HetVanGenuchten(HetHorizon horizon, HetHydraulicPedotransferParameters params, double matricPotential) {
		this.horizon = horizon;
		this.params = params;
		this.matricPotential = matricPotential;
	}

	public double execute() {

		double m = 1d - 1d / params.n;

		double a = Math.pow(params.alpha * Math.abs(matricPotential), params.n);

		double relativeSaturation = Math.pow(1d + a, -m);

		double waterContent = params.residualWaterContent
				+ (params.saturatedWaterContent - params.residualWaterContent) * relativeSaturation;

		return waterContent;

	}

}
