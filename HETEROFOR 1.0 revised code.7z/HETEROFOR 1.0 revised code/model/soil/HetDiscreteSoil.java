package heterofor.model.soil;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import capsis.defaulttype.Tree;
import heterofor.model.HetScene;
import heterofor.model.HetTree;
import heterofor.model.waterbalance.pedon.Pedon;
import heterofor.model.waterbalance.pedon.RemainingPedon;
import heterofor.model.waterbalance.pedon.TreePedon;
import jeeb.lib.util.Log;

/**
 * A soil with a map of pedons for each tree and a remaining pedon.
 * 
 * @author F. de Coligny - November 2019
 */
public class HetDiscreteSoil extends HetSoil implements HetSoilInterface, Serializable {

	// fc-12.11.2019
	// Note: treePedons should contain a pedon for each tree in the scene and
	// remainingPedon should not be null

	// Key is the treeId
	private Map<Integer, TreePedon> treePedons;

	private RemainingPedon remainingPedon;

	/**
	 * Constructor
	 */
	public HetDiscreteSoil() {

		super();

		treePedons = new HashMap<>();

		// Done in HetSoil superclass
		// nutrientDeposition = new HetElementState(); // Read in soil file
		// organicLayerHeatFluxMap = new HashMap<String, Double>();
		// soilInterfaceTemperatureMap = new LinkedHashMap<String, Double>(); //
		// fa-25.07.2017
		// soilBottomTemperatureMap = new HashMap<String, Double>();

	}

	/**
	 * Copy constructor
	 */
	public HetDiscreteSoil(HetDiscreteSoil o) {
		super(o);

		treePedons = new HashMap<>();

		for (int treeId : o.treePedons.keySet()) {
			this.addTreePedon(o.treePedons.get(treeId).getPedonCopy());
		}

		this.setRemainingPedon(o.remainingPedon.getPedonCopy());
		// this.maxHorizonId = o.maxHorizonId;

		// Done in HetSoil superclass
		// this.nutrientDeposition = o.getNutrientDeposition().getCopy();
		// this.minSoilSurfaceConductance = o.minSoilSurfaceConductance;
		// this.maxSoilSurfaceConductance = o.maxSoilSurfaceConductance;
		// this.compensatoryEffectConductance = o.compensatoryEffectConductance;
		// // fc+mj-14.9.2017
		// this.preferentialFlowProportion = o.preferentialFlowProportion; //
		// fa-29.9.2017
		// this.organicLayerThickness = o.organicLayerThickness;
		// this.organicLayerBulkDensity = o.organicLayerBulkDensity;

	}

	public void addTreePedon(TreePedon tp) {
		treePedons.put(tp.getPedonId(), tp);
	}

	/**
	 * Returns the tree pedon for the given tree id or null if not found.
	 */
	public TreePedon getTreePedon(int treeId) {
		return treePedons.get(treeId);
	}

	public RemainingPedon getRemainingPedon() {
		return remainingPedon;
	}

	public void setRemainingPedon(RemainingPedon remainingPedon) {
		this.remainingPedon = remainingPedon;
	}

	// -- HetAbstractSoil methods

	/**
	 * Returns all the pedons in this soil in a generic way (HetDiscreteSoil has
	 * several pedons).
	 */
	@Override
	public List<Pedon> getPedons() {
		List<Pedon> list = new ArrayList<>();
		list.addAll(treePedons.values());
		list.add(remainingPedon);
		return list;
	}

	/**
	 * Returns the pedons (soil blocks made of horizons) in this soil in a map
	 * which key is the pedon id.
	 */
	@Override
	public Map<Integer, Pedon> getPedonMap() {
		Map<Integer, Pedon> map = new HashMap<>();
		for (Pedon p : getPedons()) {
			map.put(p.getPedonId(), p);
		}

		return map;
	}

	/**
	 * Returns the first pedon found in the soil
	 */
	@Override
	public Pedon getPedonSpecimen() {

		Pedon pedonSpecimen = null;

//		if (remainingPedon != null)
		if (remainingPedon != null && remainingPedon.getPedonArea() != 0) // fa-25.11.2019: remainingPedons with area equals to zero are not processed
			pedonSpecimen = remainingPedon;

		if (pedonSpecimen == null)
			if (!treePedons.isEmpty())
				pedonSpecimen = treePedons.values().iterator().next(); // 1st in
																		// map
		return pedonSpecimen;

	}

	/**
	 * Returns the first horizon found in the soil
	 */
	@Override
	public HetHorizon getHorizonSpecimen() {
		try {
			return getPedonSpecimen().getHorizons().get(0);
		} catch (Exception e) {
			return null; // no pedon found -> null
		}
	}

	/**
	 * Returns true if soil instanceof HetDiscreteSoil, false otherwise.
	 */
	public boolean isDiscreteSoil () { // fc+fa-21.11.2019
		return true;
	}

	// fc-15.11.2019 MOVED into updatePedons ()
	/**
	 * Creates one treePedon for each tree in the stand + one remainingPedon.
	 */
	// public HetDiscreteSoil createPedons(HetScene scene) {
	//
	// // fc-13.11.2019 Note
	// // Here, we should deal with pedon surface
	//
	// System.out.println("HetDiscreteSoil.createPedons () #trees: " +
	// scene.getTrees().size());
	//
	// for (Tree t : scene.getTrees()) {
	// TreePedon tp = new TreePedon(t.getId());
	// addTreePedon(tp);
	//
	// }
	//
	// // fc-13.11.2019 Note
	// // Here, we should deal with pedon surface
	// setRemainingPedon(new RemainingPedon());
	//
	// return this;
	// }

	/**
	 * Called at pedons construction time (and each year to reinit), updates the
	 * list of pedons in the soil.
	 */
	@Override
	public void updatePedonList(HetScene scene) throws Exception {
		
		System.out.println();
		System.out.println("[HetDiscreteSoil] entering updatePedonList()... scene date: "+scene.getDate ());
		System.out.println("[HetDiscreteSoil] #trees: "+scene.getTrees().size ());
		System.out.println("[HetDiscreteSoil] #treePedons: "+treePedons.size ());
			
		// First call: creates the pedons, next calls: updates the tree pedon
		// list according to the trees in the scene (there may be new and
		// missing trees due to regeneration and mortality...)

		int k = 0;
		for (Tree t : scene.getTrees()) {

			int treeId = t.getId();

			// Add missing treePedons
			if (getTreePedon(treeId) == null) {
				TreePedon tp = new TreePedon(t.getId());
				addTreePedon(tp);
				k++;
			}

		}

		System.out.println("[HetDiscreteSoil] #created TreePedons: "+k);
		
		// Check if treePedons for trees which have disappeared should be
		// removed
		int nTrees = scene.getTrees().size();
		int nTreePedons = treePedons.size();
		
		k = 0;
		if (nTrees != nTreePedons) {
			Set sceneTreeIds = new HashSet(scene.getTreeIds());

			// We make a copy HashSet to avoid conurrency exception
			for (int pedonId : new HashSet<>(treePedons.keySet())) {
				if (!(sceneTreeIds.contains(pedonId))) {
					treePedons.remove(pedonId);
					k++;
				}
			}

		}

		System.out.println("[HetDiscreteSoil] #removed TreePedons: "+k);

		nTrees = scene.getTrees().size();
		nTreePedons = treePedons.size();

		if (nTrees != nTreePedons) {
			Log.println(Log.ERROR, "HetDiscreteSoil.updatePedons ()",
					"Error in updatePedons (), nTrees (" + nTrees + ") != nTreePedons (" + nTreePedons + ")");
			throw new Exception(
					"HetDiscreteSoil.updatePedons () nTrees (" + nTrees + ") != nTreePedons (" + nTreePedons + ")");
		}

		System.out.println("[HetDiscreteSoil] in the end, #trees: "+nTrees+", #treePedons: "+nTreePedons);
		
		if (remainingPedon == null)
			setRemainingPedon(new RemainingPedon());
		
		System.out.println("[HetDiscreteSoil] ...exiting updatePedonList()");
		System.out.println();
	}

	/**
	 * Called at pedons construction time (and each year to reinit), updates the
	 * pedon properties (area...).
	 */
	@Override
	public void updatePedonProperties(HetScene scene) throws Exception {

		// Pedons Area (re)calculation
		double sceneArea = scene.getArea();
		double sceneLeafArea = scene.getLeafArea();

		double areaSum = 0;
		for (Tree t : scene.getTrees()) {
			HetTree tree = (HetTree) t;

			// updatePedonList () (called before) has created the missing pedons
			// if new trees appeared -> we must find a pedon for each tree
			TreePedon tp = treePedons.get(t.getId());

			double area = tree.getLeafArea() / sceneLeafArea * sceneArea;

			double treeCrownProjection = tree.getCrownProjection();
			if (area > 2 * treeCrownProjection)
				area = 2 * treeCrownProjection;

			// fc+mj+fa-19.11.2019 area must not be 0 (we may divide by it...)
			area = Math.max(area, 0.3);
			
			tp.setPedonArea(area);
			areaSum += area;
		}

		double remainingArea = sceneArea - areaSum;

		if (remainingArea <= 0) {
			System.out.println("HetDiscreteSoil.updatePedons() Found a negative remainingArea: " + remainingArea
					+ " (set to 0 and passed)");
			remainingArea = 0; // fa-25.11.2019: processing of remainingPedon with area = 0 will have to be skipped in subsequent methods
//			remainingArea = 0.3; // fa-22.11.2019: otherwise divisions by zero occur when processing water balance on remaining pedon
		}

		remainingPedon.setPedonArea(remainingArea);

	}

	// @Override
	// public HetElementState getNutrientDeposition() {
	// return nutrientDeposition;
	// }

	@Override
	public HetSoilInterface getCopy() {
		HetDiscreteSoil copy = new HetDiscreteSoil(this);
		return copy;
	}

	// -- fc-13.11.2019 By extending HetSoil we extend Pedon but we do not use
	// the inherited Pedon methods, see treePedon and remainingPedon instance
	// variables -> disable the inherited Pedon methods

	// fc-13.11.2019 In Pedon superclass
	public int getPedonId() {
		throw new IllegalAccessError("HetDiscreteSoil does not allow " + "getPedonId ()"
				+ ", see TreePedon and remainingPedon instance variables");
	}

	// fc-13.11.2019 In Pedon superclass
	public void addHorizon(HetHorizon h) {
		throw new IllegalAccessError("HetDiscreteSoil does not allow " + "addHorizon (HetHorizon h)"
				+ ", see TreePedon and remainingPedon instance variables");
	}

	// fc-13.11.2019 In Pedon superclass
	public List<HetHorizon> getHorizons() {
		throw new IllegalAccessError("HetDiscreteSoil does not allow " + "getHorizons ()"
				+ ", see TreePedon and remainingPedon instance variables");
	}

	// fc-13.11.2019 In Pedon superclass
	public Map<Integer, HetHorizon> getHorizonMap() {
		throw new IllegalAccessError("HetDiscreteSoil does not allow " + "getHorizonMap ()"
				+ ", see TreePedon and remainingPedon instance variables");
	}

	// fc-13.11.2019 In Pedon superclass
	public HetHorizon getHorizon(int id) {
		throw new IllegalAccessError("HetDiscreteSoil does not allow " + "getHorizon (int id)"
				+ ", see TreePedon and remainingPedon instance variables");
	}

	// fc-13.11.2019 In Pedon superclass
	public boolean isLowestHorizon(int hId) {
		throw new IllegalAccessError("HetDiscreteSoil does not allow " + "isLowestHorizon (int hId)"
				+ ", see TreePedon and remainingPedon instance variables");
	}

	// fc-13.11.2019 In Pedon superclass
	public int getMaxHorizonId() {
		throw new IllegalAccessError("HetDiscreteSoil does not allow " + "getMaxHorizonId ()"
				+ ", see TreePedon and remainingPedon instance variables");
	}

	// fc-13.11.2019 In Pedon superclass
	public void setMaxHorizonId(int id) {
		throw new IllegalAccessError("HetDiscreteSoil does not allow " + "setMaxHorizonId (int id)"
				+ ", see TreePedon and remainingPedon instance variables");
	}

}
