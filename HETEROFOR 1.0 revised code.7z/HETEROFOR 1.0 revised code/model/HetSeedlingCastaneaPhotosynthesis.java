
/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import capsis.lib.castanea2018march.FmLeaf;
import capsis.lib.castanea2018march.FmSpecies;
import capsis.lib.samsaralight.SLFoliageStateManager;
import heterofor.model.meteorology.HetMeteoLine;
import heterofor.model.waterbalance.HetHorizonsWaterContentCalculator;
import heterofor.model.waterbalance.HetWaterBalance;
import heterofor.model.waterbalance.pedon.Pedon;

/**
 * Calculate grossPrimaryProduction_kgC and maintenanceLeafRespiration_kgC
 *
 * @author M. Jonard, B. Ryelandt, F. de Coligny - October 2018
 */
public class HetSeedlingCastaneaPhotosynthesis {

	private HetInitialParameters ip;
	private HetScene refScene;
	private HetCell refCell;
	private HetCohortSizeClass refClass;
	private double sla;
	private HetModel model;
	private int newYear;
	private double lai;

	// Returned values
	private double yearlyGPP_kgC;
	private double yearlyLeafRespiration_kgC = 0;

	/**
	 * Constructor
	 */
	public HetSeedlingCastaneaPhotosynthesis(HetInitialParameters ip, HetScene refScene, HetCell refCell,
			HetCohortSizeClass refClass, HetModel model, int newYear, double lai) throws Exception {

		this.ip = ip;
		this.refScene = refScene;
		this.refCell = refCell;
		this.refClass = refClass;
		this.sla = refClass.sla;
		this.model = model;
		this.newYear = newYear;
		this.lai = lai;

	}

	public void run() throws Exception {

		// fc-et-al-20.1.2017

		// Conversion Hetrofor sp -> Castanea sp
		Map<String, Integer> spMap = new HashMap<>();
		spMap.put("quercus", 3);
		spMap.put("fagus", 4);
		spMap.put("carpinus", 4);
		spMap.put("betulus", 3);
		spMap.put("broadleaved", 4);
		spMap.put("coniferous", 8);

		HetCohort cohort = (HetCohort) refClass.getCohort();
		HetSpecies sp = (HetSpecies) cohort.getSpecies();

		int castaneaCode = spMap.get(sp.getName());
		FmSpecies fmSpecies = ip.castaneaSpeciesMap.get(castaneaCode);

		// Absorbed radiation coefficients
		// double classLeafAbsorbedDirectRadiationCoefficient = 0;
		// double classLeafAbsorbedDiffuseRadiationCoefficient = 0;

		// fc+mj+br-4.10.2018 To be updated later
		// // If not fine resolution, yearly level coefficients
		// if (!ip.fineResolutionRadiativeBalanceActivated) {
		//
		// // fc+fa-17.5.2017 Refactored absorbed radiation coefficients
		// // calculation
		// HetAbsorbedRaditionCoefficientsYearlyLevel arcyl = new
		// HetAbsorbedRaditionCoefficientsYearlyLevel(newScene,
		// refTree);
		//
		// classLeafAbsorbedDirectRadiationCoefficient =
		// arcyl.getclassLeafAbsorbedDirectRadiationCoefficient();
		// classLeafAbsorbedDiffuseRadiationCoefficient =
		// arcyl.getclassLeafAbsorbedDiffuseRadiationCoefficient();
		//
		// }

		// Propsun, Propshad
		double classLaiMax = lai;
		double sunlitLai = (1d - Math.exp(-sp.extinctionCoefficient * classLaiMax)) / sp.extinctionCoefficient;
		double shadedLai = classLaiMax - sunlitLai;
		double Propsun = sunlitLai / classLaiMax;
		double Propshad = shadedLai / classLaiMax;

		// NLAI
		double NLAI = sp.getInitialLeafNitrogenConcentration() / sla; // g/m2

		double rb = 25; // hd-20.1.2017

		double g1min = 1;
		double g1max = fmSpecies.g1;

		int istrat = 0; // upper crown part
		FmLeaf fmLeaf = new FmLeaf(istrat, ip);

		// Loop on Heterofor hourly meteo lines
		List<HetMeteoLine> lines = ip.meteorology.getMeteoLines(newYear);

		// fc+mj+br-4.10.2018 To be updated later
		// HetAbsorptionCoefficientEvaluator coefEval = null;

		// if (ip.fineResolutionRadiativeBalanceActivated) {
		//
		// // Calculate for each doy of interest in the year the
		// // classLeafAbsorbedDirectRadiationCoefficient and
		// // classLeafAbsorbedDiffuseRadiationCoefficient per hour
		//
		// coefEval = new HetAbsorptionCoefficientEvaluator(refTree, refScene,
		// refScene.getVegetationPeriodOfNextYear(),
		// refScene.getBeamSetFactory().getAverageRadiation());
		//
		// }

		for (HetMeteoLine line : lines) {

			int doy = line.getDoy();
			// int doy = HetMeteorology.doy(line.year, line.month, line.day);

			// fc+mj+fa-29.6.2017
			double ladProp = 1;
			double greenProp = 1;

			if (ip.phenologyActivated) { // fa-3.7.217: ladProp and greenProp
											// are computed only when phenology
											// mode is activated

				SLFoliageStateManager foliageStateManager = (SLFoliageStateManager) refScene;

				//ladProp = foliageStateManager.getLadProportionOfNextYearAtSpeciesLevel(sp.getValue(), doy); nb-18.12.2019
				ladProp = refScene.getLadProportionAtSpeciesLevel(sp.getValue(), doy, refScene.getPhenologyMapOfNextYear());
				//greenProp = foliageStateManager.getGreenProportionOfNextYearAtSpeciesLevel(sp.getValue(), doy); nb-18.12.2019
				greenProp = refScene.getGreenProportionAtSpeciesLevel(sp.getValue(), doy, refScene.getPhenologyMapOfNextYear());

				// Seedlings have an early budburst date and a late leaf fall. mj+nb-18.12.2019

				// ladProp: proportion of leaf area compared to the level of maximum development.
				if (ladProp > 0) { // t2a_standBudburstStartingDate < doy < t5b_fallingEndingDate
					ladProp = 1.0;
				} else { // doy <= t2a_standBudburstStartingDate or doy >= t5b_fallingEndingDate
					ladProp = 0.0;
				}

				// greenProp: proportion of green leaves compared to the level of maximum development.
				if (greenProp > 0) { // t2a_standBudburstStartingDate < doy < t4b_yellowingEndingDate
					greenProp = 1.0;
				} else { // doy <= t2a_standBudburstStartingDate or doy >= t4b_yellowingEndingDate
					greenProp = 0.0;
				}

			}

			// fc+mj+fa-29.6.2017
			double classLai = classLaiMax * greenProp;

			// Check if we are in vegetation period
			if (!model.isExtendedVegetationPeriod(refScene.getPhenologyMapOfNextYear(), doy) || (ladProp == 0)
					|| (greenProp == 0)) // fa-4.7.2017: // scene
				continue; // next hour in meteo lines

			double hourlyGPP = 0;
			double hourlyLeafRespiration = 0;

			// fc+mj+br-4.10.2018 To be updated later
			// If fine resolution, hourly level coefficients
			// if (ip.fineResolutionRadiativeBalanceActivated) {
			//
			// classLeafAbsorbedDirectRadiationCoefficient =
			// coefEval.getCrownDirectCoefficient(doy, line.hour);
			// classLeafAbsorbedDiffuseRadiationCoefficient =
			// coefEval.getCrownDiffuseCoefficient(doy, line.hour);
			// }

			double T = line.airTemperature;

			// fa-23.6.2017
			double PARsun = 0;
			double PARdif = 0;

			// fc+mj+br-4.10.2018 To be updated later
			// fa-23.6.2017: if-else due to change of the definition of
			// classLeafAbsorbedDirectRadiationCoefficient and
			// classLeafAbsorbedDiffuseRadiationCoefficient in Tag mode
			// (InterceptedDirect/IncidentDirect &
			// InterceptedDiffuse/IncidentDiffuse)
			// -> to be done for Legacy mode LATER
			// if (ip.fineResolutionRadiativeBalanceActivated) {
			// PARsun = line.radiation * (1 - line.diffuseToGlobalRatio) *
			// classLeafAbsorbedDirectRadiationCoefficient
			// / (treeLeafArea_m2 * Propsun) * 4.55 * 0.46;
			// PARdif = line.radiation * line.diffuseToGlobalRatio *
			// classLeafAbsorbedDiffuseRadiationCoefficient
			// / treeLeafArea_m2 * 4.55 * 0.46;
			// } else {

			double classArea_m2 = refClass.getCover() * refCell.getArea();

			// We don't have the information direct / diffuse in the
			// regeneration library
			double classLeafAbsorbedRadiationCoefficient = refClass.getEnergy_MJ()
					/ (refClass.getIncidentEnergy() / refCell.getArea());

//			double classLeafAbsorbedRadiationCoefficient = 1d; // tmp

			// fc+mj-10.3.2017
			PARsun = line.radiation * (1 - line.diffuseToGlobalRatio) * classLeafAbsorbedRadiationCoefficient
					/ (classLai * classArea_m2 * Propsun) * 4.55 * 0.46;
			PARdif = line.radiation * line.diffuseToGlobalRatio * classLeafAbsorbedRadiationCoefficient
					/ (classLai * classArea_m2) * 4.55 * 0.46;

			// }

			// Effect of water potential on respiration inactive in heterofor

			double potsoil = 0;

			if (line.radiation <= 0) {
				// Night
				hourlyLeafRespiration = fmLeaf.getLeafRespiration(ip, fmSpecies, NLAI, T, PARdif, potsoil) * 3600; // micro
				// mol/m2/h

			} else {
				// Day

				double RH = line.relativeHumidity;

				// fa-25.11.2019
//				String key = "" + line.year + "_" + line.month + "_" + line.day + "_" + line.hour;
				String key;
				if (!refScene.getSoil().isDiscreteSoil())
					key = "" + line.year + "_" + line.month + "_" + line.day + "_" + line.hour;
				else // waterBalanceMap already integrated at daily time step
					key = "" + line.year + "_" + line.month + "_" + line.day + "_";
				
				HetWaterBalance wb = refClass.waterBalanceMap.get(key);
				
				// fa-21.11.2019: for consistency with HetCastaneaPhotosynthesis
				Pedon pedonSpecimen = refScene.getSoil().getPedonSpecimen(); // the use of getPedonSpecimen() here is OK as the methods of hwcCalculator used below only request horizon properties identical among all pedons (eg thickness, coarse fraction, ...)
				HetHorizonsWaterContentCalculator hwcCalculator = new HetHorizonsWaterContentCalculator(refScene,
						pedonSpecimen, pedonSpecimen);
				double weightedMeanPrevWaterPotential = hwcCalculator.calculateWeightedMeanWaterPotential(pedonSpecimen.getHorizonMap(), wb.horizonWaterContent);
				double soilPf = Math.log10(weightedMeanPrevWaterPotential);
				double stomatalControl = sp.swcModifier.result(soilPf);
				
				// fa-21.11.2019: commented
//				// double stomatalControl = 1;
//				// mj+fa-14.12.2017: for correspondence with transpiration
//				double rewSensitivity_oak = -11.14;
//				double rewSensitivity_beech = -2.15;
//				double stomatalControl = 1 - Math.exp(rewSensitivity_beech * (wb.relativeExtractableWater));
//				if (sp.getName().equals("quercus"))
//					stomatalControl = 1 - Math.exp(rewSensitivity_oak * (wb.relativeExtractableWater));
//				stomatalControl = Math.max(stomatalControl, 0);

				// TO BE REVIEWED when waterBalance is checked
				// fc+mj-10.3.2017 checked ;-)
				// mj+fa-14.12.2017: commented
				// if (wb.relativeExtractableWater < 0.4)
				// stomatalControl = wb.relativeExtractableWater / 0.4;

				double g1 = (g1max - g1min) * stomatalControl + g1min;
				// // g1 = g1 * 17d / refTree.getHlce(); // mj+fa-06.10.2017
				// g1 = g1 * 12d / refTree.getHlce(); // mj+fa-23.10.2017 (12 is
				// // the estimated Hlce for
				// // Hesse)

				double Nc = fmSpecies.NC;

				double photoEvergreenCorrection = 1;

				// if (doy == 200 && line.hour == 12) {
				// System.out.println("HetTreeForwardGrower breakpoint...");
				// }

				// Case of a variable atmospheric CO2 concentration over time.
				// nb-15.03.2018
				if (ip.variableAtmCO2ConcentrationOverTime) {
					if (ip.yearAtmCO2ConcentrationMap.get(newYear) == null) {
						throw new Exception("Atmospheric CO2 concentration is missing for year: " + newYear);
					} else {
						ip.Ca = ip.yearAtmCO2ConcentrationMap.get(newYear);
					}
				}

				fmLeaf.calculateFluxes(ip, fmSpecies, NLAI, T, RH, PARsun, PARdif, Propsun, Propshad, rb, g1,
						stomatalControl, Nc, photoEvergreenCorrection, potsoil);
				hourlyGPP = fmLeaf.getGrossPhotosynthesis() * 3600; // micro
																	// mol/m2/h
				hourlyLeafRespiration = fmLeaf.getRespiration() * 3600; // micro
																		// mol/m2/h

				// if (Double.isNaN(hourlyGPP))
				// System.out.println("HetTreeForwardGrower : NaN(hourlyGPP)");

			}

			// fc+mj-10.3.2017, SHOULD be divided by 1000 ?
			// yearlyGPP_kgC += hourlyGPP * 12 * 1000 / 1E6 *
			// treeLeafArea_m2;
			// yearlyLeafRespiration_kgC += hourlyLeafRespiration * 12 * 1000d /
			// 1E6 * treeLeafArea_m2;
			yearlyGPP_kgC += hourlyGPP * 12 / 1000d / 1E6 * classLai * classArea_m2;
			yearlyLeafRespiration_kgC += hourlyLeafRespiration * 12 / 1000d / 1E6 * classLai * classArea_m2;

//			System.out.println("HetSeedlingCastaneaPhotosynthesis: hourlyGPP=" + hourlyGPP + ", NLAI= " + NLAI + ", PARsun= " + PARsun + ", PARdif= " + PARdif + ", Propsun= " + Propsun + ", Propshad= " + Propshad + ", classLai= " + classLai + ", classArea_m2= " + classArea_m2 + ", yearlyGPP_kgC= " + yearlyGPP_kgC);

		}

		// // fa-19.06.2017: TRACE
		// out.close();

		// if (Double.isNaN(yearlyGPP_kgC))
		// System.out.println("HetTreeForwardGrower : NaN(yearlyGPP_kgC)");

	}

	public double getYearlyGPP_kgC() {
		return yearlyGPP_kgC;
	}

	public double getYearlyLeafRespiration_kgC() {
		return yearlyLeafRespiration_kgC;
	}

}
