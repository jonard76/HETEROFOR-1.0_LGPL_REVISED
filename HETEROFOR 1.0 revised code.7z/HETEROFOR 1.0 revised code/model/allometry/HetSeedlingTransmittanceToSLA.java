package heterofor.model.allometry;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A function computing seedling SLA from transmittance
 * Return the SLA (m2/kgOM)
 * 
 * @author B. Ryelandt - April 2019
 */
public class HetSeedlingTransmittanceToSLA extends HetSimpleFunction {

	private double a;
	private double b;
	private double c;
	private double d;

	/**
	 * Constructor.
	 */
	public HetSeedlingTransmittanceToSLA(String str) throws Exception {

		if (!str.startsWith("seedlingTransmittanceToSLA(")) {
			throw new Exception(
					"HetSeedlingTransmittanceToSLA error, string should start with \"seedlingTransmittanceToSLA(\": "
							+ str);
		}
		String s = str.replace("seedlingTransmittanceToSLA(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		a = Check.doubleValue(st.nextToken());
		b = Check.doubleValue(st.nextToken());
		c = Check.doubleValue(st.nextToken());
		d = Check.doubleValue(st.nextToken());
	}

	/**
	 * Returns HetSeedlingTransmittanceToSLA.
	 */
	public double result(double transmittance) {

		return a * Math.exp(-b*transmittance) + c * Math.exp(-d*transmittance);

	}

	public String toString() {
		return "seedlingTransmittanceToSLA(" + a + ")";
	}

}    
