/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.allometry;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A function computing sapwood area based on diameter.
 * Units for sapwood area: cm�					// fa-02.03.2017
 *
 * @author M. Jonard, L. de Wergifosse, F. de Coligny - October 2016
 */
public class HetSapwoodArea extends HetSimpleFunction {

	private double a;
	private double b;
	private double c;

	/**
	 * Constructor.
	 */
	public HetSapwoodArea(String str) throws Exception { // e.g.
																	// sapwoodArea(0.08;-0.26;0.32478)
		if (!str.startsWith("sapwoodArea(")) {
			throw new Exception(
					"HetSapwoodArea error, string should start with \"sapwoodArea(\": " + str);
		}
		String s = str.replace("sapwoodArea(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		a = Check.doubleValue(st.nextToken());
		b = Check.doubleValue(st.nextToken());
		c = Check.doubleValue(st.nextToken());

	}


	/**
	 * diameter (cm)
	 */
	@Override
	public double result(double diameter) {

		double sa = a + b * diameter + c * diameter * diameter;

		double minSa = diameter / 2d * diameter / 2d * Math.PI - (diameter - 3d) / 2d * (diameter - 3d) / 2d * Math.PI;
		double maxSa = diameter / 2d * diameter / 2d * Math.PI;
		if (diameter < 3)
			minSa = maxSa;

		sa = Math.max(sa, minSa);
		sa = Math.min(sa, maxSa);

		return sa;	// fa-02.03.2017 cm2

	}

	public String toString() {
		return "sapwoodArea(" + a + ";" + b + ";" + c + ")";
	}



}
