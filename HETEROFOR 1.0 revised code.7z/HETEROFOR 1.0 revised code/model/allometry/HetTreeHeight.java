package heterofor.model.allometry;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A function computing tree height based on diameter.
 *
 * @author M. Jonard, B. Ryelandt, F. de Coligny - October 2018
 */
public class HetTreeHeight extends HetSimpleFunction {

	private double a;
	private double b;
	private double c;
	private double d;

	/**
	 * Constructor.
	 */
	public HetTreeHeight(String str) throws Exception { // e.g.
														// treeHeight(0.08;-0.26;0.32478)
		if (!str.startsWith("treeHeight(")) {
			throw new Exception("HetTreeHeight error, string should start with \"treeHeight(\": " + str);
		}
		String s = str.replace("treeHeight(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		a = Check.doubleValue(st.nextToken());
		b = Check.doubleValue(st.nextToken());
		c = Check.doubleValue(st.nextToken());
		d = Check.doubleValue(st.nextToken());

	}

	@Override
	public double result(double diameter_cm) {

		double girth = diameter_cm * Math.PI;

		double logGirth = Math.log(girth);
		double height_m = a + b * logGirth + c * logGirth * logGirth + d * logGirth * logGirth * logGirth;

		return height_m;

	}

	public String toString() {
		return "treeHeight(" + a + ";" + b + ";" + c + ";" + d + ")";
	}

}
