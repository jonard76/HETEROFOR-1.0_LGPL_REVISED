package heterofor.model.allometry;

import java.io.Serializable;
import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A function computing the vapor pressure deficit modifier for stomatal conductance from vapor pressure deficit
 * Return the vapor pressure deficit modifier (-)
 * 
 * @author F. Andr� June 2019
 */
public class HetVpdModifier implements Serializable {

	public double a;

	/**
	 * Constructor.
	 */
	public HetVpdModifier(String str) throws Exception {

		// e.g. vpdModifier(0.123)

		if (!str.startsWith("vpdModifier(")) {
			throw new Exception(
					"HetVpdModifier error, string should start with \"vpdModifier(\": "
							+ str);
		}
		String s = str.replace("vpdModifier(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		a = Check.doubleValue(st.nextToken());
		
	}

	/**
	 * Returns radiationModifier.
	 */
	public double result(double vaporPressureDeficit) {

		return 1 - a * Math.log(vaporPressureDeficit);

	}
	
	public String toString() {
		return "vpdModifier(" + a + ")";
	}

} 
