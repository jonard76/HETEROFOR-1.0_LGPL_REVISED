/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.allometry;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A function computing the fraction of small root biomass based on total
 * root biomass.
 *
 * @author F. de Coligny - March 2016
 */
public class HetSmallRootFracFunction extends HetSimpleFunction {

	private double a;
	private double b;
	private double c;

	/**
	 * Constructor.
	 */
	public HetSmallRootFracFunction(String str) throws Exception { // e.g.
																	// smallRootFracFunction(0.08;-0.26;0.32478)
		if (!str.startsWith("smallRootFracFunction(")) {
			throw new Exception(
					"HetSmallRootFracFunction error, string should start with \"smallRootFracFunction(\": " + str);
		}
		String s = str.replace("smallRootFracFunction(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		a = Check.doubleValue(st.nextToken());
		b = Check.doubleValue(st.nextToken());
		c = Check.doubleValue(st.nextToken());

	}


	@Override
	public double result(double rootBiomass) {

		return Math.min(a + Math.exp (b * Math.pow (rootBiomass, c)),1);// Added by MJ (26/04/2016)

	}

	public String toString() {
		return "smallRootFracFunction(" + a + ";" + b + ";" + c + ")";
	}



}
